/*
** 2001-09-15
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This header file defines the interface that the SQLite library
** presents to client programs.  If a C-function, structure, datatype,
** or constant definition does not appear in this file, then it is
** not a published API of SQLite, is subject to change without
** notice, and should not be referenced by programs that use SQLite.
**
** Some of the definitions that are in this file are marked as
** "experimental".  Experimental interfaces are normally new
** features recently added to SQLite.  We do not anticipate changes
** to experimental interfaces but reserve the right to make minor changes
** if experience from use "in the wild" suggest such changes are prudent.
**
** The official C-language API documentation for SQLite is derived
** from comments in this file.  This file is the authoritative source
** on how SQLite interfaces are supposed to operate.
**
** The name of this file under configuration management is "sqlite.h.in".
** The makefile makes some minor changes to this file (such as inserting
** the version number) and changes its name to "sqlite3.h" as
** part of the build process.
*/
#ifndef SQLITE3_H
#define SQLITE3_H
#include <stdarg.h>     /* Needed for the definition of va_list */

/*
** Make sure we can call this stuff from C++.
*/
#ifdef __cplusplus
extern "C" {
#endif


/*
** Facilitate override of interface linkage and calling conventions.
** Be aware that these macros may not be used within this particular
** translation of the amalgamation and its associated header file.
**
** The SQLITE_EXTERN and SQLITE_API macros are used to instruct the
** compiler that the target identifier should have external linkage.
**
** The SQLITE_CDECL macro is used to set the calling convention for
** public functions that accept a variable number of arguments.
**
** The SQLITE_APICALL macro is used to set the calling convention for
** public functions that accept a fixed number of arguments.
**
** The SQLITE_STDCALL macro is no longer used and is now deprecated.
**
** The SQLITE_CALLBACK macro is used to set the calling convention for
** function pointers.
**
** The SQLITE_SYSAPI macro is used to set the calling convention for
** functions provided by the operating system.
**
** Currently, the SQLITE_CDECL, SQLITE_APICALL, SQLITE_CALLBACK, and
** SQLITE_SYSAPI macros are used only when building for environments
** that require non-default calling conventions.
*/
#ifndef SQLITE_EXTERN
# define SQLITE_EXTERN extern
#endif
#ifndef SQLITE_API
# define SQLITE_API
#endif
#ifndef SQLITE_CDECL
# define SQLITE_CDECL
#endif
#ifndef SQLITE_APICALL
# define SQLITE_APICALL
#endif
#ifndef SQLITE_STDCALL
# define SQLITE_STDCALL SQLITE_APICALL
#endif
#ifndef SQLITE_CALLBACK
# define SQLITE_CALLBACK
#endif
#ifndef SQLITE_SYSAPI
# define SQLITE_SYSAPI
#endif

/*
** These no-op macros are used in front of interfaces to mark those
** interfaces as either deprecated or experimental.  New applications
** should not use deprecated interfaces - they are supported for backwards
** compatibility only.  Application writers should be aware that
** experimental interfaces are subject to change in point releases.
**
** These macros used to resolve to various kinds of compiler magic that
** would generate warning messages when they were used.  But that
** compiler magic ended up generating such a flurry of bug reports
** that we have taken it all out and gone back to using simple
** noop macros.
*/
#define SQLITE_DEPRECATED
#define SQLITE_EXPERIMENTAL

/*
** Ensure these symbols were not defined by some previous header file.
*/
#ifdef SQLITE_VERSION
# undef SQLITE_VERSION
#endif
#ifdef SQLITE_VERSION_NUMBER
# undef SQLITE_VERSION_NUMBER
#endif

/*
** CAPI3REF: Compile-Time Library Version Numbers
**
** ^(The [SQLITE_VERSION] C preprocessor macro in the sqlite3.h header
** evaluates to a string literal that is the SQLite version in the
** format "X.Y.Z" where X is the major version number (always 3 for
** SQLite3) and Y is the minor version number and Z is the release number.)^
** ^(The [SQLITE_VERSION_NUMBER] C preprocessor macro resolves to an integer
** with the value (X*1000000 + Y*1000 + Z) where X, Y, and Z are the same
** numbers used in [SQLITE_VERSION].)^
** The SQLITE_VERSION_NUMBER for any given release of SQLite will also
** be larger than the release from which it is derived.  Either Y will
** be held constant and Z will be incremented or else Y will be incremented
** and Z will be reset to zero.
**
** Since [version 3.6.18] ([dateof:3.6.18]),
** SQLite source code has been stored in the
** <a href="http://fossil-scm.org/">Fossil configuration management
** system</a>.  ^The SQLITE_SOURCE_ID macro evaluates to
** a string which identifies a particular check-in of SQLite
** within its configuration management system.  ^The SQLITE_SOURCE_ID
** string contains the date and time of the check-in (UTC) and a SHA1
** or SHA3-256 hash of the entire source tree.  If the source code has
** been edited in any way since it was last checked in, then the last
** four hexadecimal digits of the hash may be modified.
**
** See also: [sqlite3_libversion()],
** [sqlite3_libversion_number()], [sqlite3_sourceid()],
** [sqlite_version()] and [sqlite_source_id()].
*/
#define SQLITE_VERSION        "3.51.1"
#define SQLITE_VERSION_NUMBER 3051001
#define SQLITE_SOURCE_ID      "2025-11-28 17:28:25 281fc0e9afc38674b9b0991943b9e9d1e64c6cbdb133d35f6f5c87ff6af38a88"
#define SQLITE_SCM_BRANCH     "branch-3.51"
#define SQLITE_SCM_TAGS       "release version-3.51.1"
#define SQLITE_SCM_DATETIME   "2025-11-28T17:28:25.933Z"

/*
** CAPI3REF: Run-Time Library Version Numbers
** KEYWORDS: sqlite3_version sqlite3_sourceid
**
** These interfaces provide the same information as the [SQLITE_VERSION],
** [SQLITE_VERSION_NUMBER], and [SQLITE_SOURCE_ID] C preprocessor macros
** but are associated with the library instead of the header file.  ^(Cautious
** programmers might include assert() statements in their application to
** verify that values returned by these interfaces match the macros in
** the header, and thus ensure that the application is
** compiled with matching library and header files.
**
** <blockquote><pre>
** assert( sqlite3_libversion_number()==SQLITE_VERSION_NUMBER );
** assert( strncmp(sqlite3_sourceid(),SQLITE_SOURCE_ID,80)==0 );
** assert( strcmp(sqlite3_libversion(),SQLITE_VERSION)==0 );
** </pre></blockquote>)^
**
** ^The sqlite3_version[] string constant contains the text of the
** [SQLITE_VERSION] macro.  ^The sqlite3_libversion() function returns a
** pointer to the sqlite3_version[] string constant.  The sqlite3_libversion()
** function is provided for use in DLLs since DLL users usually do not have
** direct access to string constants within the DLL.  ^The
** sqlite3_libversion_number() function returns an integer equal to
** [SQLITE_VERSION_NUMBER].  ^(The sqlite3_sourceid() function returns
** a pointer to a string constant whose value is the same as the
** [SQLITE_SOURCE_ID] C preprocessor macro.  Except if SQLite is built
** using an edited copy of [the amalgamation], then the last four characters
** of the hash might be different from [SQLITE_SOURCE_ID].)^
**
** See also: [sqlite_version()] and [sqlite_source_id()].
*/
SQLITE_API SQLITE_EXTERN const char sqlite3_version[];
SQLITE_API const char *sqlite3_libversion(void);
SQLITE_API const char *sqlite3_sourceid(void);
SQLITE_API int sqlite3_libversion_number(void);

/*
** CAPI3REF: Run-Time Library Compilation Options Diagnostics
**
** ^The sqlite3_compileoption_used() function returns 0 or 1
** indicating whether the specified option was defined at
** compile time.  ^The SQLITE_ prefix may be omitted from the
** option name passed to sqlite3_compileoption_used().
**
** ^The sqlite3_compileoption_get() function allows iterating
** over the list of options that were defined at compile time by
** returning the N-th compile time option string.  ^If N is out of range,
** sqlite3_compileoption_get() returns a NULL pointer.  ^The SQLITE_
** prefix is omitted from any strings returned by
** sqlite3_compileoption_get().
**
** ^Support for the diagnostic functions sqlite3_compileoption_used()
** and sqlite3_compileoption_get() may be omitted by specifying the
** [SQLITE_OMIT_COMPILEOPTION_DIAGS] option at compile time.
**
** See also: SQL functions [sqlite_compileoption_used()] and
** [sqlite_compileoption_get()] and the [compile_options pragma].
*/
#ifndef SQLITE_OMIT_COMPILEOPTION_DIAGS
SQLITE_API int sqlite3_compileoption_used(const char *zOptName);
SQLITE_API const char *sqlite3_compileoption_get(int N);
#else
# define sqlite3_compileoption_used(X) 0
# define sqlite3_compileoption_get(X)  ((void*)0)
#endif

/*
** CAPI3REF: Test To See If The Library Is Threadsafe
**
** ^The sqlite3_threadsafe() function returns zero if and only if
** SQLite was compiled with mutexing code omitted due to the
** [SQLITE_THREADSAFE] compile-time option being set to 0.
**
** SQLite can be compiled with or without mutexes.  When
** the [SQLITE_THREADSAFE] C preprocessor macro is 1 or 2, mutexes
** are enabled and SQLite is threadsafe.  When the
** [SQLITE_THREADSAFE] macro is 0,
** the mutexes are omitted.  Without the mutexes, it is not safe
** to use SQLite concurrently from more than one thread.
**
** Enabling mutexes incurs a measurable performance penalty.
** So if speed is of utmost importance, it makes sense to disable
** the mutexes.  But for maximum safety, mutexes should be enabled.
** ^The default behavior is for mutexes to be enabled.
**
** This interface can be used by an application to make sure that the
** version of SQLite that it is linking against was compiled with
** the desired setting of the [SQLITE_THREADSAFE] macro.
**
** This interface only reports on the compile-time mutex setting
** of the [SQLITE_THREADSAFE] flag.  If SQLite is compiled with
** SQLITE_THREADSAFE=1 or =2 then mutexes are enabled by default but
** can be fully or partially disabled using a call to [sqlite3_config()]
** with the verbs [SQLITE_CONFIG_SINGLETHREAD], [SQLITE_CONFIG_MULTITHREAD],
** or [SQLITE_CONFIG_SERIALIZED].  ^(The return value of the
** sqlite3_threadsafe() function shows only the compile-time setting of
** thread safety, not any run-time changes to that setting made by
** sqlite3_config(). In other words, the return value from sqlite3_threadsafe()
** is unchanged by calls to sqlite3_config().)^
**
** See the [threading mode] documentation for additional information.
*/
SQLITE_API int sqlite3_threadsafe(void);

/*
** CAPI3REF: Database Connection Handle
** KEYWORDS: {database connection} {database connections}
**
** Each open SQLite database is represented by a pointer to an instance of
** the opaque structure named "sqlite3".  It is useful to think of an sqlite3
** pointer as an object.  The [sqlite3_open()], [sqlite3_open16()], and
** [sqlite3_open_v2()] interfaces are its constructors, and [sqlite3_close()]
** and [sqlite3_close_v2()] are its destructors.  There are many other
** interfaces (such as
** [sqlite3_prepare_v2()], [sqlite3_create_function()], and
** [sqlite3_busy_timeout()] to name but three) that are methods on an
** sqlite3 object.
*/
typedef struct sqlite3 sqlite3;

/*
** CAPI3REF: 64-Bit Integer Types
** KEYWORDS: sqlite_int64 sqlite_uint64
**
** Because there is no cross-platform way to specify 64-bit integer types
** SQLite includes typedefs for 64-bit signed and unsigned integers.
**
** The sqlite3_int64 and sqlite3_uint64 are the preferred type definitions.
** The sqlite_int64 and sqlite_uint64 types are supported for backwards
** compatibility only.
**
** ^The sqlite3_int64 and sqlite_int64 types can store integer values
** between -9223372036854775808 and +9223372036854775807 inclusive.  ^The
** sqlite3_uint64 and sqlite_uint64 types can store integer values
** between 0 and +18446744073709551615 inclusive.
*/
#ifdef SQLITE_INT64_TYPE
  typedef SQLITE_INT64_TYPE sqlite_int64;
# ifdef SQLITE_UINT64_TYPE
    typedef SQLITE_UINT64_TYPE sqlite_uint64;
# else
    typedef unsigned SQLITE_INT64_TYPE sqlite_uint64;
# endif
#elif defined(_MSC_VER) || defined(__BORLANDC__)
  typedef __int64 sqlite_int64;
  typedef unsigned __int64 sqlite_uint64;
#else
  typedef long long int sqlite_int64;
  typedef unsigned long long int sqlite_uint64;
#endif
typedef sqlite_int64 sqlite3_int64;
typedef sqlite_uint64 sqlite3_uint64;

/*
** If compiling for a processor that lacks floating point support,
** substitute integer for floating-point.
*/
#ifdef SQLITE_OMIT_FLOATING_POINT
# define double sqlite3_int64
#endif

/*
** CAPI3REF: Closing A Database Connection
** DESTRUCTOR: sqlite3
**
** ^The sqlite3_close() and sqlite3_close_v2() routines are destructors
** for the [sqlite3] object.
** ^Calls to sqlite3_close() and sqlite3_close_v2() return [SQLITE_OK] if
** the [sqlite3] object is successfully destroyed and all associated
** resources are deallocated.
**
** Ideally, applications should [sqlite3_finalize | finalize] all
** [prepared statements], [sqlite3_blob_close | close] all [BLOB handles], and
** [sqlite3_backup_finish | finish] all [sqlite3_backup] objects associated
** with the [sqlite3] object prior to attempting to close the object.
** ^If the database connection is associated with unfinalized prepared
** statements, BLOB handlers, and/or unfinished sqlite3_backup objects then
** sqlite3_close() will leave the database connection open and return
** [SQLITE_BUSY]. ^If sqlite3_close_v2() is called with unfinalized prepared
** statements, unclosed BLOB handlers, and/or unfinished sqlite3_backups,
** it returns [SQLITE_OK] regardless, but instead of deallocating the database
** connection immediately, it marks the database connection as an unusable
** "zombie" and makes arrangements to automatically deallocate the database
** connection after all prepared statements are finalized, all BLOB handles
** are closed, and all backups have finished. The sqlite3_close_v2() interface
** is intended for use with host languages that are garbage collected, and
** where the order in which destructors are called is arbitrary.
**
** ^If an [sqlite3] object is destroyed while a transaction is open,
** the transaction is automatically rolled back.
**
** The C parameter to [sqlite3_close(C)] and [sqlite3_close_v2(C)]
** must be either a NULL
** pointer or an [sqlite3] object pointer obtained
** from [sqlite3_open()], [sqlite3_open16()], or
** [sqlite3_open_v2()], and not previously closed.
** ^Calling sqlite3_close() or sqlite3_close_v2() with a NULL pointer
** argument is a harmless no-op.
*/
SQLITE_API int sqlite3_close(sqlite3*);
SQLITE_API int sqlite3_close_v2(sqlite3*);

/*
** The type for a callback function.
** This is legacy and deprecated.  It is included for historical
** compatibility and is not documented.
*/
typedef int (*sqlite3_callback)(void*,int,char**, char**);

/*
** CAPI3REF: One-Step Query Execution Interface
** METHOD: sqlite3
**
** The sqlite3_exec() interface is a convenience wrapper around
** [sqlite3_prepare_v2()], [sqlite3_step()], and [sqlite3_finalize()],
** that allows an application to run multiple statements of SQL
** without having to use a lot of C code.
**
** ^The sqlite3_exec() interface runs zero or more UTF-8 encoded,
** semicolon-separated SQL statements passed into its 2nd argument,
** in the context of the [database connection] passed in as its 1st
** argument.  ^If the callback function of the 3rd argument to
** sqlite3_exec() is not NULL, then it is invoked for each result row
** coming out of the evaluated SQL statements.  ^The 4th argument to
** sqlite3_exec() is relayed through to the 1st argument of each
** callback invocation.  ^If the callback pointer to sqlite3_exec()
** is NULL, then no callback is ever invoked and result rows are
** ignored.
**
** ^If an error occurs while evaluating the SQL statements passed into
** sqlite3_exec(), then execution of the current statement stops and
** subsequent statements are skipped.  ^If the 5th parameter to sqlite3_exec()
** is not NULL then any error message is written into memory obtained
** from [sqlite3_malloc()] and passed back through the 5th parameter.
** To avoid memory leaks, the application should invoke [sqlite3_free()]
** on error message strings returned through the 5th parameter of
** sqlite3_exec() after the error message string is no longer needed.
** ^If the 5th parameter to sqlite3_exec() is not NULL and no errors
** occur, then sqlite3_exec() sets the pointer in its 5th parameter to
** NULL before returning.
**
** ^If an sqlite3_exec() callback returns non-zero, the sqlite3_exec()
** routine returns SQLITE_ABORT without invoking the callback again and
** without running any subsequent SQL statements.
**
** ^The 2nd argument to the sqlite3_exec() callback function is the
** number of columns in the result.  ^The 3rd argument to the sqlite3_exec()
** callback is an array of pointers to strings obtained as if from
** [sqlite3_column_text()], one for each column.  ^If an element of a
** result row is NULL then the corresponding string pointer for the
** sqlite3_exec() callback is a NULL pointer.  ^The 4th argument to the
** sqlite3_exec() callback is an array of pointers to strings where each
** entry represents the name of a corresponding result column as obtained
** from [sqlite3_column_name()].
**
** ^If the 2nd parameter to sqlite3_exec() is a NULL pointer, a pointer
** to an empty string, or a pointer that contains only whitespace and/or
** SQL comments, then no SQL statements are evaluated and the database
** is not changed.
**
** Restrictions:
**
** <ul>
** <li> The application must ensure that the 1st parameter to sqlite3_exec()
**      is a valid and open [database connection].
** <li> The application must not close the [database connection] specified by
**      the 1st parameter to sqlite3_exec() while sqlite3_exec() is running.
** <li> The application must not modify the SQL statement text passed into
**      the 2nd parameter of sqlite3_exec() while sqlite3_exec() is running.
** <li> The application must not dereference the arrays or string pointers
**       passed as the 3rd and 4th callback parameters after it returns.
** </ul>
*/
SQLITE_API int sqlite3_exec(
  sqlite3*,                                  /* An open database */
  const char *sql,                           /* SQL to be evaluated */
  int (*callback)(void*,int,char**,char**),  /* Callback function */
  void *,                                    /* 1st argument to callback */
  char **errmsg                              /* Error msg written here */
);

/*
** CAPI3REF: Result Codes
** KEYWORDS: {result code definitions}
**
** Many SQLite functions return an integer result code from the set shown
** here in order to indicate success or failure.
**
** New error codes may be added in future versions of SQLite.
**
** See also: [extended result code definitions]
*/
#define SQLITE_OK           0   /* Successful result */
/* beginning-of-error-codes */
#define SQLITE_ERROR        1   /* Generic error */
#define SQLITE_INTERNAL     2   /* Internal logic error in SQLite */
#define SQLITE_PERM         3   /* Access permission denied */
#define SQLITE_ABORT        4   /* Callback routine requested an abort */
#define SQLITE_BUSY         5   /* The database file is locked */
#define SQLITE_LOCKED       6   /* A table in the database is locked */
#define SQLITE_NOMEM        7   /* A malloc() failed */
#define SQLITE_READONLY     8   /* Attempt to write a readonly database */
#define SQLITE_INTERRUPT    9   /* Operation terminated by sqlite3_interrupt()*/
#define SQLITE_IOERR       10   /* Some kind of disk I/O error occurred */
#define SQLITE_CORRUPT     11   /* The database disk image is malformed */
#define SQLITE_NOTFOUND    12   /* Unknown opcode in sqlite3_file_control() */
#define SQLITE_FULL        13   /* Insertion failed because database is full */
#define SQLITE_CANTOPEN    14   /* Unable to open the database file */
#define SQLITE_PROTOCOL    15   /* Database lock protocol error */
#define SQLITE_EMPTY       16   /* Internal use only */
#define SQLITE_SCHEMA      17   /* The database schema changed */
#define SQLITE_TOOBIG      18   /* String or BLOB exceeds size limit */
#define SQLITE_CONSTRAINT  19   /* Abort due to constraint violation */
#define SQLITE_MISMATCH    20   /* Data type mismatch */
#define SQLITE_MISUSE      21   /* Library used incorrectly */
#define SQLITE_NOLFS       22   /* Uses OS features not supported on host */
#define SQLITE_AUTH        23   /* Authorization denied */
#define SQLITE_FORMAT      24   /* Not used */
#define SQLITE_RANGE       25   /* 2nd parameter to sqlite3_bind out of range */
#define SQLITE_NOTADB      26   /* File opened that is not a database file */
#define SQLITE_NOTICE      27   /* Notifications from sqlite3_log() */
#define SQLITE_WARNING     28   /* Warnings from sqlite3_log() */
#define SQLITE_ROW         100  /* sqlite3_step() has another row ready */
#define SQLITE_DONE        101  /* sqlite3_step() has finished executing */
/* end-of-error-codes */

/*
** CAPI3REF: Extended Result Codes
** KEYWORDS: {extended result code definitions}
**
** In its default configuration, SQLite API routines return one of 30 integer
** [result codes].  However, experience has shown that many of
** these result codes are too coarse-grained.  They do not provide as
** much information about problems as programmers might like.  In an effort to
** address this, newer versions of SQLite (version 3.3.8 [dateof:3.3.8]
** and later) include
** support for additional result codes that provide more detailed information
** about errors. These [extended result codes] are enabled or disabled
** on a per database connection basis using the
** [sqlite3_extended_result_codes()] API.  Or, the extended code for
** the most recent error can be obtained using
** [sqlite3_extended_errcode()].
*/
#define SQLITE_ERROR_MISSING_COLLSEQ   (SQLITE_ERROR | (1<<8))
#define SQLITE_ERROR_RETRY             (SQLITE_ERROR | (2<<8))
#define SQLITE_ERROR_SNAPSHOT          (SQLITE_ERROR | (3<<8))
#define SQLITE_ERROR_RESERVESIZE       (SQLITE_ERROR | (4<<8))
#define SQLITE_ERROR_KEY               (SQLITE_ERROR | (5<<8))
#define SQLITE_ERROR_UNABLE            (SQLITE_ERROR | (6<<8))
#define SQLITE_IOERR_READ              (SQLITE_IOERR | (1<<8))
#define SQLITE_IOERR_SHORT_READ        (SQLITE_IOERR | (2<<8))
#define SQLITE_IOERR_WRITE             (SQLITE_IOERR | (3<<8))
#define SQLITE_IOERR_FSYNC             (SQLITE_IOERR | (4<<8))
#define SQLITE_IOERR_DIR_FSYNC         (SQLITE_IOERR | (5<<8))
#define SQLITE_IOERR_TRUNCATE          (SQLITE_IOERR | (6<<8))
#define SQLITE_IOERR_FSTAT             (SQLITE_IOERR | (7<<8))
#define SQLITE_IOERR_UNLOCK            (SQLITE_IOERR | (8<<8))
#define SQLITE_IOERR_RDLOCK            (SQLITE_IOERR | (9<<8))
#define SQLITE_IOERR_DELETE            (SQLITE_IOERR | (10<<8))
#define SQLITE_IOERR_BLOCKED           (SQLITE_IOERR | (11<<8))
#define SQLITE_IOERR_NOMEM             (SQLITE_IOERR | (12<<8))
#define SQLITE_IOERR_ACCESS            (SQLITE_IOERR | (13<<8))
#define SQLITE_IOERR_CHECKRESERVEDLOCK (SQLITE_IOERR | (14<<8))
#define SQLITE_IOERR_LOCK              (SQLITE_IOERR | (15<<8))
#define SQLITE_IOERR_CLOSE             (SQLITE_IOERR | (16<<8))
#define SQLITE_IOERR_DIR_CLOSE         (SQLITE_IOERR | (17<<8))
#define SQLITE_IOERR_SHMOPEN           (SQLITE_IOERR | (18<<8))
#define SQLITE_IOERR_SHMSIZE           (SQLITE_IOERR | (19<<8))
#define SQLITE_IOERR_SHMLOCK           (SQLITE_IOERR | (20<<8))
#define SQLITE_IOERR_SHMMAP            (SQLITE_IOERR | (21<<8))
#define SQLITE_IOERR_SEEK              (SQLITE_IOERR | (22<<8))
#define SQLITE_IOERR_DELETE_NOENT      (SQLITE_IOERR | (23<<8))
#define SQLITE_IOERR_MMAP              (SQLITE_IOERR | (24<<8))
#define SQLITE_IOERR_GETTEMPPATH       (SQLITE_IOERR | (25<<8))
#define SQLITE_IOERR_CONVPATH          (SQLITE_IOERR | (26<<8))
#define SQLITE_IOERR_VNODE             (SQLITE_IOERR | (27<<8))
#define SQLITE_IOERR_AUTH              (SQLITE_IOERR | (28<<8))
#define SQLITE_IOERR_BEGIN_ATOMIC      (SQLITE_IOERR | (29<<8))
#define SQLITE_IOERR_COMMIT_ATOMIC     (SQLITE_IOERR | (30<<8))
#define SQLITE_IOERR_ROLLBACK_ATOMIC   (SQLITE_IOERR | (31<<8))
#define SQLITE_IOERR_DATA              (SQLITE_IOERR | (32<<8))
#define SQLITE_IOERR_CORRUPTFS         (SQLITE_IOERR | (33<<8))
#define SQLITE_IOERR_IN_PAGE           (SQLITE_IOERR | (34<<8))
#define SQLITE_IOERR_BADKEY            (SQLITE_IOERR | (35<<8))
#define SQLITE_IOERR_CODEC             (SQLITE_IOERR | (36<<8))
#define SQLITE_LOCKED_SHAREDCACHE      (SQLITE_LOCKED |  (1<<8))
#define SQLITE_LOCKED_VTAB             (SQLITE_LOCKED |  (2<<8))
#define SQLITE_BUSY_RECOVERY           (SQLITE_BUSY   |  (1<<8))
#define SQLITE_BUSY_SNAPSHOT           (SQLITE_BUSY   |  (2<<8))
#define SQLITE_BUSY_TIMEOUT            (SQLITE_BUSY   |  (3<<8))
#define SQLITE_CANTOPEN_NOTEMPDIR      (SQLITE_CANTOPEN | (1<<8))
#define SQLITE_CANTOPEN_ISDIR          (SQLITE_CANTOPEN | (2<<8))
#define SQLITE_CANTOPEN_FULLPATH       (SQLITE_CANTOPEN | (3<<8))
#define SQLITE_CANTOPEN_CONVPATH       (SQLITE_CANTOPEN | (4<<8))
#define SQLITE_CANTOPEN_DIRTYWAL       (SQLITE_CANTOPEN | (5<<8)) /* Not Used */
#define SQLITE_CANTOPEN_SYMLINK        (SQLITE_CANTOPEN | (6<<8))
#define SQLITE_CORRUPT_VTAB            (SQLITE_CORRUPT | (1<<8))
#define SQLITE_CORRUPT_SEQUENCE        (SQLITE_CORRUPT | (2<<8))
#define SQLITE_CORRUPT_INDEX           (SQLITE_CORRUPT | (3<<8))
#define SQLITE_READONLY_RECOVERY       (SQLITE_READONLY | (1<<8))
#define SQLITE_READONLY_CANTLOCK       (SQLITE_READONLY | (2<<8))
#define SQLITE_READONLY_ROLLBACK       (SQLITE_READONLY | (3<<8))
#define SQLITE_READONLY_DBMOVED        (SQLITE_READONLY | (4<<8))
#define SQLITE_READONLY_CANTINIT       (SQLITE_READONLY | (5<<8))
#define SQLITE_READONLY_DIRECTORY      (SQLITE_READONLY | (6<<8))
#define SQLITE_ABORT_ROLLBACK          (SQLITE_ABORT | (2<<8))
#define SQLITE_CONSTRAINT_CHECK        (SQLITE_CONSTRAINT | (1<<8))
#define SQLITE_CONSTRAINT_COMMITHOOK   (SQLITE_CONSTRAINT | (2<<8))
#define SQLITE_CONSTRAINT_FOREIGNKEY   (SQLITE_CONSTRAINT | (3<<8))
#define SQLITE_CONSTRAINT_FUNCTION     (SQLITE_CONSTRAINT | (4<<8))
#define SQLITE_CONSTRAINT_NOTNULL      (SQLITE_CONSTRAINT | (5<<8))
#define SQLITE_CONSTRAINT_PRIMARYKEY   (SQLITE_CONSTRAINT | (6<<8))
#define SQLITE_CONSTRAINT_TRIGGER      (SQLITE_CONSTRAINT | (7<<8))
#define SQLITE_CONSTRAINT_UNIQUE       (SQLITE_CONSTRAINT | (8<<8))
#define SQLITE_CONSTRAINT_VTAB         (SQLITE_CONSTRAINT | (9<<8))
#define SQLITE_CONSTRAINT_ROWID        (SQLITE_CONSTRAINT |(10<<8))
#define SQLITE_CONSTRAINT_PINNED       (SQLITE_CONSTRAINT |(11<<8))
#define SQLITE_CONSTRAINT_DATATYPE     (SQLITE_CONSTRAINT |(12<<8))
#define SQLITE_NOTICE_RECOVER_WAL      (SQLITE_NOTICE | (1<<8))
#define SQLITE_NOTICE_RECOVER_ROLLBACK (SQLITE_NOTICE | (2<<8))
#define SQLITE_NOTICE_RBU              (SQLITE_NOTICE | (3<<8))
#define SQLITE_WARNING_AUTOINDEX       (SQLITE_WARNING | (1<<8))
#define SQLITE_AUTH_USER               (SQLITE_AUTH | (1<<8))
#define SQLITE_OK_LOAD_PERMANENTLY     (SQLITE_OK | (1<<8))
#define SQLITE_OK_SYMLINK              (SQLITE_OK | (2<<8)) /* internal use only */

/*
** CAPI3REF: Flags For File Open Operations
**
** These bit values are intended for use in the
** 3rd parameter to the [sqlite3_open_v2()] interface and
** in the 4th parameter to the [sqlite3_vfs.xOpen] method.
**
** Only those flags marked as "Ok for sqlite3_open_v2()" may be
** used as the third argument to the [sqlite3_open_v2()] interface.
** The other flags have historically been ignored by sqlite3_open_v2(),
** though future versions of SQLite might change so that an error is
** raised if any of the disallowed bits are passed into sqlite3_open_v2().
** Applications should not depend on the historical behavior.
**
** Note in particular that passing the SQLITE_OPEN_EXCLUSIVE flag into
** [sqlite3_open_v2()] does *not* cause the underlying database file
** to be opened using O_EXCL.  Passing SQLITE_OPEN_EXCLUSIVE into
** [sqlite3_open_v2()] has historically been a no-op and might become an
** error in future versions of SQLite.
*/
#define SQLITE_OPEN_READONLY         0x00000001  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_READWRITE        0x00000002  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_CREATE           0x00000004  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_DELETEONCLOSE    0x00000008  /* VFS only */
#define SQLITE_OPEN_EXCLUSIVE        0x00000010  /* VFS only */
#define SQLITE_OPEN_AUTOPROXY        0x00000020  /* VFS only */
#define SQLITE_OPEN_URI              0x00000040  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_MEMORY           0x00000080  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_MAIN_DB          0x00000100  /* VFS only */
#define SQLITE_OPEN_TEMP_DB          0x00000200  /* VFS only */
#define SQLITE_OPEN_TRANSIENT_DB     0x00000400  /* VFS only */
#define SQLITE_OPEN_MAIN_JOURNAL     0x00000800  /* VFS only */
#define SQLITE_OPEN_TEMP_JOURNAL     0x00001000  /* VFS only */
#define SQLITE_OPEN_SUBJOURNAL       0x00002000  /* VFS only */
#define SQLITE_OPEN_SUPER_JOURNAL    0x00004000  /* VFS only */
#define SQLITE_OPEN_NOMUTEX          0x00008000  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_FULLMUTEX        0x00010000  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_SHAREDCACHE      0x00020000  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_PRIVATECACHE     0x00040000  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_WAL              0x00080000  /* VFS only */
#define SQLITE_OPEN_NOFOLLOW         0x01000000  /* Ok for sqlite3_open_v2() */
#define SQLITE_OPEN_EXRESCODE        0x02000000  /* Extended result codes */

/* Reserved:                         0x00F00000 */
/* Legacy compatibility: */
#define SQLITE_OPEN_MASTER_JOURNAL   0x00004000  /* VFS only */


/*
** CAPI3REF: Device Characteristics
**
** The xDeviceCharacteristics method of the [sqlite3_io_methods]
** object returns an integer which is a vector of these
** bit values expressing I/O characteristics of the mass storage
** device that holds the file that the [sqlite3_io_methods]
** refers to.
**
** The SQLITE_IOCAP_ATOMIC property means that all writes of
** any size are atomic.  The SQLITE_IOCAP_ATOMICnnn values
** mean that writes of blocks that are nnn bytes in size and
** are aligned to an address which is an integer multiple of
** nnn are atomic.  The SQLITE_IOCAP_SAFE_APPEND value means
** that when data is appended to a file, the data is appended
** first then the size of the file is extended, never the other
** way around.  The SQLITE_IOCAP_SEQUENTIAL property means that
** information is written to disk in the same order as calls
** to xWrite().  The SQLITE_IOCAP_POWERSAFE_OVERWRITE property means that
** after reboot following a crash or power loss, the only bytes in a
** file that were written at the application level might have changed
** and that adjacent bytes, even bytes within the same sector are
** guaranteed to be unchanged.  The SQLITE_IOCAP_UNDELETABLE_WHEN_OPEN
** flag indicates that a file cannot be deleted when open.  The
** SQLITE_IOCAP_IMMUTABLE flag indicates that the file is on
** read-only media and cannot be changed even by processes with
** elevated privileges.
**
** The SQLITE_IOCAP_BATCH_ATOMIC property means that the underlying
** filesystem supports doing multiple write operations atomically when those
** write operations are bracketed by [SQLITE_FCNTL_BEGIN_ATOMIC_WRITE] and
** [SQLITE_FCNTL_COMMIT_ATOMIC_WRITE].
**
** The SQLITE_IOCAP_SUBPAGE_READ property means that it is ok to read
** from the database file in amounts that are not a multiple of the
** page size and that do not begin at a page boundary.  Without this
** property, SQLite is careful to only do full-page reads and write
** on aligned pages, with the one exception that it will do a sub-page
** read of the first page to access the database header.
*/
#define SQLITE_IOCAP_ATOMIC                 0x00000001
#define SQLITE_IOCAP_ATOMIC512              0x00000002
#define SQLITE_IOCAP_ATOMIC1K               0x00000004
#define SQLITE_IOCAP_ATOMIC2K               0x00000008
#define SQLITE_IOCAP_ATOMIC4K               0x00000010
#define SQLITE_IOCAP_ATOMIC8K               0x00000020
#define SQLITE_IOCAP_ATOMIC16K              0x00000040
#define SQLITE_IOCAP_ATOMIC32K              0x00000080
#define SQLITE_IOCAP_ATOMIC64K              0x00000100
#define SQLITE_IOCAP_SAFE_APPEND            0x00000200
#define SQLITE_IOCAP_SEQUENTIAL             0x00000400
#define SQLITE_IOCAP_UNDELETABLE_WHEN_OPEN  0x00000800
#define SQLITE_IOCAP_POWERSAFE_OVERWRITE    0x00001000
#define SQLITE_IOCAP_IMMUTABLE              0x00002000
#define SQLITE_IOCAP_BATCH_ATOMIC           0x00004000
#define SQLITE_IOCAP_SUBPAGE_READ           0x00008000

/*
** CAPI3REF: File Locking Levels
**
** SQLite uses one of these integer values as the second
** argument to calls it makes to the xLock() and xUnlock() methods
** of an [sqlite3_io_methods] object.  These values are ordered from
** least restrictive to most restrictive.
**
** The argument to xLock() is always SHARED or higher.  The argument to
** xUnlock is either SHARED or NONE.
*/
#define SQLITE_LOCK_NONE          0       /* xUnlock() only */
#define SQLITE_LOCK_SHARED        1       /* xLock() or xUnlock() */
#define SQLITE_LOCK_RESERVED      2       /* xLock() only */
#define SQLITE_LOCK_PENDING       3       /* xLock() only */
#define SQLITE_LOCK_EXCLUSIVE     4       /* xLock() only */

/*
** CAPI3REF: Synchronization Type Flags
**
** When SQLite invokes the xSync() method of an
** [sqlite3_io_methods] object it uses a combination of
** these integer values as the second argument.
**
** When the SQLITE_SYNC_DATAONLY flag is used, it means that the
** sync operation only needs to flush data to mass storage.  Inode
** information need not be flushed. If the lower four bits of the flag
** equal SQLITE_SYNC_NORMAL, that means to use normal fsync() semantics.
** If the lower four bits equal SQLITE_SYNC_FULL, that means
** to use Mac OS X style fullsync instead of fsync().
**
** Do not confuse the SQLITE_SYNC_NORMAL and SQLITE_SYNC_FULL flags
** with the [PRAGMA synchronous]=NORMAL and [PRAGMA synchronous]=FULL
** settings.  The [synchronous pragma] determines when calls to the
** xSync VFS method occur and applies uniformly across all platforms.
** The SQLITE_SYNC_NORMAL and SQLITE_SYNC_FULL flags determine how
** energetic or rigorous or forceful the sync operations are and
** only make a difference on Mac OSX for the default SQLite code.
** (Third-party VFS implementations might also make the distinction
** between SQLITE_SYNC_NORMAL and SQLITE_SYNC_FULL, but among the
** operating systems natively supported by SQLite, only Mac OSX
** cares about the difference.)
*/
#define SQLITE_SYNC_NORMAL        0x00002
#define SQLITE_SYNC_FULL          0x00003
#define SQLITE_SYNC_DATAONLY      0x00010

/*
** CAPI3REF: OS Interface Open File Handle
**
** An [sqlite3_file] object represents an open file in the
** [sqlite3_vfs | OS interface layer].  Individual OS interface
** implementations will
** want to subclass this object by appending additional fields
** for their own use.  The pMethods entry is a pointer to an
** [sqlite3_io_methods] object that defines methods for performing
** I/O operations on the open file.
*/
typedef struct sqlite3_file sqlite3_file;
struct sqlite3_file {
  const struct sqlite3_io_methods *pMethods;  /* Methods for an open file */
};

/*
** CAPI3REF: OS Interface File Virtual Methods Object
**
** Every file opened by the [sqlite3_vfs.xOpen] method populates an
** [sqlite3_file] object (or, more commonly, a subclass of the
** [sqlite3_file] object) with a pointer to an instance of this object.
** This object defines the methods used to perform various operations
** against the open file represented by the [sqlite3_file] object.
**
** If the [sqlite3_vfs.xOpen] method sets the sqlite3_file.pMethods element
** to a non-NULL pointer, then the sqlite3_io_methods.xClose method
** may be invoked even if the [sqlite3_vfs.xOpen] reported that it failed.  The
** only way to prevent a call to xClose following a failed [sqlite3_vfs.xOpen]
** is for the [sqlite3_vfs.xOpen] to set the sqlite3_file.pMethods element
** to NULL.
**
** The flags argument to xSync may be one of [SQLITE_SYNC_NORMAL] or
** [SQLITE_SYNC_FULL].  The first choice is the normal fsync().
** The second choice is a Mac OS X style fullsync.  The [SQLITE_SYNC_DATAONLY]
** flag may be ORed in to indicate that only the data of the file
** and not its inode needs to be synced.
**
** The integer values to xLock() and xUnlock() are one of
** <ul>
** <li> [SQLITE_LOCK_NONE],
** <li> [SQLITE_LOCK_SHARED],
** <li> [SQLITE_LOCK_RESERVED],
** <li> [SQLITE_LOCK_PENDING], or
** <li> [SQLITE_LOCK_EXCLUSIVE].
** </ul>
** xLock() upgrades the database file lock.  In other words, xLock() moves the
** database file lock in the direction NONE toward EXCLUSIVE. The argument to
** xLock() is always one of SHARED, RESERVED, PENDING, or EXCLUSIVE, never
** SQLITE_LOCK_NONE.  If the database file lock is already at or above the
** requested lock, then the call to xLock() is a no-op.
** xUnlock() downgrades the database file lock to either SHARED or NONE.
** If the lock is already at or below the requested lock state, then the call
** to xUnlock() is a no-op.
** The xCheckReservedLock() method checks whether any database connection,
** either in this process or in some other process, is holding a RESERVED,
** PENDING, or EXCLUSIVE lock on the file.  It returns, via its output
** pointer parameter, true if such a lock exists and false otherwise.
**
** The xFileControl() method is a generic interface that allows custom
** VFS implementations to directly control an open file using the
** [sqlite3_file_control()] interface.  The second "op" argument is an
** integer opcode.  The third argument is a generic pointer intended to
** point to a structure that may contain arguments or space in which to
** write return values.  Potential uses for xFileControl() might be
** functions to enable blocking locks with timeouts, to change the
** locking strategy (for example to use dot-file locks), to inquire
** about the status of a lock, or to break stale locks.  The SQLite
** core reserves all opcodes less than 100 for its own use.
** A [file control opcodes | list of opcodes] less than 100 is available.
** Applications that define a custom xFileControl method should use opcodes
** greater than 100 to avoid conflicts.  VFS implementations should
** return [SQLITE_NOTFOUND] for file control opcodes that they do not
** recognize.
**
** The xSectorSize() method returns the sector size of the
** device that underlies the file.  The sector size is the
** minimum write that can be performed without disturbing
** other bytes in the file.  The xDeviceCharacteristics()
** method returns a bit vector describing behaviors of the
** underlying device:
**
** <ul>
** <li> [SQLITE_IOCAP_ATOMIC]
** <li> [SQLITE_IOCAP_ATOMIC512]
** <li> [SQLITE_IOCAP_ATOMIC1K]
** <li> [SQLITE_IOCAP_ATOMIC2K]
** <li> [SQLITE_IOCAP_ATOMIC4K]
** <li> [SQLITE_IOCAP_ATOMIC8K]
** <li> [SQLITE_IOCAP_ATOMIC16K]
** <li> [SQLITE_IOCAP_ATOMIC32K]
** <li> [SQLITE_IOCAP_ATOMIC64K]
** <li> [SQLITE_IOCAP_SAFE_APPEND]
** <li> [SQLITE_IOCAP_SEQUENTIAL]
** <li> [SQLITE_IOCAP_UNDELETABLE_WHEN_OPEN]
** <li> [SQLITE_IOCAP_POWERSAFE_OVERWRITE]
** <li> [SQLITE_IOCAP_IMMUTABLE]
** <li> [SQLITE_IOCAP_BATCH_ATOMIC]
** <li> [SQLITE_IOCAP_SUBPAGE_READ]
** </ul>
**
** The SQLITE_IOCAP_ATOMIC property means that all writes of
** any size are atomic.  The SQLITE_IOCAP_ATOMICnnn values
** mean that writes of blocks that are nnn bytes in size and
** are aligned to an address which is an integer multiple of
** nnn are atomic.  The SQLITE_IOCAP_SAFE_APPEND value means
** that when data is appended to a file, the data is appended
** first then the size of the file is extended, never the other
** way around.  The SQLITE_IOCAP_SEQUENTIAL property means that
** information is written to disk in the same order as calls
** to xWrite().
**
** If xRead() returns SQLITE_IOERR_SHORT_READ it must also fill
** in the unread portions of the buffer with zeros.  A VFS that
** fails to zero-fill short reads might seem to work.  However,
** failure to zero-fill short reads will eventually lead to
** database corruption.
*/
typedef struct sqlite3_io_methods sqlite3_io_methods;
struct sqlite3_io_methods {
  int iVersion;
  int (*xClose)(sqlite3_file*);
  int (*xRead)(sqlite3_file*, void*, int iAmt, sqlite3_int64 iOfst);
  int (*xWrite)(sqlite3_file*, const void*, int iAmt, sqlite3_int64 iOfst);
  int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
  int (*xSync)(sqlite3_file*, int flags);
  int (*xFileSize)(sqlite3_file*, sqlite3_int64 *pSize);
  int (*xLock)(sqlite3_file*, int);
  int (*xUnlock)(sqlite3_file*, int);
  int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
  int (*xFileControl)(sqlite3_file*, int op, void *pArg);
  int (*xSectorSize)(sqlite3_file*);
  int (*xDeviceCharacteristics)(sqlite3_file*);
  /* Methods above are valid for version 1 */
  int (*xShmMap)(sqlite3_file*, int iPg, int pgsz, int, void volatile**);
  int (*xShmLock)(sqlite3_file*, int offset, int n, int flags);
  void (*xShmBarrier)(sqlite3_file*);
  int (*xShmUnmap)(sqlite3_file*, int deleteFlag);
  /* Methods above are valid for version 2 */
  int (*xFetch)(sqlite3_file*, sqlite3_int64 iOfst, int iAmt, void **pp);
  int (*xUnfetch)(sqlite3_file*, sqlite3_int64 iOfst, void *p);
  /* Methods above are valid for version 3 */
  /* Additional methods may be added in future releases */
};

/*
** CAPI3REF: Standard File Control Opcodes
** KEYWORDS: {file control opcodes} {file control opcode}
**
** These integer constants are opcodes for the xFileControl method
** of the [sqlite3_io_methods] object and for the [sqlite3_file_control()]
** interface.
**
** <ul>
** <li>[[SQLITE_FCNTL_LOCKSTATE]]
** The [SQLITE_FCNTL_LOCKSTATE] opcode is used for debugging.  This
** opcode causes the xFileControl method to write the current state of
** the lock (one of [SQLITE_LOCK_NONE], [SQLITE_LOCK_SHARED],
** [SQLITE_LOCK_RESERVED], [SQLITE_LOCK_PENDING], or [SQLITE_LOCK_EXCLUSIVE])
** into an integer that the pArg argument points to.
** This capability is only available if SQLite is compiled with [SQLITE_DEBUG].
**
** <li>[[SQLITE_FCNTL_SIZE_HINT]]
** The [SQLITE_FCNTL_SIZE_HINT] opcode is used by SQLite to give the VFS
** layer a hint of how large the database file will grow to be during the
** current transaction.  This hint is not guaranteed to be accurate but it
** is often close.  The underlying VFS might choose to preallocate database
** file space based on this hint in order to help writes to the database
** file run faster.
**
** <li>[[SQLITE_FCNTL_SIZE_LIMIT]]
** The [SQLITE_FCNTL_SIZE_LIMIT] opcode is used by in-memory VFS that
** implements [sqlite3_deserialize()] to set an upper bound on the size
** of the in-memory database.  The argument is a pointer to a [sqlite3_int64].
** If the integer pointed to is negative, then it is filled in with the
** current limit.  Otherwise the limit is set to the larger of the value
** of the integer pointed to and the current database size.  The integer
** pointed to is set to the new limit.
**
** <li>[[SQLITE_FCNTL_CHUNK_SIZE]]
** The [SQLITE_FCNTL_CHUNK_SIZE] opcode is used to request that the VFS
** extends and truncates the database file in chunks of a size specified
** by the user. The fourth argument to [sqlite3_file_control()] should
** point to an integer (type int) containing the new chunk-size to use
** for the nominated database. Allocating database file space in large
** chunks (say 1MB at a time), may reduce file-system fragmentation and
** improve performance on some systems.
**
** <li>[[SQLITE_FCNTL_FILE_POINTER]]
** The [SQLITE_FCNTL_FILE_POINTER] opcode is used to obtain a pointer
** to the [sqlite3_file] object associated with a particular database
** connection.  See also [SQLITE_FCNTL_JOURNAL_POINTER].
**
** <li>[[SQLITE_FCNTL_JOURNAL_POINTER]]
** The [SQLITE_FCNTL_JOURNAL_POINTER] opcode is used to obtain a pointer
** to the [sqlite3_file] object associated with the journal file (either
** the [rollback journal] or the [write-ahead log]) for a particular database
** connection.  See also [SQLITE_FCNTL_FILE_POINTER].
**
** <li>[[SQLITE_FCNTL_SYNC_OMITTED]]
** The SQLITE_FCNTL_SYNC_OMITTED file-control is no longer used.
**
** <li>[[SQLITE_FCNTL_SYNC]]
** The [SQLITE_FCNTL_SYNC] opcode is generated internally by SQLite and
** sent to the VFS immediately before the xSync method is invoked on a
** database file descriptor. Or, if the xSync method is not invoked
** because the user has configured SQLite with
** [PRAGMA synchronous | PRAGMA synchronous=OFF] it is invoked in place
** of the xSync method. In most cases, the pointer argument passed with
** this file-control is NULL. However, if the database file is being synced
** as part of a multi-database commit, the argument points to a nul-terminated
** string containing the transactions super-journal file name. VFSes that
** do not need this signal should silently ignore this opcode. Applications
** should not call [sqlite3_file_control()] with this opcode as doing so may
** disrupt the operation of the specialized VFSes that do require it.
**
** <li>[[SQLITE_FCNTL_COMMIT_PHASETWO]]
** The [SQLITE_FCNTL_COMMIT_PHASETWO] opcode is generated internally by SQLite
** and sent to the VFS after a transaction has been committed immediately
** but before the database is unlocked. VFSes that do not need this signal
** should silently ignore this opcode. Applications should not call
** [sqlite3_file_control()] with this opcode as doing so may disrupt the
** operation of the specialized VFSes that do require it.
**
** <li>[[SQLITE_FCNTL_WIN32_AV_RETRY]]
** ^The [SQLITE_FCNTL_WIN32_AV_RETRY] opcode is used to configure automatic
** retry counts and intervals for certain disk I/O operations for the
** windows [VFS] in order to provide robustness in the presence of
** anti-virus programs.  By default, the windows VFS will retry file read,
** file write, and file delete operations up to 10 times, with a delay
** of 25 milliseconds before the first retry and with the delay increasing
** by an additional 25 milliseconds with each subsequent retry.  This
** opcode allows these two values (10 retries and 25 milliseconds of delay)
** to be adjusted.  The values are changed for all database connections
** within the same process.  The argument is a pointer to an array of two
** integers where the first integer is the new retry count and the second
** integer is the delay.  If either integer is negative, then the setting
** is not changed but instead the prior value of that setting is written
** into the array entry, allowing the current retry settings to be
** interrogated.  The zDbName parameter is ignored.
**
** <li>[[SQLITE_FCNTL_PERSIST_WAL]]
** ^The [SQLITE_FCNTL_PERSIST_WAL] opcode is used to set or query the
** persistent [WAL | Write Ahead Log] setting.  By default, the auxiliary
** write ahead log ([WAL file]) and shared memory
** files used for transaction control
** are automatically deleted when the latest connection to the database
** closes.  Setting persistent WAL mode causes those files to persist after
** close.  Persisting the files is useful when other processes that do not
** have write permission on the directory containing the database file want
** to read the database file, as the WAL and shared memory files must exist
** in order for the database to be readable.  The fourth parameter to
** [sqlite3_file_control()] for this opcode should be a pointer to an integer.
** That integer is 0 to disable persistent WAL mode or 1 to enable persistent
** WAL mode.  If the integer is -1, then it is overwritten with the current
** WAL persistence setting.
**
** <li>[[SQLITE_FCNTL_POWERSAFE_OVERWRITE]]
** ^The [SQLITE_FCNTL_POWERSAFE_OVERWRITE] opcode is used to set or query the
** persistent "powersafe-overwrite" or "PSOW" setting.  The PSOW setting
** determines the [SQLITE_IOCAP_POWERSAFE_OVERWRITE] bit of the
** xDeviceCharacteristics methods. The fourth parameter to
** [sqlite3_file_control()] for this opcode should be a pointer to an integer.
** That integer is 0 to disable zero-damage mode or 1 to enable zero-damage
** mode.  If the integer is -1, then it is overwritten with the current
** zero-damage mode setting.
**
** <li>[[SQLITE_FCNTL_OVERWRITE]]
** ^The [SQLITE_FCNTL_OVERWRITE] opcode is invoked by SQLite after opening
** a write transaction to indicate that, unless it is rolled back for some
** reason, the entire database file will be overwritten by the current
** transaction. This is used by VACUUM operations.
**
** <li>[[SQLITE_FCNTL_VFSNAME]]
** ^The [SQLITE_FCNTL_VFSNAME] opcode can be used to obtain the names of
** all [VFSes] in the VFS stack.  The names of all VFS shims and the
** final bottom-level VFS are written into memory obtained from
** [sqlite3_malloc()] and the result is stored in the char* variable
** that the fourth parameter of [sqlite3_file_control()] points to.
** The caller is responsible for freeing the memory when done.  As with
** all file-control actions, there is no guarantee that this will actually
** do anything.  Callers should initialize the char* variable to a NULL
** pointer in case this file-control is not implemented.  This file-control
** is intended for diagnostic use only.
**
** <li>[[SQLITE_FCNTL_VFS_POINTER]]
** ^The [SQLITE_FCNTL_VFS_POINTER] opcode finds a pointer to the top-level
** [VFSes] currently in use.  ^(The argument X in
** sqlite3_file_control(db,SQLITE_FCNTL_VFS_POINTER,X) must be
** of type "[sqlite3_vfs] **".  This opcode will set *X
** to a pointer to the top-level VFS.)^
** ^When there are multiple VFS shims in the stack, this opcode finds the
** upper-most shim only.
**
** <li>[[SQLITE_FCNTL_PRAGMA]]
** ^Whenever a [PRAGMA] statement is parsed, an [SQLITE_FCNTL_PRAGMA]
** file control is sent to the open [sqlite3_file] object corresponding
** to the database file to which the pragma statement refers. ^The argument
** to the [SQLITE_FCNTL_PRAGMA] file control is an array of
** pointers to strings (char**) in which the second element of the array
** is the name of the pragma and the third element is the argument to the
** pragma or NULL if the pragma has no argument.  ^The handler for an
** [SQLITE_FCNTL_PRAGMA] file control can optionally make the first element
** of the char** argument point to a string obtained from [sqlite3_mprintf()]
** or the equivalent and that string will become the result of the pragma or
** the error message if the pragma fails. ^If the
** [SQLITE_FCNTL_PRAGMA] file control returns [SQLITE_NOTFOUND], then normal
** [PRAGMA] processing continues.  ^If the [SQLITE_FCNTL_PRAGMA]
** file control returns [SQLITE_OK], then the parser assumes that the
** VFS has handled the PRAGMA itself and the parser generates a no-op
** prepared statement if result string is NULL, or that returns a copy
** of the result string if the string is non-NULL.
** ^If the [SQLITE_FCNTL_PRAGMA] file control returns
** any result code other than [SQLITE_OK] or [SQLITE_NOTFOUND], that means
** that the VFS encountered an error while handling the [PRAGMA] and the
** compilation of the PRAGMA fails with an error.  ^The [SQLITE_FCNTL_PRAGMA]
** file control occurs at the beginning of pragma statement analysis and so
** it is able to override built-in [PRAGMA] statements.
**
** <li>[[SQLITE_FCNTL_BUSYHANDLER]]
** ^The [SQLITE_FCNTL_BUSYHANDLER]
** file-control may be invoked by SQLite on the database file handle
** shortly after it is opened in order to provide a custom VFS with access
** to the connection's busy-handler callback. The argument is of type (void**)
** - an array of two (void *) values. The first (void *) actually points
** to a function of type (int (*)(void *)). In order to invoke the connection's
** busy-handler, this function should be invoked with the second (void *) in
** the array as the only argument. If it returns non-zero, then the operation
** should be retried. If it returns zero, the custom VFS should abandon the
** current operation.
**
** <li>[[SQLITE_FCNTL_TEMPFILENAME]]
** ^Applications can invoke the [SQLITE_FCNTL_TEMPFILENAME] file-control
** to have SQLite generate a
** temporary filename using the same algorithm that is followed to generate
** temporary filenames for TEMP tables and other internal uses.  The
** argument should be a char** which will be filled with the filename
** written into memory obtained from [sqlite3_malloc()].  The caller should
** invoke [sqlite3_free()] on the result to avoid a memory leak.
**
** <li>[[SQLITE_FCNTL_MMAP_SIZE]]
** The [SQLITE_FCNTL_MMAP_SIZE] file control is used to query or set the
** maximum number of bytes that will be used for memory-mapped I/O.
** The argument is a pointer to a value of type sqlite3_int64 that
** is an advisory maximum number of bytes in the file to memory map.  The
** pointer is overwritten with the old value.  The limit is not changed if
** the value originally pointed to is negative, and so the current limit
** can be queried by passing in a pointer to a negative number.  This
** file-control is used internally to implement [PRAGMA mmap_size].
**
** <li>[[SQLITE_FCNTL_TRACE]]
** The [SQLITE_FCNTL_TRACE] file control provides advisory information
** to the VFS about what the higher layers of the SQLite stack are doing.
** This file control is used by some VFS activity tracing [shims].
** The argument is a zero-terminated string.  Higher layers in the
** SQLite stack may generate instances of this file control if
** the [SQLITE_USE_FCNTL_TRACE] compile-time option is enabled.
**
** <li>[[SQLITE_FCNTL_HAS_MOVED]]
** The [SQLITE_FCNTL_HAS_MOVED] file control interprets its argument as a
** pointer to an integer and it writes a boolean into that integer depending
** on whether or not the file has been renamed, moved, or deleted since it
** was first opened.
**
** <li>[[SQLITE_FCNTL_WIN32_GET_HANDLE]]
** The [SQLITE_FCNTL_WIN32_GET_HANDLE] opcode can be used to obtain the
** underlying native file handle associated with a file handle.  This file
** control interprets its argument as a pointer to a native file handle and
** writes the resulting value there.
**
** <li>[[SQLITE_FCNTL_WIN32_SET_HANDLE]]
** The [SQLITE_FCNTL_WIN32_SET_HANDLE] opcode is used for debugging.  This
** opcode causes the xFileControl method to swap the file handle with the one
** pointed to by the pArg argument.  This capability is used during testing
** and only needs to be supported when SQLITE_TEST is defined.
**
** <li>[[SQLITE_FCNTL_NULL_IO]]
** The [SQLITE_FCNTL_NULL_IO] opcode sets the low-level file descriptor
** or file handle for the [sqlite3_file] object such that it will no longer
** read or write to the database file.
**
** <li>[[SQLITE_FCNTL_WAL_BLOCK]]
** The [SQLITE_FCNTL_WAL_BLOCK] is a signal to the VFS layer that it might
** be advantageous to block on the next WAL lock if the lock is not immediately
** available.  The WAL subsystem issues this signal during rare
** circumstances in order to fix a problem with priority inversion.
** Applications should <em>not</em> use this file-control.
**
** <li>[[SQLITE_FCNTL_ZIPVFS]]
** The [SQLITE_FCNTL_ZIPVFS] opcode is implemented by zipvfs only. All other
** VFS should return SQLITE_NOTFOUND for this opcode.
**
** <li>[[SQLITE_FCNTL_RBU]]
** The [SQLITE_FCNTL_RBU] opcode is implemented by the special VFS used by
** the RBU extension only.  All other VFS should return SQLITE_NOTFOUND for
** this opcode.
**
** <li>[[SQLITE_FCNTL_BEGIN_ATOMIC_WRITE]]
** If the [SQLITE_FCNTL_BEGIN_ATOMIC_WRITE] opcode returns SQLITE_OK, then
** the file descriptor is placed in "batch write mode",en intULL_-th the dn_frnteg avaidh th** thad free locktiple writn
** totageoIN_ATOMIC_WRITE] and
** [SQLITE_FCN  Sve perTE_NOTFOUis unlo** and  escripktipleative fiefault, All other VFS shoulf the Fevent a cale [ide sistOMIC_WRITE]]
** If the [SQLITE_thad changes. The to ilo** caIN_ATOMIC_WRITE] and
** [SQLITE_FC of [SQLITE_SYNTL_RBU])
#define SQLILITE_FC, the user lle con [SQbjeLite () methodpragmaoase connect or file handlecode sets the low-lned patry coragma] deteame ord causes ndled thnts are opcodes for thee if SQLite iE_HINT]]
** The VFSes that do require it.
**
** <lli>[[SQLITE_FCNTL_[[SQLITE_FCNTL_RBUE] and
** [SQLITE_FC oor debugging.MIC propesed fohe dn_frnamed, ** theevhods e [ide sistequeste [SQLITE_SYNTL_RBU** If the [SQLITE_FCsting
nimum writktiple wrie SQLite stack are doinPRAGMA]
** file conat an sed durck on ttive fieeot-fileplieimum write [ide sislds befAME] after a transacmode causemethodto flu the Rsinrdion t mainteger dependiimit.   [ide sis, y generate instanct* ar returns SQLITE_OK, thenrmatadviscriptor is plas of SQLit mode",en inta native ous or forceful inolean lues as ^the user lleE_FCNT.  The ITE_FCNTL_RBUE] and
** [SQLITE_Fte that -file changee [ide sistequesteQLITE_SYNTL_RBU** If the [SQLITE_FNOTFOUND for this opcode.
**)
#define SQLILITE_FC <li>[[SQLITE_FCNTL_RBU])
#define SQLILITE_FC oor debugging.MIC propesed fohe dn_frnamed, ** theevhods e [ide sistequeste [SQLITE_SYNTL_RBU** If the [SQLITE_FCsting
cate that, .LITE_FCgenerate instanct* arturns SQLITE_OK, thenrmatadviscriptor is plazero,of SQLit mode",en intative ous or forceful inolean lues as ^the user lleE_FCNT.  The ITE_FCNTL_RBU])
#define SQLILITE_Fte that -file changee [ide sistequesteQLITE_SYNTL_RBU** If the [SQLITE_FNOTFOUND for this opcode.
*CK_PETIMEOU[[SQLITE_FCNTL_SIZE_LIMITCK_PETIMEOU[[TE_FCNTL_WIN32_AV_RETRY] opcodused to ight
** bbit vfile Ms, with a delay
** ofmpil equih
** ffoll aftere [SQNTER] opcdowngradesa
** tempo_int6     d volation 3 */
 what tointQLITE_FCerrogated.  Terprets its arg32-AP_Pses in _EXCLUSIVE])
ission r returns** write])
Mma anting
*teger. B
** ofPRAGMA** ried. 32-AP_Pses inc()]. mage
** mmap.  The
** pointer heevhods ument is MFOUND for
** this opcode.
**CK_PEONINT_NEC[[SQLITE_FCNTL_SIZE_LIMIT*CK_PEONINT_NEC[[TE_FCNTL_WIN32_AV_RETRY] opcothe parser ight
** be autoak a calase filrades th In ordts argwrsioCNTLse
** for SQLite s_WIN32_AV_Rl is used urns 
** busag argying native filg.  HigSIZETheLKT*CK_PEONINT_NEC[FOUND for
** this opcode.
*sync_V
** ON[SQLITE_FCNTL_SIZE_LIMITsync_V
** ON[TE_FCNTL_WIN32_AV_Rg.  c value. sere [SQa
** read or wri the in-memory database.  The arg32-AP_Punses in _EXCLUStQLITE_FC"appenproblem"riptor
**ge
*reans that
**t settingase.  Tn the file"appenproblem"ralue. sewITE_FCNTLny locks wPRAGMA]stom VFS [sqlite3_file] ile want
** to teger ithrsqlitTL_erride builaoase connect log]) for a particulaf resursqlit* string cont a transacis f genmight choose to hanged for gass
** evel
he files is use.nous]=Fr file total_alue. she [sqlite3_fileWIN32_GET_HANDLE theat an erile want
oase co particulafked
*lue.  , invoktit writes _fileWsqlite3sing locks laoastempoafieeo gus  */
thad frar retendit is openemelockismAV_Rg.  c value. sere  */
tby
** thestried. [SQLFr file total_alue. she ites _fileWsqlite3sing r TEMP talocks laoalds be [SQNme
**locks lama
** y
he filues are changed for n the fileinternalues _problem [SQLmhad chL_TRACE]emelockismAV_Rg.  c value. sere [SQa

** er tttacho use
** foit writhe
**duysis ae filues are changed for , invoktiNme
**locks laTE_FCNTL_RBU] opcodues are changed forhat inalignt changesqlitontrol is not are doing.
d *) in
*melockismAV_Rg.  c value. ser of typh to anteger is thile-cone
** thile-conl might harrlying native fil-file crite-aheadtttacho use
** foVFSes that do require it.
**KPT_STAR[[SQLITE_FCNTL_SIZE_LIMIT*KPT_STAR[[[SQLITE_FCNTL_OVERWen indatabasaeckResase. [sqlitgwrsioCNTLy
** of 25 climethod rommit,NULL and wthat it iswITE_NO number ger
** read or write to the database file.
**KPT_Dk (oSQLITE_FCNTL_SIZE_LIMIT*KPT_Dk (o[SQLITE_FCNTL_OVERWen indatabasaeckResase. [sqlitgwrsioCNTL file  25 climethhor dekisho uNULLataband wthat it iswITE_NO number ger
** read or wr,committed immedi*-shmHowever, updata genericdes rled thfilopcode is uand wtAME] after kResase. hen SQLITE_TEST is defined.
*EXTE** ThurnsLITE_FCNTL_JEXPERIMENTAL  is defined.
*EXTE** ThurnsLITTE_FCNTL_WIN32_AV_Rg.  c a natnteger depending
rc().
**ues are chlimethbasanhe files is ue file hwIT- plazerofter opening contay be invoked bydepend.USIV to.
** This capabay unix.the fileThe ar) most cases, the poin should <em>not</entrol()] for this opcode fileument is a poi* to).eeds to be synced.he integer
1ontrol is NULL. H).
**wITE_NOoCNTLse
** fo ndled treter, truetlues art sthlimethbasanhe files is uer of typhe top-levhor al othofter opening contay be invoked b.USIV tonteger
0ces of thiss NULL. H).
ile inwIT- pla db has ntrol ile-contre [sqhanged forhbasanL, or e files is u.ype "[sqlite3
** read-oN32_AV_Rg.  c v* string contd sinc invoythlimetdjacent bytesis negatrocess orthat icent bhe files is use.te to the database file.
**KSM  SeeoSQLITE_FCNTL_SIZE_LIMIT*KSM  SeeoTE_FCNTL_WIbit vontrol opcode is ed. [SQLckReseum^When the]s the
** upper-most shim only.
*HARET_fine FCNTL_BEGIN_ile-cohe top-levntrfter opening contay be invoked b,le handling s NULL. H).
ile infoll db htf it rett shim only.
*HARET_fine FLITE_FCNTL_TEMPFIpurgarturnsCNTLbuilaor bound on the sge
**cacho._BEGIN_ile-coons to zerofter openin has ntrol  dbH).
**foll-db htf "[sqlite3i and the ,
ile i the PRA** upper-most shim only.
* See* ThQLITE_FCNTL_FILE_POINTER]]
** ThQCNTL_BEGIN_ATOMIULL_IO] optrol
** is ntrol provides e locks),  or file handle for tWIN32_Aad of the first pagee ha the transacpending addiode in schoma database to be readable. hods] object and for the [sqltrol()] fornnything.  CxClose follstr]gase.  Tn tJSON*foxthod returnsfileumthods ae isilaor bounle sqlite3_fi** [sqlieans
** that wbounle sqlitstrmly across all pOINTER]]
** ThTE_FCNTL_WIN3. The nd the ,
ction tSQLITE_USE_Fsed fo forceful N32_AV_Rero-damd VFSeE_IOCAP_about the differeKSTATE]]
** Thee SQLITE_IOCAP                0xKSTATEThe ]]
*PROXY]]
*_IOCAP YNC_NORMAL       E_HINT]he ]]
*PROXY]]
*_IOCAP YNC_FULL         KSTATE]AST_ERRNO SQLITE_IOCAP                0xE_HINT]]
** Thee SQLITE_IOCAP 5              0xE_HINT]]
** The  SQLITE_IOCAP 6              0xE_HINT See also [SQLITE_IOCAP 7              0xE_HINT]]]
** The SQQQQQQQQQQQQ               0xRETRY]]
** ^The [SQLQQQQQQQQQQ9              0xRETRY]]
** ^The [QLITE_IOCAP  OMIC           0xWRITE]]
** ^The SQLITE_IOCAP                 0xKSTATE]
** ^Te SQLITE_IOCAP  1YNC_NORMAL       E_HINT00
#define SQLITE_IOCAP1YNC_FULL         KSTATEnternale SQLITE_IOCAP  1               0xE_HINT]
** ^The [LITE_IOCAP  15              0xE_HINTnvoke the [SITE_IOCAP  16              0xE_HINT]]
** TheSQLITE_IOCAP  1               0xRETRY]* thele SQLITE_IOCAP   19              0xRETRY]]]
** TheQLITE_IOCAP   K               0xE_HINT]]]
le SQLITE_IOCAP    2               0xKSTATE]]
** The [SQLIOCAP    2YNC_NORMAL       E_HINT]]
** The [SQLITCAP    2YNC_FULL         KSTATE]]
** TheLITE_IOCAP    2               0xE_HINT]]
**  SQLITE_IOCAP    25              0xE_HINTcialle SQLITE_IOCAP    26              0xE_HINTcontrol(db,TE_IOCAP    27              0xE_HINT]]
** The [SQLIOCAP    2               0xRETRY]]
** ^Ghe [SQLITCAP    29              0xRETRY]]DBlle SQLITE_IOCAP    3               0xE_HINT** If the [SQLITE_t    3               0xKSTATE]]
** Tthe [SQLITE_t   3YNC_NORMAL       E_HINT])
#define SQLILITE_Ft 3YNC_FULL         KSTATE]K_PETIMEOU[E_IOCAP    3               0xE_HINTsync_V
** ONE_IOCAP    35              0xE_HINT]]
** The ITE_IOCAP    36              0xE_HINT*KPT_Dk (LITE_IOCAP    37              0xE_HINTHARED],_BYTE  SQLITE_IO3               0xRETRY]*KPT_STAR[ITE_IOCAP    39              0xRETRY]EXTE** ThurnsLIOCAP    6K              0x_LIMIT*KSM  SeeLITE_IOCAP    4               0xKSTATEHARET_fine TE_IOCAP    4YNC_NORMAL       E_HINT]]
** TSQLITE_IOCAP    4YNC_FULL         KSTATE*CK_PEONINT_NEC[CAP    4               0xE_HINT]]
** ThTLITE_IOCAP    45in fooledesata gnerate_about the differeThe ]]
*PROXY]]
*_IOCAP     0xKSTATEThe ]]
*PROXY]]
*NC_FULL          he ]]
*PROXY]]
*_IOCAP     0xKSTATE he ]]
*PROXY]]
*      /* xLock() AST_ERRNO SQLITE_IOCAP       KSTATE]AST_ERRNO
in future releasesMufox: OS Interfacecrosmufox: pluod to siion Type  object.to memory ufoxFCsting
aides e o chc v* poi the [mufox:an [sqlite3_ Mac OSX f wri_FCNTlookGMA] ft bound TEMP ta* againstRAGMA] anxUnlock() me ufoxFCLUSIV theing sealation ontrol is an s),  or file  ufoxFCd by the [sqliMufoxo be adj shoudsa
** t or file  ufox_obtained 
** database corruption.
*/mufox:tion.
*/mufox in future releasesLoor the EVFS used Tfilee [sqliAcode will set *Xopaquunle sqlitapi_rlocject.tended to
er a  the ar returnse of te readable. h own usqlite3at tloor the  VFS useds]de is used tended to
TE_FCNT databasshortly after iort , nevertSQLITE_r waMA** used f** impres uniformly* database corruption.
*/api_rlocject.tion.
*/api_rlocject in future releases*
** Nbe filfacec poiods] object anera]_FCNTL_SIZE_HINT] opcoa  tto generateelement isis foLite invokestions .USIVANDLER]cs arele(*xWrit** ar) that tet pointsa and tQLIT,the argument po, UTF-8e unreadission on the do genera,commE_NOod (vse
*ng
n  the the  is imp resinter psthe
** underlying dev ds] object anera_irst page xDevg dev ds] object anera_ the tre xDevg dev ds] object anera_wtre xDevg dev ds] objeuri_e readable xDevg dev ds] objeuri_integere xDevg dev ds] objeuri_a vale xDevg dev ds] objeuri_keye xDevgIOCAP_abdatabase*xWrit** a *ds] object anerads for an open file */
};

/*
**ce File VirtuAect) with a poinunle sqlitde isf this object.
** tes _fileWmake th returnsMac OSX f wrndled the used to o_FULL, but amonglite3_ "de "[sqlitg* totof the arra for the*/
}WIbit "vREF: OSse. Alamong"r data returnsions |^Whendocu reduce f return to r is rol provithey do not
Lite () method tonimpete o the size the dme othe fon 3 */
 ns. The to eer thEl 25SE_FCnter pnl VFS used bRAGMAried. ite3_io_ by ap[sqlisretry ile-control. ite3_io_ nced.hod rohe xul int1with thMac OSX[ods above.5.0* inv[dataof:e.5.0*e.  If ttry anhe the2
thee if Mac OSX[ods above.7.0* inv[dataof:e.7.0*e.ndled tf ttry anhe to igh3ee if Mac OSX[ods above.7.6* inv[dataof:e.7.6]de Ais object by appendi  /* Adds
** that wbounle sqlitde isf thisndled thite3_io_ nced.endi  /*ttry anhrm varnal methodsods aboe3at Mac OSVFSeENoze is thduysis ons ods aghLog] setended tosed fpoinunle sqlitde isf thisalue.  Thtg* tofter  objeten into Mac OSX[ods above.5.9FCsti[ods above.6.0* inv[dataof:e.6.0*intsadley[sqliteite3_io_ by ap, or  if thry anhethey do not
szOs*
** by ap,g.
d *)ended
** firt (or, mCxClose follhandlsed tended to
TL_SIZE_tf "[oint  mxPathtof tg.
d *) that
** angif sed to 
n thtof tgn_tf "[ointhey do Regusemnerate sqlitde isf thi be adk patxSyn linVERW[fileum writby the spepNoxthase.  Tn the vfs.xOpen]
**_regusemnhe [sqladlefs.xOpen]
**_ust gusemnhe e () metholamanags shoullred memoryaesuread-the
ndedn the vfs.xOpen]
**_ thehe e () methosed tearchct.
** lredn tNteger ithAdds
iority iol retng addiosed to o avoid conflistom xFileCo spepNoxthase.  Tnhey do not
pNoxthby ap,g.
d *)that by ap,gnoinunle sqlitde sed tended to
is ththe user lle_FCNT plifdn tthe user lle.
** Tvide a cuoNT plifd should  ap, S encosome othecrite-aheadrridic[mufoxactivity ts
iority iois opcod_FCNT plifdthis will database cone sqlitde sed sf thisoed, ** tsf thiswhether or gusemnernhey do not
z* intd  ap,osomlement of the arra clospluod[VFSes] in 
TE_F invothe iquunacrossVFS stackspluode.te to t[fs.xOpen]
** is forLITE_Fthe useol action, then the zFenerate e readable. his fo[sqlisrteger ie the code willngee** argument poendinrtionsullPathtof (** [sqli_PRAGMA] frt frcumsitiof the strart frcumieand that wbounzFenerate e readabl,3_file] 
to hansfile coa

** er "-"ralubit ofe same algbevntrmd immeaides 11VFSpeaiu rthiradl/it "-"ralubit ofss as ^the usen to r iol action, then the spethe equivalent;
  /* adleunalue.  Tuntilway to n theangesqlitontBthod is will becevhods ele-ced,, returnsior file handleIN32the
** oc()]opcode will set *E_NO numtof tg
** sing testiy ils an he do generaunless it rolledter to a [sqzFenerate e readable. his fo3i andthe code willd tf is fo[sqlTE_FCa prntpcodes lefollowed tneraunleshe do geAGMALITE_FCNTment isiFenerate e readabletement 3_file] ovse
*ng
urnsC foit writ *E_NO 
** te readablele] othrludNTL_FILE_P_IOC_** <lEONCLOS_FNOTFOUNDtabas
** to NULL.
**
**s fon thhrludNsVFS sbcodentegith the ses
** to NULL.
**
*ior file  to _v2ned frOs ntrior file  to ed from [sior file  to 16he e CNTL_Se.  If s
** thhrludNsVFtlues ato t[_FILE_P_IOC_urnsLITE_FC|t[_FILE_P_IOC_CurnE_FNOTFls
**s fon t to sopcdowngread-Red in tf theE_FCN*pOutF
** ttointer rludNTL_FILE_P_IOC_urns.  Thith the
sbcodebas*pOutF
** t  /* AdE_FNOTFOUND^(the user llevse
*nd  to
** xe sesevent a cf
** ttotempo_s fon angesqli,oolean inttay be isf thisif thed sincthe
** underlying dev L_FILE_P_IOC_ */
_DB]lying dev L_FILE_P_IOC_ */
_]]
** T]lying dev L_FILE_P_IOC_nvok_DB]lying dev L_FILE_P_IOC_nvok_]]
** T]lying dev L_FILE_P_IOC_nRANSIENT_DB]lying dev L_FILE_P_IOC_SUB]]
** T]lying dev L_FILE_P_IOC_SUPER_]]
** T]lying dev L_FILE_P_IOC_W T]lyingIOCAer toOUNDtabasowngervao avoid conflisIN32leCo spesf this* poi 
** ttointelocks withnded,it sealation onsacpithFe
** lockiGMA] ts
iority ih the FOUise old vaarrly lockcrashcdes vle contal file (se.  T con [SQt *XopeA] anxject associatecall
**  the
** ttotem CNect assowalloc()]vse
*ng
ll
**se.ndlen er ffoll he database fect assowalloGIN_ATOnto MacLE_P xRea frOs litei avoid conflisse.  Tdes that ight haer to help writes teg avaidoataband -ytes in nderlielure t befoe
** toryaerthe mfrom [da
** ponteguppcodeerva
** availaTvi [d** ee
** uppethe usese.  Tvse
*nd  to
** xe sesevent a cf
** ttotempo_s fofon 3 *the
** underlying device:
**
_IOC_** <lEONCLOS_Flying device:
**
_IOC_NDING], orxDevgIOCAP_oOUNDtabaice:
**
_IOC_** <lEONCLOS_Fcf
**OCAP_SEQUbase. Alrol()] fing se
** are autimit. les tdAGMA fails with _IOC_** <lEONCLOS_Flyinteg avainteg
** tempor to helhe names irfect assArieter  inta nar to helhy pointubect assANOTFOUND^ fails with _IOC_NDING], orcf
**Oi anlded  This
** hanj
** bus
thee if tfails with _IOC_CurnE_Fcf
**ed in "be adboif write he lockassogit mightfaiO_NDIN poinO_CurnEcf
** t and theOSIX o fon angeAPI the other
** _IOC_NDING], ocf
**ed iautpairhar** whichnto MacLE_P_IOC_CurnE_,s_WIN32_AV_Rla write tranase. Alrol()]nlded  invothj shoude.ndled adiimit. hat the Vg
** sallureyter, trNOTFlsmit. <i Applii>IN32_AV_Rla write trbase. Alrol()] ftd sinc invfe
** rlusnt aTvide NOTFOUND^Atlues arszOs*
** isory  ann the snn bytFS migd is generated LENAis ournsior file handletended to
a  the arturnse of  lock NULL.
**
**s fo other bs foLite invise old vAME] re [SQaVFS migh] setended to; theErol()]ds oe a ciimito otNoze is t [SQt *Xbs foLite invTE_FCrol is  ds] object a.p4 iOfst,. h with the a;
  /* ontrol method
** of the [sqlnges.
** thiXbs foLiE_FCd. The tisrt in ntrol  opeA]r messaethe useex isilathen the ds] object a.p4 iOfst Thehe pragmivalent;
  /* afile bs foLIN_ATOMIrsinrdion t ma firt vide a cuoNTm to wor is invos foLsqli.te to t[fs.xOpen]
** iAvide SQLITE_FCNTs
** to NULL.
**
**Avide n t  /* Adls with ACCESS_NDISTS]ted LENally nleshe der, te robuswhen data other thanACCESS_urnsLITE_FCs. The lly tnteger aHowever,  for thet befoe
* theta other thanACCESS_urns]ted LENally tnteger aHowever, etlues ar for the databaer thanACCESS_urnsE_NO 
**ue oriFCNTLes. The N32_Aan. Or, if tE_FCNTL_RBUbase co it is aE_NOtion oat Mac OSV DtabasowngOr, amRBU] opcodeld be  control iertSN32_GEnc metrite per.eeds *Avide Lite invPRAGMA]
** file cona ioi vide  less it is argumentt the VFCNTL_EGIN_ile-coonserva the Vas ntrol   of theh the sesowngde in base conld be  control isrelitgalable z* file co[sqlisrPRAGMA_Se.  If argumenttas menttans that
**t setock)(sqlAV_Rla write
theenteger depending
** on -coovide ** TNOTFOUND^the user llevsded  aVFS mighetlues armxPathtof +1 isory ain disk I/locpmmitunreadnsullPathtof V Dtaba* l thended
** firlocpmmitunrea[sqlisrvse
*a  the arta e readable. hboif * xDeviceCI** firlocpmmitunrea[sqlisrendi
** laensqli* [SQLITE_CANT_IOC]o, then the opGMA_S. Smed, **e s_W[sqlmes thatarta f tola the Vis genera, de ii avoid conflinversion.** tavo used toecevsed ure sbllowing t mxPathtof te char frcciop-lev
** laverwriP_oOUNDtabaxRthe mnde n , xSleepn , xCe top-Tif (*e.ndlexCe top-Tif I vale xDev () metholann bunlo*tricbase le is being
** on avail,voktit e snn inter rludNBUbase cof
** anded to
ry coo avot
*de NOTFDtabaxRthe mnde n 's
** busy ffoll testiy  All nBsory isorysed fpogood-quag argrthe mnde *t setzsqlV Dtabay  All nced.he h the seLes. T* is an advisory advrthe mnde *ument poNOTFDtabaxSleepn Lite invugging.  Thsqlion theatabaso sleepi the t [SQues arol   is an advmicros a delade inAGMA faixCe top-Tif (*[sqlTte invPRAGMA]
a JulionsD /*Nis an nleshe deger pointewrndledE_FCar reta floL, but of thverwriP_oMA faixCe top-Tif I vale lTte invPRAGMA]o reament as a
og] seJulionP_oMD /*Nis an S.)^
**ent lim86400000 (ol   is an advmiwith a dela aE_NOa 24-rsiiluey)s as ^the user lleleCo spexCe top-Tif I vale lTte invorithtshe deger poa nar twrndledE_FCinstead iptor. Or,This capab(g
**te3_io_ Or,2 of [SQg shoursndled ths
** busy to memory unlo** t)s beforwhenFS sble used toxCe top-Tif (*CinsxCe top-Tif I vale l_WINnk is not iOTFOUND^ faixSetSve petualn , xGetSve petualn , ndlexNllySve petualn v () methol lock  bunloTL_SIZE_tfnsMac OSX f wV DtabsePRAGMA] fr () metholann bchL_TRAc invoytfile con* ttotethrg amigh]abilitthe arra clo silenBy and so
rnsfile availaoragmaion on
** busshe usepcoded for t,
**fostresence tSN3file iS.)mighead Lhe nam the VFCns obje* maximusion.he fi** cuvaidifrccd La cuoNTi ass
** eAV_Rla uc V DtabaRITE]fe availaoragmaVE])
iN32_GEand so
dfo[sqlumth wthat ito
*ser ighanhe fifile reat ito
*ods abov ma firtam
*ser ighdisk I/tagede Apriority invVE])
leCo spsee () metholamE_FCNT er generaargumeya cuoNTFS s ma fisee () metholasting
ent 3on nleshe irfbeAMEanges.elocks endinrtioto
*rele* in orol   agede Apriority invmE_FCile iffoll he dTvide a cun er ma fiseeon 3 */
ntrol  *te3_io_ he arra clooulls uer oove.ly* database corruption.
*/de ition.
*/de ; databaseee()](*ds] obje avorag_ptrfuncti);
 corruption.
*/de i{
  le spte3_io_;SQLITE_IOCAP/o Manded to
ods abov is an (he top-lev3)e_ab  le sszOs*
**;SQLITE_IOCAP/o Mnded
**t (or, mCxCle sqlite3_fi_ab  le smxPathtof ;LITE_IOCAP/o Mthat
**e3_fin thtof t angif _ab  tion.
*/de i*pNoxt;_IOCAP/o Noxthr gusemnera clo_ab  *xWrit** a *z* in;E_IOCAP/o Nof the aroulvREF: OSse. Alamongo_ab  nvokedpAprD to;LITE_IOCAP/o Phis opcode priority i-ile in car toi_ab  le s(*os fo)(tion.
*/de *, ds] object anera
z* in, ds] object a*,
TLITE_IOCAP    le ss
** , le s*pOutF
** );
  le s(*oDe
** )(tion.
*/de *, *xWrit** a *z* in, le s datDir);
  le s(*oAvide )(tion.
*/de *, *xWrit** a *z* in, le ss
** , le s*pk)(sql);
  le s(*osullPathtof )(tion.
*/de *, *xWrit** a *z* in, le snsql,t** a *zsql);
  nvoked(*oDls fo)(tion.
*/de *, *xWrit** a *zFenerate);
  nvoke(*oDlEthe )(tion.
*/de *, le snBsor,t** a *zEthMsg);
  nvoke(*(*oDlSym)(tion.
*/de *,he ar, *xWrit** a *zSymbol)functi);
  nvoke(*oDly to )(tion.
*/de *, he ar);
  le s(*oRthe mnde )(tion.
*/de *, le snBsor,t** a *zsql);
  le s(*oSleep)(tion.
*/de *, le smicros a del);
  le s(*oCe top-Tif )(tion.
*/de *, dou* er);
  le s(*oGetLs aEthe )(tion.
*/de *, le ,t** a *);
  /*
  TFDtabaon 3 */
abragmful in
ods abov1 fpoinunle sqltde isf thi
  TFD objeicular dTistentranaseventsnn byddNBUbasods abov2 ofticalr
  T/
  le s(*oCe top-Tif I val)(tion.
*/de *, ds] objea val*);
  /*
  TFDtabaon 3 */
abragmful in
ods abont1w two  fpoinunle sqltde isf thi.
  TFDtao cuvaentsnn bnlesods abovew twog shour.
  T/
  le s(*oSetSve petual)(tion.
*/de *, *xWrit** a *z* in, ds] obje avorag_ptrf;b  tion.
*/ avorag_ptrs(*oGetSve petual)(tion.
*/de *, *xWrit** a *z* inf;b  *xWrit** a *(*oNoxtSve petual)(tion.
*/de *, *xWrit** a *z* inf;b  /*
  TFDtabaon 3 */
abragmful in
ods abont1wsursqlit3 fpoinunle sqltde isf thi.
  TFDNew by appi  /* Adds
** thaal methodsods aboentrol. ite3_io_
  TFDnced.hle] othrr pragmiITE_FCNTmeisph to as.
  T/
} in future releases*
** tnleshe d*Avide Ltackss for thOTFDtabss to be sy*xWriaite3IN32_GET_HANarturnse of tics methods. Thehe d*Avide Lite invokesn ,X) must be
**an [sqlite3_yng.  The P
theenanaktheaoccut do not
sehe d*Avide Lite invoullook a cfPRA**  W if Macith ACCESS_NDISTS,ehe d*Avide Lite infile iSplyr kResseenteger ng
** on er, trNOTFlW if Macith ACCESS_urnsLITE_,ehe d*Avide Lite infile kResseenteger ng
* amRBUwrite perme sboif  for thet befoe
* thefile(t bhe filwordscontre WAL SN32_GEnddNB,iy ifile h befr not t databa Thehe dwrite per)mly across all pACCESS_urnsLITE_y*xWriaite-cohe top-levT_HANRed iis ed. [SQLfoll_oc()]_write permurs at*e.  sqlit*by thsion.locks w] opcdud tosed rele* inat Mac OSVFSeEW if Macith ACCESS_urns,ehe d*Avide Lite infile kResseenteger ng
*owever,  for the databaer thanACCESS_urnsy*xWriaite-cfile e top-levTnTL_Se.  sqlitl to the2_GET_HAN] opcdud to rele* inatuppethe us.P_about the differeACCESS_NDISTS    K              0xACCESS_urnsLITE_y1CAP/o UL_SIZE_nternalfoll_oc()]_write perm_about the differeACCESS_urnsyyyyyy2CAP/o UnTL_Sm_abn future releases*
** tnleshe d*d volatitackss for thOTFDtabss to be sy*xWriaite3ut the he dumthods radeto o_FULL, or all aame algbevhe d*d volatiite invokeontrol method
** of n the filesevent a ca immediRed iitgalcoo bent aboe3at f
** ttotempfile*d volatiite inthe
** underlying dev         HM ]]
* |         HM ase filying dev         HM ]]
* |         HM NDING], olying dev         HM UN]]
* |         HM ase filying dev         HM UN]]
* |         HM NDING], olyingIOCAP_oOUNDhe to befor** ried. tam
*ase fillesNDING], ocf
**amE_FCNT ** a*ent ar ret or de in oase co p[sqlite3_fi radeiP_oOUNDtabaxd volatiite invSN32fter  objetmake tht before h befase fille invotke tht before h befNDING], oCLUSIV
** reafter  objetmake thtase filyin befNDING], oCP_about the differe HM UN]]
*                      0x HM ]]
*         YNC_NORMAL        HM ase fiCAP    4NC_NORMAL        HM NDING], oc QQ  n future releasesMthat
**xd volatiinolxP_oOUNDtabaxd volatiite invon ontrol method
** of t  /*leCon arra invotke tht0sndled r, uppe
sbevertaile
**"offset"* pointed ly across a OSX f wrr lleE_FCNTiffoll he dTvqu somlielule* innc me
** beuts opehe aroulrcks enabout the differe HM N]]
*       Q  nn future releasesIthing.  Cacross a OSXLibr  By dOUND^ faids] objea hing.  C() rlocjecnything.  C stack, ts a OSXlibr  BAGMA faition.
*/ hutdown() rlocjecing seaVFS migs file coourc** maximuen bytFS migd is ds] objea hing.  C().OTFDtabss rlocject.ers oeses in e dTiAN] oes is uea hing.  onflis be [SQ hutdownvon ls addNBUlamongentrWorksconflisapriority inva
** k, ts a OSX tQLITntros unloing t (*)(void teger i ma fiseerlocjectiP_oOUNDAtequesteQds] objea hing.  C() -coons"effed fve"tequesg
** sir returns SleteSE_FCns] objea hing.  C() -coTL_OVERWThis cap** lrfeSE_FCNeh the serocess ortrsg
** sirturns SleteSE_FCns] objea hing.  C() -coTL_OVERfilesevent a catequesteQds] obje hutdown()[VFSeOalds b effed fvetequesed fpons] objea hing.  C() ise ofilea hing.  onfli* the RBU extoragm lock  b* amls uell
**s.er toOUNDAtequesteQds] obje hutdown() -coons"effed fve"tequesg
** sirturns Sletfile questeQds] obje hutdown() amed, ** tls arss] objea hing.  C().VFSeOaldlyin b effed fvetequesteQds] obje hutdown() ise ofiledea hing.  onfli*OUNDAe RBU ext
  /* oragma] dds] obje hutdown() k  b* amls uell
**s.er toOUND faids] objea hing.  C()  () method toheatabthe
,voktids] obje hutdown()[sqlisrendV DtabaRs] obje hutdown() -() methodmE_FCRed ii [sqlit reat iafile i* er heatab* the RBcontrues are changed for ]amE_FCNT les td.ndlenuesed fU exts a OSX coourc** mE_FCNT seaVFS migd changes.oTL_OVrnsfile s] obje hutdown()[ toOUNDAmoo o_eger ng** u, ^ds] objea hing.  C() le] oth_OVEfile s] objeosea hi().VFSimilarly, ^ds] obje hutdown()[sqlle] oth_OVEe s] objeoseehehe.y dOUND^ faids] objea hing.  C() rlocjecnPRAGMA]
** file cona ioi vide f the strnless it rolled,Cns] objea hing.  C() -couna* eAV_Rlahing.  Ch the selibr  B (pe
h t to indiuna* eAV_RaVFS migheoing edX coourc*Cnterlyin se [mufox)** should besn , the VFCNT]turns
** any result cod.y dOUND^ faids] objea hing.  C() rlocjecny thelit rrol opcode is mn er ith the s a OSX () methola,of SQLitisapriority iIN3. The ise old ving t (inter _OVEe s] objea hing.  C() irite heithFe
** lockiGMior file  to ed fromoragma s] objea hing.  C() ted to s a OSXlibr  Bmivalent;auto procntee thaything.  CxC iautior file  to ed ny thelit rr
** shor  if her oything.  Cxall aalurey.VFSHe avbl,3_f s a OSX  tSQLITE_dee if tfails with _** TtUTOINIT fromoQLITE_USE_FCNTL_TR htf it retauto proc oragma] dds] objea hing.  C() lock  botransacndled thapriority iImE_FCeques s] objea hing.  C() irite he locchanges.oa
** tn er ith  s a OSX () methoithFe
* that
**and pArg ar, reto indict anm** thatSQLitpriority invvsded  r _OVEe s] objea hing.  C()
 metrite if
*hanges.oa
** tn er ith  s a OSX () methoithFud to rele* iysed fpothe usesale cqu somarouCLUS bhe filwordscoe co eAMEangeexhibi pointsy needs  OSX  tSQLITE_dee if ls with _** TtUTOINIT to the2_G and thaing seead Lo eAMEangei** imprdud to rele* inat Mac OSVFSeOUND faids] objeosea hi() rlocjecnise o_FULL, bu-lamongoile in c thaything.  RAGMA] and ths a OSXlibr  BAGM faids] objeoseehehesed rlocjecnverong.  Theffed  fpons] objeosea hi().VFTypocnt taskGMA] eimum writbevhe ss rlocject.r rludNTaVFS miulaf reseaVFS mibus
thefponridic[ coourc**,aything.  RAGMA] anglobnt ld initi , invowing t uphaereead Lo,X) must be
**spluod,controlng t upE_NOa reead LoETRY] opity iIN3** t or file ETRY] ned 
*eOUND faits
iority iois opcod_FCNT)(void teger ins] objeosea hi()a cuoNTds] objeoseehehe irite heith faits
iority iois opcod durch_OVEfile s] objea hing.  C() points] obje hutdown()[VF faids] objeosea hi()
Dev () methony thelit rauto procntee is ds] objea hing.  C()s be [SQ s] objeoseehehe y thelit ris ds] obje hutdown()[VFAproc*haite
thei avoid conflinvfo ins] objeosea hi() points] objeoseehehesed e adbit i*t setthe user autimit. lQLITE_defo iUnix, Winoow ortrsOS/2.OUNDhe to[If it rbit ds |dbit i*fo ihe files unifor from(a
** tempols with _S_OTHER=1 [SQLITE_USE_Fa cuoTL_TR)ed thapriority iImE_FC** a*ychar 
* theei avoid conflis returnns] objeosea hi() points] objeoseehehe[VFAne priority i-i* a*ent
thei avoid confli fpons] objeosea hi()uoNTds] objeoseehehe
themE_FCy  All ** file cona ioi vide  pointemeturns
*, the VFCNT]tupus
them to woCP_abdiffereAPI le s s] objea hing.  C(ncti);
differeAPI le s s] obje hutdown(ncti);
differeAPI le s s] objeosea hi(ncti);
differeAPI le s s] objeoseehehncti);
n future releasesCTRY] op** tcross a OSXLibr  By dOUND faids] objeETRY] nev () methony tN32_AV_R contglobnt ETRY] opity ifile kue. sere s a OSX (ly after itunoss a OSXt wbounlle in caing teNeh the se priority i[VF faireead LoETRY] opity iIndict anm** thabytesoetfiletpriority invvointed tndiclocjecny tN3. The ld vinide   BAGMI sir retchL_TRAca] dd* and  rnn bypriority inve if TnTL. T* ng tA** upperb> faids] objeETRY] nev () methony tendingatabthe
.h faits
iority i
themE_FCens to
is thnor ith  s a OSX () methoceful in* file-co ith the ngatabt, S encds] objeETRY] nev dicuntrol.</bAP_oOUNDtaba Sleteo NULL.
**
*ds] objeETRY] nev diment as a
 [SQLETRY] opity iIoTL_TR]
is thg.  The Ps
theenanaroc*erty fpothe usea anting
ETRY] opcb* tSe",en intao NULL.
s
thev  Bmolean inttay be iLETRY] opity iIoTL_TR]
Dev (turns Slete pointed ly 
DevFytesoet ETRY] opity iIoTL_TRscoe cods] objeETRY] nev () metho
themype ed ii [in* file*hanges.olibr  Bmything.  RAGMA]a
** k, t[ds] objea hing.  C()]uoNTFfile  hutdownv-co[ds] obje hutdown() activity ned paMA] frETRY] opity iIoTL_TRsstead iNDLER]
** fileQLitiy SE_Fa cue adjelit r"his E_FCETRY] opity iIoTL_TRs"f the strds] objeETRY] nev dihelit rafile [ds] objea hing.  C()]uvointted ik, t[ds] obje hutdown() e file hanleteo NULL.
**ing theile i this E_FfromoQRY] opity iIoTL_TR htf it retds] objeETRY] nevequesefault, All other VMISUSEVFSeENoze, he avbl,3*ing ^ds] objeETRY] neveqnii [sqlit rasle is being

thei avoid confli fpotisapriority i-ted whetior file  sea hi()d.y dOUND^he toamoQRY] opity iIoTL_TRV tonte,tds] objeETRY] nevPRAGMA]
** file conf the strmediRTL_TRV tounknownvorothe usea auna* eAV_Rrol is  RTL_TRh the snd tndiclocjecnPRAGMA]
a argumentt, the VFCNT]CP_abdiffereAPI le s s] objeETRY] nle ,t...);
n future releasesCTRY] opodues are changed fors
theMETHOD:s s] objy dOUND faids] objedbeETRY] nev () methony tN32_AV_R contETRY] opity ifile kue. sere atrues are changed ford from [ () method tonimilarste [SQLor file ETRY] nedlned patthen the  kue. sea a*yce chari* er [SQLues are changed ford (lle in NBUbase coanleteo NULL.
)VFSeOUND faidld be  control *
*ds] objedbeETRY] nD,V,...) sirturn [SQLdiffereDBCONFIG_LOOKASIDE |doQRY] opity iIvblb] -ument as a
*cplazerof write writeseenanaae isi] and thLues are changed ford e sbf theETRY] opcb*the se",en intao NULL.
sev  Bmolean inttay be ioQRY] opity iIvblb.y dOUND^Cragma] dds] objedbeETRY] nevt, All other VOKat an sed durckh the seequesgs hansfdmnerat [ide sisCP_abdiffereAPI le s s] objedbeETRY] n s] obj*, le se ,
...);
n future releasesM the sAVFS miulafRlocject toOUNDAect) with a poini isf this object.
** tes _fileWmake th generated n seULL_IO] opn the snVFS miulafrlocjectiP_oOUNDTni isf thisi  This
** d durto
* the Ubase cos a OSX () methoiOUNDAtts its argument  with a poini isf thisirturns control *
 [SQLor file ETRY] nedlwf it retoQRY] opity iIoTL_TRV t [SQLdiffereCONFIG_MALLOC]a other thanCONFIG_GETMALLOC]iOUNDByhj sho** tn nt  with a poini isf thited n sea  t** ti
**
*ior file oQRY] ](LdiffereCONFIG_MALLOC])
 metop** toQRY] opity iGMA] ts
iority ieIN32tle inds b all opc fve
them the snVFS miulaf
** availaforothe uses.oa
oi the S s mai
s
thedynapleam the s ng tA** uppeNoze is ths a OSX fmenve if savbl fr[ it is aem the snVFS miorr fromght harrleimute if
aden migheleshe dmap. helmg t majo fix fpotpriority inted n sethen thi isf thisirtd dura
osiste chao**y mg o fix fpotpriority inted e if s is im  CxCn the snVFS miulafrcqu soLL.
sntrol issf thisirall aasoent.  This capabilit fpothe usea(ly after itle inds b all opc fve
them the snVFS mioSIVE])
 iS.)migsem the sloc-ofon the sFCns obje* ba They after iap.ifd sh ths a OSXdes vles grthosisldseat interlyinFCns obje*iP_oOUNDtabaxMnVFS , xRenVFS , ndlexFrebaon 3 */
mE_FCort ,likd thaing mobtaine,iy obtaineile reaeen 's
** buswthat it ise*/
}ard CXlibr  BAOUND^the useol action, then the dld be  control *
OUNDxRenVFS Oi anlded  aDnced.h opGMA_S the e*hangeequesteQxReverupiP_oOUNDxMndedon only.  All urns VFS migd ended
**aCn the snVFS miula retchevhodsdurtment poinrtionMnVFS      RenVFS ith faitVFS migd ende
**Oi anlded  atlues arhethigNarturnsrcquabigd endedoktiiNDLER]
** lTnhey do not
xReveruplTte invPRAGMA]
waximusion.ng
urns VFS migd ended
*E_NOa n the snVFS miulafde in hecrite-aheadrcquabigd endeithMoet n the all aaFS miorr nevertuplTtthe snVFS miula  atlues ar orol   age S.)^
**osed fpo8* tSemetaaFS miorr nevertuple cha
** lT S.)^
**olnges.
pcodwr i ma2.OUNDEvle cn the snVFS miulafrcqueet ETmg t base rsqlit or file  obtaineda cuoNT or file y obtaine]oanleteoragmaxReverupible zxReveruplPRAGMA]
0,fromght hugging.  Thsp[sqlite3_fi n the snVFS miulaftotetilnhey do not
xIthiLite invothing.  C stacem the snVFS mioSithFe
** lockiG reto ise.  TvsFS mighenle cqu sod[mufoxe  lesothing.  Crrol opcodues turnnanded toentrol. xShutdownvite invoul
** file(te wite he)tby the[ds] obje hutdown() evointn onlyseaVFS mig file coourc** Tvqu soc invoytxIthintrol. pAprD toy to memory T_HANarturnsd durics methods. ThexIthiLndlexShutdown
** uppethe useosomlementLdiffereMUTEX_STATIC_ */
][mufox:r autimit** fir returnsxIthiLite in, ted to xIthiLite inving t read-ongatabthe
.hthe filexShutdownvite invould dursqlit reat i[ds] obje hutdown() etedit frar retendiing t (*d-ongatabthe
 teger ithFe
*ae RBU exton 3 */, generated osomlementLdiffereMUTEX_STATIC_ EM][mufox:as rangNarturn [SQLdiffereCONFIG_MEMSTATUS]moQRY] opity iIoTL_TRV topGMA_S TRV( in "batcimit. byireead L)vvointed tbaon 3 */
art;auto procntee dlr im  Cx.OUNDHe avbl,3_f LdiffereCONFIG_MEMSTATUS]mt. disa* ed htf it ret ith the on 3 */
mE_FCd-ongatabthe
 e
**lseeoakd thaires learrcks LL.
se returnnlr im  provithey do the user lled_FCNT)(void xIthie lTd immeaisoed, e that ument asr in** k, tequesteQxShutdown()[ t* database corruption.
*/memod
** ofption.
*/memod
** of;
 corruption.
*/memod
** ofp{
  nvoked(*oMnVFS )* to);LITE_IOCA/o M the snVFS miulafs
** busy_ab  nvoke(*osaee)The ar);LITE_IOCAP/o Freba e*hangenVFS miulaf_ab  nvoked(*oRenVFS )*he ar, to);LI/o Reended b alFS miulaf_ab  le s(*oSnde)The ar);LITE_IOCAPI/o Re All urnsended
**ab alFS miulaf_ab  le s(*oReverup)* to);LITE_IOCAI/o Revertuplrcqueet endedV_RaVFS miulaf
nded_ab  le s(*oIthi)The ar);LITE_IOCAPI/o Ithing.  Catacem the snVFS mioSy_ab  nvoke(*oShutdown)The ar);LITE_I/o Deithing.  Catacem the snVFS mioSy_ab  nvokedpAprD to;LITE_IOCAPLITE_I/o A NULL.
**
**I hi() poinxShutdown() T/
} in future releasesCQRY] opity iIOpty inted KEYWORDS: {oQRY] opity iIoTL_TR}
thOTFDtabss *xWriaite3a immediThis capabto be sy*xWY] opity iIoTL_TRssteadk, teqn*ng
n  the arturns Slete control *
*mentLor file ETRY] nedl () methoiOUN
theMosi] and th*xWY] opity iIoTL_TRssfo ins] objeETRY] neted e lle.
** ort ,r
**n* file*hanges.o[ds] objea hing.  C()]uoNTFfile the[ds] obje hutdown() V Dtabasew ned paMA] ttotem CNruod e adjelit  the"his E_FCETRY] opity iIoTL_TRs"f the Cqlion tLor file ETRY] nedlwfile hanleteo NULL.
**ing theile i ted n s E_FCETRY] opity iIoTL_TR basmake th oragma] d[ds] objea hing.  C()]uvoi the[ds] obje hutdown() ei and the **ing PRAGMA]
other VMISUSEVFSeOUND faidlle coais E_FCETRY] opity iIoTL_TRsteqn*locks w(bBmytnlrty inted n s/ reselety in)inrtioto
*rele* infpothe use orol   agedOUNDA oat Mac OSsods above.42.0,nd th*x avot
idlle coais E_FCETRY] opity i
*d fo forceisthe
underlying devdiffereCONFIG_LOGlying devdiffereCONFIG_Pfine _HDRSZlyingIOCAP_oOUNDNew ETRY] opity iIoTL_TRst  /* Addd thaal methodsrele* iynat Mac OSVFSeEEr, t** toQRY] opity iIoTL_TRst  the2_GEdisd foinucb* tApriority inted tn only kResturnsrc All FCNTLeat i[ds] objeETRY] nedlV_R conts to
is th the seequesort control. Lor file ETRY] nedl () methosefault, All a retengumentt, the VFCNT]at anEdisd foinucbuoNTund* and o uNURY] opity iIoTL_TR
**Oi a*n* filA** upperderlyin[LdiffereCONFIG_SINGLETHurns]]erdt>differeCONFIG_SINGLETHurns</dt>upperdd> fareck  bunao NULL.
setotem CNoTL_TRAGMA f CNoTL_TReE_FCNurn [SQLngatab_fi nCNT]are si* er-heatab* tS bhe filwordscoit fisa* e all aam[mufox** tn le*utsos a OSX ().
pc pla wN_ile-)
iN32 ed ii [usoc invoytae i* er heatab* te strds  OSX  tSQLITE_dee ifh the seLdiffereTHurnsefin |        THurnsefin=0 [SQLITE_USE_FNoTL_TRetf ibatcimit. enditss
** eAV_Rlocks withnLngatab_fi nCNT]aeat iite3ut ad La cuument is si* er-heatabvvointedLor file ETRY] nedlwfault, All [SQLdiffereERROR]at asqlit re if tfaidiffereCONFIG_SINGLETHurnsfromoQRY] opity iIoTL_TR.</ddAP_oOUND[LdiffereCONFIG_MULTITHurns]]erdt>differeCONFIG_MULTITHurns</dt>upperdd> fareck  bunao NULL.
setotem CNoTL_TRAGMA f CNoTL_TReE_FCNurn [SQLngatab_fi nCNT]are M.)^
-heatab* tS bhe filwordscoit fisa* e all mufox** tontrues are changed for evoin[er generanrid LL.
le for tWactivity ts
iority iondictlite
** eAfo inlr im  ** tnd of tho [SQLues are changed fors evoin[er generanrid LL.
f n tBktiNU extoufoxe 
 cue adero-dada,of SQLithe user lleNT *he
 s.oa
oi] opcm.)^
-heataboc invenvirontrol is rangNartntrfwo ngatabt,iffoll he dleCo spesbe filtrues are changed for evto spesbe  SE_F.te strds  OSX  tSQLITE_dee ifh the seLdiffereTHurnsefin |        THurnsefin=0 [SQLITE_USE_FNoTL_TRetf ibatcimit. enditss
** eAV_Rrol is  M.)^
-heatabQLngatab_fi nCNT]avoi the[ds] objeETRY] nedlwfault, AllQLdiffereERROR]at asqlit re if tfa do thefereCONFIG_MULTITHurnsmoQRY] opity iIoTL_TR.</ddAP_oOUND[LdiffereCONFIG_SERIALIZEs]]erdt>differeCONFIG_SERIALIZEs</dt>upperdd> fareck  bunao NULL.
setotem CNoTL_TRAGMA f CNoTL_TReE_FCNurn [SQLngatab_fi nCNT]are slr im  Cx.US bhe filwordscoe  CNoTL_TReero-da all aam[mufoxct.r rlud** temporeAGMAfve
themufoxe  lntrues are changed for evoin[er generanrid LL.
le for tWactivInd tndi pla ( in "sirturnsreead Loy needs  OSX  tSQLITE_dee if [SQLdiffereTHurnsefin=1])d to s a OSXlibr  Bmivaleiteelf dlr im  CdTvide a cu] d[ues are changed fors evoin[er generanrid LL.
f a,of SQLiurn [SQts
iority iondieaeehe dleCo spesbe trues are changed for ein disk I/sbe trer generanrid LL.
le] odifrerL.
**iatabt,ifo spesbe  SE_F.
the strds  OSX  tSQLITE_dee ifh the seLdiffereTHurnsefin |        THurnsefin=0 [SQLITE_USE_FNoTL_TRetf ibatcimit. enditss
** eAV_Rrol is  slr im  CxQLngatab_fi nCNT]avoi the[ds] objeETRY] nedlwfault, AllQLdiffereERROR]at asqlit re if tfa do thefereCONFIG_SERIALIZEsmoQRY] opity iIoTL_TR.</ddAP_oOUND[LdiffereCONFIG_MALLOC]]erdt>differeCONFIG_MALLOC</dt>upperdd> ^(TfaidiffereCONFIG_MALLOCNoTL_TRetconstae i* er o NULL.
* in "sirE_NOa ts its argument  with a poin,  or file  emod
** ofletended toactivity t NULL.
*lle in N all aal opc fveeULL_IO] opn the snVFS miulafrlocjectt (*d-oThis
**  the UNeh the sen the snVFS miulafrlocjecttbit i*t setthe us.)^D^the use consbatcimdes le*havaOSX fpy] and th*xWLbuia poin,  or file  emod
** ofletended to invoted i*mentLor file ETRY] nedlequesPRAGMA].</ddAP_oOUND[LdiffereCONFIG_GETMALLOC]]erdt>differeCONFIG_GETMALLOC</dt>upperdd> ^(TfaidiffereCONFIG_GETMALLOCNoTL_TRetconstae i* er o NULL.
* in "
**Oi an ts its argument  with a poin,  or file  emod
** ofletended toactivity  or file  emod
** oflturnnanded toondieilit re if tfai e top-levted whetn the snVFS miulafrlocjectier to  f CNoTL_TReIN32_GET_HANrgu vleloorturnsreead Lon the snVFS miula retrlocjecttwfile hwrappe
sVE])
 iS.)migsem the snVFS miulafs to wor  the nraessem the susage,vfe
** locki. </ddAP_oOUND[LdiffereCONFIG_SMALL_MALLOC]]erdt>differeCONFIG_SMALL_MALLOC</dt>upperdd> ^TfaidiffereCONFIG_SMALL_MALLOCNoTL_TRetconstae i* er o NULL.
*Neh the poile ,t its er thatarta integered in "bntroru bchL_TRArta hiol *
OUNDthe use  adiimilrol()]nnvoke
** laTtthe snVFS miula  ntrtss
** e. do the user lleruafs smemor
** sirteaeehe d cont
** laTtthe snVFS miula G retoktidemetapriority invm the2er fs arguruafsldwr iinl Vlocks w returnol action, y lockTtthe sfrs ad confli ght harrless
** eAr
*
** lall aaFS miula  arecknvokcontrolisphinmit. enQLITntroff.lyingIddAP_oOUND[LdiffereCONFIG_MEMSTATUS]]erdt>differeCONFIG_MEMSTATUS</dt>upperdd> ^TfaidiffereCONFIG_MEMSTATUSNoTL_TRetconstae i* er o NULL.
*Nehe poile ,
**Oiits er thatarta integered in "bero-da f resisa* e nd th*xlitcnfli fp
them the snVFS mi_TReEconfstics. ^(he tom the snVFS mi_TReEconfsticssnn intedisa* ed htf esevent a cs a OSX () methoce_G and engu_FULL, oralthe
u underlyin ng devior file hard_heap_limivale ]lyin ng devior file m the _T_HAe ]lyin ng devior file m the _h thwaemnhe [sql ng devior file soft_heap_limivale ]lyin ng devior file Econusale ]lyin ngIOCAer to ^M the snVFS miulafEconfsticssnn dero-dadabyireead Lt beof tds  OSX  fromoQLITE_dee if ls with DEFAULT_MEMSTATUS]=0iinl in "bC foin the all aaFS miulafEconfsticssnn ddisa* edabyireead L.lyingIddAP_oOUND[LdiffereCONFIG_SCRATCH]]erdt>differeCONFIG_SCRATCH</dt>upperdd> TfaidiffereCONFIG_SCRATCHIoTL_TRV tounarangr iunhetheyngIddAP_oOUND[LdiffereCONFIG_PAGEfine ]]erdt>differeCONFIG_PAGEfine </dt>upperdd> ^TfaidiffereCONFIG_PAGEfine NoTL_TReEle in N Oa n the spnteh the  ths a OSX N32leCoeleshe dues are cand X Nchere if tfaireead Ltand k, teqcheri avoid confli. to  f CNoQRY] opity iIoTL_TRV tond the *ipotisapriority i-ted whetand k, teqcheri avoid conflivoulloaboc a
** tempols with CONFIG_Pfine 2]iP_oMA fareck  bngateao NULL.
setotdiffereCONFIG_PAGEfine :DAtts its argP_oM8-isor ytes in n the s(pM t), urnsended
**el 25and X Ncherljecn(sz),ted n srol   is an adv Ncherljecs (N)mly acrossz t NULL.
*lhsion.ng
urnsended
** fir
** lstdues are cand ly a(pcodwr i mafwo make th 512 n sr65536)  tutonimpl VFra isory ain el 2ly aand XhtaborAGMA fai is an adv VFra isory ing edXbevhe dand Xhtabor
, teqn*ng
g.  The Pdsa
** t differeCONFIG_Pfine _HDRSZnf the smit. * amls u,sap is hat it iswabigd n the ,ted eleshe dsz e readable. hbR]
** lTmmeaisinide   BAGMol. pM t
 cue NULL.
*mE_FCd-oteger ie the code willngen ts its argumen8-isorall aaes in b
** beann the s coatlues arsz*N isory,.he fi** cturnne",en inta eAMEangeishe usft poNOTFD^he topM tory unlo** t, the user lle*trivehe dleCo spen the sphL_TRAc invV_Rronfsfy5and X Ncher ng t,enFS ** tile (] d[ds] obje obtainedrckh tha5and X Ncherljecnoull** lTmmeaissz isory amor
*FS s ma fiopM totunrea[sqlisrexhaubigd.
the strpM tory the cn srNory ungument htf itel 25ues are changed forintedse ofisothing.otulksnVFS miulafsamoand X Nchern the all eat i[ds] obje obtainedrr frcciop-fsamoNv Ncherljecs r
*Nory essi fveereturn ma-1024*N isory r
*Nory negc fve.e strais objectly aand X Nchern the ory neg edXbey be wing thechL_TRAcabevhe dothing.all aaFS miula htf itthe useooes(] d[ds] obje obtainedrs genaemldsein el 2ly aais objectv Ncherljec. </ddAP_oOUND[LdiffereCONFIG_HEAP]]erdt>differeCONFIG_HEAP</dt>upperdd> ^TfaidiffereCONFIG_HEAPNoTL_TReEle in N Oa rridic[m the otunrea[sql SQLithe user llea
oi the S s mai
sedynapleam the snVFS miulaf ng t invoty be tao cuchL_TRAcafe Vis LdiffereCONFIG_PAGEfine ]iP_oMA faidiffereCONFIG_HEAPNoTL_TReould durThis capabttrds  OSX  tSQLITE_dP_oMe if teger iLdiffereENABLE_MEMSYS3]a other thanENABLE_MEMSYS5]h befr AGMA] [SQLdiffereERROR]at a*n* filehe fi** ciP_oMA fareck  bngateao NULL.
setotdiffereCONFIG_HEAPthe
uAnM8-isor ytes in ode will set * n the ,ted ol   is an advisory rno spen the stunreae.ndled t mg at
**aVFS miulaf
ndef the strmedianleteode will( spen the spde wil)ory the  htf itthe usecevsrt a cu] dut** ti
ssreead Lon the snVFS mioll( spe availa obtaineri avoid confli),ted vero** tn er*hange*n*  miulaf f LdiffereCONFIG_MALLOC]i e strmed
them the s to memory unlo** thtf it retaal opc fveen the all aaFS miorlisrengagHANrgumes the S s mathe ussem the snVFS miulaf ng tA** Dtaba Sleteode will( spen the spde wil)omE_FCd-oytes in rgumen8-isorall beverae contne",en inta eAMEangeat Mac OSsr lleNT e usft poNOTFDT t mg at
**aVFS miulaf
ndev diheppileQLi2**12. Rolledcapabn arra inveleshe dmg at
**aVFS miulaf
ndevk  b2**5se rsqlit2**8.</ddAP_oOUND[LdiffereCONFIG_MUTEX]]erdt>differeCONFIG_MUTEX</dt>upperdd> ^(TfaidiffereCONFIG_MUTEXNoTL_TRetconstae i* er o NULL.
* in "sir a retts its argument  with a poin,  or file  ufoxod
** ofletended toactivity t NULL.
*lle in N  aal opc fveeULL_IO] opnufox:rlocjectt (*d-oThis
**Oii  the UNeshe dmufox:rlocjecttbit i*t setthe us.)^DD^the use consoamoQpy] ated ol  *xWLbuia poin,  or file  ufoxod
** ofletended tovoted i*mentequeste the[ds] objeETRY] nedlPRAGMA].e strds  OSX  tSQLITE_dee ifh the seLdiffereTHurnsefin |        THurnsefin=0 [SQLITE_USE_FNoTL_TRetf ibatce sebui sommufox** t
** availaouldtransachat it isbit d.ndlehe roboragma]  the[ds] objeETRY] nedlwfif tfaidiffereCONFIG_MUTEXNoQRY] opity iIoTL_TRVle] 
to t, AllQLdiffereERROR].</ddAP_oOUND[LdiffereCONFIG_GETMUTEX]]erdt>differeCONFIG_GETMUTEX</dt>upperdd> ^(TfaidiffereCONFIG_GETMUTEXNoTL_TRetconstae i* er o NULL.
* in "
**Oi an ts its argument  with a poin,  or file  ufoxod
** ofletended toahthe file or file  ufoxod
** oflturnnanded toondieilit re if tfai e top-levted whetnufox:rlocjectier to  f CNoTL_TReIN32_GET_HANrgu vleloorturnsreead Lonufox:aVFS miula retrlocjecttwfile hwrappe
sT_HANrgunraesonufox:usagefsamoaimum with  rettroeil** torapabilit,vfe
** locki. te strds  OSX  tSQLITE_dee ifh the seLdiffereTHurnsefin |        THurnsefin=0 [SQLITE_USE_FNoTL_TRetf ibatce sebui sommufox** t
** availaouldtransachat it isbit d.ndlehe roboragma]  the[ds] objeETRY] nedlwfif tfaidiffereCONFIG_GETMUTEXNoQRY] opity iIoTL_TRVle] 
to t, AllQLdiffereERROR].</ddAP_oOUND[LdiffereCONFIG_LOOKASIDE]]erdt>differeCONFIG_LOOKASIDE</dt>upperdd> ^(TfaidiffereCONFIG_LOOKASIDE oTL_TRetconstfwo o NULL.
sets thg.  The Pbatce sereead Loended
**[lookas open the na ioel 25rues are changed ford ** Dtaba Slete control isrdisk I/snded
**el 25lookas opetunreadslnlo("sz").ndled t dld be irturns is an adk I/slnl  aVFS migANrguel 25ues are changed foro("cnt")ier to ^(thefereCONFIG_LOOKASIDE E_FCNurn <i reead Llii>Ilookas ope
ndef theT seLdiffereDBCONFIG_LOOKASIDE] oTL_TRet d[ds] objedbeETRY] ne]tSN3file_GET_HANrgulocks withnlookas opeoQRY] opity iIonite w_TRu frETRged forsier to  fseL-Ds with DEFAULT_LOOKASIDE] oTL_TReIN32_GET_HANrgulocks withintedeead Lolookas opeoQRY] opity iIat[SQLITE_USE_FtheyngIddAP_oOUND[LdiffereCONFIG_Pfine 2]]erdt>differeCONFIG_Pfine 2</dt>upperdd> ^(TfaidiffereCONFIG_Pfine 2NoTL_TRetconstae i* er o NULL.
* in "sirE_NOa ts its argumen[ds] objep Ncheod
** of2**an [sqlite3 issf thislle in N all he dot) methos).
pcIf it rand X Ncheri avoid confli.er to ^the use consoamoQpy] aoin,  or file p Ncheod
** of2**an [sql</ddAP_oOUND[LdiffereCONFIG_GETPfine 2]]erdt>differeCONFIG_GETPfine 2</dt>upperdd> ^(TfaidiffereCONFIG_GETPfine 2NoTL_TRetconstae i* er o NULL.
* in "
**Oi an ts its argumen[ds] objep Ncheod
** of2**an [sqlits a OSX fpiiynatated ol  *ger poiand X Ncheri avoid confli*t setts than [sql)^D</ddAP_oOUND[LdiffereCONFIG_LOG]]erdt>differeCONFIG_LOG</dt>upperdd> TfaidiffereCONFIG_LOGiRTL_TRV tou_HANrgulTRY] opod to s a OSturnolobnt , the Vlogd ** D(A faidiffereCONFIG_LOGiRTL_TRVtconstfwo o NULL.
s:an ts its argum inve
** busywfile heques es at wor isnvok(*)*he ar, to,*xWrit** a*),ted n srn ts its arguhe a.e strmedia
** busy to memory unlo** t,** sir retin* file-co[ds] objelognedlV_Res is ueel 25logg** tevsedi e strmed
thea
** busy to memory the  htf o[ds] objelognedltes _fileWma fmenvcall
** P_oMA fainvokets its aring thed t dld be  control *
*differeCONFIG_LOGiir retc  the e rsqlitarturns Sletee readable. htty ts
iority i-ted whetloggea[sqle
** busywITE_FCNTmeanas
** busyi a*n* filAGMA faitld be ics methods. Thehe dloggeaas
** busyi aamoQpy] aoin,  Sletee readable. htty sp[sqlite3_fi the[ds] objelognedlequesan. Or, itsndg t (*d-oa [sqld LoETNT]tur i ted [extsndg tsqld LoETNT]AGMA faie of tics methodc  the eoehe dloggeaairE_NOa logen ssagefafile um wilng t viavior file Enpr itf() activity s a OSXlogg** t () methony tendirerolacti;ehe dloggeaas
** busturnnep**ent limtty ts
iority ivmE_FCile )(void n ers a OSX () methoactivIndpcm.)^
-heataboc ts
iority i,htty ts
iority i-ted whetloggea[sqle
** busymE_FCd-ongatabthe
. </ddAP_oOUND[LdiffereCONFIG_URI]]erdt>differeCONFIG_URIupperdd>^(TfaidiffereCONFIG_URINoTL_TRetconstae i* er o NULL.
*Nehe poile activIf ungument htf itURINmes t** t snolobntlevero-dadeCI** firics method snment  Thehe itURINmes t** t snolobntlevdisa* ed.)^D^I**URINmes t** t snolobntle Theero-dad,e S sct anerasdc  the eoeior file  to ed GMior file  to _v2ed G the[ds] obje to 16()]uoNturnnle in NBUasle is bei[ATTine [SQLwitdceful ints er thatartURIs,Irsinrdion turn maenteger depending
*** file cPEN_URI]O 
**ue orol wf it retues are 
, teanged foro CNoTeA_S. ^I*** sirtolobntlevdisa* ed,sct anerasdnn inted durchts er thatartURIs
ntrol  * file cPEN_URIO 
**ue orol wf it reintedes are changed foro CNoTeA_S. ^(Byireead L,*URINmes t** t snolobntle Thedisa* ed.F faireead Loument   /* Adlocks t limSQLITE** te if tfa do ** file USE_URI]Osymbolvted whe.er toOUND[LdiffereCONFIG_COVERING_INDEX_SCAN]]erdt>differeCONFIG_COVERING_INDEX_SCANupperdd>^TfaidiffereCONFIG_COVERING_INDEX_SCANNoTL_TRetconstae i* er t as a
 [SQo NULL.
* in "sir iits er thatarta integerea(ly after iero-daf resisa* e Thehe du infpos vle** t (dicry ain sisl * theesIN3y rno spequle coTL_mnder P_oMA faireead Loeolng t t. d.  The Pdfile_ying
*** file ALLOW_COVERING_INDEX_SCAN]moQLITE_USE_FCNTL_TR horlisr"on" retinstead SQLITE_USE_FNoTL_TReouldtransaactivity tArg arer isisa* eehe du infpos vle** t (dicry ain sisl * theesIN3y
**Oi ama gginonimplinsp[sqe if
ETNTdiitgacytapriority invm the2mals
** busturnwf it retoTL_mndonflivoulero-dadeC PhL_TR** tempotArg arer  Thedisa* et retoTL_mndonflivaVFSwrturnsdldeae.buggy ts
iority ieIpla r iort P_oMe iflocklocks wevsete if newr iods abontat Mac OSVFSeOUND[LdiffereCONFIG_Pfine ]]e[LdiffereCONFIG_GETPfine ]]upperdt>differeCONFIG_Pfine h befaiffereCONFIG_GETPfine upperdd> TfasePRAGMA]ceful obsovot
ivointn only read-oTL_SIZE_new ETdef theT s snn  t, nt poine Viackwnrd tSQLIityArg areoktik  bunwell
**s.heyngIddAP_oOUND[LdiffereCONFIG_difLOG]]upperdt>differeCONFIG_difLOGupperdd> f CNoTL_TReould durThis capabttrds] obX  tSQLITE_dee if tfa [SQLdiffereENABLE_difLOG]2er -es is ue
* tcrovted whe.Dtaba Slete control tn onlfile_GEn ts its argumle
** busyNehe poinvok(*)*he ar, s] obj*,*xWrit** a*,t it)mly acrossld be lhsion.ng
Nehe poiThe ar).Dtabaequeile (oul
** file_ying
*libr  By d base reers genaem circum with scoidbui fent limtty ument n  the arturn invelurthrics methoeCI** firelurthrics metho(oul0 htf it retues are changed forinten  the arturnsdld be  control hor jE_FCd-in oTeA_S.  faie of t control retts itsere attunread*xWLnt ** temponof the art   ] odes are cct aeCI** fi invelurthrics metho(oul1 htf it retdifanrid LL.
 then the e of tics metho retts itsere hor jE_FCd-in execunsaa Ol,3_f  firelurthrics metho(oul2,etf ibatce sehanged forobf then  the arturnsdld be ics metho(oulbf theEes td.the filee of tics methodisdc  the ** thInd tndiC fo[VFAne* lockithe a
** tem  fromoQRY] opity iIoTL_TRVIN32_GEser oytturns"pabi_ s]log.c" oourc*Coweveribatce sehaungocnt s a OSXoourc*Ctree.</ddAP_oOUND[LdiffereCONFIG_MMAP_SIZ ]]upperdt>differeCONFIG_MMAP_SIZ upperdd>^differeCONFIG_MMAP_SIZ Vtconstfwo 64-bimit* be sy(tion.
*/a val)bn arra invght harrlurnsreead Lonmap/sndedlimivl( spereead Loeolng t  return[nternalnmap_snde]).ndled t  that
**aame algnmap/sndedlimiv P_oMA faireead Loeolng t iN32_GEand so
dfo limel 25ues are changed foroa
** k, tteger ing
**nternalnmap_snde][SQLwitd horlby a
** temp [SQLdiffereFCNTL_MMAP_SIZ ]Coweved for t.VFSeT t  that
**aame algnmap/sndeP_oMe lleNT *t an if
tr
**migAN_f inide   Ba,of SQLiit frary reaned he e  
, teaLITE_USE_FN that
**nmap/sndedrol is ed. [SQLdiffereMAX_MMAP_SIZ ]CSQLITE_USE_FNoTL_TR.er to ^I**teger iecontrol *
*me CNoTL_TReoulnegc fve htf it rate control is
, teocks t V_RltsCSQLITE_USE_FNreead L.lyiOUND[LdiffereCONFIG_WIN32_HEAPSIZ ]]upperdt>differeCONFIG_WIN32_HEAPSIZ upperdd>^TfaidiffereCONFIG_WIN32_HEAPSIZ NoTL_TReould durThis capabttrds  OSX  
, teaLITE_oine VWinoow ee if tfails with WIN32_MALLOC]aer -es is ue
* tcrointedee whe.D^differeCONFIG_WIN32_HEAPSIZ Ntconstae32-bimiunses in t* be syn arr invght hlle in N  d t  that
**ended
** firj shoeleheapVFSeOUND[LdiffereCONFIG_Pfine _HDRSZn]upperdt>differeCONFIG_Pfine _HDRSZlyingdd>^TfaidiffereCONFIG_Pfine _HDRSZNoTL_TRetconstae i* er ics method in "
**Oi an ts its argument  be sy befoe
*ry rnsetts tht  be syurns is an adv VFrafile_y*ry pemoand X cqu sod[ein el 2oand Xin LdiffereCONFIG_PAGEfine ]iP_oMity tmou.
*Neh VFra spthon cqu sod[eqn*locks wolean inttay be ioQLITE_r  Theh** ltles unifo,h befaif OSsods aboVFSeOUND[LdiffereCONFIG_PMASZn]upperdt>differeCONFIG_PMASZlyingdd>^TfaidiffereCONFIG_PMASZNoTL_TRetconstae i* er ics method in "
**Oi anniunses in t* be syvoint_FCNurn "Mg at
**PMA Snde"veleshe dm.)^
heataboc invsnd ole. htt tht  be s[VF faireead Lomg at
**PMA Sndeue orol is ed. [SQLdiffereSORTER_PMASZnCSQLITE_USE_FNoTL_TR. DNew *iatabt,irR]
*
**hAc invV_Rhelp e if snd  _FULL, or nwf itm.)^
heataboc snd ** k, toulero-dadm(a
** tempolnternalfiatabt][SQLwitd).ndled t tmou.
*Neh*xWLbui invV_RNT *nd o uned hes* firicgnsendedSE_Fsshe dmg at
**being

thelnternal Ncheosnde][eolng t ndled r, n arrVFSeOUND[LdiffereCONFIG_STMTJRNL_SPILL]]upperdt>differeCONFIG_dTMTJRNL_SPILLlyingdd>^TfaidiffereCONFIG_dTMTJRNL_SPILLNoTL_TRetconstae i* er ics method in "
**Oma fmenvtf o[drid LL.
 journal][eITEl-to-disklfiatsosom. [SQLdrid LL.
 journals ev  b*els
** m the suui lvtf irsended(t b_y*ryeted ned hes* fislfiatsosom,Iat[ in "sts itvtf  snn  oe
*tener isiseiP_o Ol3_f  firfiatsosomtoul-1 hdrid LL.
 journal  arecklded  *elsted nedluAfvedurch m the . do tmed, mn erdrid LL.
 journal  E_FCNT_G and l** l,[eolng t urnsdpe] 
to fiatsosomtre atument nter art64KiB[eqn*g sholle cdud, ** ttmou.
*NectivI/On cqu sod[] dd* and  drid LL.
 r teile iP_oMity reead Loument eleshee orolng t t. d for tlnt limtty [SQLdiffereSTMTJRNL_SPILL]CSQLITE_USE_FNoTL_TR.FSeOUND[LdiffereCONFIG_SORTERREF_SIZ ]]upperdt>differeCONFIG_SORTERREF_SIZ upperdd> faidiffereCONFIG_dORTERREF_SIZ NoTL_TReTvidptstae i* er ics methoturn mae poiT it) -yurns ew ument is urnsdnd ol-r fs e robendedSiatsosom. [SQU3. The,oy needs  OSXging. b exl opcodsnd  rgu  aftedes rd tTvi rd** k, trgumenORDER BYeEeggin,e S scteomle cqu sod[limtty sqlitrharrleatsrol iit reinte*nd o udes rd . He avbl,3_f s a OSXg.  The Ps are dtay be ideEegsod[] poturn maa * theecolumnf SQLiit, n arrt,irR]
ike*yce cbSsodsyt
** la-ll** lT invghtit retoQRY] opoc snd ol-r fs e robendedSiatsosom -yurnndpcr fs e rok, touloc()]s
** el 2o*nd o udes rd.ndled t  cqu sod[eolumnfn arrt,loaboc inveat it isues are casedes rd tTr.h opGMA_S i** id o u  aft.F faireead L invument eleshee ooTL_TRV topo E_FCNTleCo se ooTL_m  onfli* Sle indg t n invnegc fvevument eleshee ooTL_TRVatsc()]rturnsreead Lo eAMEang. to  f CNoTL_TReould durThis capabttrds  OSX  tSQLITE_dee if tfa [SQLdiffereENABLE_dORTER_REFERENCES]CSQLITE_USE_FNoTL_TR.FSeOUND[LdiffereCONFIG_MEMDBeMAXSIZ ]]upperdt>differeCONFIG_MEMDBeMAXSIZ upperdd> faidiffereCONFIG_MEMDBeMAXSIZ NoTL_TReTvidptstae i* er ics methoturn[tion.
*/a val] ics method in "sirturnsreead Lo that
**ended the ent -n the all ues are ch shoeleN3** t or file dedlr im  C() V Dtaissreead Lo that
*inte*ndediN32_GEadjubigdtupl ress lefnge*n w_TRu frues are s a
** temp [SQLdiffereFCNTL_SIZ _LIMIT t or file owev_d for t|owev-d for t]ible zem  fromoQRY] opity iIrolng t t. E_FCNTleCd htf it retreead Lo that
**t. d.  The Pdfile_ying
*** file MEMDBeDEFAULT_MAXSIZ ]CSQLITE_USE_FNoTL_TR. DInstead
, teaLITE_USE_FNoTL_TRV tountonte,ttf it retreead Lo that
**t. 1073741824.FSeOUND[LdiffereCONFIG_ROWID_IN_VIEW]]upperdt>differeCONFIG_ROWID_IN_VIEWupperdd> faidiffereCONFIG_ROWID_IN_VIEWNoTL_TReero-da f resisa* e nd thtArg ar invelr VIEWsere hovGEn ROWID[VF faicaptArg areiN32 ed ii [ero-dadmttrds  OSX  
, teaLITE_oie if -Ds with ALLOW_ROWID_IN_VIEW,iinl in "bC foitfaicaptArg arintedeead Lsere  i[VF f CNoQRY] opity iIoTL_TRVqule N  d t *ger poirolng t return kue. serrnsdllng t uonataf re i[VF fai control isrn ts its argument  be sactivIf ts tht  be syothing.d iosomlea ument is 1 htf it rettArg areelr VIEWserectivhovGEROWIDs isrnd fvansaa CI** firt  be syothing.d iosomlement htf itemp [SQtArg aret. d.nd fvansaa CA er ith  othing.oument elesheirt  be syleovGsrdisk I/solng t uneocks ta CAfile  kue. s,*ipotiy,* firt  be syos oe
*tenee ifh tha 1f re0,3_f  firtArg areelr VIEWserevhovGEROWIDs isronvorooff. CI**s a OSturn  tSQLITE_dee iflock-Ds with ALLOW_ROWID_IN_VIEW ( in "sirturnsTL. T*voi thect anm** thaC fo)htf it rett  be syos klded  eilit re if ment hrsinrdion turnimai
seothing.oument.heyngIderly/
#dee whidiffereCONFIG_SINGLETHurnsCAPLITE_I1_I/o n lvy/
#dee whidiffereCONFIG_MULTITHurnsmmmmmmmmmm2_I/o n lvy/
#dee whidiffereCONFIG_SERIALIZEsmmmmmmmmmmm3_I/o n lvy/
#dee whidiffereCONFIG_MALLOCNNNNNNNNNNNNNNN4_I/o or file  emod
** of*vy/
#dee whidiffereCONFIG_GETMALLOCNNNNNNNNNNNN5_I/o or file  emod
** of*vy/
#dee whidiffereCONFIG_SCRATCHIIIIIIIIIIIIII6_I/o Nnarangr iunhevy/
#dee whidiffereCONFIG_PAGEfine NNNNNNNNNNNN7_I/o he ar, le s z, le sNvy/
#dee whidiffereCONFIG_HEAPNNNNNNNNNNNNNNNNN8_I/o he ar, le snByze, le she vy/
#dee whidiffereCONFIG_MEMSTATUSNNNNNNNNNNNN9_I/o integerey/
#dee whidiffereCONFIG_MUTEXNNNNNNNNNNNNNNN10_I/o or file  ufoxod
** of*vy/
#dee whidiffereCONFIG_GETMUTEXNNNNNNNNNNNN11_I/o or file  ufoxod
** of*vy/
/etchevhodsdurdiffereCONFIG_CHUNKALLOCNNNN12d in "sirtunweTnTL ta y/
#dee whidiffereCONFIG_LOOKASIDE NNNNNNNNNN13_I/o inmitnmiy/
#dee whidiffereCONFIG_Pfine NNNNNNNNNNNNNN14_I/o  the *y/
#dee whidiffereCONFIG_GETPfine NNNNNNNNNNN15_I/o  the *y/
#dee whidiffereCONFIG_LOGiiiiiiiiiiiiiiiii16_I/o xFune, he ar*y/
#dee whidiffereCONFIG_URINiiiiiiiiiiiiiiii17_I/o inmiy/
#dee whidiffereCONFIG_Pfine 2iiiiiiiiiiiii18_I/o or file p Ncheod
** of2*vy/
#dee whidiffereCONFIG_GETPfine 2iiiiiiiiii19_I/o or file p Ncheod
** of2*vy/
#dee whidiffereCONFIG_COVERING_INDEX_SCANN20_I/o inmiy/
#dee whidiffereCONFIG_difLOGiiiiiiiiiiiiii21_I/o xSs]log, he ar*y/
#dee whidiffereCONFIG_MMAP_SIZ Viiiiiiiiii22_I/o or file a val, or file a val*y/
#dee whidiffereCONFIG_WIN32_HEAPSIZ Niiiii23_I/o inminByzeiy/
#dee whidiffereCONFIG_Pfine _HDRSZNiiiiiii24_I/o inmiypsziy/
#dee whidiffereCONFIG_PMASZNiiiiiiiiiiiiii25_I/o unses in t* s zPmaiy/
#dee whidiffereCONFIG_dTMTJRNL_SPILLNiiiii26_I/o inminByzeiy/
#dee whidiffereCONFIG_SMALL_MALLOCNiiiiiii27_I/o integerey/
#dee whidiffereCONFIG_dORTERREF_SIZ Niiiii28_I/o inminByzeiy/
#dee whidiffereCONFIG_MEMDBeMAXSIZ NNiiiii29_I/o or file a valiy/
#dee whidiffereCONFIG_ROWID_IN_VIEW       30_I/o inmr*y/
n future releasesDes are cCanged foroCQRY] opity iIOpty intedP_oMityss *xWriaite3a immediThis capabto be sy*xWY] opity iIoTL_TRssteadk, teqn*ng
n  the arturnstld be ics methods.vtf o[ds] objedbeETRY] ne]t () methoiOUN
theTf o[ds] objedbeETRY] ne]t () metho isrn var- cosle
** busAGMI stconsta invum initis is an advics methoscoe sqlitalded  atlues artwo[VF fai is an adk I/ics methos
n  the rnsetds] objedbeETRY] nevolean sronv in "sis urne 
, teanriaite3 snoe in hrturnstld be ics methoV Dtaissrocuid confli*and ly ar fs serevics methos
oty be tansdld be  s "o NULL.
s"V Dtaus,nwf it rir retc gnseed  "tansN-ile  NULL.
"to iseN3y "tansN-ileics methodc  Liurn [SQ*xWY] opity iIoTL_TR"voro"tans(N+2)-ileics methodsetds] objedbeETRY] ne"A** uppeNew ETRY] opity iIoTL_TRst  /* Addd thaal methodsrele* iynat Mac OSVFSeEEr, t** toQRY] opity iIoTL_TRst  the2_GEdisd foinucb* tApriority inted tn only kResturnsrc All FCNTLeat i[ds] objedbeETRY] ne]tV_R conts to
is th the seequesort contr^Tf o[ds] objedbeETRY] ne]t () metho efault, All a retengumentt, the VFCNT]at anEdisd foinucbuoNTund* and o uNURY] opity iIoTL_TR
**Oi a*n* filA** upperderlyin[LdiffereDBCONFIG_LOOKASIDE]]upperdt>differeDBCONFIG_LOOKASIDE</dt>upperdd> TfaidiffereDBCONFIG_LOOKASIDE RTL_TRV tou_HANrguadjubiiurn [SQ*xWY] opity iIoaoin,  lookas open the  aaFS miordlwfif] opcues are 
, teanged foractivity t NULL.
sds.vtf odiffereDBCONFIG_LOOKASIDE RTL_TRVa im<i>noLlii>
 d base ,  DBCONFIG t NULL.
s|TL. T*um wil activity s afereDBCONFIG_LOOKASIDE RTL_TRVtconstfgateao NULL.
s,pendinwt  The,of SQLiatequesteQ[ds] objedbeETRY] ne]tVSQLiging.s afereDBCONFIG_LOOKASIDEted tn onlyhovGEn tota s maffvevics methos.heyngoerlying de<p>taba Slete control ("buf")sir a retts its argumen the stunreaes.oa
oi thelookas open the  ** Dtaba Slete control   /* Ad** thinl in "bC foiSac OSsr lleaVFS mig urn [SQlookas opetunreaditeelf N3** t or file  obtained.lying de<P> faidld be  control ("sz").isrdisk I/snded
**el 25lookas opetunreadslnlntrLookas opei. disa* edat a"sz"
**Oi aeof tghtit8[VF fai"sz" t NULL.
*lhsion.ng
a S.)^
**olnfN8_eof tghti
**O65536. CI**"sz" frary reameen thi ieanrirale ,t tondictdud,S i** ndeduui l
**Oit frar.lying de<p>tabae of t controlo("cnt") irturns is an ad/slnl .rLookas opei. disa* edturnima"cnt"i aeof tghtit1[VF fai"cnt"oument e lleNT ctdud,S,N_f inide   B, te invght h firirodusi] an"sz" tbe "cnt"ofrary reaned he 2,147,418,112. F fai"cnt"k I/ics methoV tou_. They kosena,of SQLiurnrirodusi] an"sz" tbe "cnt"oi aeof  invghtit1,000,000.heyngIoerlyingp>I** fir"buf"i control isrunlo** t,*t autimimE_F retts itargumen the stunreaewfile hendedSing theg sholTmmeaiturn r en mlds.vtf oirodusi] an"sz" tbe "cnt" ** DtabatunreaemE_FCd-oytes in rgumen8-isor beverae  ** Dtabalookas open the  [SQ*xWY] opity iI the 5ues are changed foroiN32 ed ii [eocks t wf it rat
, teanged for isrunlo e top-levN3** tlookas open the  horli bhe filwords
, twf it retnced.h opGMA_S theLdiffereDBSTATUS_LOOKASIDE USED]d snmentdOUNDAny,iffoll he dlocks withnlookas open the sFCnY] opity iIwf itlookas opOUNDn the ory i32leColeovGsrdissFCnY] opity iIuneocks th befr AGMA] [SQLdiffereBUSY]activIf tsir"buf"i control isrthe cn srtisaffoll k, trgumVFS mig n the stre dtay "sz" tbe "cnt"os tos,etf ibatclookas opei. *t an if
disa* ed.lyingp>
theTf o[differeCONFIG_LOOKASIDE]moQRY] opity iIoTL_TRVIN32_GET_HANrgurol is intedeead Lolookas opeoQRY] opity iIat[a hing.  onfli* the file -Ds with DEFAULT_LOOKASIDE] oTL_TReIN32_GET_HANrgurol is  deead Lolookas op [SQ*xWY] opity iIat[SQLITE_USE_Ft thypocnt n arrt, thelookas opea im1200  return"sz" tbe 40Nrgu100  re "cnt" ** D</ddAP_oOUND[LdiffereDBCONFIG_ENABLE_FKEY]]upperdt>differeDBCONFIG_ENABLE_FKEY</dt>upperdd> ^Tf CNoTL_TReoulT_HANrguero-daf resisa* e is  en receLL.
*Neh th[ed ies  keyieanrirale s V Dtaissthed t dof teolng t ural is
, tero-dadm resisa* ed[limtty lnternaled ies _keyfleteid LL.
 ** Dtaba Slete control isrment  be sy in "sirt0er isisa* eeFK en receLL.
, rettssi fveerguero-dafFK en receLL.
 depeegc fvevrguleovGfFK en receLL.
 retuneocks ta C faidld be ics methoV ton ts its argument  be syrnset in "
**Oi aoe
*tene0 dep1 V_Rle writeaenteger FK en receLL.
 isnataf re i invelvent a c tndiC lla C faidld be ics methoV  /* Add the code wil,eribatc in "bC foitfaiFK en receLL.
 rolng t t. Endireand o uile iD</ddAP_oOUND[LdiffereDBCONFIG_ENABLE_TRIGGER]]upperdt>differeDBCONFIG_ENABLE_TRIGGER</dt>upperdd> ^Tf CNoTL_TReoulT_HANrguero-daf resisa* e [CREATE TRIGGER | triggeas activityre*lhsion.ng
uwo ois objectvo NULL.
s ** Dtaba Slete control isrment  be sy in "sirt0er isisa* eetriggeas, rettssi fveerguero-daftriggeas depeegc fvevrguleovGfrrnsdllng t uneocks ta** Dtabadld be ics methoV ton ts its argument  be syrnset in "
**Oi aoe
*tene0 dep1 V_Rle writeaenteger triggeas nn ddisa* eda r ena* edturnelvent a c tndiC lla C faidld be ics methoV  /* Add the code wil,eribatc in "bC foitfaitriggea rolng t t. Endireand o uile i** upperp>Origin Theyhee ooTL_TRVdisa* edaquestriggeas.VFSeHe avbl,3si rok, taif OSsods abo 3.35.0,nTEMP triggeas nn dst lleaVFS algevsetiated ol CNoTL_TReouldff. CSo,li bhe filwordscoe  CNoTL_TReunwe ed ifisa* e all triggeas rno spen ] odes are cschemahorli brrnsdchemas bei[ATTine -edturnues are sl)^D</ddAP_oOUND[LdiffereDBCONFIG_ENABLE_VIEW]]upperdt>differeDBCONFIG_ENABLE_VIEW</dt>upperdd> ^Tf CNoTL_TReoulT_HANrguero-daf resisa* e [CREATE VIEW | views activityre*mE_FCd-onwo ois objectvo NULL.
s ** Dtaba Slete control isrment  be sy in "sirt0er isisa* eeviews, rettssi fveerguero-dafviews depeegc fvevrguleovGfrrnsdllng t uneocks ta** Dtabadld be ics methoV ton ts its argument  be syrnset in "
**Oi aoe
*tene0 dep1 V_Rle writeaenteger views nn ddisa* eda r ena* edturnelvent a c tndiC lla C faidld be ics methoV  /* Add the code wil,eribatc in "bC foitfaiview rolng t t. Endireand o uile i** upperp>Origin Theyhee ooTL_TRVdisa* edaquesviews.VFSeHe avbl,3si rok, taif OSsods abo 3.35.0,nTEMP views nn dst lleaVFS algevsetiated ol CNoTL_TReouldff. CSo,li bhe filwordscoe  CNoTL_TReunwe ed ifisa* e all views rno spen ] odes are cschemahorli brrnsdchemas beiATTine-edturnues are sl)^D</ddAP_oOUND[LdiffereDBCONFIG_ENABLE_FTS3_TOKENIZER]]upperdt>differeDBCONFIG_ENABLE_FTS3_TOKENIZER</dt>upperdd> ^Tf CNoTL_TReoulT_HANrguero-daf resisa* e a
** temp [SQLfts3_tokennderne]oa
** busy-le is beitty lFTS3] sisl-tage sear "berge Pbatcextsnsbusy-le iflocka
** tbevervics methos
as* firics methos. Do** tte invi. disa* edabyireead L.vityre*mE_FCd-onwo ois objectvo NULL.
s Dtaba Sleth thacontrol isrment  be seCI** tondin  the 0 htf ita
** tfts3_tokenndernebatc  iflockbevervics methos
i. disa* edeCI** tondin  the attssi fveen arr  Thehe itcFS ** tfts3_tokennderc  iflockbevervics methos
i. ero-dadeCI**it invi. n  the atnegc fvevument,shee orolng t t.  reamod fent -c tndiC 32_G retu_HANrguqule celesheir*ger poirolng t.Dtabadld be ics methoV ton ts its k, trgument  be syrnset in "Oi aoe
*tene0 dep1 V_Rle writeaheir*ger poin arr invofshee orolng t (afile  tondimod fent,*ipotpriori-da)a C faidld bek I/ics methoV  /* Add the code wil,eric in "bC foitfaivment is urnsdolng t invi. Endireand o uile iDR fs argulFTS3] rocuid confli*ain sire fild, ntls.heyngIddAP_oOUND[LdiffereDBCONFIG_ENABLE_LOAD_EXTENSION]]upperdt>differeDBCONFIG_ENABLE_LOAD_EXTENSION</dt>upperdd> ^Tf CNoTL_TReoulT_HANrguero-daf resisa* e is  [ds] objeload_extsnsbuse ]lyin () metho inolean an if
oaoin,  load_extsnsbuse ]tdifae
** busA
theTf o[ds] objeero-daeload_extsnsbuse ] APIeero-da f resisa* e nboif tfa [SQC-APIe[ds] objeload_extsnsbuse ].ndled t difae
** bus  load_extsnsbuse ]activityre*mE_FCd-onwo ois objectvo NULL.
s ** DWf it ret Slete control *
*meist () metho isr1 htf it ed i retC-APIeis
, tero-dadmndled t difae
** bus ren ] . disa* edeCCI** fireSlete control *
ted ol CN () metho isr0 htf itboif tfatC-APIendled t difae
** bus nn ddisa* edactivIf tsir Slete control isr-1 htf itnon kue. senn dmadse orol  teid d
**eeger h the seC-APIelesheirdifae
** busA
theTf odld be ics methoV ton ts its argument  be syrnset in "
**Oi aoe
*tene0 dep1 V_Rle writeaenteger [ds] objeload_extsnsbuse ]. () metho invi. disa* eda r ena* ednelvent a c tndiC lla C faidld be ics methoV  / inv Add the code wil,eric in "bC foitfainew rolng t t. Endireand o uile i** ngIddAP_oOUND[LdiffereDBCONFIG_MAINDBNAME]]erdt>differeDBCONFIG_MAINDBNAME</dt>upperdd> ^Tf CNoTL_TReoulT_HANrgulocks withnnof the art "n ] "cues are 
, tdchemalite3 issTL_TRVdrary reaelventtemp [SQLDBCONFIG t NULL.
s|TL. T*differeDBCONFIGe control um wil activit issTL_TRVtconstexae if
to
*ois objectvo NULL.
a,of SQLiurn [SQ[ds] objedbeETRY] ne]tSNlleharta tota s mafgateaics methos. the file VFra e NULL.
*mE_FCd-on ts its argumleanriait UTF8e*tri* tein "
**Oe lleNT and tfainew rchemahnof tii  the UNes"n ] ".DD^the usedrar
**O reamcontamoQpy] aoin, new n ] orchemahnof t*tri* ,a,of Sy ts
iority iOUNDnE_FCsns to
is tf Sy t NULL.
*n  the rnsetdiffereDBCONFIGeMAINDBNAME invi. uneocks thuui lvafile thetues are changed foreEes ts.heyngIddAP_oOUND[LdiffereDBCONFIG_NO_CKPT_ON_CLOSE]]upperdt>differeDBCONFIG_NO_CKPT_ON_CLOSE</dt>upperdd> U3. The,oy nee 5ues are cin LWAL nCNT]andiCes tdf res, n*hAcLeat iaturnues are umes th, the use kRess
ntr_f  fireck  bhe filETRged forse orol 
, tdof tues are ,h bef_f  fireck  bnonhe filues are changed foro(ieing

thehanged forobf theCes tdfthed t l  LioTeAehanged foro orol  ues are )  Thehe itthe useaimum wrta [ kRests it]voted i*Ces g t urnshanged forovoi thedevot
hed t WAL ct aeCvity s afereDBCONFIG_NO_CKPT_ON_CLOSE oTL_TReIN3 inv AdT_HANrgu vler opeis tf eAMEang.Dtaba Slete control c  the eoeheis
, t_FULL, orl( spee of tics methodteQ[ds] objedbeETRY] ne]) isrment  be sbatc in "bisttssi fveergusisa* e  kRests its-on-Ces t horlmentt( spereead L)k, trguero-dafthem,h befeegc fvevrguleovGfrrnsdllng t uneocks ta** Dtabadld be  controlo(tsir lurthrics metho)V ton ts its argument  be slyin ()et in "Oi aoe
*tene0 dep1 V_Rle writeaenteger  kRests its-on-Ces tlyinhovGEd-in disa* eda-e0 ieing
yck  bnot fisa* et,*1 ieing
yck  .heyngIddAP_oOUND[LdiffereDBCONFIG_ENABLE_QPSG]]erdt>differeDBCONFIG_ENABLE_QPSG</dt>upperdd>^(TfaidiffereDBCONFIG_ENABLE_QPSGNoTL_TReTv fvans f res.nd fvans all he d[qule c thnger teiArg areol action] (QPSG)a CWf it retQPSGNisrnd fvr  Theae i* er difaqule cdrid LL.
 r lleaVded  leCo spesbe talgoe
*hmIrsinrdion turn man arrt,bei[bevervics methos]l)^DTretQPSGNsisa* e nnimplqule coTL_mndity inted is tflook,ifo spen arrt,beibevervics methos,c in "bC nR contsimplqule N all sldwr n tBkti retQPSGNhas* firadvcti gnseannorrleat wr* thee eAMEang.D W ifh the seQPSGNnd fvr iSac OSsr lleaVded  leCo spesbe tqule c thnli brrnscteom as
, twaulT_HANduri* tpabilitli brrnslab ** Dtaba Slete control *
*meistrolng t t. ment  be sy in "sirt0er isisa* eh the seQPSG,ttssi fveerguero-dafQPSG,tdepeegc fvevrguleovGfrrnsdllng t retuneocks ta tabadld be ics methoV ton ts its argument  be syrnset in "
**Oi aoe
*tene0 dep1 V_Rle writeaenteger tretQPSGNisrdisa* eda r ena* edturnelvent a c tndiC llaheyngIddAP_oOUND[LdiffereDBCONFIG_TRIGGER_EQP]]erdt>differeDBCONFIG_TRIGGER_EQP</dt>upperdd> Byireead L,*tretoutpus beiEXPLAIN QUERY PLAN[SQLwitdcedrary relyin (rludetoutpus  the ey _FULL, or naimum wed[limtriggea progs ms Dtais
, t_FL_TReoulT_HANrgurol e VFleort( spereead L)umle
**uis tfg vlenseheis
, t eAMEang.Dtaba Sleteics methodc  the eoehe issTULL, orlt. ment  be sy- rettssi fveerguero-dafoutpus  thetriggea progs ms horlmenttrgusisa* e i
, retdepeegc fvevrguleovGfrrnsdllng t uneocks ta** Dtabadld be ics methoV ton ts its argument  be syrnset in "Oi aoe
*ten** D0 dep1 V_Rle writeaenteger outpus- th-triggeas has*d-in disa* eda-e0 ielyin l isrunlofisa* et,*1 iei l isaheyngIddAP_oOUND[LdiffereDBCONFIG_RESET_DATABASE]]erdt>differeDBCONFIG_RESET_DATABASE</dt>upperdd> Sol is  siffereDBCONFIG_RESET_DATABASEle
**undled tnuruaOUND[VACUUM]ea(ly after iatsrte 5ues are cile (] d b empareues are 
, te if noorchemah befeoh*xWLbui.Dtaba lvent a ces is ueort sgevset returnacildif
ETrrup o udes are cct athe
ugoerlying devIf tsirdes are changed foro CNnewly oTeA_S,R conts to
il hor atabing

theeeeeedes are cschemahber*h geng t urnn discard** nnimplqule cag ] .ting

theeeeeedes are  horlcFS ** tds] obje* the_eolumnod
*ades (),ergnor** tn e
theeeeee the slite3 isstepeould durinide   Ba_f  firts
iority iedesirctt (*keep
theeeeeetsirdes are ca(lWAL nCNTvafile thetatsrteiei l waula(lWAL nCNTvoted i
theeeeeetsiratsrt.lying detds] objedbeETRY] ndb, siffereDBCONFIG_RESET_DATABASE,r1 h0);lying det[ds] objeexec]ndb, "[VACUUM]",r0 h0 h0);lying detds] objedbeETRY] ndb, siffereDBCONFIG_RESET_DATABASE,r0 h0);lyingIoerlyinBa gginoatsrtng t nrdes are ca. d.nandedfvev bef_rcevsr
** e,ing

thees is ue cqu sorturnsTLevofshee oobsc to
APIendleS.)^
**olstepserectivhelp sns to
is tfit frary reahappeo limaccidbui.nBa gginoheis
, tfeat wormE_FCd-ocaptA*olnfNatsrtng t ETrrup nues are s,ovoi theshutng t ss levirt mldsa* e n  /* cqu soeTvidsse. htt thETrrup  thestorage,vrrnslibr  BrmE_FC arndorovourchdrilit rvirt mldsa* e batc  iflockcFS ** ttf irsxD.nanoy() d
** of.FSeOUND[LdiffereDBCONFIG_DEFENSIVE]]erdt>differeDBCONFIG_DEFENSIVE</dt>upperdd>TfaidiffereDBCONFIG_DEFENSIVENoTL_TReTv fvans f res.nd fvans ing

the"reesnsbve"ve
**u the 5ues are changed fora CWf it retreesnsbve
, tf
**ue oero-dad,ethnol gefseat wosets thaVFS   rd**  Brdifar  ThedelibenaemldsETrrup ntsirdes are cowevenn ddisa* edaVF fairisa* edturnseat wose (rludetoktik  buntdlimivhe eoehe d lvent a the
uguerlying devTty lnternaloe
* the_schema=ONleteid LL.
 ** Dg devTty lnternaljournal_nCNT=OFFleteid LL.
 ** Dg devTty lnternalschema_ods abo=Nleteid LL.
 ** Dg devWe
*ry s.vtf o[ds] obedbc gn]rvirt mldsa* e ** Dg devDisqe foe
*ry teQ[dhadnttea* e d.lying/uerlyingIddAP_oOUND[LdiffereDBCONFIG_WRITABLE_dCHEMA]]erdt>differeDBCONFIG_WRITABLE_dCHEMA</dt>upperdd>TfaidiffereDBCONFIG_WRITABLE_dCHEMANoTL_TReTv fvans f res.nd fvans ing

the"oe
* the_schema"ve
** DtaisNhas* firsbe teffqe fan. Or,logocntlevequ n abui invV_Rsrtng t lnternaloe
* the_schema=ONle othnternaloe
* the_schema=OFFl ** Dtaba Slete control *
*meistrolng t t. ment  be sy in "sirt0er isisa* eh the seoe
* the_schema,ttssi fveerguero-dafoe
* the_schema,tdepeegc fvevrgh thleovGfrrnsdllng t uneocks taDtabadld be ics methoV ton ts its argumelyin () e syrnset in "Oi aoe
*tene0 dep1 V_Rle writeaenteger tretoe
* the_schema
**Oi aero-dadm resisa* ed[elvent a c tndiC llaheyngIddAP_oOUND[LdiffereDBCONFIG_LEGACY_ALTER_TABLE]]upperdt>differeDBCONFIG_LEGACY_ALTER_TABLE</dt>upperdd>TfaidiffereDBCONFIG_LEGACY_ALTER_TABLENoTL_TReTv fvans f res.nd fvans all he ditgacyt eAMEangeat tf o[ALTER TABLENRENAME][SQLwitd nter is tfit
, t eAMEes
as*it fokethangeteQ[ods abo 3.24.0] (2018-06-04)a CSeg urn [SQ"CQLIityArg areNotice"vay be i[ALTER TABLENRENAME rocuid confli]t returnais objectvinum wilfora taisNfeat worC nRals cbSspGMA_S orovoinatated a
** tempolnternalitgacy_aal oe* theleteid LL.
 ** DgIddAP_oOUND[LdiffereDBCONFIG_DQS_DML]]upperdt>differeDBCONFIG_DQS_DML</dt>upperdd>TfaidiffereDBCONFIG_DQS_DMLNoTL_TReTv fvans f res.nd fvans all he ditgacyt[douthe-quovhe *tri* t] obral][misfeat wor theDMLNteid LL.
s
, t_nly,* fng theDELETE,rINSERT, sELECT,h befUPDATE teid LL.
s.the filereead Loument ofshee orolng t i. d.  The Pd[limtty l-Ds with DQS]
thehaLITE_USE_FNoTL_TR.FSeDgIddAP_oOUND[LdiffereDBCONFIG_DQS_DDL]]upperdt>differeDBCONFIG_DQS_DDL</dt>upperdd>TfaidiffereDBCONFIG_DQSNoTL_TReTv fvans f res.nd fvans all he ditgacyt[douthe-quovhe *tri* t] obral][misfeat wor theDDLNteid LL.
s  The,ter artCREATE TABLEN befCREATE INDEX.the filereead Loument ofshee orolng t i. d.  The Pd[limtty l-Ds with DQS]
thehaLITE_USE_FNoTL_TR.FSeDgIddAP_oOUND[LdiffereDBCONFIG_TRUSTED_dCHEMA]]upperdt>differeDBCONFIG_TRUSTED_dCHEMA</dt>upperdd>TfaidiffereDBCONFIG_TRUSTED_dCHEMAssTL_TRVteagmaSac OSsrgh thassumo
is tfdes are cschemasenn duWLnt tPd[limmaiorhodsh*xWLbui.h thWf it retdiffereDBCONFIG_TRUSTED_dCHEMAssTL_TRVisrdisa* ed iSac OSall hconstais objectvreesnsbvelstepsereees tqe f firts
iority ieeat iharmlyin (rlud a the
uguerlying devProhibimiurnsTLevofsdifae
** busse (s opetriggeas,eviews, retCHECKieanrirale s, DEFAULTeEeggins, exeats abo inolxes, rettaring.oinolxes,f regenenaemd[eolumns retuneof tgho cue
** bussea immaggt re if LdiffereINNOCUOUSd.lying devProhibimiurnsTLevofsvirt mldsa* e n (s opeofshriggeas depviews retuneof tgho cuvirt mldsa* e na immaggt re if LdiffereVTABeINNOCUOUSd.lying/uerlyinTee orolng t deead Lsere "on", theltgacytSQLIityArg ar, he avblh thalleapriority invareckdvithe eoehAll itnatafifttss
** e.nTee orolng t
theh nRals cbSsd for tlnt a
** tempolnternalfrubigd_schemaleteid LL.
 ** DgIddAP_oOUND[LdiffereDBCONFIG_LEGACY_FILE_FORMAT]]upperdt>differeDBCONFIG_LEGACY_FILE_FORMAT</dt>upperdd>TfaidiffereDBCONFIG_LEGACY_FILE_FORMATNoTL_TReTv fvans f res.nd fvans all he ditgacytoweveum wilve
** DhWf itnd fvansa,shee of
**u ggin  aVFNnewly
theh shoeledes are cowevsere hovGEn schemahum wilvods abo  is an ( spe4-isorall  () e syfevervatnatasrte44 rnsettsirdes are chtabor) is 1V DtaisstnehAllall seN3y is tf Sy sqld Lg t des are cowevee lleNT ctado-daf befoe
* thee  all a ers a OSXods abo ile (] d3.0.0 (rueseof:3.0.0]).D W ifoutshee orolng t, retnewly h shoeledes are nvarecgenenatlevuntde usrriaid thee  rs a OSXods abor retchangeteQ3.3.0 (rueseof:3.3.0]).D As* fie cw rd tTr.hoe
*ten,  fire
**Oi aunwescarcmldsa ernehe eoegenenaemedes are cowevserht harrlSQLIityA eh thquestreto /* le (] dods abo 3.0.0,nitd n
*meistrolng t t. is g atl

theesnd fcnt gin,eoktiistthL_TReda,of SQLithe use aAehanoinucNrgullaim urn [SQtArg arer igenenaemenew des are cowevserht harrlSQLIityA ere if dods abo [SQ3.0.0.lyingp>Noto
is tfwf it retdiffereDBCONFIG_LEGACY_FILE_FORMATNrolng t t. in  Thehe D[VACUUM]eSQLwitd e lles toewfile noobsc to
 the Vy nee ffoll g t uo
thees is uea * theewfilegenenaemd[eolumns n srn descan inttinolxV Dtaissth retnnlo o(s oprhe atbug3si rors a OSXods aborQ3.3.0 n srearlifiluoounton* and  retteger igenenaemd[eolumns  res.scan inttinolxts.heyngIddAP_oOUND[LdiffereDBCONFIG_dTMT_SCANSTATUS]]upperdt>differeDBCONFIG_dTMT_SCANSTATUS</dt>upperdd>TfaidiffereDBCONFIG_dTMT_SCANSTATUSNoTL_TReould durginfuleribatcSiffereENABLE_dTMT_SCANSTATUSNbit ds.tInd tndiC fo,t tot_FCNe VFleorrE_NOa e
**uis tfero-da fc tln* busyNeheabadr file Etmt_sIN3yeidus_v2ed thestitys fcs.tForestitys fcsce cbSsc tln* Cd htf  e
**umE_FCd-orol eibatce seues are umes thtboif wf it retdifcdrid LL.
 istth genadmndlew autim
**Oi astepphe.Dtaba 
**ue orol (c tln* busyNehstitys fcsci aero-dadd thebyireead L.v<p>ta issTL_TRVtconstfwo o NULL.
s:anent  be sy befn ts its argall a ht  be s[VF fai Slete control isr1,r0 hore-1erguero-da,rdisa* e, returnleovGfuneocks thtl  teid LL.
a,IN3yeidusNoTL_TR. DInstebadld be  control
**Oi aunlo** t,*t aut spen arryNeheabadeid LL.
a,IN3yeidusNsrtng t nftho retts is u** tempo Slete control isroe
*tenernsettsirt  be syur tf Sy dld bek I/ control cs itsereaheyngIddAP_oOUND[LdiffereDBCONFIG_REVERSE_SCANORDER]]upperdt>differeDBCONFIG_REVERSE_SCANORDER</dt>upperdd>TfaidiffereDBCONFIG_REVERSE_SCANORDER oTL_TReIkue. serrnsreead Loy aftall  (t in "Osa* e nan. Onolxts nn dschngeda,of SQLiurnrsIN3y yeirt,ifo speebek I/ dlewor (] wnrdo spebegin ** tnaehlTmmeai yeirtg t nto spebegin ** tvoi thewor g t uownrdo speebe. Soltg t differeDBCONFIG_REVERSE_SCANORDER isrdisk I/sbe tasRsrtng t lnternalcevsr
e_uny aftgd_seln* s V <p>ta issTL_TRVtconsbatcewo o NULL.
st in "Oareckent  be sy befn ts its arg a ht  be s[VF fai Sletk I/ control isr1,r0 hore-1erguero-da,rdisa* e, renleovGfuneocks thtl k I/cevsr
ersIN3ly afte 
** hrslle tfvedu. DInstebadld be  controlOi aunlo** t,batce sne0 dep1 isroe
*tenernsettsirt  be syur tf Sy dld be/ control cs itserefilereean inttay _f  fircevsr
ersIN3ly afte 
**ue orol afile ts is u** tempturnsSlete control.heyngIddAP_oOUND[LdiffereDBCONFIG_ENABLE_ATTine_CREATE]]upperdt>differeDBCONFIG_ENABLE_ATTine_CREATE</dt>upperdd>TfaidiffereDBCONFIG_ENABLE_ATTine_CREATENoTL_TReero-da f resisa* e batce setArg areat tf o[ATTine DATABASE]tdifcSQLwitd rgul shoe atneweues are 
, toweverf tsirdes are cfTE_denof dli brrnsATTine SQLwitd frary reaalctade Theer, tV DtaisstArg areat ATTine rgul shoe atneweues are Oi aero-dadmbrintedeead L* tApriority ine aAesisa* e orireroa* e is  tArg areelr ATTine rg
theh shoeenew des are cowevsea
** tem   DBCONFIGeoTL_TR.gp>
theTf issTL_TRVtconstfwo o NULL.
st in "Oareckent  be sy befn ts its  invV_Ra ht  be s[VF fai Slete control isr1,r0 hore-1erguero-da,rdisa* e, returnleovGfuneocks thtl   ffach-h shoee 
** hrslle tfvedu. DInstebadld bek I/ control isrunlo** t,*t aut0 dep1 isroe
*tenernsettsirt  be syur tf Syk I/sld be/ control cs itsereereean inttay _f  fir ffach-h shoee 
**ue orolk I/ file ts is u** tempnsSlete control.heyngIddAP_oOUND[LdiffereDBCONFIG_ENABLE_ATTine_WRITE]]upperdt>differeDBCONFIG_ENABLE_ATTine_WRITE</dt>upperdd>TfaidiffereDBCONFIG_ENABLE_ATTine_WRITENoTL_TReero-da f resisa* e nd t [SQtArg areat tf o[ATTine DATABASE]tdifcSQLwitd rguoTeAe 5ues are celr oe
*g t.
theTf iscaptArg arei aero-dadmbredeead L* tApriority ine aAesisa* e ork I/ceroa* e is iscaptArg area
** tempo*ger poiDBCONFIGeoTL_TR. DInbatce  iscaptArg arei adisa* ed itf o[ATTine]eSQLwitd e llest llewor ,batcbu ntsirdes are ce lleNT oTeA_S ctad-d duible zem  ssTL_TRVisrdisa* ed batce sneis  tArg arergul shoe atneweues are ON3** t ATTine]eisstls cdisa* ed batcrsinrdion eat tf on arryNeheabaLdiffereDBCONFIG_ENABLE_ATTine_CREATE]
, t_TL_TR.gp>
theTf issTL_TRVtconstfwo o NULL.
st in "Oareckent  be sy befn ts its  invV_Ra ht  be s[VF fai Slete control isr1,r0 hore-1erguero-da,rdisa* e, returnleovGfuneocks thtl   Arg arerguATTine anhe filues are celr oe
*g t batcrslle tfvedu. DInstebadld be  controlOi aunlo** t,*t aut0 dep1 isroe
*tenall  ()ettsirt  be syuet in "O Sy dld be/ control cs its,ereean inttay entegerbatce setArg arerguATTine a ctad/oe
*reues are Oi aero-dadm resisa* edk I/ file ts is u** tempnsSlete control.heyngIddAP_oOUND[LdiffereDBCONFIG_ENABLE_COMMENTS]]upperdt>differeDBCONFIG_ENABLE_COMMENTS</dt>upperdd>TfaidiffereDBCONFIG_ENABLE_COMMENTSNoTL_TReero-da f resisa* e nd t [SQtArg areV_Rlerludet anm**
seotrdifarexL* tCanm**
searecero-dadmbredeead L* [SQAn ts
iority ieIaAesisa* e orireroa* e  anm**
seotrdifarexL a
** tem  fromDBCONFIGeoTL_TR.gp>
theTf issTL_TRVtconstfwo o NULL.
st in "Oareckent  be sy befn ts its  invV_Ra ht  be s[VF fai Slete control isr1,r0 hore-1erguero-da,rdisa* e, returnleovGfuneocks thtl   Arg areV_Ruse  anm**
seotrdifarexL batcrslle tfvedu. DInstebadld be  controlOi aunlo** t,*t aut0 dep1 isroe
*tenall  ()ettsirt  be syur tf Sy dld be/ control cs itsereereean inttay _f
thehaLm**
searecaVFS algotrdifarexL  file ts is u** tempnsSlete control.heyngIddAP_oOUNDgIderlyoOUND[LDBCONFIG t NULL.
s]]erh3>A NULL.
stTetdiffereDBCONFIGeOpty in</h3>
* upperp>Moss beitty differeDBCONFIGeoTL_TRsstcontfwo o NULL.
s,a,of SQLiurn [SQ vlequesequesteQ[ds] objedbeETRY] ne]tharta tota s ma lurvics methos.heyn fai Slete control ( spee of tics methodteQds] objedbeETRY] ne) isrment  be sa** Dtabadld be  controlo ton ts its argument  be seCCI** fireSlete control isr1,batce sneis  sTL_TRVma fmenvero-dadeC I** fireSletet  be sy control isr0 htf it re
, t_TL_TR
i. disa* edeCvIf tsir Slete control isr-1 htf itis  sTL_TRVdolng t invi. uneocks ta C faidld be  control itf ots its argument  be s,   /* Ad** tactivIf tsirdld be  controlOi aunlo** t,*t auta ument is 0 dep1 isroe
*tenernsebatce set  be syuet in "O Sy dld be/ control cs its,ereean inttay entegerf Syk I/sllng t i. disa* eda r ena* edn file ts
iy** tn eeIkue. selle in NdmbrinteempnsSlete control.heyupperp>Whwevemoss differeDBCONFIGeoTL_TRssleCo spe control um wilintedescrib dli brrnschevhodstics graph,heabaLdiffereDBCONFIG_MAINDBNAME]k I/ dleLdiffereDBCONFIG_LOOKASIDE]eoTL_TRssnn ddiffs e ta CSeg urn [SQrocuid confli*beitto cuned pobjectvoTL_TRssfoild, ntls.he/
#dee whidiffereDBCONFIG_MAINDBNAMEiiiiiiiiiiii1000I/o *xWrit** a*iy/
#dee whidiffereDBCONFIG_LOOKASIDE iiiiiiiiiiii1001I/o he ar inmitnmiy/
#dee whidiffereDBCONFIG_ENABLE_FKEYiiiiiiiiiii1002I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_TRIGGERiiiiiiii1003I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_FTS3_TOKENIZERi1004I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_LOAD_EXTENSIONi1005I/o inmitnm*iy/
#dee whidiffereDBCONFIG_NO_CKPT_ON_CLOSE iiiii1006I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_QPSGNiiiiiiiiii1007I/o inmitnm*iy/
#dee whidiffereDBCONFIG_TRIGGER_EQPNiiiiiiiiii1008I/o inmitnm*iy/
#dee whidiffereDBCONFIG_RESET_DATABASEliiiiiii1009I/o inmitnm*iy/
#dee whidiffereDBCONFIG_DEFENSIVENiiiiiiiiiiii1010I/o inmitnm*iy/
#dee whidiffereDBCONFIG_WRITABLE_dCHEMANiiiiii1011I/o inmitnm*iy/
#dee whidiffereDBCONFIG_LEGACY_ALTER_TABLENiii1012I/o inmitnm*iy/
#dee whidiffereDBCONFIG_DQS_DMLN Niiiiiiiiiiii1013I/o inmitnm*iy/
#dee whidiffereDBCONFIG_DQS_DDLN Niiiiiiiiiiii1014I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_VIEW       iiii1015I/o inmitnm*iy/
#dee whidiffereDBCONFIG_LEGACY_FILE_FORMATNiii1016I/o inmitnm*iy/
#dee whidiffereDBCONFIG_TRUSTED_dCHEMAs   iiii1017I/o inmitnm*iy/
#dee whidiffereDBCONFIG_dTMT_SCANSTATUSN  iiii1018I/o inmitnm*iy/
#dee whidiffereDBCONFIG_REVERSE_SCANORDER iiii1019I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_ATTine_CREATENi1020I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_ATTine_WRITENNi1021I/o inmitnm*iy/
#dee whidiffereDBCONFIG_ENABLE_COMMENTSN  iiii1022I/o inmitnm*iy/
#dee whidiffereDBCONFIG_MAXNNNNNNNNNNNNNNNiiii1022I/o L** lsoiDBCONFIGey/
n future releasesEoa* e Or Disa* e ExtsnRedaRqld LtCade batcMETHOD:Qds] objheyuppe^Tf ods] objeextsnRed_sqld L_FCNTs() rout whiero-da f resisa* e nd t [SQ[extsnRed sqld LVFCNTs]Nfeat worat Mac OSVe^Tf oextsnRed sqld L
thehades nn ddisa* edabredeead Lsfoilf itorfcnt SQLIityArg ar.he/
differeAPIei.
a,s] objeextsnRed_sqld L_FCNTs(,s] objr, le sonoff);
n future releasesL  LiInsert RowidbatcMETHOD:Qds] objheyuppe^Ea "bertrurch moss dif OSsra* e n(ned posfoil[WITHOUTEROWID]sra* e d theharta uniqnt 64-bimises in
ll  () e sykeyieilit reabaLROWID | "rowid"]Ve^Tf orowideisstlded  ahis capak I/  anniundeEegsod[eolumnfnof dlROWID, OID, oil_ROWID_/  arang
as* fs tlyinnof sik  buntdtls cT_HANbreex
iori if
deEegsod[eolumnsVe^Inbatce Ssra* eeharta eolumnf mae poi[INTEGERiPRIMARY KEY]htf itis thETlumn invi. anhe filaliascelesheirrowid.heyuppe^Tf ods] objel  L_insert_rowid(D)N () metho u_. Theyr AGMA]reabaLrowid]*Neh theabamoss recL.
a,uvidssfule[INSERT]  ()etaorowideta* e ori[virt mldsa* e]
, t_nrdes are changed foroDVe^Inserts  ()et[WITHOUTEROWID]sra* e ik  buntbatcrss rd ta ^In nooruvidssfule[INSERT]s  ()etrowideta* es hovGE_FCNToc*ger d
, t_nrtsirdes are changed foroD,*t autds] objel  L_insert_rowid(D)Nr AGMA] [SQmentdOUN [SQAsroelleasobf therol autowilfcntlevor aows nn dinserthe rnsetues are 
, tta* es, tf on arry opGMA_S thehee of
** bus   /* Adrol ex
iori if
brinte[ds] objerolel  L_insert_rowid( ]lyibatcSimplvirt mldsa* e impleid confli n  /*INSERT aows  ()etrowideta* es ar retc is beihaLmitng t nrtransad foro(e.g.yuetflushtues eTviumulathe rnen the  [SQr isisk).tInd tndiC foorubseqntnckcFS s *
*meiste
** bus rehAll heirrowidk I/  sociathe e if tfasset  bopcodINSERT _FULL, or ,c in "bleadserefileunintui fveesqld LsVeVirt mldsa* e impleid confli nis tfdofoe
*r )etrowid
, tta* esli brrisroareiN32ahe abrrisrpro* em theatsc()** tempnorigin Tbatcrowiden arryN3** t or file rolel  L_insert_rowid( ]voted i*rehAllg t
theh for t s.vtf oT_Hr.heyuppe^(Ipotie[INSERT] oc*geslwfif] opctriggea tf it rir rout whiwe] 
to rehAll heirLrowid]*Nece set serthe row/  arang
as* faitriggea   fromrun ** . Oncoitfaitriggea progs meebes, tf on arry opGMA_S
** thehee orout whicevsrtsereews tfit wasobfed i*tfaitriggea wasof sod.)^heyuppe^Aie[INSERT] is tfs tos ducNrguaieanrirale lviolL, orlt. untdtk I/suvidssfule[INSERT] itd frary realocks withnn arry opGMA_S thehee batcrout whntr^TfusdINSERT OR FAIL,dINSERT OR IGNORE,dINSERT OR ROLLBACK,k I/ dleINSERT OR ABORT  contnon kue. ses.vtf orehAll ument ofshee batcrout wh wf it reiret serty ieentls.VFSeWf itINSERT OR REPLACE invencounthos
aieanrirale lviolL, or,fit frary reaentl. the fileINSERT hanoinucses.vSQLIleL_TReTfile devot** tnows is thEggindh theabaeanrirale lpro* em s cINSERT OR REPLACEsr lleaVded   kue. h theabarehAll ument ofshee N () metho.)^heyuppe^Flesheirpurpo iynat hee orout wh,otie[INSERT] iso o(s oprhe refile Adruvidssfuleevsetian l isrrubseqntncheyr tlnt ile i** uppeTeiste
** bus isrndis u** e iotdifcdrid LL.
slviand t [SQ[l  L_insert_rowid( sdifae
** bus]i** uppeIpotdroics to
isatabiaimum wrta newe[INSERT] o brrnsdof  [SQres are changed forowhweveheirLds] objel  L_insert_rowid( ]lyine
** bus isrrun ** undled useIkue. serrnsl  LiinsertrLrowid],batce sneis  nced.h opGMA_S theLds] objel  L_insert_rowid( ]   fromuneat wr* theendleS the2 reann mldteger iempnoldelesheirnewturnl  LiinsertrLrowid].he/
differeAPIeor file a valids] objel  L_insert_rowid(,s] objr);
n future releasesSol is  L  LiInsert Rowidoument.heynMETHOD:Qds] objheyuppeTf ods] objerolel  L_insert_rowid(D,*R) d
** ocaVFS s* firas
iority ierefilerol is  nced.h opGMA_S thecFS ** tds] objel  L_insert_rowid(D)NiotRfile  iflockt serty t nrrow/rnsettsirdes are .he/
differeAPIehe abds] objerolel  L_insert_rowid(,s] objr,or file a val);
n future releasesCounteTf oNis an Of Rows Mod fentbatcMETHOD:Qds] objheyuppe^Tf  cue
** busserehAll heir is an ad/nows mod fent,*i serthe returndevot
d[limtty moss recL.
lyvSQLIleLedrINSERT, UPDATE theDELETEfilereid LL.
a_nrtsirdes are changed forolle in Ndmbriempno durics methoVuppeTf ofwo e
** bussea imidbuifcnt ned posfoiltfait poiofheabarehAll umentk I/ dle fng tf heir is an ad/nows mod fent[limtty moss recL.
rINSERT, UPDATE, retdepDELETE isrg sholTmmeaimtty maximum nced.hd* and o ulimt poi"a v",etf ibatceabarehAll ument ofsor file Ikue. s()vi. undee whta ^Execut** tn eeoegerbatce poiofhdifcdrid LL.
 frary reamod fywithnn arry opGMA_S thehe  cue
** bussVuppeFlesheirpurpo iynat hee o () metho,ottCREATE TABLENAS sELECTcdrid LL.
 [SQroary realounte  anniINSERT, UPDATE theDELETEcdrid LL.
  dlef icoitfainowsk I/ d thasettsirnewe* thee  ttsirCREATE TABLENAS sELECTcdrid LL.
ik  buntbatccounthd.heyuppe^OnleeIkue. semadsedisqe if
brttsirINSERT, UPDATE theDELETEcdrid LL.
  r 
, teanr oprhe - auxiliareeIkue. seEggind theLCREATE TRIGGER | triggeas , ret[ed ies  keyiad forsle othREPLACE]aeanrirale latsolu bus nn d realounthd.heyuppeCkue. ses.vaiview rht harrl () md poNdmbrinte[INSTrnsmOFitriggea | INSTrnsmOFitriggeaslenn d realounthd.e^Tf oumentk I/ opGMA_S theor file Ikue. s()vimmt waemlds file tniINSERT, UPDATE thfromDELETEcdrid LL.
 run oroviview isstlded  mentd OnleeIkue. semadser iat Tbatcra* e ik  blounthd.heyuppeTeingsenn dmorrlSQLIioriteef_f  fieor file Ikue. s()ve
** bus is invexecut t wfwevenitriggea progs meisrrun ** .nTee o  /*happeo ieing

theprogs megin  heirLIkue. s()vdifae
** bus] horlifnnimplhe filEFS ile lyine
** bus in* fiseor file Ikue. s()vdisqe if. Essbuifntle:heyupperuerlyin ng dev^(Bfed i*e() mg t nrtriggea progs meithnn arry opGMA_S thlyin nnnnnnor file Ikue. s()ve
** bus issdovhd.eAfile thettriggea progs mlyin nnnnnnhasof nished itf oorigin Tnn arryisrrtsc()od.)^heyuppe ng dev^(Wfif] opctriggea progs meea "bINSERT, UPDATE  dleDELETEfile nnnnnnoeid LL.
a,_FCNithnn arry opGMA_S theor file Ikue. s()file nnnnnnup ieIQLIleL_TReTry rrmal. Oeihagest,shee oument e lle realerludefile nnnnnnn eeIkue. seaimum wed[limrub-triggeas,eas* firsr file Ikue. s()file nnnnnnument e lleNT dovhdh befr sc()ods file ea "brub-triggea hor aun.)^heyng/uerlyiuppe^Tfe o eN3y is tf_f  fieIkue. s()vdifae
** bus (oresimilao)V togindh thbrttsirsSleteINSERT, UPDATE theDELETEcdrid LL.
 wfif] opctriggea,tim
**Or AGMA]reabaument asRsrt wf it retcFS ** tdrid LL.
 beg b execut** Vuppe^I** tondigind the Sy dld be/oresubseqntnck,ter drid LL.
 wfif] opctriggea
theprogs m, tf on arry opGMA_S refln* s heir is an ad/nows mod fent[limtty
theprevhodstINSERT, UPDATE theDELETEcdrid LL.
 wfif] orrnsdof ctriggeai** uppeIpotdroics to
isatabimconstIkue. seo brrnsdof rdes are changed forfile fweve[sr file Ikue. s()] isrrun ** ue sneis  nced.h opGMA_S
invi. uneat wr* theendle reamea ** fuli** uppeSeg tls the
uguerlying devheirLds] objetota  Ikue. s()] i() metho invg devheirLlount_Ikue. searagma] invg devheirLlkue. s()vdifae
** bus] invg devheirLdes _ods aboearagma] invg/uerly/
differeAPIei.
a,s] objelkue. s(,s] objr);
differeAPIeor file a valids] objelkue. s64(,s] objr);
n future releasesTota sNis an Of Rows Mod fentbatcMETHOD:Qds] objheyuppe^Tf  cue
** busserehAll heirtota s is an ad/nows i serthe, mod fent[returndevot
d[limques[INSERT], [UPDATEle othDELETE]cdrid LL.
slSQLIleLedfileriicoitfaires are changed forowas oTeA_S,R (rlud a itto cuneecut t ar retc is beitriggea progs ms Dta ofwo e
** bussea imidbuifcnt ned posfoiltfabatce poiofheabarehAll ument  dle fng tf heir is an ad/nows mod fent[limtty
, teanged foroned hesmtty maximum nced.hd* and o ulimt poi"a v",etf ibatceabarehAll ument ofsor file tota  Ikue. s()vi. undee whta ^Execut** k I/ deeoegerce poiofhdifcdrid LL.
 frary reaaffqe fithnn arry opGMA_S thlyinor file tota  Ikue. s().heyuppe^Ckue. semadseastc is bei[ed ies  keyiad forslearrl (rludedli brrnbatccount,cbu ntso cumadseastc is beiREPLACEseanrirale latsolu bus nn batcnnlnt^Ckue. ses.vaiview rht harrl () md poNdmbr INSTrnsmOFitriggeask I/ n d realounthd.heyuppeTeirLds] objetota  Ikue. s(De]t () metho o durreand s heir is an retdftnows is thEocks thducNrgudifcdrid LL.
 run ag ] .tiues are 
, teanged foroDVeDAny,Ikue. sebynhe filues are changed forsea imignor ta** Dto d.  ctn kue. seng ] .tia des are coweveeat ihe filues are 
, teanged forssleCo spelnternaldes _ods abo]eSQLwitd oiltfabatcLdiffereFCNTL_DATA_VERSION]i[eilSsd for t]i** uppeIpotdroics to
isatabimconstIkue. seo brrnsdof rdes are changed forfile fweve[sr file tota  Ikue. s()] isrrun ** ue sneis  nced.k I/ opGMA_S i. uneat wr* theendle reamea ** fuli** uppeSeg tls the
uguerlying devheirLds] objeIkue. s()] i() metho invg devheirLlount_Ikue. searagma] invg devheirLlkue. s()vdifae
** bus] invg devheirLdes _ods aboearagma] invg devheirLdiffereFCNTL_DATA_VERSION]i[eilSsd for t] invg/uerly/
differeAPIei.
a,s] objetota  Ikue. s(,s] objr);
differeAPIeor file a valids] objetota  Ikue. s64(,s] objr);
n future releasesI() mrup nA Long-Run ** uQule batcMETHOD:Qds] objheyuppe^Tfiste
** bus  ggin  any,ean inttdes are csTULL, orls.vaborttvoi therehAll  tfitsrearlif LioTand un ar.nTee orout wh isrdypocntly
thehilit rincrsllorscNrguaiT_Hriad fore,ter arteats antt"Caicol" retdepCtrl-C wf  i*tfaiT_Hriwa*
seaarang
qule coTULL, orls.vha L
theimmt waemld.heyuppe^Il isrrafcNrgulquestre orout wh eat ia
isatabidiffs e t eat itfabatcehatabingng the e top-levrun ** ue stdes are csTULL, orn tBktiil
**Oi aunlorafcNrgulquestre orout wh wfile h[des are changed for] is t
**Oi aCes tdf reS the2Ces tobfed i*or file a v mrup ()Nr AGMA].heyuppe^IpotiedifasTULL, orlt. vle cnearlyof nished nto speSE_FNwf ibatcor file a v mrup ()NndiC lled itf utimim the2 reahovGEnnioTand un arbatce cbSsa v mrup hdh befS the2CanoinucNrgulQLIleL_TR.heyuppe^AiedifasTULL, orlngng thea v mrup hdhe llerehAll LdiffereINTERRUPT]Vuppe^I**thSsa v mrup hdhdifasTULL, orlt. tniINSERT, UPDATE, theDELETEfilengng thea s opean ex
iori rtransad for htf itis  buif i*transad forfile  lleNT c tlnt ile  autowilfcntle.heyuppe^Tf ods] objea v mrup (D)ulquesisstneeffqe fuui lvauesee top-levrun ** uppeSifcdrid LL.
slus  des are changed for] DlSQLIleLe.VFSA erneweSifcdrid LL.
sfilengng nn dstad o uafile thetor file a v mrup ()Nlques befbfed i*tfa therun ** udrid LL.
 lounterea "e  mentharrl () mrup hdh s ieing
ychad*d-in therun ** uchangeteQthetor file a v mrup ()Nlque.VFSNeweSifcdrid LL.
sfilengng nn dstad o uafile thetrun ** udrid LL.
 lounterea "e  mentharrbatcnnleeffqe nd the Sy dr file a v mrup ()Vuppe^AsequesteQds] objea v mrup (D)ungng oc*geslwf itis reck  bnonrun ** uppeSifcdrid LL.
sl ton no-op  dlefTry reeffqe foneSifcdrid LL.
sfilengng nn dstad o uafile thetor file a v mrup ()Nlquesr AGMA].heyuppe^TeirLds] objeis_ () mrup hd(De]t () metho C 32_GlT_HANrgud.  The P entegerbatcdepereaanl () mrup  the e top-levtneeffqe ffoil[des are changed for] DactivItOr AGMA]r1 ieianl () mrup  the e top-levtneeffqe , the0ihe fiwie .he/
differeAPIehe abds] objea v mrup (,s] objr);
differeAPIei.
a,s] objeis_ () mrup hd(,s] objr);
n future releasesD.  The P I**AiedifaSrid LL.
 IstCanIleLeheyuppeTeiinoaout whsenn duinfuleduri* tSQLwitd-l wh inpus rgud.  The P ieing

thehe top-leve() mHANrage seemses.vum w
aieanIleLeudifcdrid LL.
 returnieiais objectvinpktiistneheeefbfed i*san intt speSage rnsebatcdif OSsfoilicss** .ne^Tf  cuaout whserehAll 1 ieing
vinpkti*tri* k I/ ppeorrce cbSsaieanIleLeudifcdrid LL.
.VFSAcdrid LL.
 istjudgHANrgub 
, teanIleLeuian l ebes wfile hsemicolorls.kenfan. Or,ereaateatfixtdfttk I/oell-um wed[CREATE TRIGGER drid LL.
.VFSSemicolorserht harrles ad thawfif] batcotri* t] obral f requovhe idbuiffifilnof sie VFaLm**
searec relyin (olean an ls.kens ( spyck  be is beitty s.kenf (t in "Osspyck   inves ad th)undled useuoountolounte  ancdrid LL.
   The atng.D ^Wh
*ryptho invndleFaLm**
seis tfslventtempof nctvsemicolorla imignor ta** uppe^Tf  cuaout whserehAll 0f_f  fieorid LL.
 ist (rQLIleLe.VFSIfttk I/n the caVFSrity ieentls htf itdiffereNOMEMyisrrtpGMA_Sa** uppe^Tf  cuaout whseuoountoicssi*tfaiSifcdrid LL.
slndled usfile  lleunlof.  ctnsyntnd fcntlevtnETrr ctnSif.heyuppe^(Ipodif OSsfTry rt*d-in  niifntiznt a
** tLds] objeiniifntizn()] changbatce cin* f** tds] objerQLIleLe16()htf itds] objeiniifntizn() ist (* fidk I/ utowilfcntlevtheor file IQLIleLe16()eCvIf tsng tniifntizity ieentls batceabnceabarehAll ument eat ids] objerQLIleLe16()h  lleNT non-ment thereinrdion eat enteger oepereang
vinpktiSifcislSQLIleLe.)^heyuppeThh inpus rgu[ds] objerQLIleLe()] mE_FCd-on ment-  The atidk I/UTF-8e*tri* .heyuppeThh inpus rgu[ds] objerQLIleLe16()] mE_FCd-on ment-  The atidk I/UTF-16cotri* tinfno fveeisorly aft.he/
differeAPIei.
a,s] objerQLIleLe(*xWrit** a *,s]);
differeAPIei.
a,s] objerQLIleLe16(*xWrithe ab*,s]);
n future releasesRegisile A CFS ile Dto Hes thtdiffereBUSY Ethe suturKEYWORDS: {busy-mes thilEFS ile } {busyumes thr}batcMETHOD:Qds] objheyuppe^Tf a,s] objebusy_mes thr(D,X,P) rout whi,_FCNalEFS ile te
** bus Xfilengng S the2bSsa * fid wfile control Plwf iavblh thaee ffoll  isemadser iTvidssea des are c* theen sociathe e ifbatcLdes are changed for] Dly nee nhe filehatabbatcdepes is uehas* fir* theeFSrk ta** Dtabads] objebusy_mes thr()N () metho iulT_HANrguimpleid cbatcLds] objebusy_SE_Foute ].ndlelnternalbusy_SE_Fout].heyuppe^Ipo firbusyuEFS ile tiul** t,*t aut[differeBUSY]
**Oi a opGMA_S immt waemldsup ieencounthointt speFSrk.VFSIft firbusyuEFS ile 
**Oi aunlo** t,*t aut speEFS ile tS the2bSsa * fid wfilefwo o NULL.
s.heyuppe^Teir Slete control *
*meirbusyumes thilistamoQpy] aoin, he ar ts its a in "
**Oi a fir* of t control *
*ds] objebusy_mes thr().ne^Tf  dld be/ control sebatce sebusyumes thilEFS ile tiulheir is an ad/SE_Fy is tf Sy busyumes thilhas
, t eensa * fid prevhodsl celesheirdof rFSrkinttevset.VFSIft fi
, t usyuEFS ile tr AGMA]r0 htf itno ois objectvoffoll senn dmadse oh thavidsse. stdes are c dleLdiffereBUSY]Oi a opGMA_Sbatce ctfiras
iority iVuppe^I**thSsEFS ile tr AGMA]rnon-ment,*t autanhe filaffoll 
**Oi amadser iTvidsse. stdes are c dlethSsEyclbarepeo
s.heyuppeTf  eats icoidftt busyumes thilfrary reaol action is tfit   lleNT  (* fidk I/wf itis recisrFSrkh*xWLbui orn ^Ipodif OSsd.  The Py is tf_n* f** t Sy busyk I/mes thilEould sqld LV] opcdtabFSrk,fit   lleg iThtabh befr hAll LdiffereBUSY]
**Oe ctfiras
iority iea sttabhdft_n* f** t Sy
, t usyumes thiVuppeCanr oprEn scenahan wf  i*to
*es is ueisrholdy t nrrtabhFSrkhis t
**Oi  isetryg t uo*es motcNrguaiats rvhdhFSrkhvoi theaadld be is is ueisrholdy t nrrts rvhdhFSrkhis tfit isetryg t
**Oe ces motcNrguaronedlusbvelFSrk.VFTeir Sleteis is uechngoteis isndh thba gginoit isebFSrk t the Sy dld be/ dlethSsdld be is is uechngoth this isndhba gginoit isebFSrk t the Sy  SleteCvIf boif is is ue batc (* fif Sy busyumes this hnteger i  llemcontany,erogss u.VFTeirfed i,batcdif OSsr AGMA]rLdiffereBUSY]Oelesheir Sleteis is u, hep** t Satshee file  lle (oucoitfai Sleteis is uer iatlere OitsrrtabhFSrkh befnventbatce sedld be is is uee ces isnd.heyuppe^Teirdeead LsbusyuEFS ile tiul** t.heyuppe^(Teirf C 32o durd-on  i* er busyumes thilfee whtOelesea "batcLdes are changed for]a CSetng t nrnewebusyumes thilEleorrtn e
theprevhodsl csrt mes thiV)^VFSNoto
is tfcFS ** tLds] objebusy_SE_Foute ]batcdepeumenang t lnternalbusy_SE_Fout=Nle  llelocks with
, t usyumes thiundled useIleortany,erevhodsl csrt  usyumes thiVuppuppeTf  busyuEFS ile tshould ereancontany,ad forst in "Omod fywithupperes are changed forois tf_n* ft reaba usyumes thiV tIndhe filw rd   Thehe Dbusyumes thilisterearerotrantVeDAny,,ter acty inted sqld LV] oundee whtt eAMEang.uppuppeADbusyumes thilmE_FCuntoles totfaires are changed forbatcdep[th genadmdrid LL.
]ois tf_n* ft reaba usyumes thiVhe/
differeAPIei.
a,s] objebusy_mes thr(,s] objr,i.
(*)(he ar,i.
),he ar);
n future releasesSol A BusyuTE_FoutbatcMETHOD:Qds] objheyuppe^Tfistrout whi,_FCNal[,s] objebusy_mes thr |a usyumes thi]ois tfsleeps
, tfthe 5lle in Ndmamountead/SE_Foy nee 5sa* e iseFSrk tane^Tf  mes thifile  llesleepeS.)^
**olSE_Fy uui lvatblea_FC"ms"tS S *dld be eat sleepg t
**OhovGEnviumulathe.VFSAfile ttblea_FC"ms"tS S *dld be eat sleepg t  Thehe Dmes thr r AGMA]r0c in "bC gin   or file rtepe ].r iathAllall LdiffereBUSY].heyuppe^CFS ** ttfe orout wh wfile n/ control eof tghN3ly ann mldr iment theAGMA]ratafquesbusyumes this.heyuppe^(Teirf C 32o durd-on  i* er busyumes thilfthe 5tarincularbatcLdes are changed for] t hany,givsetmoLL.
.VFIpotihe filbusyumes thifile aslfee whtO (a
** tLds] objebusy_mes thr()])uchangeteQcFS **  Thehee orout wh,ongng oe filbusyumes thiOi aCeea)od.)^heyuppeSeg tls t elnternalbusy_SE_Fout]he/
differeAPIei.
a,s] objebusy_SE_Foute,s] objr, le sms);
n future releasesSol is  SollkuTE_FoutbatcMETHOD:Qds] objheyuppeTee orout wh isrd durginfulericSiffereENABLE_dETLK_TIMEOUTEbit ds.tIeh theabaVFShd* and sebFSrki* t]Srks,t tot_FCN speSE_Flockt smsigind th inveligitheeFSrksstconn orowmldnCNTvdes are nvthe Sy dle in Ndmues are 
, tmes th.tIndnon-SiffereENABLE_dETLK_TIMEOUTEbit ds horlifneabaVFShfrarbatcnnled* and ebFSrki* t]Srks,tteiste
** bus isrn no-op.heyuppePas antt0 *
*meiste
** bus sisa* e nbFSrki* t]Srks tltogteger.ePas antuppe-1ergumeiste
** bus requesty is tf Sy VFShb]Srks fthe 5rang
SE_Fo-lyin (olf niemldsifttss
** e.nTeeesqld Lseat pas antt deeoegerceegc fvevumentk I/ n duWdee whtaheyuppeI  bopcoly,*ea "bdif OSsdes are umes thtsc()ostfwo SE_Flockn arrt,-with
, t usy-SE_Flock(gind fthec tlile tSCNTvdes are n horlifneabaVFShfrarc relyind* and ebFSrki* t]Srks)/ dlethSsdlllk-SE_Flock(gind fthebFSrki* t]Srksbatcdrowml-SCNTvdes are n).Dtabads] objebusy_SE_Foute  d
** oct_FCNboifbatcn arrt,tteiste
** bus t_FCNe durthSsdlllk-SE_Flockument.FTeirfed i,batcrgulQRY] u i*saics to
 usy-SE_Flockitd nlllk-SE_Flockuments fthe 5 i* erupperes are cmes th,Nlquesds] objebusy_SE_Foute  slvent_S thehee of
** busaheyuppeWf iavbllheir is an ad/eanged forssrguaiwmldnCNTvdes are  fFS s eat uppe1ergu0,vrrnsla_FChanged foroiconstaronedlusbvelFSrka_nrtsirdes are  batceabnccheckcs itseitd fevot
CN spewmldeilS. Whweveit isedo** ttfe ,tn e
thenewehanged forois tftrieuer iatabheat itfavdes are  fFtos wfile nbatcdiffereBUSY  the . Oa,tieitty differedETLK_BLOCK_ON_CONNECTc 
**ue 
thep  the eoehe is re,vrrnsnewehanged forob]Srks uui lvis  bedlusbvelFSrk
, tmes*d-in atlere dVhe/
differeAPIei.
a,s] objenlllk_SE_Foute,s] objr, le sms, le s 
**s);
n future releasesF
**s fthe,s] objenlllk_SE_Foute)he/
#dee whidifferedETLK_BLOCK_ON_CONNECTc0x01
n future releasesConvsei icoiRout whseFlesRun ** uQuleie batcMETHOD:Qds] objheyuppetaissthe 5rtgacyt () metho ngng theprts rvhdhftheble wnrds SQLIityArg ar.he* Ust ofshee N () metholistereareFaLm**dhtaheyuppeDlf niefor: A <b>sqld LVsa* e</b>sthe 5n the cues enanded worC shoelelimtty
, tLds] objegtee* the()] i() methoVeDA sqld LVsa* ecrss rd nd t [SQeanIleLeuqule csqld Lseeat ihne orimorrlquleie VuppuppeTf  ta* e  and po. Theyharta  is an ad/nows ndleFalumnsVetBktbatceabsir is ansik  buntde is beitty sqld LVsa* ecitself.VFTei tlyinnis ansik  bobLnt admdaics todu. DLol NcbSspeir is an ad/nows
invndleMcbSspeir is an ad/FalumnsVuppuppeADsqld LVsa* ecise n/ cray] aots its sdr iment-  The atid/UTF-8e*tri* s.heyn fareck  b(N+1)*Mvel LL.
sl neis  tcray.VFTeir SleteMots its sdts itbatcrgument-  The atid/*tri* s ngng h*xWLa neis  nof sie**thSsEalumnsVuppnTeeesqma ninttentrieuequests itcrguqule csqld Ls.VF** tkuments sqld L
the ne** tkts its sVeDAuesoegercuments arrl (*thSir/UTF-8ement-  The atidk I/otri* th gats iconfli*a a opGMA_S theLds] objeEalumn_Sage()]VuppuppeADsqld LVsa* ecS the2Cansiss beihne orimorrln the caVFSrity isactivItOi aunlorafcNrgup  t nrrtsd LVsa* ecdisqe if
rgu[ds] objefree()]VuppeADsqld LVsa* ecshould birdeaVFSritnt a
** tLds] objefreee* the()].heyuppe^(AstaroneanIle beitty sqld LVsa* ecum wil,nd* ane c uqule csqld L
**Oi aascelVFS s:heyupperb]Srkquovh><gatrlyin nnnnnnNof rrrrrrrr| Agefile nnnnnn-----------------------file nnnnnnAlicerrrrrrr| 43file nnnnnnBob rrrrrrrr| 28file nnnnnnC (oyrrrrrrr| 21upper/gatr</b]Srkquovh>uppuppeTf reck  bfwo eolumns (M==2)/ dlethree/nows (N==3).VFTeu nd t [SQsqld LVsa* echart8tentrieua CS* ane ctty sqld LVsa* ecistsc()on
ll  (e n/ cray]nof dlazRqld L.VFTeinlazRqld Lrholdsshee N*xWLbui:heyupperb]Srkquovh><gatrlyin nnnnnnazRqld L&#91;0] = "Nof ";lyin nnnnnnazRqld L&#91;1] = "Age";lyin nnnnnnazRqld L&#91;2] = "Alice";lyin nnnnnnazRqld L&#91;3] = "43";lyin nnnnnnazRqld L&#91;4] = "Bob";lyin nnnnnnazRqld L&#91;5] = "28";lyin nnnnnnazRqld L&#91;6] = "C (oy";lyin nnnnnnazRqld L&#91;7] = "21";lyinr/gatr</b]Srkquovh>)^heyuppe^tabads] objegtee* the()te
** bus eumenan seo e orimorrk I/oemicolor-daics todeSifcdrid LL.
sl neis  ment-  The atid/UTF-8k I/otri* tdft_
sl2be ics methoV befr hAllt nrrtsd LVsa* ece ctfi
theps its agivsetint_
sl3f tics methoVuppuppeAfile thetas
iority iehasof nished e if tfarrtsd LVeat ids] objegtee* the() batcimimE_FCp  t tty sqld LVsa* ects its arguds] objefreee* the()tinty aftett therelere Otty n the cis tfwa amaVFSrhe.VFBa gginobeitty oaretty
, tLds] objemaVFSrne]thappeoslwfif] ods] objegtee* the() *thSsEFS antuppef
** bus  E_FCuntotrurrgulques[ds] objefree()]vdisqe if.  Onle
, tLds] objefreee* the()]Oi aa* ece crelere Otty n the cprsTULldsa dorafcle.heyuppetabads] objegtee* the()t () metholistimpleid chdh s aiwrappesy cever
, tLds] objeneec()]. etabads] objegtee* the()trout wh frary reahovGEnviessbatcrgu deet  bopcodues enanded wosrat Mac OSVevItOgin  e durthSspubior
ll  () metholfee whtOf re.D As*aieanreqntnho,o the s ngng oc*geli brrnbatcwrappesylayan auts opeofshhSsa v mpcodLds] objeneec()]Nlques   buntbatcrsfln* Cdli brubseqntnckcFS s *
*Lds] objenrrFCNT()]NngbatcLds] objenrrmsg()].he/
differeAPIei.
a,s] objegtee* the(
nnor file *db, rrrrrrrrI/o AnuoTeAedes are  e/
  *xWrit** a *zSql,rrrrI/o difar cbSseumenan d e/
  ** a ***pazRqld L,rrrI/o Rqld Lseat hhSsqule ce/
  tnmiypnRow, rrrrrrrrII/o Nis an ad/nqld LVnows oe
*tenef rece/
  tnmiypnColumn,rrrrrrII/o Nis an ad/nqld LVeolumns oe
*tenef rece/
  ** a **pzErrmsgrrrrrII/o Ethe  msgroe
*tenef rece/
);
differeAPIehe abds] objefreee* the(** a **nqld L);
n future releasesFm wiltodeStri* tPri*ng t F
** bussheyuppetabinoaout whsenn dwor -alik sie**thSs"pri*nf()" fFmily] aof
** bussheyheat itfavriaid f tC library.uppetabinoaout whsee usrriaid moss e**thSsEamm ieem wilti* tdTL_TRssfat uppetfavriaid f tlibrary pri*nf()
theplusNsimplois objectvnon-riaid f tem wils ([%q], [%Q], [%w],nitd [%z])VuppeSeg urn [bit t-in pri*nf()]Qrocuid confli*foild, ntls.heyuppe^tabads] objempri*nf()sa dors] objevmpri*nf()saout whseoe
*r )hSir [SQsqld Ls  ()etn the cobLnt admeat iLds] objemaVFSr64()]Vuppetabadtri* s  opGMA_S thehe  cufwo aout whseshould bi therelere S theLds] objefree()]V  ^Boif aout whserehAll tk I/** tkts its tieiLds] objemaVFSr64()] i. una* ece caVFSritntenougfbatcn the ciorhold tty sqld L** udrri* .heyuppe^(Teie,s] objennpri*nf()saout whcistsimilaoere "nnpri*nf()"sfat uppetfavriaid f tC library. nTeeesqld L isroe
*tenernsettsi
, t uffs nd* alihdh s e sedld be ics methoVwso cusizhcistgivsetbrinteempnsSleteics methoV Noto
is tfempny afteoft fi
, tsSletefwo ics methosOi a ovsr
edmeat innpri*nf()V)^VFtaissthe nbatcf itorfcnt nvii an lss tfcFn rt*d-tsSxed e iflockbreakantuppeble wnrds SQLIityArg ar.VFSeNoto
tls cis tfss] objennpri*nf() therehAllt nrts its argu_
sl uffs na sttabhdftpeir is an ad [SQe* aacthos
aco. Theyoe
*tenernsettsir uffs V)^VFWploimithis t
**Opeir is an ad/F* aacthos
oe
*tenewould biraimorrlginfuleathAllall ument bu nwefcFn rt*locks withnimpleid confli ofsor file nnpri*nf() theunwee iflockbreakant SQLIityArg ar.he*uppe^A arang
as* fai uffs ndizhcistg sholTmmeaimment,*or file nnpri*nf() theol actiony is tf Sy buffs nasstlded  ment-  The atidane^Tf   Sletk I/ics methoV"n"Oi a fir*ota sdizhcoff Sy buffs ,R (rlud a iyptho*foi
**Opeirmenth  The atng.D Settsirrangf Liotri* tss tfcFncbSsc nIleLele
, toe
*tenew lleNT n-1/F* aacthos.heyuppe^tabads] objevnnpri*nf()saout whcista umrargsdods abo ofsor file nnpri*nf()i** uppeSeg tls t  [bit t-in pri*nf()],p[thi*nf()sdifae
** bus] i/
differeAPIe** a *,s] objempri*nf(*xWrit** a*,...);
differeAPIe** a *,s] objevmpri*nf(*xWrit** a*, um_l it);
differeAPIe** a *,s] objennpri*nf(i*n,** a*,*xWrit** a*, ...);
differeAPIe** a *,s] objevnnpri*nf(i*n,** a*,*xWrit** a*, um_l it);
n future releasesM the cAVFSrity ieSubsysttmheyuppetabathe use orrlgins* fie cthree/nout whsefthe lltdft_
slownall  () mpcodn the caVFSrity ienehes. "Corr"l neis  prevhodsts ictnhoupperrary realerludetsTULL, ng-systtm dle in c [VFS]nimpleid confli. the fileW (oows VFShgins*no fveemaVFSrnesa dofree() fthe,implhFULL, or .heyuppe^tabads] objemaVFSrnesrout whicehAllt nrts its arguaob]Srkuppedftn the catblea_FCNeisorsl nelength, wf  i*NOi a firics methoVuppe^Ipods] objemaVFSrnesi. una* ece cobLnt nd*fn cie t eaeebatcn the ,t tocehAllt nr** tkts its .VFSIft firics methoVNerefilers] objemaVFSrnesi. menthorceegc fvevtf itds] objemaVFSrnesr AGMA] [SQnr** tkts its .heyuppe^tabads] objemaVFSr64(Nesrout whiwor stju_FClik filers] objemaVFSrnNesned posss tfNcise n/unses in 64-bimi () e sya sttabuppedftaises in 32-bimi () e s.heyuppe^CFS ** tds] objefree() wfile hts its aerevhodsl c opGMA_S
** theds] objemaVFSrnesthe,s] objereaVFSrnesr lere y is tfn the csebatce  tfit S the2bSsregind.ne^Tf  ds] objefree() aout whcis [SQnrno-op ian l isrhilit rwfile h** tkts its .VFPas antt h** tkts its batcrguds] objefree() isrharmls u.VFAfile bf thefreee, m the  [SQshould eteger ibSsread errtoe
*ten.VFEvin atad** uchevhodsl cersndh thn the cS the2sqld LV] opcsegid confli*fad Loy soegercsovsre  the .h thM the cETrrup for hpcsegid confli*fad L,oy soegercsovsre  the h thn the2sqld LV]fuds] objefree() isrhilit rwfile hnon-** tkts its tis t
**OwTry rt*obLnt admeat ids] objemaVFSrnesthe,s] objereaVFSrne.heyuppe^tabads] objereaVFSrnX,N)t () metholoffoll see credizhctk I/changen the caVFSrity ieXce cbSsatblea_FCNeisorsVuppe^I**thSsXtics methodteQds] objereaVFSrnX,N)
**Oi aa ** tkts its tisent_
sl eAMEanglistidbuifcnt teQcFS **  Thers] objemaVFSrnNeVuppe^I**thSsNtics methodteQds] objereaVFSrnX,N)si. menthor theuegc fvevtf it Sy beAMEanglistexae if
reirdof rasQcFS **  Thers] objefree(XeVuppe^ds] objereaVFSrnX,N)scehAllt nrts its arguaon the caVFSrity iuppedftatblea_FCNeisorsl nedizhcor ** tkian nd*fn cie t n the ci  ahis capaVuppe^I**MOi a firdizhcoff Sy changeaVFSrity i,*t authe (N,M)eisorsloft fi
, tchangeaVFSrity iik  blopihe rnset Sy begin ** uoff Sy buffs c opGMA_S
** theds] objereaVFSrnX,N)s dlethSschangeaVFSrity iie ofrsnd.heye^Ipods] objereaVFSrnX,N)scehAllt ** tk dleNciseposi fve htf it re
, tchangeaVFSrity iie o reaersnd.heyuppe^Teirds] objereaVFSr64(X,N)t () metholwor streirdof ras Thers] objereaVFSrnX,N)sned posss tfNcise  64-bimiunses in  () e sya sttabuppedftai32-bimises in  () e s.heyuppe^IpoXsthe 5n the caVFSrity iichevhodsl cobLnt admeat ids] objemaVFSrne, Thers] objemaVFSr64(),e,s] objereaVFSrne,sthe,s] objereaVFSr64(),etf ibatcor file mdizh(XeOr AGMA]reabadizhcoff S tfn the caVFSrity iieneisorsVuppe^Teirn arry opGMA_S theor file mdizh(XeOS the2bSsl** lTmmeaimtty  is an retdftisorslrequest t wfeieXcwTryaVFSritnt.VFSIftXOi aa ** tkts its tisenbatcor file mdizh(XeOr AGMA]rmentd  IftXOcs itseree,impif] g ngng theuntbatc Sy begin ** uoffn the caVFSrity i horlifnil cs itsereeatem wULldall umeidfn the caVFSrity iingng fTry rw*d-in freee, tf it Sy beAMEang retdftor file mdizh(XeOi. undee whtk dletss
** yrharmfuli** uppe^Teirn the c opGMA_S theor file maVFSrne,s,s] objereaVFSrne, Thers] objemaVFSr64(),ea dors] objereaVFSr64()
**Oi aalded  ales in reeatblea_FCaim8eisorlbeverae ,tngeteQtk I/4eisorlbeverae tieitty Ldiffere4_BYereALIGNED_MALLOC]eSQLpile-SE_F retdTL_TR
i. ushd.heyuppeTeirts its to NULL.
strgu[ds] objefree()]nitd [,s] objereaVFSrne]batcmE_FCd-oteger i** tky anlseots its sdobLnt admeat ia changbatc_n* confli ofsLds] objemaVFSrne]tdep[,s] objereaVFSrne]ingng fTvrbatcnnleyet*d-in atlere dVheyuppeTeiras
iority ie E_FCuntoread rrtoe
*ntany,e is be [SQnrbFSrka_ffn the cafile ittmes*d-in atlere d a
** 
, tLds] objefreene]tdep[,s] objereaVFSrne].he/
differeAPIehe ab*ds] objemaVFSrni.
);
differeAPIehe ab*rs] objemaVFSr64(rs] objeua val);
differeAPIehe ab*rs] objereaVFSrnhe ar, i.
);
differeAPIehe ab*rs] objereaVFSr64(he ar, rs] objeua val);
differeAPIehe abds] objefreenhe ar);
differeAPIeor file ua valids] objemdizh(he ar);
n future releasesM the cAVFSritdepSridisifcsheyuppethe useprovidns* fie ctwot () methosefthereand inttay tfavriatusfileNeheabaLds] objemaVFSrne],tLds] objefreene],nitd [,s] objereaVFSrne]batcnout whs,c in "bum w
 Sy but t-in n the caVFSrity iisubsysttm.heyuppe^TeirLds] objen the _ushdne]trout whicehAllt peir is an ad/isorsuppedftn the che top-levautsiaidintt(maVFSrhe bu n reaersnd).uppe^TeirLds] objen the _h thwholTne]trout whicehAllt peirmaximumall ument ofsLds] objem the _ushdne]triicoitfaih th-wholTrmark
**OwTryla_FCats t.ne^Tf  uments sqpGMA_S theLds] objem the _ushdne]taer
, tLds] objen the _h thwholTne]tlerludet deeovsrhtabuppe d thathethe useint_
slimpleid confli ofsLds] objemaVFSrne],
, t u n reaovsrhtabe d thathe deee usriy** tsysttm librarybatcnout whsingng Lds] objemaVFSrne]tmayuEFS i** uppe^Teirn the ch th-wholTrmarkyisrrtsel *
*meirhe top- ument of
, tLds] objen the _ushdne]tieiand e durift firics methoVrefileLds] objen the _h thwholTne]tlsetrue.ne^Tf  umentc opGMA_S
** theLds] objen the _h thwholTn1e]tlsetfaih th-wholTrmark
**OchangeteQthetats t.he/
differeAPIeor file a valids] objen the _ushdnhe a);
differeAPIeor file a valids] objen the _h thwholTnle latsetF
**);
n future releasesPseudo-Randt iNis an GenULL,ngbatuppethe use*xWLa n aa h th-n ml arepseudo-randt i is an genULL,ng (PRNG)lT_HANrg Thereln*  randt iLROWID | ROWIDs] wfeiet serty t newerss rd ni()etaosa* eces t
**Oalreadyegin  heirl** lsoitss
** eiLROWID]. etabaPRNGOi aals cT_HANfoi
**Opeirbut t-in randt nesa dorandt bFSb()sdifae
** busu.VFTee N () metholaVFS s
**Oas
iority iser iTvidsse. stdof rPRNGOfy soegercpurpo iy.he*uppe^AsequesteQtfe orout wh sc()ostNeisorsloftrandt ns uei()etbuffs cP.uppe^TeirPrics methoVcFncbSsnr** tkts its .heyuppe^It hee orout whsfTry rt*d-in chevhodsl chilit rorlifneabachevhods [SQequeshad*N eof tghN3ly e oria ** tkts its tfy sP, tf it Sy PRNGOi  Thereheeefa
** trandt ns ueobLnt admeat i Sy xRandt ns ued
** ocNeh theabadeead LsLds] objevfsle bjn* Vuppe^I**thSsprevhodstequesteQtfe orout wh habh b*N oft1 orimorrl befnbatcnnn-** tkP tf it Sy pseudo-randt ns ueisrgenULL,in
ll  () opcolyl befe iflockrss ursece ctfisLds] objevfslexRandt ns uh thn ** o.he/
differeAPIehe abds] objerandt ns unle lN,ehe ab*P);
n future releasesCoLpile-TE_F Au** rizity ieCFS ile  batcMETHOD:Qds] objheyrKEYWORDS: {au** rizhilEFS ile }** uppe^Tee orout wh regisilese n/ u** rizhilEFS ile  wfile htarincularbatcLdes are changed for],nd* alihdh neis   Slete control.uppe^Teir u** rizhilEFS ile  ist (* fidrasQSifcdrid LL.
slnre bf theSQLpileS
** theLds] objeth genane]tdep_
slvaria*
seLds] objeth gena_v2ne],
, tLds] objeth gena_v3ne],tLds] objeth gena16()],tLds] objeth gena16_v2ne],
, titd [,s] objeth gena16_v3()]V  ^Atlvariods [SQcs itseduri* tthSsEampility iich is u,   aragic isebf theS shoelbatcrguaimum wlvariods acty in *thSs u** rizhilEFS ile  ist (* fidrrg ThereP ieingne c d forsea imavent_S.ne^Tf   u** rizhilEFS ile  should
therehAll LdiffereOK]ce caVFSttempoad for hLdiffereIGNORE]Qr isisaVFSttemp Therle in c ad fore u naVFSttempodifcdrid LL.
 rgulQRoinucNrgub 
, teanIiled idep[differeDENY] teQcFleCo spebuif i*difcdrid LL.
 rgubi therejn* Cdlwfile n/ the . e^I**thSs u** rizhilEFS ile  r AGMA] [SQndeeument othlTmmeaimLdiffereIGNORE], LdiffereOK] idep[differeDENY]h theabnctfisLds] objeth gena_v2ne]ly ann iumetnckcFS  is tftriggeandh theaba u** rizhilw llefFtolwfile n/ the hn ssageaheyuppeWf i*thSsEFS ile tr AGMA]rLdiffereOK] i S tfn alt peirhFULL, or therequest t isrdk.D ^Wh i*thSsEFS ile tr AGMA]rLdiffereDENY],etty
, tLds] objeth gena_v2ne]ly ann iumetnckcFS  is tftriggeandetty
, t u** rizhilw llefFtolwfile n/ the hn ssage ex
ia ninttes t
**Oacis ueisrdsei d.heyuppe^TeirsSleteics methoOe ctfirau** rizhilEFS ile  istamoQpy] aoin, * of 
 I/ics methoVteQthetor file roleau** rizhi()t () metho.e^Tf  dld be/ics methobatcrguthSsEFS ile tise n/ () e syLdiffereCOPY | ad foreFCNT]ois tfsle in Nsh theabatarincular ad foree cbSsau** rizhd.e^Tf o* of tthrougftrixif ics methosbatcrguthSsEFS ile tarrleeger i** tkts its sdorument-  The atid/*tri* sbatce  tf*xWLa neois objectvd, ntlsvabouttempoad foree cbSsau** rizhd.batcAs
iority ise E_FCalded  bSspregenadme cencounthoia ** tkts its t (e nyfileNeheaba* of tthrougfteabadixif ics methoseNeheabaau** rizity ieEFS ile .heyuppe^Ipo firad foreFCNTtiseLdiffereREAD]
, titd thSsEFS ile tr AGMA]rLdiffereIGNORE]Qrf it re
, t[th genadmdrid LL.
]oorid LL.
 isteanriru* Cdlree,ubstituty
, t F** tkumentt (e
iachcoff Sy ta* e  alumnfis tfwould fTvrbatcd-in ataef_f LdiffereOK]chad*d-inrrtpGMA_Sa etabaLdiffereIGNORE]
therehAll C 32_GlT_HANrgud.ny,an/unirustnt a
Hriadis uee cindividu Tbatceolumns dftaitcapaVuppe^W nee 5sa* e iserefs e cthathe aLdELECT]t u n r  alumnfuments arruppeextaacthdmeat i SaLVsa* ec(eleseeanIle ] opcqule clik file"sELECTccount(*) FROMVsa*")heabnctfisLdiffereREAD]rau** rizhilEFS ile 
**Oi a (* fidrand OelesheaLVsa* ecwfile h alumnfnof ctgng the n/ mparedrri* .heye^Ipo firad foreFCNTtiseLdiffereDELETE]citd thSsEFS ile tr AGMA]
, t[differeIGNORE]Qrf it rethDELETE]csTULL, orles isndscbu ntse
, t[irunritntdTL_mizity i]tlsesisa* edh befnve aows nn ddevot
d[individu Tle.heyuppeAn/ u** rizhiliulT_HANwfeieLds] objeth gena | th geni* ]uppethecdrid LL.
sleat ian/unirustnt s urho,oe censuro
is tfempnSifcdrid LL.
sfileuoountotrurrguadis ueues etspyck  bereaavent_S ree,ee,tngets tfempyeuoountbatcerurrguneecut emaVichodstsrid LL.
slis tfdamagtotfaires are a eFoi
**OeeanIle,otieas
iority ie aynaVFSttaiT_Hrie cents to bitrarybatcSifcquleie Oeleseumenangore yea des are n tBktiteiras
iority iefrarbatcnnlewa*
iteirT_Hrie cbSsa* ece cmconta bitraryn kue. ses.vtf fileues are n tAn/ u** rizhilEould rf itbSspockt s
iachcwhweveheifileT_Hr-e() mHANSifcislbf theLds] objeth gena | th gened] is t
**OsisaVFStstevsryif] g ned posLdELECT]tsrid LL.
s.heyuppeAs
iority isers tfneheee ces isssQSifceat iunirustnt s urhouh thn the2als ceanr opr ent_ri* th s urhoclim_
sla
** tLds] objelim_
ne]batc beflim_
inttdes are cdizhca
** t rethmax_pagt_count]elnterna]
**Oineois objeee cu antt d/ u** rizhi.heyuppe^(Onleen  i* er au** rizhilEFneNT  (e
iachconea des are changed forbatct ha SE_F.VFEa "bC uesteQds] objeroleau** rizhiaovsrridns* fi
**OchevhodstequeV)^VFSDisa* ectfirau** rizhilbyya stFS ** t F** tkEFS ile .hey Tf   u** rizhillsesisa* edhbyydeead LVheyuppeTeirau** rizhilEFS ile   E_FCuntodgu deif] g ngng   llemod fyh theabades are changed forois tf_n* ft reabaau** rizhilEFS ile .hey Noto
is tfLds] objeth gena_v2ne]litd [,s] objertepe ].boif mod fywithir [SQues are changed forseelesheirmea **  dft"mod fy"l neisistc iagraph.heyuppe^WfeieLds] objeth gena_v2ne]liulT_HANrguth gena ncdrid LL.
,etty
, torid LL.
 S the2bSsre-th genadmduri* t[,s] objertepe ].ducNrgunbatcscheman kue. .VFHtnho,oteiras
iority ieshould ensuro
is tfempbatceorr ctn u** rizhilEFS ile  r ma n a (e
iachcduri* tthSs[,s] objertepe ].heyuppe^Noto
is tfempn u** rizhilEFS ile  ist (* fidre durduri* 
, tLds] objeth genane]tdep_
slvaria*
sn tAu** rizity ietheuntbatcaimum wed[duri* torid LL.
 eumenangoreins[,s] objertepe ],iunls uh thastsrid dh neis  chevhodstc iagraph,*or file ntepe t (* fis Thers] objeth gena_v2neee creth gena ncdrid LL.
s file tcscheman kue. .he/
differeAPIei.
a,s] objenlleau** rizhi(
nnor file*,
  tnmi(*xAu**)(he ar,i.
,*xWrit** a*,*xWrit** a*,*xWrit** a*,*xWrit** a*),
  he ab*pU_HrDes 
);
n future releasesAu** rizhilRehAll CCNTsheyuppetabs[,s] objeroleau** rizhia|n u** rizhilEFS ile  e
** bus]  E_F
therehAll eeger iLdiffereOK]cy sonhcoff Sys bfwo eo stF.
sl ney aftbatcrguses ctvthe useenteger oepereang
va* bus isrp Thettnt.VFSeg urn
, tLds] objeroleau** rizhia|n u** rizhilrocuid confli]Oelesois object
**Oinem wilbusaheyuppeNoto
is tfdiffereIGNOREOi aals cT_HAN s ai[lQRYior latsolu bus nCNT]
therehAlladmeat i Sy Lds] objevs a_on_lQRYior ()] i() methoVhe/
#dee whidiffereDENY   1rrI/o Aborttempodifcdrid LL.
 wfile n/ the he/
#dee whidiffereIGNOREO2rrI/o Don' naVFSttadis u,cbu ndon' ngenULL,ie n/ the he/
n future releasesAu** rizhilA* bus CCNTsheyuppetabs[,s] objeroleau** rizhi()] i() metho regisilese lEFS ile  e
** busbatce  tfist (* fidrrgn u** rizh cerLa nedifcdrid LL.
 a* busu.VFTerk I/oed be ics methoVrguthSsEFS ile tise n/ () e syFCNTtis tfsle in Nsh thwht ha* bus isrbf theau** rizhd.eetabinoa i*tfai () e syad foreFCNTs is t
**Oempn u** rizhilEFS ile   aynbSsp  theVheyuppeTeisirad foreFCNTtuments ses  fywwht hkinbhdftsTULL, orlt. rgubi theau** rizhd.eetabl3f titd 4if ics methosee ctfirau** rizL, or theEFS ile te
** bus w lleNT ics methoseN i** tkolean inttay  in "boff Sys batceoNTs iulT_HAN s e sedld be ics metho.VFSetabl5if ics methoes.vtf file u** rizhilEFS ile  istpeir of coff Sy ues are c("ma n", "foll",
, tetc.)tieias
ioriapaV)^VFStabl6if ics methoes.vtf rau** rizhilEFS ile 
**Oi apeir of coff Sy inger-moss triggea N iview rht hisrrtslorsi* ecum 
**Oempn vidsseaffoll  or ** tkianisist vidsseaffoll  lsesisqe if
fat uppetop-levstvtheceoNTVhe/
/*******************************************l3f t************l4if ***********/
#dee whidiffereCREATE_INDEXrrrrrrrrII1rrI/o IndexnNof rrrrrrTa* ecNof rrrrrr*/
#dee whidiffereCREATE_TABLErrrrrrrrII2rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereCREATE_TEMP_INDEXrrrrr3rrI/o IndexnNof rrrrrrTa* ecNof rrrrrr*/
#dee whidiffereCREATE_TEMP_TABLErrrrr4rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereCREATE_TEMP_TRIGGER   5rrI/o Triggea Nof rrrrTa* ecNof rrrrrr*/
#dee whidiffereCREATE_TEMP_VIEWrrrrrr6rrI/o View Nof rrrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereCREATE_TRIGGER        7rrI/o Triggea Nof rrrrTa* ecNof rrrrrr*/
#dee whidiffereCREATE_VIEWrrrrrrrrrrr8rrI/o View Nof rrrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDELETEcccccccccccccccc9rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDROP_INDEXrrrrrrrrII 10 rI/o IndexnNof rrrrrrTa* ecNof rrrrrr*/
#dee whidiffereDROP_TABLErrrrrrrrII 11rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDROP_TEMP_INDEXrrrrr 12 rI/o IndexnNof rrrrrrTa* ecNof rrrrrr*/
#dee whidiffereDROP_TEMP_TABLErrrrr 13rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDROP_TEMP_TRIGGER    14rrI/o Triggea Nof rrrrTa* ecNof rrrrrr*/
#dee whidiffereDROP_TEMP_VIEWrrrrrrr15rrI/o View Nof rrrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDROP_TRIGGER         16rrI/o Triggea Nof rrrrTa* ecNof rrrrrr*/
#dee whidiffereDROP_VIEWrrrrrrrrrrr 17rrI/o View Nof rrrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereINSERT               18rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidifferenternal              19rrI/o PragmacNof rrrrr1ete co or ** tk*/
#dee whidiffereREAD                 20rrI/o Ta* ecNof rrrrrrColumncNof rrrrre/
#dee whidifferedELECTc              21rrI/o ** tkkkkkkkkkkkk** tkkkkkkkkkkkk*/
#dee whidiffereTRANSACTION          22 rI/o OTULL, orlkkkkkk** tkkkkkkkkkkkk*/
#dee whidiffereUPDATEc              23rrI/o Ta* ecNof rrrrrrColumncNof rrrrre/
#dee whidiffereATTACHc              24rrI/o Filenof rrrrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereDETACHc              25rrI/o Des are cNof rrr** tkkkkkkkkkkkk*/
#dee whidiffereALTER_TABLErrrrrrrrII26rrI/o Des are cNof rrrTa* ecNof rrrrrr*/
#dee whidiffereREINDEXrrrrrrrrII rII27rrI/o IndexnNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereANALYZEc             28rrI/o Ta* ecNof rrrrrr** tkkkkkkkkkkkk*/
#dee whidiffereCREATE_VTABLErrrrrrrr29rrI/o Ta* ecNof rrrrrrModu ecNof rrrrr*/
#dee whidiffereDROP_VTABLErrrrrrrrII30rrI/o Ta* ecNof rrrrrrModu ecNof rrrrr*/
#dee whidiffereFUNCTION          rII31rrI/o ** tkkkkkkkkkkkkF
** buscNof rrre/
#dee whidifferedAVEPOINTc           32 rI/o OTULL, orlkkkkkkSavets itcNof rr*/
#dee whidiffereCOPY                  0rrI/o NorrangfrlT_HAN*/
#dee whidiffereRECURSIVEc           33rrI/o ** tkkkkkkkkkkkk** tkkkkkkkkkkkk*/
n future releasesD.psqeid dhTracinttAbe Profilg t F
** busshey DEPRECATEDheyuppeTeisiraout whsenn dd.psqeid d. Ust  Sy Lds] objetaaca_v2ne]li() metho inva sttabhdftpeiraout whseuescribhtOf re.heyuppeTeisiraout whseregisileeEFS ile te
** buss is thE 32_GlT_HANum 
**Oeracinttabe is filg t  spebeecutfli ofsSifcdrid LL.
s.heyuppe^TeirEFS ile te
** bus regisile_S theor file taaca() ist (* fid  t
**Ovariods SE_Fy y nee nedifcdrid LL.
 isrbf therun theLds] objertepe ].heye^Teirds] objetaaca() EFS ile  ist (* fidrwfile hUTF-8er**dhri* tdfttf filedifcdrid LL.
 rage  s e sedrid LL.
 sSletebeginsebeecutf* .heye^(Ais objectvds] objetaaca() EFS ile s S the2oc*geh thastea "btriggeandesuberogsamliste() mHA.eetablEFS ile s eleshriggeas [SQexWLa neohUTF-8etheceomman lss tfidbuiffif a fir*riggea.)^heyuppeThh [differeTRACredIZE_LIMIT]eSQLpile-SE_FtdTL_TR
C 32_GlT_HANrgulim_

**Oempnlength ofsLbever ics metho] ex
ansgoreinspeirhutpockdftor file taaca().heyuppe^TeirEFS ile te
** bus regisile_S theor file is filn() ist (* fidk I/ s*ea "bdifedrid LL.
 sSnishes.ne^Tf  is filnrEFS ile t*xWLa n 
**Oempn rig nctvsrid LL.
 rage  be/ d esSE_itntdfewmll-cFSrkhiE_F retdf how5rang
Ss tfsrid LL.
 rgokee crun.ne^Tf  is filnrEFS ile 
**OeE_Ftist ( un as dftnanodld be , hewavbllheirhe top- impleid confli
**Oi ae durcapa* ecdftn S *dld belatsolu bus soteabadixblea_FCses  fiC 3t
**Osigi
sl neis  eE_Ftnn dmea ** ls u.VFFud worods abosrat Mac OS
 thn the2providntg sholTmatsolu bus oneis  ch filnilEFS ile . tIn* f** 
, teeger iLor file taaca()]tdep[,s] objetaaca_v2ne]l  llelaicol* fi
**Och filnrEFS ile .he/
differeAPIediffereDEPRECATEDehe ab*rs] objetaaca(or file*,
  ehe a(*xTrace)(he ar,*xWrit** a*), he ar);
differeAPIediffereDEPRECATEDehe ab*rs] objeis filn(or file*,
  ehe a(*xProfile)(he ar,*xWrit** a*,rs] objeua val), he ar);
n future releasesSifeTraceFEvint CCNTsheyrKEYWORDS: differeTRACrheyuppeTeisireo stF.
sl dbuiffurcl  thsrat evsets is thE 32_Glmon a()on
ll a
** t reth,s] objetaaca_v2ne]leracinttragic.eetablMe controlbatcrguh,s] objetaaca_v2nD,M,X,P)]tise n/OR-eleFaLbe atfli ofshne orimorrlNeh theabaelVFS  theSQ stF.
sane^Tf   Slete control *
*meirtaacalEFS ile 
**Oi aonhcoff SyaelVFS  theSQ stF.
saheyuppeNew rracintteo stF.
sl aynbSs d tha nefud worr lere y.he*uppe^AstaacalEFS ile ehasofou to NULL.
s: xCFS ile (T,C,P,X).uppe^TeirTe control i aonhcoff Sya () e sytypeceoNTs above.uppe^TeirCe control i aamoQpy] aoin, *xWLbxthts its ae  the in  s e suppefou ile control rguh,s] objetaaca_v2n)]VuppetabaP  be/Xto NULL.
stk  bes its sdwso cumea ** skolean  oneT.he*uppe<dlrlyin[[differeTRACredTMT]]e<dt>differeTRACredTMT</dt>uppe<dd>^An differeTRACredTMT EFS ile  ist (* fidrw nee 5th genadmdrid LL.
uppefSletebeginserun ** u dletss
** yrng oe filSE_Fy duri* tthS
, teeecutfli ofsis  chegenadmdrid LL.
,,,ter aseaf e sedriis beiea "batctriggea suberogsam.e^TeirPr control i aamts its argu re
, t[th genadmdrid LL.
].e^TeirXr control i aamts its arguaiotri* t in "
**Oi a firunex
andHANSifcLbxthofsis  chegenadmdrid LL.
 orianetheceomman 
atce  tfindoritf a fir_n* confli ofsar*riggea. e^TeirEFS ile tE 32SQLputy
, tt stdof rLbxthis tfwould fTvr*d-inrrtpGMA_Svthe Sy rtgacytLor file taaca()] inva ) metho by a
** t retXr control wfeieXcbeginsewfile"--"fan. On* f** 
, tLds] objene
andHA_ds](P)]the fiwie .he*lyin[[differeTRACrePROFILE]]e<dt>differeTRACrePROFILE</dt>uppe<dd>^An differeTRACrePROFILErEFS ile tprovidns*approxE_itnif
reirdof 
**Oinem wilbus asetheprovidnSvthe Sy [or file is filn()]lEFS ile .hey ^TeirPr control i aamts its argu ret[th genadmdrid LL.
]oitd thShey Xr control cs itsereeat64-bimi () e sy in "bis*approxE_itnif
, tt st is an ad/nanodld be 
is tfempnchegenadmdrid LL.
 rgokee crun.hey ^TeirdiffereTRACrePROFILErEFS ile tist (* fidrw neee sedrid LL.
 sSnishes.he*lyin[[differeTRACreROW]]e<dt>differeTRACreROW</dt>uppe<dd>^An differeTRACreROWrEFS ile tist (* fidrw neavbll 5th genad
, torid LL.
 genULL,isen  i* er row5ad/nqld L.hey ^TeirPr control i aamts its argu ret[th genadmdrid LL.
]oitd thShey Xr control i. unushd.heyuppe[[differeTRACreCLOSE]]e<dt>differeTRACreCLOSE</dt>uppe<dd>^An differeTRACreCLOSE EFS ile  ist (* fidrw nee 5ues are 
, thanged foroles ts.hey ^TeirPr control i aamts its argu ret[des are changed for]  bjn* 
* titd thSsXr control i. unushd.hey </dlrly/
#dee whidiffereTRACredTMT       0x01
#dee whidiffereTRACrePROFILEr   0x02
#dee whidiffereTRACreROWr       0x04
#dee whidiffereTRACreCLOSE      0x08
n future releasesSifeTraceFHgokuturMETHOD:Qds] objheyuppe^Tf a,s] objetaaca_v2nD,M,X,P) i() metho regisilese ltaacalEFS ile 
**Oe
** bus X aga n tcLdes are changed for] D, a
** tprsTULtyl ask M
* titd *xWLbxthts its aP. e^I**thSsX EFS ile  isuppeN* tky aifneabaMl ask i. ment, tf it racinttlsesisa* ed.VFTerk I/Me controlcshould bireababimwie /OR-eleFaLbe atfli ofk I/menthorcmorrl[differeTRACr]eSQ stF.
saheyuppe^Ea "bC uesteQeeger ior file taaca(D,X,P) ora,s] objetaaca_v2nD,M,X,P) retdvsrridns*(laicols)/ uesthangecFS s *
*or file taaca(D,X,P) or
Thers] objetaaca_v2nD,M,X,P) elesheirLdes are changed for] D.VFEa "
[SQues are changed forl aynhovGEnt moss enirtaacalEFS ile .heyuppe^TeirXrEFS ile tist (* fidrw neavbll ny] aoin, evsets idbuiffifd th inv ask M2oc*ge. e^Teir () e syrehAll umentteat i Sy EFS ile tisthe top-le
**Oign()on, tfougfteaisl aynlocks w nefud worr lere y. eCFS ile 
**Oimpleid confliseshould rehAll menth  censuro
fud worSQLIityArg ar.he*uppe^AstaacalEFS ile eist (* fidrwfilefou to NULL.
s: cFS ile (T,C,P,X).uppe^TeirTe control i aonhcoff Sya[differeTRACr]
, thanstF.
sle cindiritntwhyi Sy EFS ile twTry (* fid.uppe^TeirCe control i aamoQpy] aoin, *xWLbxthts its VuppetabaP  be/Xto NULL.
stk  bes its sdwso cumea ** skolean  oneT.he*uppeTf a,s] objetaaca_v2n)t () metholistiictndHANrguh glacoitfairtgacy inva ) methosiLor file taaca()]titd [,s] objeth filn()],.boif dfewin "
**Onn dd.psqeid d.he/
differeAPIei.
a,s] objetaaca_v2n
nnor file*,
  unses in uMask,
  tnm(*xCFS ile )(unses in,he ar,he ar,he ar),
  he ab*pCtx
);
n future releasesQule cProgss ueCFS ile  batcMETHOD:Qds] objheyuppe^Tf a,s] objeerogss u_mes thr(D,N,X,P) i() metho C gin   Sy EFS ile 
**Oe
** bus X e cbSs (* fidrTULiodirildurduri* 5rang
run ** ucFS s *

, tLds] objertepe ].itd [,s] objeth genae ].itd similaoeum 
**Oues are changed forlDn tAn/eeanIle leCoelesheis inva ) metho t. rgukeepea GUI updid dhduri* 5arl** lcqule .heyuppe^Teirics methoePethep  the ehrougft s e see durics methoes.vtf fileEFS ile te
** bus X.ne^Tf  ics methoVNei a firapproxE_itnr is an ad [SQ[viro. Tl ach whcinriru* flis]ois tfarrleumenan d betw-inr,teidssiv 
**Oin* conflisie**thSsEFS ile tX. e^I**Nei aeof tghN3ly e tf it Sy progss u
**Omes thiOi asisa* ed.heyuppe^Onleen  i* er progss uumes thilmaynbSsdee whtk s enirtE_FtperbatcLdes are changed for]; nllng t nrneweprogss uumes thillaicolsvtf fileold eni. e^Setng t ics methoVX e c** tkoisa* e n Sy progss uumes thiVuppe^Tf  is gss uumes thili aals csisa* edhbyynllng t Nereeatumenttls uh thghN3l1.heyuppe^Ipo firis gss uuEFS ile tr AGMA]rnnn-ment, tf tsTULL, orlt. inva ) mrup ed.VFTee ofead worS 32_GlT_HANrguimpleid cunbatc"Caicol"cbu tus onea GUI is gss uudialog.box.heyuppeTeirtrogss uumes thillaS ile   E_FCuntodgu deif] g ngng   llemod fyh theabades are changed forois tf_n* ft reabaprogss uumes thiVuppeNoto
is tfLds] objeth gena_v2ne]litd [,s] objertepe ].boif mod fywithir [SQues are changed forseelesheirmea **  dft"mod fy"l neisistc iagraph.heyuppeTeirtrogss uumes thillaS ile  would  rig nctleva durd-o_n* ft reat i SyuppeisorFCNTteng nSVevItOst llem the2bSs_n* ft rduri* t[,s] objeth genae ]
* titd similaoebecFleCo sosiraout whsem the2elehola h geninobeitty schema
* t in "bin* lveserun ** ueababsorFCNTteng nSVevHewavbl, begin ** uwfil
*pethe useods abo 3.41.0,vrrnstrogss uumes thillaS ile    the2als cb 
**Oin* ft rdisqe if
fat  [,s] objeth genae ].whweveanctyz** u dlegenULL,** 
, tFCNTtelesc nIlexlquleie Vup/
differeAPIehe abds] objeerogss u_mes thr(or file*,va ), tnm(*)(he ar), he ar);
n future releasesOeaninttAeNew Des are cCanged forbatcCONSTRUCTOR:Qds] objheyuppe^Tf siraout whseoTeAeanetheiOSsdes are ufilnrastsle in Ndmlimtty
, tfilenof r control.e^Tf   Slenof r controllistiictrth chdh s UTF-8efor
Thers] objeoTeA()sa dors] objeoTeA_v2n)t be/ s UTF-16l neis  no fveebsorfileo aftefthe,s] objeoTeA16().e^(ArLdes are changed for] mes thtiulT_u TlefilertpGMA_Sv ne*ppDb, evsetieian/ the hoc*geu.VFTerva durned po orlt. rs t
**Oit Mac OS i. una* ece caVFSritntn the ciorhold tty [,s] obj]  bjn* ,
, tic** tkw lleNT oe
*tenernset*ppDbva sttabhdftamts its argu ret[,s] obj]fileobjn* V)^e^(Iff Sy ues are ciseoTeA_Sv(es /lesc shoel)r,teidssfuoly,*tsenbatcLdiffereOK]cisrrtpGMA_Sa eOe fiwie ian/[ the hFCNT]oisrrtpGMA_Sa)^e^Trn
, tLds] objenrrmsg()]tdep[,s] objenrrmsg16()]raout whseS 32_GlT_HANrguobLnt 
* tit E* eishrl*nguagtouescriptfli ofsis   the helVFS  theaefFtourrlNee nyfileNeheabars] objeoTeA()saout whs.heyuppe^Teirdeead Lsencod** uwflleNT UTF-8eforvdes are nvC shoelea
** 
, trs] objeoTeA()sthe,s] objeoTeA_v2n).ne^Tf  deead Lsencod** uforvdes are n
, tF shoelea
** e,s] objeoTeA16()uwflleNT UTF-16l neis  no fveebsoreo aftaheyuppeWf tger oepereaan/ the hoc*geu wfeiettciseoTeA_S,th s urhouh thassocia CdlwfileheirLdes are changed for] mes thtshould birrelere S thh thpas anttil rguh,s] objeles te ].wheiettcisenorrangfrlrequir dVheyuppeTeirrs] objeoTeA_v2n)t () metholwor stlik trs] objeoTeA()
, teed posss tfitt vidl seewoeois objectvics methoseelesois object *xWLrol retdvsreis  new des are changed for.VFSetabl 
**srics methoVrefilers] objeoTeA_v2n)t E_FClerlude,ct ha minimum,aonhcoff SyaelVFS  thh thearee/ 
**uFaLbe atflis:)^heyuppe<dlrlyin^(<dt>LdiffereOPENeREADONLY]</dt>uppe<dd>TSy ues are ciseoTeA_Svin atae-a durnCNTd  Ift Sy ues are cfrarbatcnnlealreadyeexist,aan/ the hisrrtpGMA_Sa</dd>)^heyuppe^(<dt>LdiffereOPENeREADWRfer]</dt>uppe<dd>TSy ues are ciseoTeA_Svftheread** u befer_
inttifitss
** e, or
Theread** ue durift firfilnriseoe
*r erotn* Cdlthe Sy sTULL, ngfilerysttm. tInQeeger icre Otty ues are c E_FCalreadyeexist,ahe fiwie 
* tit  the hisrrtpGMA_Sa eFoicf itorfcnt reas in *iftsTUninttin
Theread-oe
*r nCNTvfFtos ducNrguOS-levstvp Thessy in * d/ ffoll  ls inv adece copeiettcin atae-a durnCNTd h,s] objedbereada du()]lEFncb 
**OT_HANrgud.  The seenteger  Sy ues are ciseaco. The
Theread-oe
*ra</dd>)^heyuppe^(<dt>LdiffereOPENeREADWRfer] | LdiffereOPENeCREATE]</dt>uppe<dd>TSy ues are ciseoTeA_Svftheread** u befer_
int,nitd invC shoeleid [SQiterrary reaalreadyeexist.FtaisstheeababeAMEangltgng the lded  T_HANum 
**Ors] objeoTeA()sa dors] objeoTeA16().</dd>)^hey </dlrlyyuppeIneois objeee ceabarequir dl 
**s,f SyaelVFS  thedTL_TRnt  
**srarruppeals cd* anroel:heyuppe<dlrlyin^(<dt>LdiffereOPENeURI]</dt>uppe<dd>TSy  Slenof rEFneNT  (ctrth chdh s a URIkianisist 
**uists ta</dd>)^heyuppe^(<dt>LdiffereOPENeMEMORY]</dt>uppe<dd>TSy ues are cwflleNT oTeA_Svase n/ (-n the cues are n tTSy ues are 
**Oi anof dlthe Sy " Slenof "r controllelesheirpurpo iy ad/Fache-sheni* ,
**Oit sheneleFache nCNTviste(a* ed,cbu ntse " Slenof "riseoe fiwie iign()on.hey </dd>)^heyuppe^(<dt>LdiffereOPENeNOMUTEX]</dt>uppe<dd>TSy new des are changed forcwflleleCo spe"md L*-earead"
, tLearead thenCNT]V)^VFtaissn alt pe tfsaics to eareadsea imavent_Sh the cT_H Mac OS af e sedof rLime,   arang
as*ea "bthataef_sea
** 
, tardiffs e tcLdes are changed for].heyuppe^(<dt>LdiffereOPENeF* tMUTEX]</dt>uppe<dd>TSy new des are changed forcwflleleCo spe"sleializhd"
, tLearead thenCNT]V)^VFtaissn alt pe c E L*plo eareadseEFnerafcle
, taffoll  e cT_H e sedof rdes are changed forcaf e sedof rLime.hey (MutexFy yflleNFSrkh ny]aco. Tchanhe topcy,cbu n neisistnCNTh theabrecisenorharmn neiry** .)heyuppe^(<dt>LdiffereOPENeSHAREDCACHE]</dt>uppe<dd>TSy ues are ciseoTeA_Svwfile[sheneleFache]te(a* ed,cdvsrrid thh thea  deead LssheneleFache nllng t providnSvth
, tLds] objen(a* e_shenel_Fachen)]V)^hey TSy [ginobeisheneleFache nCNTvistdiss uragtd]litd htnhoisheneleFachefileEFpaArg aif amaynbSsohettnt
fat  m ny]but dsrat Mac OSVevIn,,ter cre s,h theaiseoTo orlt. nrno-op.heyuppe^(<dt>LdiffereOPENePRIVATECACHE]</dt>uppe<dd>TSy ues are ciseoTeA_Svwfile[sheneleFache]tsisa* ed,cdvsrrid thh thea  deead LssheneleFache nllng t providnSvth
, tLds] objen(a* e_shenel_Fachen)]V)^hey
, tL[OPENeEXRESCODE]]e^(<dt>LdiffereOPENeEXRESCODE]</dt>uppe<dd>TSy ues are changed forolo_Fy upn ne"exctndHANnqld LVeode nCNT".uppeIneoe filw rd ,  Sy ues are cbeAMEisenseid [SQLds] objenectndHA_nqld L_eoNTs(db,1e]twerechilit ron  Sy ues are 
, tFCnged forcasNsion  s e stFCnged forcinvC shoel.eIneois objeee cnllng th thea  exctndHANnqld LVeode nCNT,nisist 
**uals ce gin  [rs] objeoTeA_v2n)]h the crehAll tn exctndHANnqld LVeodea</dd>hey
, tL[OPENeNOFOLLOW]]e^(<dt>LdiffereOPENeNOFOLLOW]</dt>uppe<dd>TSy ues are c Slenof risbereaavent_S reeexWLa neohsymbolictlink</dd>hey </dlr)^hey
, tIft Sy 3f tics metho *
*or file oTeA_v2n)t ry rt*onhcoff Sy
Therequir dlFaLbe atflistshown aboveedTL_TRntdurcaLbe _Svwfileoe fibatcLdiffereOPENeREADONLY | differeOPENe*abims]h theabnctfisbeAMEanglistundee whtVevH itorfcrods abosrat Mac OS
 thhovGEsSlen if
ign()on,,trplusNbi
sl neis   
**srics methoVrefilers] objeoTeA_v2n), hewavbllheatsbeAMEangl  the2 rt*d-tcarrihe ehrougf inva )o
fud worods abosrat Mac OSsa doroOas
iority iseshould entorele
, tuporcit.neNoto
 (e
arincular is tfempnSiffereOPENeEXCLUSIVEc 
**uistnrno-op
, tfthe,s] objeoTeA_v2n).neTmpnSiffereOPENeEXCLUSIVEcrrary*ent*ce ginh thea  opeie)o
fFtolift Sy ues are calreadyeexists.neTmpnSiffereOPENeEXCLUSIVE
, tf
**uistiictndHANftheginothe Sy [or file vfs|VFSh () metho]ue du,nitd untbatctheor file oTeA_v2n).heyuppe^Teirfou ileics metho *
*or file oTeA_v2n)t ryis  nomhcoff Sy
TheLds] objevfsle bjn*  is tfdee wht peirhFULL, * tsysttm  () metholis t
**Opeir ew des are changed forcshould ue n t^Ipo firfou ileics metho is [SQnr** tkts its tisentea  deead LsLds] objevfsle bjn*  i. ushd.heyuppe^Ipo firfSlenof risb":n the :", tf ita chavhoe, tolloraryn (-n the cues are 
**Oi aC shoeleelesheirhanged for.VFSTee N (-n the cues are  yfllevanish.wheih thea  des are changed forci aCes td.VFFud worods abosrat Mac OSl  the inv ake leCoNee is objectvdle int  Slenof slheatsbeginlwfileheir":"/F* aactho.uppeI hisrrteommandHANrgng   nee 5ues are   Slenof r co. Theyrrarybeginlwfil [SQnr":"/F* aactho youcshould th fixo firfSlenof rwfile htathnof r,ter as [SQ"./"ce cahe abaLbegu ar.he*uppe^Ipo firfSlenof risb n/ mparedrri* , tf ita chavhoe, tollorary retdn-sisk ues are cwflleNT C shoel.eFSTee Nchavhoe ues are cwflleNT [SQnutowilbrildurdevot
d[asNsion  s e stdes are changed forci aCes td.hey
, tL[URIk Slenof slinOrs] objeoTeA()]]e<h3>URIkFilenof s</h3>he*uppe^Ipo[URIk Slenof ]  (ctrth cL, orlt. e(a* ed,citd thSs Slenof r controlbatcteginsewfile" Sle:", tf it firfSlenof risb (ctrth chdh s a URI. ^URI
, tfilenof r (ctrth cL, orlt. e(a* edtieitty LdiffereOPENeURI]tf
**uisfileretl neis  e of t control rgurs] objeoTeA_v2n), orlifnil has [SQd-inre(a* edtglobildura
** t rethdiffereCONFIGeURI]toTo orlwfilehei
TheLds] objelQRYig()]td
** ocNrothe Sy [differeUSEeURI]tSQLpile-SE_FtdTL_TR.uppeURIk Slenof r (ctrth cL, orlt. pGMA_Svoffbatcthedeead L,cbu nfud worr lere yrat Mac OSl  there(a* eeURIk Slenof  inva )trth cL, orlbyydeead LVVFSeg "[URIk Slenof s]"Oelesois object
**Oinem wilbusaheyuppeURIk Slenof slk  bear
edmacs rd** t o RFC 3986.e^Ipo firURIk*xWLa n aan [SQnut* rity,*tsenfit SE_FCd-oteger i n/ mparedrri*  lesheirdrri*  [SQ"FSrilhost".e^I**thSs u** rityrisbereaan/ mparedrri*  les"FSrilhost",aan [SQ the hisrrtpGMA_SVrguthSsEFS ea. ^TeirfragmtnckcQLponhnthdftamURI,eid [SQpatse ), tsiign()on.heyuppe^Mac OSlgin   Sy tathkcQLponhnthdft firURIkastpeir of coff Sy uisk  Sleuppe in "b*xWLa n ae stdes are .FSIft firicthkteginsewfilea '/'/F* aactho,h theabncillistiictrth chdh s  d/ bsolu iricth.FSIft firicthkrrary reateginuppe filea '/'/(mea **  is tfempn u** riareded forci aohettnt
fat   firURI)h theabnctfisicthkisb (ctrth chdh s a r lo fveeicth.uppe^(Orlwf(oows,f SyaeSletecQLponhnthdftad/ bsolu iricth
**Oi a 5urfveerle in cL, orl(e.g. "C:")V)^hey
, tL[ orrlURIkqule cics methos]]hey TSy qule ccQLponhnthdftamURIl aynlxWLa neics methosees tfarrl (ctrth chd [SQ eger ibhethe useitself,cNrothea [VFS | cE_Ft  VFSh mpleid confli]VuppeMac OSsa do_
sl ut t-in [VFS s]l (ctrth cmtty
, tflVFS  thequle cics methos:heyuppe<ulrlyin  <li> <b>vfs</b>: ^Teir"vfs"eics metho maynbSsT_HANrgurle inytpeir of coflyin   ea VFSh bjn*  is tfprovidns* firhFULL, * tsysttm  () metholis t should
theeeeebSsT_HANrguTvidsse. stdes are ufilnr iefisk.e^It hee ooTo orlt. sel *
lyin   ean/ mparedrri*  ea  deead LsVFSh bjn*  i. ushd.e^Mle inyantt d/unknownall     VFSh se n/ the . ^Ipods] objeoTeA_v2n)t ryT_HAN td thSsvfsooTo orlt.all     patse ), eabnctfisVFShsle in NdmlimttyooTo orltake Nchecedtnhoidvsrall     thSsvmenttp  the astpeirfou ileics metho *
*or file oTeA_v2n).heyuppe  <li> <b>nCNT</b>: ^etablnCNTvics metho maynbSssel *
* eger i"ro", "rw",
, ttttt"rwc",cNro"n the ".eAffoll ** t o retl l *
* ny] ger iumentt slyin   ean/ the )^.lyin   e^Ipo"ro"lt. sle in Nd, eabnctfisues are ciseoTeA_Svftheread-a dulyin   eadis u,cju_FCnseiditty LdiffereOPENeREADONLY]tf
**uhad*d-inrretl neis all     thof t control rgurs] objeoTeA_v2n).FSIft firnCNTvoTo orlt. sel *
lyin   e"rw", eabnctfisues are ciseoTeA_Svftheread-oe
*r ( u n reaC shoe)lyin   eadis u,cnseididiffereOPENeREADWRfer ( u n readiffereOPENeCREATE)uhad
theeeeebSinrret.FSVmentt"rwc"lt. en iumetncke cnllng t.boif
theeeeediffereOPENeREADWRfer  td differeOPENeCREATEn t^Ipo firnCNTvoTo orlt.
theeeeesel *
*"n the " tf ita c wor[ (-n the cues are ]ois tfeavbllreads
theeeeerrtoe
*nsleat iuisk i. ushd.e^Ith se n/ the Nrgurle inytatumenttum 
**O    thSsnCNTvics metho tgng theeof tatsrric fvevtfarois tfsle in Ndmli
**O    thSs 
**sric the in is  e of tics metho *
*or file oTeA_v2n).heyuppe  <li> <b>Fache</b>: ^TeirFache ics metho maynbSssel *
* eger i"shenel" m 
**O    "chavhoe".e^Setng t  l *
*"shenel" t. en iumetncke cnllng t.is all     differeOPENeSHAREDCACHE bimi ( thSs 
**sr control c  the e
lyin   ers] objeoTeA_v2n).FSSllng t.is rFache ics metho *
*"chavhoe"lt.
theeeeeen iumetncke cnllng t.is  differeOPENePRIVATECACHE bim.lyin   e^Ipods] objeoTeA_v2n)t ryT_HAN td thSs"Fache"eics metho is patse )tin
The   ea URIk Slenof ,p_
slvaent ovsrridns* ny]beAMEanglrequest t byynllng tall     differeOPENePRIVATECACHE depSiffereOPENeSHAREDCACHE  
**.heyuppe <li> <b>psow</b>: ^Teirpsoweics metho indoritf aenteger oepereang
all     [pnt_rrafc ovsroe
*n]tprsTULtylrraryorvdrary reaapplyes.vtf file   ertoragttd
diatay  in "b. stdes are ufilnratsidns.heyuppe <li> <b>noFSrk</b>: ^TeirnoFSrkeics metho is a.boolernequle cics methofile   e in "bifssel oisa* e nfilnrFSrkinttin roS ile  jou ectvnCNTu.VFTee file   e ryT_HfulOelesoeidssitheaedes are uonea filnsysttm is tfdrary refile   er* anrorFSrkint. eCFutfli:  Des are ceorruTo orl  thernqld LViditwo
theeeeerrtmorrles issseseoe
*r teQthetoof rdes are c be/ dy*onhcoff Sos file   ees isssesegin  noFSrk=1.heyuppe <li> <b>immusa* e</b>: ^Teirimmusa* eeics metho is a.boolernequle file   eecs metho tgng tndoritf a f tfempndes are ufilnrt. sa()on on
The   eatae-a durn
dia.D ^Wh i*immusa* eet. sel,eMac OSsassumf a f tfemp
The   edes are ufilnrcan rt*d-tcocks d, evsetthea es isssQ fileh thhofile   echavilnge,sa doroOtfisues are ciseoTeA_Svatae-a dur befnve FSrkintlyin   eandnlocks wd.  d forci asisa* ed.VFCFutfli: Sllng t.is rimmusa* efile   ees TULtyloee 5ues are   Sle is tfdrary nefactnlocks wEFnenqld Lfile   e n/ (eorr ctnqule cnqld Ls* n /leshdiffereCORRUPT]/ the s.lyin   eSeg als :t[differeIOCAP_IMMUTABLE].heyuppe</ulrlyyuppe^Mle inyantt d/unknowneics metho in.is rqule ccQLponhnthdftamURIlisbereaan [SQ the .VFFud worods abosrat Mac OSl  theee usrsiaide is objectvqule fileics methosVVFSeg "[qule cics methosQ filedle int mea **  io Mac OS]"Oele [SQnis objectvinem wilbusaheyuppeL[URIk Slenof /eeanIles]]e<h3>URIk Slenof /eeanIles</h3>he*uppe<sa* eebo aft="1" align=cents tcellpnis ng=5>hey <tr><th>eURIk Slenof sl<th>eRqld Lshey <tr><td>k Sle:ues .db <td>lyin   eeeeeeOp it firfSle "ues .db" in.is rhe top- disqe oe .hey <tr><td>k Sle:/home/f)on/ues .db<br>lyin   eeeeee Sle:///home/f)on/ues .db <br>lyin   eeeeee Sle://FSrilhost/home/f)on/ues .db <br> <td>lyin   eeeeeeOp it firues are   Sle "/home/f)on/ues .db".hey <tr><td>k Sle://uerkdrii/home/f)on/ues .db <td>lyin   eeeeeeAn/ the . "uerkdrii"lisbereaarrteognizhdn u** riar.hey <tr><td sayle=" inte-sptho:nowrap">lyin   eeeeee Sle:///C:/Docuid cs%20aid%20Sllng ts/f)on/Desktop/ues .dblyin   e<td>kWf(oowsue du:eOp it firfSle "ues .db" oeef)on'seuesktopr iefriv 
**OOOOOOOOOOC:. Noto
is tfempn%20 escapinttin hee oeeanIle ]sbereasrric dulyin   eeeeeeneisssaryn- sptho/F* aacthoseS 32_GlT_HAN] obr The
Theeeeeeeeeein URIk Slenof s.hey <tr><td>k Sle:ues .db?nCNT=ro&Fache=chavhoe <td>lyin   eeeeeeOp itfSle "ues .db" in.is rhe top- disqe oe vftheread-a dusoeidss.lyin   eeeeeeRegardeof tdfewiteger oepereashenel-Fache nCNTviste(a* edmli
**O    e   edeead L,cleCoa chavhoerFache.hey <tr><td>k Sle:/home/f)on/ues .db?vfs=unix-dotfSle <td>lyin   eeeeeeOp itfSle "/home/f)on/ues .db". Ust  Sy dle int VFSh"unix-dotfSle"lyin   eeeeeeis tfgin  dot-filnst (e
iachcoffpodixbadvisoe vFSrkint.hey <tr><td>k Sle:ues .db?nCNT=reada du <td>lyin   eeeeeeAn/ the . "reada du"lisbereaarvaeidvoTo orlelesheir"nCNT" ics metho.lyin   eeeeeeUst "ro"lt sttab:  " Sle:ues .db?nCNT=ro".hey </sa* erlyyuppe^URIkheeade imnt escapSssequlnhosi(%HH)farrld* anroelQ filinctfisicthkaiduppequle ccQLponhntshdftamURI. Akheeade imnt escapSssequlnhoceanr stshdftafileiercrolcsignn- "%"n- flVFS  t byyeeae if
ewoeheeade imnt sigi
sfilerle inyantt d/octhtlvaent.FSBefo i*tfaiicthklesqule ccQLponhntshdftauppeURIk Slenof rarrl (ctrth chd, eabyck  bencodelea
** eUTF-8e befnveuppeheeade imnt escapSssequlnhosih glacohathe a i* er bsorelxWLa ng t.is all eorr slord** uectht. It hee oes isssQgenULL,isenn/ (vaeidvUTF-8eencod** ,h theabcnqld Ls* retundee whtVhe*uppe<b>Noto
iokWf(oowsuT_Hrs:</b>neTmpnencod** uT_HANum  thSs Slenof r controlbatcofers] objeoTeA()sa dors] objeoTeA_v2n)tSE_FCd-oUTF-8,cnnlews tevsrall codepagttisthe top-le dee whtVevFilenof selxWLa ng t. () opcobject
**OF* aacthoseSE_FCd-olxWvsr CdlreeUTF-8ethangergutas anttthSm  ()efilers] objeoTeA()sthe,s] objeoTeA_v2n).he*uppe<b>Noto
iokWf(oowsuRunSE_FtT_Hrs:</b>neTmpntolloraryndisqe oe vSE_FCd-osel [SQpaangergucFS ** trs] objeoTeA()sthe,s] objeoTeA_v2n).neOe fiwie ,lvariods [SQfead wo a f tfrequir  thSsleCoNeetollorarynfilnstmaynfFto.he*uppeSeg als :t[,s] objetoll_disqe oe ]he/
differeAPIei.
a,s] objeoTeA(
  *xWrit** a * Slenof ,prI/o Des are c Slenof r(UTF-8)k*/
 ers] obj **ppDbvvvvvvvvvv/o OUT:etheiOSsdb mes tht*/
);
differeAPIei.
a,s] objeoTeA16(
  *xWrithe ab* Slenof ,prI/o Des are c Slenof r(UTF-16)k*/
 ers] obj **ppDbvvvvvvvvvv/o OUT:etheiOSsdb mes tht*/
);
differeAPIei.
a,s] objeoTeA_v2n
nn*xWrit** a * Slenof ,prI/o Des are c Slenof r(UTF-8)k*/
 ers] obj **ppDb,vvvvvvvvv/o OUT:etheiOSsdb mes tht*/
  tnmi 
**s,ffffffffffffff/o F
**sr*/
  *xWrit** a *zVfsffffffff/o Nof coffVFShmodu ece cT_H */
);
n future releasesObLnt  Vments FoicURIkPcs methosbathey TSyinoa i*utfg arsaout whs,yT_HfulOrguhVFS|cE_Ft  VFSh mpleid conflis],h thea thEhee eife 5ues are   Sle w s a URIke  tf*xWLa nhdn erle in c qule fileics metho,nitd iforoOobLnt s thSsvmenttoff Satequle cics methoVheyuppeTeirsSleteics methoOe ctfiseva ) methosi(abre file refs rhe e
lyin s F)tSE_FCd-oonhcof:uppe<ulrlyin<li> A5ues are   Slenof rts its tC shoelelimttyotheiOSs orrlaiduppeic the inteQthetxOTeA()sd
** ocNfea VFSh mpleid confli, or
The<li> A5 Slenof robLnt nt
fat  h,s] objedbe Slenof ()],.or
The<li> A5 ew  Slenof rEanriru* Cdla
** tLds] objeC shoee Slenof ()].uppe</ulrlyytIft Sy Feics metho is  rt*onhcoff Sy above, eabnctfisbeAMEanglislyytundee whttabe is ba* yrundesiriapaVneOlafteods abosrat Mac OSlwerelyytmorrltolULLnthdft (vaeidvFeics methosees n5 ewfteods abosVheyuppeIftF is a.suisa* ee Slenof r(aseuescribhtO neis  chevhodstc iagraph)lyinitd ifoPt ryis  nomhcoff Syequle cics metho,*tsenbatcrs] objeuri_ics metho(F,P) r AGMA]rthSsvmenttoff Se Pfileics metholifnil exists oria ** tkts its t foPtdrary reaappear astauppequle cics methor ieFd  IftP is a.qule cics methor ftF a do_
uppehasenorex
iicitlvaent, eabncrs] objeuri_ics metho(F,P) r AGMA]lyinimts its arguan/ mparedrri* .heyuppeTeirrs] objeuri_boolern(F,P,B)saout whsassumf a f tfP is a.boolernfileics metholand r AGMA]rtrntt(1)sthefalstt(0)macs rd** t o thSsvmentbatcofeP.neTmpnrs] objeuri_boolern(F,P,B)saout whsr AGMA]rtrntt(1)siff Sy
Thevmenttoffqule cics methorP i aonhcoff"yes", "frnt",cNro"on" in. nyfilecre Oy aifneabavmenttteginsewfilea nnn-mentr is an.VFTerk I/os] objeuri_boolern(F,P,B)saout whssr AGMA]rfalstt(0)mifneabavmenttoflyinqule cics methorP i aonhcoff"no", "falst",cNro"off" in. nyecre Oy lyinifneabavmenttteginsewfilea numfrfcrmentd  IftP is ereaarqule fileics methor ieFOy aifneabavmenttofoPtdrary reamater any] aoin,lyinibove, eabncos] objeuri_boolern(F,P,B)sa AGMA]r(B!=0).heyuppeTeirrs] objeuri_a val(F,P,D)saout whslxWvsr sneabavmenttofoPtinteQauppe64-bimises in  () e syand r AGMA]rtgng tn) e s,cNroDt foPtdrary re [SQ xist.FtIft Sy vmenttofoPtisNsid
**** uetger  Sane n/ () e s,*tsenbatcmentrisrrtpGMA_SaheyuppeTeirrs] objeuri_key(F,N)sa AGMA]ramts its argu retnof r(untbatceSy vment)toff Se N-ilequle cics methorum   Slenof rF, oria ** tfileis its t foNei aeof tghN3lmenthorcg sholTmtfaroisst is an ad/qule fileics methos mindst1.neTmpnNiumentt slment-bre S roONtshould bir0NrguobLnt 
* tis  nomhcoff SyesSletequle cics metho,*1Num  thSsdld be ics metho,laidupperoOum thVheyuppeIftF is a.** tkts its , eabncrs] objeuri_ics metho(F,P) r AGMA].** tkaiduppers] objeuri_boolern(F,P,B)sa AGMA]rB.FtIftF is ereaar** tkts its taiduppeis ereaarues are   Sle tathnof rts its tis tfempnSifiOSs orrlic theuppeinteQthetxOTeAfVFShm
** o, eabnctfisbeAMEanglot hee oaout whsistundee whtlyinitd is ba* yrundesiriapaVheyuppeBegin ** uwfilnSifiOSs[ods abo 3.31.0] (Ldeseof:3.31.0]).is rinpockFfileics methorS 32als cb tis  nomhcoffa roS ile  jou ectvfilnr r WAL  Sleuppeineois objeee ceabama nrues are   Sle.FtPaangerguods abo 3.31.0,ctfiseuppeaout whsswould   du wor t foF w s is  nomhcoff Syema nrues are   Sle.uppeWabnctfisFeics metho is is  nomhcoff SyeroS ile  jou ectv r WAL  Sle,
**Oil hasuTvidsse. caVFQthetoof rqule cics methosQasuwerecfever oneis all ma nrues are   Sle.uppuppeSeg tty LURIk Slenof ] rocuid conflieelesois object inem wilbusahe/
differeAPIe*xWrit** a *rs] objeuri_ics metho(rs] obje Slenof rz, *xWrit** a *zPcs m);
differeAPIei.
a,s] objeuri_boolern(rs] obje Slenof rz, *xWrit** a *zPcs m, tnm bDeead L);
differeAPIers] objea valrrs] objeuri_a val(rs] obje Slenof , *xWrit** a*,ers] objea val);
differeAPIe*xWrit** a *rs] objeuri_key(rs] obje Slenof rz,  itcN);
n future releaseseTranslhoer Slenof sbathey TSyinoaout whsenn davaila* ece chVFS|cE_Ft  VFSh mpleid conflis]Num 
**Oeranslho** ufilenof sebetw-inr Syema nrues are   Sle,f Syajou ectvfiln,lyinitd  SyaWAL  SleVheyuppeIftF is is  nomhcoffancrs] obrues are   Sle,fjou ectvfiln,r r WAL  Sleuppeic the limttyotheiOSs orrlinteQthetVFS, eabncrs] objefilenof _ues are (F)lyinr AGMA]rthSsnomhcoff Syeeorr slord** uues are   Sle.uppuppeIftF is is  nomhcoffancrs] obrues are   Sle,fjou ectvfiln,r r WAL  Sleuppeic the limttyotheiOSs orrlinteQthetVFS, y aifnF is a.ues are   Slenof batcobLnt nt
fat  h,s] objedbe Slenof ()],.eabncrs] objefilenof _jou ect(F)lyinr AGMA]rthSsnomhcoff Syeeorr slord** uroS ile  jou ectvfiln.uppuppeIftF is is  nomhcoffancrs] obrues are   Sle,fjou ectvfiln,r r WAL  Sleuppergng  aseic the limttyotheiOSs orrlinteQthetVFS, y aifnF is a.ues are  [SQfSlenof robLnt nt
fat  h,s] objedbe Slenof ()],.tsenbatcrs] objefilenof _wct(F)nr AGMA]rthSsnomhcoff Syeeorr slord** uppeWAL  SleVheyuppeIncaVFQoff Sy above, iftF is ereais  nomhcoffa ues are , jou ectv r WAL [SQfSlenof ric the inteQthetVFShfat   firtheiOSs orrlaidtF is ereais lyinr AGMA umentteat ih,s] objedbe Slenof ()],.eabnceabcnqld Llislyytundee whttabe istlik leen n the cTvidsseEanlilbusahe/
differeAPIe*xWrit** a *rs] objefilenof _ues are (rs] objefilenof );
differeAPIe*xWrit** a *rs] objefilenof _jou ect(rs] objefilenof );
differeAPIe*xWrit** a *rs] objefilenof _wct(rs] objefilenof );
n future releaseseDes are cFile Corr slord** uTo A Jou ect
e*uppe^IpoX is is  nomhcoffauroS ile   r WAL-nCNTvjou ectvfilnrtgng thuppeic the inteQthetxOTeAsd
** ocNfeLds] objevfsl,.tsenbatcrs] objeues are efile_ bjn* (X)sa AGMA]ramts its argu ret[rs] objefile]fileobjn* a f tfrepatse )sf Syema nrues are   Sle.upphey TSe oaout whsistiictndHANfthegino nrcE_Ft  hVFS]h mpleid conflisfileo duVevItOis ereaargenULLl-purpo iva ) methoVuppetaba controlcss] objefile_ bjn* (X)sSE_FCd-oa  Slenof rts its tis t
**OhasubSinric the inteQLds] objevfsl.xOTeAsd
** ocwabrecis lyin 
**srics methoVretxOTeAs*xWLa n aonhcoff Sy bi
sfileLdiffereOPENeMAIN_JOURNAL]tdep[differeOPENeWAL]n tAny] ger iginh thot hee oaout whsnqld Ls* ( undee whttabe is ba* yrundesiriapah thbeAMEangahe/
differeAPIess] objefile *rs] objeues are efile_ bjn* (*xWrit** a*);
n future releasesC sholtabe DtsrroytVFShFilenof sbathey TSyinoa ) methosiarrles vidnSvftheginothe[VFS shim]h mpleid conflistaiduppearrlereaT_HfulOoutsidntoff Sate*xWLbxtaheyuppeTeirrs] objeC shoee Slenof (D,J,W,N,P) aVFSritnstn the ciorhold auods abo oflyinues are   Slenof rDuwfilneorr slord** ujou ectvfilnrJtabe WAL  Sle Wtaiduppeancarray PtoffN URIkKey/Vmenttp ieu.VFTervnqld Llfat uppers] objeC shoee Slenof (D,J,W,N,P) i aamts its arguaiues are   Slenof rrs t
**Oiserafcergutas he crout whselik :uppe<ulrlyin<li> [rs] objeuri_ics metho()],h th<li> [rs] objeuri_boolern()],h th<li> [rs] objeuri_a val()],h th<li> [rs] objeuri_key()],h th<li> [rs] objefilenof _ues are ()],h th<li> [rs] objefilenof _jou ect()],.or
The<li> [rs] objefilenof _wct()].uppe</ulrlyytIftn n the cTVFSritabo  the hoc*geu,ers] objeC shoee Slenof ()l  the invrehAll tr** tkts its .VFTervn the cobLnt nt
fat  rs] objeC shoee Slenof (X)lyinSE_FCd-orelere S thaamoQrr slord** uC uesteQrs] objefreee Slenof (Y).heyuppeTeirPeics metho in.rs] objeC shoee Slenof (D,J,W,N,P) should birancarrayh thot 2*Nbes its sdteQrrri* s.VFEa "tp iecoffpo its sdin hee oarray oQrr slorduh thgguaikeur befumenttum  a.qule cics metho.VFTervPeics metho  aynbSs  ** tfileis its t foNei amentd  Nonhcoff Sy 2*Nbes its sd neis  Poarray  aynbSfile** tkts its staidikeurts its stshould entod-otmparedrri* sVuppeNonhcoff Sy D, J,r r Weics methoseeo.rs] objeC shoee Slenof (D,J,W,N,P) mayh thd-o** tkts its s, tfougfteaeyeS 32_Gltmparedrri* sVuppuppeTeirrs] objefreee Slenof (Y)oaout whsnqlere yrn n the cTVFSritabofileihevhodsl cobLnt nt
fat  rs] objeC shoee Slenof (). tIn* f** 
, trs] objefreee Slenof (Y)owabrecY is a.** tkts its  is a.harmeof tno-op.heyuppeIft Sy Ytics metho *
*or file freee Slenof (Y)o se ny**** uetgeruppergnl tr** tkts its  oria ts its aehevhodsl cacquir dl at uppers] objeC shoee Slenof (),.eabncbad  S** sk,ter aseheap
, teorruTo orlthe,egead Lstmaynoc*ge. TSy vmenttYtshould entod-lyytu_HAN ga neofile or file freee Slenof (Y)ohasubSinrhilit .VFtaissn altuppergng iditty Lds] objevfs.xOTeA()]sd
** ocNfea VFShhasubSinrhilit la
** tY,h theabnc Syeeorr slord** uLds] objemodu e.xCes te sd
** ocshould als cb 
**Oin* ft rpaangergucFS ** trs] objefreee Slenof (Y).he/
differeAPIess] objefilenof r,s] objeC shoee Slenof (
  *xWrit** a *zDes are ,
  *xWrit** a *zJou ect,
  *xWrit** a *zWct,
   itcnPcs m,
  *xWrit** a **azPcs m
);
differeAPIehe abds] objefreee Slenof (rs] objefilenof );
n future releasesEthe hCCNTstAbe Msssage batcMETHOD:Qds] objheyuppe^Ipo firnCstfrecrolcss] obje* APIe* uesassocia CdlwfilfileLdes are changed for] DnfFtoNd, eabnctfis,s] objenrrcode(D)t () metholyinr AGMA]rthSsnumfrfcr[nqld LVeode]tdep[exctndHANnqld LVeode]Num  th t
**OAPIe* ue.heye^Teirds] objenectndHA_nrrcode()uppeint metho t. rhetoof reed posss tfitt lded  r AGMA]rthSfileLexctndHANnqld LVeode]Nevset  neeexctndHANnqld LVeodesrarruppesisa* ed.heyuppeTSy vmentsrrtpGMA_SVtheor file nrrcode()* n /leuppers] objenectndHA_nrrcode()l  theelocks wwfilnea "bAPIe* ue.heyeEed po, eabrnoa i*sid
oa ) methosies tfarrlguaLLnteCdlreenevsrall cocks wthSsvmenttoff Se  the hFCNT.VFTerv the -eode patserv** 
, ta ) methosilerludef SyeslVFS  th:heyuppe<ulrlyin<li> or file nrrcode()lyin<li> or file nectndHA_nrrcode()uppe<li> or file nrrmsg()uppe<li> or file nrrmsg16()uppe<li> or file nrror_offset()uppe</ulrlyyuppe^Tfis,s] objenrrmsg()sa dors] objenrrmsg16()vrehAll E* eish-l*nguagth thebxthis tfuescribhsf Se  the ,cnse eger iUTF-8eor UTF-16lr slec fvely,h thor ** tkidinorethe hmsssageo se vaila* e.hey (Seg how5theiOSsmes thsr[ (vaeidvUTF]Num  ned po orsargu re oau e.)uppe^(M the ciorhold tty ethe hmsssageodrri*  issnanagtd. () opcllyVuppetaba s
iority itdrary reaneCdlreeworry abou nfreeg t.is rnqld L.hey Hewavbl, tty ethe hdrri*  m the2bSsovsroe
*teneorvdeaVFSritndmli
**OsubsequlntecFS s *
* ger ithe useint metho e
** bussV)^hey
, t^Tfis,s] objenrrdrr(E) i() metho reAGMA]rthSsE* eish-l*nguagthebxtuppergng uescribhsf Se [nqld LVeode]tE,h s UTF-8,hor ** tkidiEOis ereaalyinr ld LVeode um   in "bahebxthethe hmsssageo se vaila* e.hey ^(M the ciorhold tty ethe hmsssageodrri*  issnanagtd. () opcllylyinitd  E_FCuntobenfreee limttyo s
iority i)^.lyiuppe^Ipo firnCstfrecrolcethe hrefs lnhosi erle in c t ftnd neis  inpocuppeSQL,ctfis,s] objenrror_offset() i() metho reAGMA]rthSsbsoreoffseth thot hesedriis beiis tfe ftn.ne^Tf  bsoreoffsetrrtpGMA_SVthuppers] objenrror_offset() assumf a f tfemprinpockSifeis UTF-8.uppe^Ipo firnCstfrecrolcethe hdrary rearefs lnhoi erle in c t ftnd neis  inpocuppeSQL,ctfinctfis,s] objenrror_offset() e
** bus reAGMA]r-1.heyuppeWabnctfissleializhdtLearead thenCNT]sistiitu_H,fit S the2bSsthefileEFsnrtgng asdld be  the hoc*geu oee 5saics to eareadtiitbetw-inh theabrtE_Ftoff SyesSlete the hitd  SyaC uesteQtSyinoa ) methos.uppeWabnctfal hapTeAs,f Syadld be  the hwflleNT reanroelQ
**coitfas  inva )trethosialded  r anror firnCstfrecrolcnqld L. uTo ahe ah theais,fea "bthataefS 32obLnt  nedlusiv sleCoNeethirLdes are changed for] Dh thdy On* f** uLds] objemutex_ents ](h,s] objedbemutex](D))eNTfo i*begin ** h thgguleCoDfan. On* f** uLds] objemutex_lerve](h,s] objedbemutex](D))eofilelyinillecFS s *
*is  in)trethosilist t abrnoa i*c nIleted.heyuppeIfe n/ () metho eFtos wfilnSiffereMISUSE,ctfal n alt pe c () metholyinwTry (* fid/ (eorr ctdurdimttyo s
iority iVevIn, Sate*re , thefile the hFCNTnitd  sssageomaynoo  aynuntobenret.he/
differeAPIei.
a,s] objenrrcode(rs] obj *db);
differeAPIei.
a,s] objenectndHA_nrrcode(rs] obj *db);
differeAPIe*xWrit** a *rs] objenrrmsg(rs] obj*);
differeAPIe*xWrithe ab*rs] objenrrmsg16(rs] obj*);
differeAPIe*xWrit** a *rs] objenrrdrr(i.
);
differeAPIei.
a,s] objenrror_offset(rs] obj *db);
n future releasesSetrEthe hCCNTstAbe MsssagebatcMETHOD:Qds] objheyuppeS cmttye the hFCNTnoff Sy ues are cmes thtp  the astpeirfSlete controlbatctorethcCNT,nitd  Syaethe hmsssageogguaioQpy] aonul-  The itndmdrri*  [SQzEthMsg. It zEthMsg is p  the ** t,ctfinctfisethe hmsssageo sesel *
lyin Sy ueead Lsmsssageoassocia Cdlwfileheird* al Ndm the hFCNT.VFSubsequlntfileEFS s *
*[or file nrrcode()]litd [,s] objenrrmsg()]titd similaoewfll invrehAll thSsvmentsesel dimtte oaout whsi(e
iachcoffwgng  aseihevhodsl upperel dimthe useitself.upphey TSe oe
** bus reAGMA]rdiffereOK iditty  the hFCNTnitd ethe hmsssageoarruppe,teidssfuoly sel,eMacfereNOMEMtieian/OOMhoc*geu,e td differeMISUSEeid [SQ Sy ues are cmes thtiseN* tky ai(vaeid.heyuppeTSy  the hFCNTnitd  sssageosel dimtte oaout whsrema n at  nffn* aunSEl [SQ Syyck  bcocks d, eeger ibhean ger iC uesteQtSe oaout whsthegnSElQ Syyck  all cocks dlreedimthe useitselfhe crefln* a frvnqld Lloferof r,tbsqulntfileAPIe* ue.heyhey TSe oe
** bus istiictndHANftheginothethe usenectn abosrartoeapTeeu.VFTer invadea t. rhat tn exctns orltheoeapTeefS 32T_H e e oaout whs o retl the lyinSsssage nitd ethe heodesratd  SusNbeAMEitmorrllik tas orrlMac OS
 thfead worfat   firts itlofeviewhdftad/ s
iority iVhe/
differeAPIei.
a,s] objeretenrrmsg(rs] obj *db,  itcethcCNT,n*xWrit** a *zEthMsg);
n future releasesPh genadmSrid LL.
 Objn* 
* tKEYWORDS: {th genadmdrid LL.
} {th genadmdrid LL.
s}heyhey Anlt stancehot hee oobjn* arepatse )sf a i* er Sifeorid LL.
 is t
**OhasubSinrSQLpilee inteQbe ae vfthmtabe istreadyee cbSseumenan d.heyhey TSenkhot ea "bSifeorid LL.
  s a saics to SQLputs aehogram.VFTer inv rig nctbSifeebxthisNsiurhohFCNT.VFA th genadmdrid LL.
  bjn* 
* tis e stFCLpilee objn* aFCNT.VFAltbSifeSE_FCd-olxWvsr CdlinteQauppeth genadmdrid LL.
 NTfo i*iteS 32_Glrun.heyuppeTSy life-cyclhcoffauth genadmdrid LL.
  bjn* lT_u Tle gohselik  hee :heyuppe<olrlyin<li> C sholt firth genadmdrid LL.
  bjn* lT_i* t[,s] objeth gena_v2n)].lyin<li> Bibefuments *
*[ics methos]ra
** t ret,s] objebe d_*()lyin   eoa ) methos.uppe<li> Run  firtheothecFS ** t[,s] objertepe ].owhsthemorrltimos.uppe<li> Res cmttyeth genadmdrid LL.
 T_i* t[,s] objeatsete ].tfincg cble 
**OeeeeeieQrrep 2.VFDeQtSe omenthorcmorrltimos.uppe<li> Dtsrroytttye bjn* lT_i* t[,s] objef nctizh()].uppe</olrly/
typeuee riru* a,s] objertm a,s] objertm ;
n future releasesRun-SE_FtLimit batcMETHOD:Qds] objheyuppe^(Tee N () metho avent. rhetoan. On* f**  s [SQfiru* Cdla
sSseumenlbatcnitd isaicsd forci aCebysd forci aCebasiervnqld eics methoOe ctfifileLexctnre changed for] Dh thumea *lbatcfifiloel *
* ele ccQLitaissn ,teids ics metho,laidnhcoff"no",des albatcfmli
goup/
] uescribfssumfocks laewitegru* Cdla
sSseumenOn* flbatcnirvnqld tics metho *
*orifileLexctSlenlbatcfh t
**OAgru* Cdla
y
, t^Tfis,irnCstfSlenlbatcfno-op
egeicth.n ad/qadld blbatcfno-us dlreed^(M theRIkPSifeolbatcfmli
gouyereMISUSLIMIT_<i>NAME</srrtisenorhafocksalbatcs |eof d uS 32Tbonei]el dimthatile-SE_FtdTL_ToQrr CenadmsQgenUynuntcrot la
**ocksalbatcs |ereMISUSEAX_<i>NAME</sre</olrnCNTv"SLIMIT_is rhe toisb (ctr dlreedimth"SEAX_".) TSy [^l ** t indiritee SchavhlbatcfedTL_Ttcs of d uS 32Tboneippe,teidsif
ign()Cdlnmli
**  in)trof d uS 32Tboneippe^Ipo fdeof tdfewiteger oepereasheneld blbatcfhevh d, eegerteLds] objelQRYilbatcfincetho reAGMA]rthSsbsoreergucFtoff Se  the lbatc^(M thH erl,FtoliiyaC uest- disqetoff Se  vhlbatcfheirreeg d, el *
*",teidsim.vtfid/ (eomenthetholwor steird* altics metho *
*or
* egeryuppeWabncE_FtLimitlbatcs (ctrth cfthegino nrcE_Ftrity iseshouln alt d. ()y On*oird* afpo wnopcllylyiare c be/ dy*onisa* e nvC shoarrlguaLLol retd
**ocksbesirCdlabrnos orylyiaouh tha/eeanIle leCoerity itdrary2bSsthefi in "beb brhet tfempnSSinrtcs  wno e nvC shos] obrods *
rfcnt yppers] obto SQLpure nvC shoel retd
**sbesJavaSfli otrity iseshould wnloadnitd isf  the Icllyletrvnqld pcllylyiare c be/2_GlT_HANgiveall ma nrcqule,d Lsmsssalbatcs. are cFileagtd. () oae iforylyiaouh tha_GlTocksbANgivealmsehesm. ^Tetlbatcs iapagguthSsEodsls a s ianFSh"f r, 
, nwTry att*Oe. arp Thyloese2als cb 
**wanT_H e sedof r[bjeretenrrmsriar.hez,h th )trethosialdFtoliics 32T_l retdsirCdlabrnoreMpnrs] obn* f** es are cmes ocks lelimttyotknownCdlabrnotfli o_GlT_HAN nhdn erlet ret,s] ds] omax_isth_conet] [PRAGMAuppe</ulres ar_FtLimitlbatcfmli
goup/
bSs  ** tddeis  corr lere yrat MdiffereAPIei.
a,s] objeretenlbatcfbj*);
dicethcCidcethcCSleValfuture releasesPh geE_FtTimit batc Cli
goup/
EYWORDS: {th gelbatcfmli
gouy ge*lbatcfmli
goup/
ey Anlt oa ) mru* Cancs iafssum s [SQfiloelbusat helbatcMETHO*re , tT_HAN byyrid pats_FtLimitt[,s] objef nctlbatcfin^(M tAe topgn()iptfli ofsis   thesitlbatcs   th:hd diffebject inem wilbusahe/
s e stFa* ece chVs] olbatcs |e batcMs  cS]"Oeleppe<b>Notin^(<dt[[reMISUSLIMIT_LENGTH<dt>LdiffreMISUSLIMIT_LENGTHuppe<dd>TSy ues amaxaonhobn* f** aoin  les"FSriBLOBeirdre chVrhe,etw-iyt Md<heyuppe^(<dt[[reMISUSLIMIT_reM_LENGTH<dt>LdiffreMISUSLIMIT_reM_LENGTHuppe<dd>TSy ues amaxaonhof
igsqulfheiOSsd LL.
 T_i*,etw-iyt Md</heyuppe^(<dt[[reMISUSLIMIT_COLUMN<dt>LdiffreMISUSLIMIT_COLUMNuppe<dd>TSy ues amaxaonhon ad/qule colum nffn*adre chViafssithe,egea all     tLlofero
* el  vh[SELECT]eirdrri*maxaonhon ad/qule colum nffn*anopcdexrig ncffn*ano {tER BY ncfGROUP BY  lat^Ip</heyuppe^(<dt[[reMISUSLIMIT_EXPR_DEPTH<dt>LdiffreMISUSLIMIT_EXPR_DEPTHuppe<dd>TSy ues amaxaonhodepsqulfhsoreemacs)Cdea filnne if )sftheod</heyuppe^(<dt[[reMISUSLIMIT_COMPOUND_SELECT]dt>LdiffreMISUSLIMIT_COMPOUND_SELECTuppe<dd>TSy ues amaxaonhon ad/qule  itnnffn*adnhntsneipSELECT LL.
 T_i*d</heyuppe^(<dt[[reMISUSLIMIT_VDBNeWA]dt>LdiffreMISUSLIMIT_VDBNeWAuppe<dd>TSy ues amaxaonhon ad/qule i* Cdla
shoulfn*advirhanhentchssumam.VFTedd>TrguTvidsid confliheiOSsd LL.
 T_i*tF is objeth gena_v2n)].lyinhe<li> the hetncke cnllup/
bFSritntn the/F* aafrrltimos.sst isnagtd.y opratd  )tret* er Sifeonadmdrid LL.
 T_i*,heiOSsdOMEMtieianhisrrtpGMA_Sa</dd>)^heyuppe^(<dt[[reMISUSLIMIT_FUNCTION_ARG]dt>LdiffreMISUSLIMIT_FUNCTION_ARGuppe<dd>TSy ues amaxaonhon ad/qule rolbatct 5saicsbus isti>)^heyuppe^(<dt[[reMISUSLIMIT_ATT 
**D]dt>LdiffreMISUSLIMIT_ATT 
**Duppe<dd>TSy ues amaxaonhon ad/qule [ATT 
* |eatt*Ohid re c be/2ey
,hey
, tL[OPENereMISUSLIMIT_LIKE_PATTERN_LENGTH<d(M thediffreMISUSLIMIT_LIKE_PATTERN_LENGTHuppe<dd>TSy ues amaxaonhof
igsqulfhsoreemtoryltrol rgurs] oof r[LIKEnhe<li> [GLOB]L, * tsyin </heyuppe^(<dt[[reMISUSLIMIT_VARI.hey_NUMBER<d(M thediffreMISUSLIMIT_VARI.hey_NUMBERuppe<dd>TSy ues amaxaonhopcdexon ad/qule r.y methos]ra
]ffn*anoSsd LL.
 T_i*tuppe^(<dt[[reMISUSLIMIT_TRIGGER_DEPTH<dt>LdiffreMISUSLIMIT_TRIGGER_DEPTHuppe<dd>TSy ues amaxaonhodepsqulfhree tdlesheir"nriggein </heyuppe^(<dt[[reMISUSLIMIT_: {KER_THRferS<dt>LdiffreMISUSLIMIT_: {KER_THRferSuppe<dd>TSy ues amaxaonhon ad/qule ruxilithmt foF tfemeEFnerasdld be Sife(<dt[nadmdrid LL.
 T_i*]bSs   beii>)^hey </dlrlyyuppe/
#iafssumreMISUSLIMIT_LENGTH                    0
#iafssumreMISUSLIMIT_reM_LENGTH                1
#iafssumreMISUSLIMIT_COLUMN                    2
#iafssumreMISUSLIMIT_EXPR_DEPTH                3
#iafssumreMISUSLIMIT_COMPOUND_SELECT           4
#iafssumreMISUSLIMIT_VDBNeWA                   5
#iafssumreMISUSLIMIT_FUNCTION_ARG              6
#iafssumreMISUSLIMIT_ATT 
**D                  7
#iafssumreMISUSLIMIT_LIKE_PATTERN_LENGTH       8
#iafssumreMISUSLIMIT_VARI.hey_NUMBER           9
#iafssumreMISUSLIMIT_TRIGGER_DEPTH            10
#iafssumreMISUSLIMIT_: {KER_THRferS           11ture releasesPh genadmSrisr*/
 y Anlt oa ) mru* Cancs iafssum s [SQfirics m*re , tT_HANe inteQthetxOTenlt "nadmr*/
  metho is pao Lds] objevfs.xna_v2n)].3td simids] objelQRYina_v2n)16].3td sethos.uppe<li>/ulres arics mSs  ** tddeis  corr lere yrat Mac OSVevIn,pe<b>Notin^(<dt[[reMISUSPREPARUSPERSISTENT]dt>LdiffreMISUSPREPARUSPERSISTENTuppe<dd>TSy ues areMISUSPREPARUSPERSISTENTuistnrno-ophiurs] oof rcics melannergnl tr*eth genadmdrid LL.
 T_i* NT reanroet
fat  rts itas*eaLimitpeic the yrundesrerguTvtd.y .uppe<)^ ^Weirreeg 
**uals , objevfs.xna_v2n)].3td Try as] objenrrmsna_v2n)16].3td sf a f  tr*eth genadmdrid LL.
 T_i* NT rocksbANrguTvnseidot heerVs] recrocsbs a.uppe Syaethen)iptttyerlet retds] objelQRYiizh()].uppe fveeicthl,eMoIn, Tuest- disqeid conflistaid Theo duVevg 
**uhiursyotk*rs]ret,s] oeethirL[lookaoff S cTVFS]s
iorais lyi Sy udep.hey the lbatcid LLimosirLlookaoff S cTVFS.worods abosrat Mac Sy uSl  theea. TchVevg 
**uhiurs e tcLdesluppe^Ipo [[reMISUSPREPARUSNORMALIZ(<dtdiffreMISUSPREPARUSNORMALIZ(uppe<dd>TSy ues areMISUSPREPARUSNORMALIZ(uistnrno-op
, tf.oe
** bstnrushe cT_H Manroedl at upd  Syyenadmdrid LL.
 T_i*  aseic ni
**  i sedof ds] objelQRYinbusatLear_bjetd sethos.uppitorl, tty etheds] objelQRYinbusatLear_bjetd sethos.uppreaalywla* ece chVFS|peheeadnadmdrid LL.
s}heyh,roeof tdfewiteger oepereasheneld ye e oaouteeadheyuppe <li>[[reMISUSPREPARUSNO_VTAB<dtdiffreMISUSPREPARUSNO_VTABuppe<dd>TSy ues areMISUSPREPARUSNO_VTAB bstnr  [rs] heothecFle-SE_Fr cT_H Ml tn exctndisrrt(hFCNTnitd  reMISUSERROReabavmentLL.
 T_i* t[d  )trSyyevirhanhere chsppe <li>[[reMISUSPREPARUSDONT_LOG<dtdiffreMISUSPREPARUSDONT_LOGuppe<dd>TSy ues areMISUSPREPARUSDONT_LOG bstnrodsls asthecFle-SE_Fr cT_s.lyin  firtbis rnsgurs] oof rhFCNTnlogwhtVevFi tLds] oreCORRUPTURI]tLOG<issn altGlT_HAN] ob,ned po  leCo,Ftold oopttocks e-SE_Frs] obea i r,tbsqSsd Lylisxreaawell-lbusob,nheirreegL,isennretds] ge nitd ey ues aldura
rhFCNTnlogwwllistiictrhent Sy vmentoptts e-SE_Feeadhwfils,s] objenrrorna_v2n)].3tdsteQtSA]rthSsbsoreeed poisrrtptf a fileo duVoe fibrnheirreeg 
**uals ;stiinseidoatcMs uesteQtSyinobjef nctlogfincg Ohasublog  the ,cnse./dlrlyyuppe/
#iafssumreMISUSPREPARUSPERSISTENTuuuuuuuuuuuuuu0x01
#iafssumreMISUSPREPARUSNORMALIZ(uuuuuuuuuuuuuuu0x02
#iafssumreMISUSPREPARUSNO_VTAB                 0x04
#iafssumreMISUSPREPARUSDONT_LOG                0x10
ure releasesC shole-SE_s rnAnoSsd LL.
 ObjnEYWORDS: {th gerid LL.
  s a le-SE_Frey AOD:Qds] objheyuppe^ PTUSTRUCTOR:objertm ;
n fy Anlt oiiciee e DtsOSsd LL.
 T_i*,etFCd-oteeics mbeilee inteQbe aea-iyt  patsc the yVFTett[,s] ff"no",desut whsenn dafter,etw-iC ues fods,,desut whsenn d )trSrriru* Cdla
yin  irdrri*[nadmdrid LL.
 T_i*]b lT_i*ppeTSy life-prhe e
lyiwhs o retl ueoTeA_objeth gena_v2n)].lyin<ssn ,teidobjeth gena_v2n)td sethos.uppreaaleofcfumentd birancarr*rs]ed^(M tobjevfs.xna_v2n)].3td sh/ bsolextra "nadmr*/
  mrltake Nheeof tushe cT_s] obt VFSh" iva ) uppeTeirrs] oeethirLdes eor UTethosilerluds-prhe e
lyUTF-8Ss orrla-le dee Sy udoded  leemac_HANumTF-8e befpnrs] o6lr sleethosiarrles vidnSvfthe )trSsicsd fls i erlpnrs] o6lr sleethosiarrle foF bysd fdlinret,s] ds] kSifeiisNsiunF-8ethannfit SE_* uLds] trr slord** uLds] eor UTethosilerppeTeirsSleteics mrol rgur, "db",rno-opnre changed for] Dh th nt
fat  rs] oth genagucFssfuoly sesteQtSyinobjef nct)]]e<h3,nobjef nct)]]e].lyinhe<li> objef nct)]]erehAn<ssn ,are changed forci aCeuntobenfrmorrlSQLpil.hey
, tL[URITd be  the rol rgur, "zSql",rno-mentLL.
 T_i* H Manrlee inte,delea
** )trSsi iUTF-8eor UTF-16lr slpnrs] objeuri_bna_v2n)td,objenrrorna_v2n)].orliTry as] bjevfs.xna_v2n)].3td )trethosiald tush8ethannfas] bjevfs.xna_v2n)rehA,objenrrorna_v2n)16].orliTry as] bjevfs.xna_v2n)16].3tdtush8ethaslp
t^Tfis,irnCstfSBffserol rgursctrhegeicthnfit SEzSqleadyee c upf file   ereics morcmo itndmdrIpods] oSBffseds-posiicthnfit SEtcfifils amaxaonh  ern ad/qule iyt Myee c rs] ozSqlpnrtfal SBffseds-posiicthnfzSqleadyee cdd>Trpf file reics morcmo itndmdrIpnSElQ Syyck   SBffseiyt MymorrlSQLpiee ciTry bahebreadsleelnrFSrIft Ss] oSBffseds-orcmnfit SEnodnadmdridTry LL.
 T_i* iULL,isenn/d^(M tirnCstfa. ^Te eicstfemprinpoc Ndm the   issnanag The itndmdrrinbatcrs] otisenorhafesm. ^iloelbusat headv niguaioQpnttthSm al SBffseetho tgng tndos e stFk   S ad/qule iyt My  inpocuppeS   issna<i>def Syssn</srli> the  The itndmdrse./dlris tfempn%SBffsemeas f tfreeof
igsqulfhsoreuppeS tw-iyt M,[SQ xistcthoseSE_Fetthea  irdrri*6lr sleethosiarrlp
t^Tfis,irnpzTwfireaalyiny ai(it SE*pzTwfireaamadaioQpnoiurs] oof reics mbytic the le the hndSyesSlete the rid LL.
  s a inozSqlpnrTaout whsenn dayin   ealee intsSlete the LL.
  s a inozSql,s
io*pzTwfireaaleftpnoiuro thSsTry bapatseat  nfunlee intep
t^Tfis,*ppSs] oeaaleftpnoiuro thSs*adnhntinteQ[nadmdrid LL.
 T_i*]b*re , tT_HA cT_siee e * tLds] objeC sho ].owhspo firnCNTenorhafn ,cnse e*ppSs] oeaathot heSs*y aipo firnCNTvkSifeiisNsi n aonhcon OS]" (ifhsoreuppeS tsmparedrriTry LLles"FSriadnhnT_i*)(it SE*ppSs] oeaathoeSs*y aip[URITd b* t[,s] msQgeduenorhard** usiSlenoaVFSrleis rFache hntinteSy uSl  LL.
 T_i* t[,s] objeatsetizh()].uppe  or fisuTvidsfssishileheirdtc^(M tppSs] ontobenret.hy aip[URTfis,OnFssfuolys,s] objenrrorna_v2n)** bamilnul- whssr AGMA]rfalfereOPENeWK]; duVete ,lvarmpar[hFCNTnitd ]tpGMA_SaheyuppeTeirrs] objeuri_kna_v2n)].orli bjevfs.xna_v2n)].3td,objenrrorna_v2n)16].orliTry as] bjevfs.xna_v2n)16].3tdtethosiarrles vinizhnT_ithegino . ^iSlene yVFTesp[URITd boods aethosi(abre bjenrrorna_v2n)** as] bjevfs.xna_v2n)rehA) )trSrrioet
fat  rts **Oewaodse hnteicbsaout, beeg 
afpoueoTeA_discoud
did^(M thI inpoc"vX"aethosi(abr,th genadmdrid LL.
 T_i*gnl tr*etpGMA_Saheyu (of r[bjeretenrs] ]b lT_i*)i n aonhcoy] aonul- tv rig nctbSifeebxthisNs.sn altGl[rs] heotobjertepe ].owhstethosialdFtoocksbAmorrl e tcLdesluy  inpdea r anppe<olrlyin<li> C shTfis,irnCstfre changesebrmah d, ees, ab:  " ulfhreSahe,s] oreOPENeSCHEMA]didif*gnl   r anrrguTvidsdo,tobjertepe ].owhstNT reautosahecgohsenizhn intsSletreOTry LL.
 T_i* Syaetrhold ruSEtcfeofil. Aagtd.y idioreOPENeEAX_SCHEMA_RETRY Try reSup/
bNT reu,e t i*iteS bjertepe ].owhNgivesTrpf AGMA]rtgng he . ^Ipo/dlrly shTfili> C shTfis,tfal ae hoc*geu,ers] oobjertepe ].owhstNT reA]rfalfff"no",des det
f
**ocksaheodesratd [exctndHANnqld heodesratd [f  bsoreleofcfuanglot hes  nomdos e objertepe ].owhstN  du wor tl tr** tkL,iseqld reMISUSERROR] LVeode um  Try as] t
iority iVevIntN  du morrlld ma orrle  the teQtSyinobjef ncte ].tfin )tret ="1" FtoliiyaC uessiaidly uesteeethirLdes e yrlem. Weird* al"v2"enadmdri )trethosiald ,C uessiaidly uese Scesheir"nCNThisrrtpGMA_Sa</ddsa* D ^Wtepetaba ly shTfili> C shTfis,irnCstfn c t ftntteginssneipSs*admethos]ra
 |eoos methoOe ct]a all     tWHERE  lat^Ie2als cinflceanr ache hoicqule cics melasois ob LL.
 T_i*,li> then-mentLL.
 T_i* NT reanrautosahecgohsenizhn intd,ditty Ldifred-inrretlTry aesebrmah d, ee,ey ues ae the objertepe ].owhstteQtS  th:heyucre Oyd, eet heSs*heotobjertepe*()lyisNsi|e vfyssn [extfe ftnmethos]ra
]^Teirds] ob c t ftntteginl  vhWHERE- lat^Iemethos]ra
]f2als cinflceanr achxistctoicqule cics melasoifhsoreemao is is  nomhcleft-himilaodinl  vh[LIKEnrig nc [GLOB]L, * tsyifneabavmentemao is is  n hnte
lyin *anopcdexlyicolum Try as] t
io reMISUSEN.hey_STAT4]ile-SE_FtdTL_Trlt. sel *edmli
*taba ly shTfirly/
typili> Cp>^bjenrrorna_v2n)].3tds e tcLs rs] objeC shona_v2n)].orl wor t alglothgguleChelextra nadmr*/
 metho,laidupbifsseloolertcfeoQrr slshdftes"FSfhorcmorrds] gimosirLt
io reMISUSPREPARUSPERSISTENT|reMISUSPREPARUS*]arics f  bsorTry LjeC shona_v2n)].orl etholwor storks if
ewoeheoreeed pasTry LjeC shona_v2n)].3tdsa numfrorcmonadmr*/
 metho,laiddiffereAPIei.
a,s] objeretenna_v2n)*] obj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *zEthMsSql,sfff/o s aSsd LL.
 T_i*,eeencod** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *zEthM*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
differeAPIei.
a,s] objeoTeA_na_v2n)].or] obj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *zEthMsSql,sfff/o s aSsd LL.
 T_i*,eeencod** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *zEthM*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
differeAPIei.
a,s] objeoTeA_na_v2n)].3r] obj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *zEthMsSql,sfff/o s aSsd LL.
 T_i*,eeencod** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] ounn  () e syonadmr*/
 ,
**sZrcmorrltimosreMISUSPREPARUSarics mrs] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *zEthM*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
differeAPIei.
a,s] objeoTeA_na_v2n) *xWribj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *rs] osSql,sfff/o s aSsd LL.
 T_i*,eeenc16d** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *rs] o*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
differeAPIei.
a,s] objeoTeA_na_v2n) *].or] obj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *rs] osSql,sfff/o s aSsd LL.
 T_i*,eeenc16d** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *rs] o*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
differeAPIei.
a,s] objeoTeA_na_v2n) *].3r] obj **ppDbdbffffffffff/o s are c Slenht*/
  tnmi t** a *rs] osSql,sfff/o s aSsd LL.
 T_i*,eeenc16d** ,hlyitnmi 
**sSBffsffffffffff/o F
**sMaxaonhof
igsqulfhzSqleaw-iyt Mders] ounn  () e syonadmr*/
 ,
**sZrcmorrltimosreMISUSPREPARUSarics mrs] obj **ppa,s] o**ppSs] ,OUT:etheiOSL.
 T_i* ht*/
  tnmi t** a *rs] o*pzTwfiro F
**stheiOP arguaiuesunrguTv firfsis   zSqle
diffeure releasesPh geEeSup/othgOSL.
 T_i* reOTry D:Qds] objheyup;
n fy Anlt ,s] objenrrdrbjetP metho reAGMA]rthSsbits arguaiues a aonul- tv eeencoSy uSl  isNsirguTvids lelimQ[nadmdrid LL.
 T_i*]bPtdrarywasTry  lelimttyotobjeth gena_v2n)].lyin, objevfs.xna_v2n)].3td ,(M tobjevfs.xna_v2n)16].orl
The< objenrrmsna_v2n)16].3td ^Teirds] objenectndHpanrrcobjetP metho reAGMA]rthSsbits arguaiues aeencoSy uLLles"F ng t.is all euSl  isNsi itsadmdrid LL.
 T_i* PfileLdes assneipethos]ra
** dHpanrrc^Teirds] objenectnnbusatLear_bjetP metho reAGMA]rthSsbits arguaiues aeencoSy uLLles"F ng t.is all eunbusatLearuSl  isNsi itsadmdrid LL.
 T_i* Pissn ,teids manhecnrrguTvidsnbusatLeas arid LL.
  s a sdee wb c t fe is basu
* tis e ids d, ee/eearocsm.isonh,r The
Thts *
*[iNT reanroelathe aa num* ee Sle(M tpathehoods lp
t^Tfis,eRIkPS  leCo,Fih genadmdrid LL.
  bjn*  n lelimttt ret,s] oreOTry isNsi"SELECT $abc,:xyz"ifoPt ryemao is is$abc*  nssneipSs* syand r2345Try as] emao is is:xyzfno-usssneincrs] objefilenbjetdtNT reA]rfalguleChelnctbSifeeLLles",i"SELECT $abc,:xyz"ibeegbjenectndHpanrrcobjet) duVoe reA]rfalf"SELECT 2345,y ai"y
, t^Tfis,s] objenrrdrrHpanrrcobjet)metho reAGMA]rthSsbidiEOis insuf ftibjn* cTVFSs e stFa* ece chVFS|tty ethe LVeode,fneabavmentLVeode N  du o ored achxistmaxaonhobLles"Ff
igsqude itndmmttyo s
io[reMISUSLIMIT_LENGTH<. t^Tfis,s] o[reMISUSTRACy_SIZUSLIMIT]ile-SE_FtdTL_Trlt. selbatcs t] obn* f**ocksbsneipethos]ra
 dHpanVheyup s,s] o[reMISUSOMIT_TRACy]ile-SE_FtdTL_rig nlt. seGl[rs] bjenrrdrrHpanrrcobjet)mFS|per AGMA]rthShy aip[URTfis,s] obsVuppuMA_SVtheor file nrrcobjetP mas] bjevfs.xnbusatLear_bjetP  )trSrritd. () oae Ss orrlaeippe,rautosahecgohse limttwhen-mentnadmdridTry LL.
 T_i* iULizh()].uc^Teirds] obLles"FA_SVtheor file nrrcodHpanrrcobjetP ,ey ues aiC uesht*/,s e stF nt
fat  h,s] objedbe Smitntntd simild-olxWvs limttyo s
iority i)^.lyocksbypnttthSm itSyinobjef nct limtd ^TeiTeirds] objenectnnbusatLear_bjet)metho reAGMidayin Fa* ece chVQ Sy ues a reMISUSEN.hey_NORMALIZ(<ile-SE_FtdTL_Trlt. sel *htVhe*uppefereAPIe*xWrit** a *rs] objefilenbjetbj **ppa,s] o*pSs] ffereAPIe*xWritrs] objenrrdrrHpanrrcobjetbj **ppa,s] o*pSs] ffe#ifiru*reMISUSEN.hey_NORMALIZ(ereAPIe*xWrit** a *rs] objefilennbusatLear_bjetbj **ppa,s] o*pSs] ffe#endQ Sure releasesPh geDe itndmmtirnAnoSsd LL.
 Objn Writ Mys] oDe cmes ocksD:Qds] objheyup;
n fy Anlt ,s] objenrrdrbn f_ee cyin E_FCetho reAGMA]rthSsbs1)sifentr is )VQ Sy uanu wor ty Lds] onadmdrid LL.
 T_i*]bX ma ocon O oe ]hh d, eesin Sy ueeadxtahentSy ues are cmes tupphey TSe ois tfempn%[rity i)^.ly-htVevFi Ssd bussV)^henhe<li> ovirhanhere chs]eelocks wwfilnes are cmes tvfysurdimttsaics odin aunSE.Tfis,eRIkPS  leCo,Fih gnority itdrary tVevFsicsbus isti "an d()"nomdos e  *
*[oobjenrrmsgxeceabnceabcnqld   th:heyucrid LL.
  s a N  duxistcthfilnes are cmes ttgng threaeye odi- aunSEnppe<olrlybntnkqus t><nadhTfirrrrSELECT an d('DELETE FROM t1') FROM t2;Tfirlynadh</bntnkqus t>pe<olrlBulxWvteeethes a rELECT]eLL.
  s a  rearefs cthfilnes are cmes ttgngolrlysurdimt,objenrrdrbn f_ee cyin E) N  du ste reA]rfalfs1)sy
, t^Tfis,sho**a isti _l retdsLL.
s}heyh aseheap
[BEGINn, oCOMMIT], oROLLBACK ,(M toSAVEPOINT], as] oRELEAS(<ileeethbjenrrdrbn f_ee cyin E) H Ml tn exs1)s,teidsianr acheLL.
s}heyh achmselvesTdoalyinrct gohsemodQ ynes are cmes tbeSQL,cratSane ney _l retdses adTLes"FSfhwhen-iC uesLL.
s}heyh modQ ynes olrlye cmes p s,s] o[ATT 
* [,s] oDET 
* [LL.
s}heyh b 
**leeetTry LjeC shobn f_ee cyin E) H Ml tn exs1)sdsianrupbifng thea *LL.
s}heyhxistcthfilnes a_l figurarfsis   aare changed forci aC,e ney doalyinma oxistcthfilis  in)trxtahentSy ues are cmes tupph ey udisk^Teirds] objenectnbn f_ee cyin E) etho reAGMA]rthSsbs1)siis o[BEGINndsianr(M toBEGINndmerel,eMacs pcllylyiaf*/
 ,
beeg 
atoBEGIN|BEGIN IMMEDIATE simids] oBEGIN|BEGIN EXCLUSIV(<ile-td.dsTdoatouchues are cmes tas] boTry LjeC shobn f_ee cyin E) A]rfalstt(0)mieir"nConged -td.ds^TeiTeirds]ut whsrema n rfalstt(0)miirnCNTenorhafnits tthbsaoutfemprinpoTry LL.
 T_i* elocks wwfilnes are cmes tFtPaang^Att(0)mil tn ex reaTry lyinnteCdlreefemprinpoc L.
 T_i* NT re wwfilnes are cmes tFtPaaTeirdRIkPS  leCo,FgnoUPDATE LL.
 T_i* elocksmorrlatWHERE  lat^Ieomdos e ma ocotcfep
, tf,
beeg 
atLjeC shobn f_ee cyin E) A]eode N  du ste rocksbAtt(0)mang^Soewfllmt,oa CREATE T.hey IF NOT EXISTS LL.
 T_i* iULr ld LVad-wor t
, tfty Lds] re chValee cbSs oria,tbeSQL,cLjeC shobn f_ee cyin E) ste reA]rfalstt(0)mieir"asehea LL.
 T_i*t
t^Tfis,irnpadmdrid LL.
  bjn*X tsmpar[EXPLAINnds o[EXPLAIN QUERY PLAN]Try LL.
 T_i*ncrs] objefilenbn f_ee cyin E_FCA]rthSsbsoreeed ptteginasTry y Lds] EXPLAIN s oEXPLAIN QUERY PLAN-prheixcfeveroatct*uppefereAPIe*xWris] objeretenrn f_ee cyin Ebj **ppa,s] o*pSs] ffeure releasesPh geQics mTs] EXPLAIN Settes"FRIkPAenadmSrid LL.
 ObjnocksD:Qds] objheyup;
n fy Anlt ,s] objenrrdrbn f_isrHpl
fa(S) etho reAGMA]rthSsb1Sy
Thevmentpadmdrid LL.
  bjn*S tsmparEXPLAIN LL.
 T_i*ncIkP2Sy
ThevmentLL.
  bjn*S tsmparEXPLAIN QUERY PLAN^Teirds] objenectnbn f_isrHpl
fa(S) etho reAGMA]rthSsb0Sy
TSpeic that ="1vfthmtLL.
  bjn* * tfileits .VFTerpefereAPIe*xWris] objeretenrn f_isrHpl
fa(bj **ppa,s] o*pSs] ffeure releasesPh geCwwfilnTs] EXPLAIN Settes"FRIkPAenadmSrid LL.
 ObjnocksD:Qds] objheyup;
n fy Anlt s] objenectnbn f_rHpl
fa(S,) metho reAGMcthfilis s] EXPLAINteids ttes"Fis o[nadmdrid LL.
 T_i*]bSt Sy vEeds-orcmnfit SESxWvtom d )trSsnbusattpadmdrid LL.
  bjnt Sy vEeds-1nfit SESxWvmorrsditty Try yasthecFisNsibegat a num"[EXPLAINn"t Sy vEeds-2nfit SESxWvmorrsditty Try yasthecFisNsibegat a num"[EXPLAIN QUERY PLAN]"t
t^TfisC trs] objefreeebn f_rHpl
fa(S,) melocks at^IeS_H Manroepadmdrid.Sy uSl orrllup/
bFSri*rs] aroepadmdri,
beegaroepadmdriy2bSsthefiorce niFSs e y ues ae the lho**ithe,eunF-8EXPLAIN s oEXPLAIN QUERY PLAN-sistppeBegin *teeethirLdes eohentFSh"reeworryoepadmdri,
a teQtSyiQL,cLjeC shobn f_rHpl
fa(S,) mNT rehwfinSiffereMISUSERRORSy
TSpcan-lyytu_HANoepadmdridxWvteeethtcfhevh lelimttt ret,objeth gena_v2n)td set:  " ulfSy ueeadnefev objeth gena_v2n)].lyinhe<tobjevfs.xna_v2n)].3td sethosiarrlesmids] heanr hrais eeevaruSl  isNsiSiffebifsserryoepadmdrit
t^TfisCd, el *
Chelexpl
fads ttes"Fis ogenadmdrid LL.
  bjn* rearefs cthfilguleChelnctbSifeeSl  isNsieir"nCNTLL.
  bjnt SH erl,Fy Lds] Sl  isNsi ctbSifeld-o** tgat a numEXPLAIN s oEXPLAIN QUERY PLAN,ibeegbjenectnbn f_rHpl
fa(S,0)s e stF la
** ids  fdlininpoc L.
 T_i* be aeat ="1vfthmtLL.
  bjn,s s] EXPLAINteids oEXPLAIN QUERY PLAN-key fodsmNT reste refS 3aea all  ile nrrcobjetS)s e hsrputetthea fteaeyeS 3c L.
 T_i* lywlaa
sSas orrlnbusattSsd LL.
 T_i*ty Anlt s]ut whsrema n rfalstreOPENeWKty  the hxpl
fadjou eisdssfuoly sel,xistcthfildncIkPae hoc*geitd  y  the hxpl
fadjou ecentod-otmpar dlreed^(M tThe hxpl
fadjou ecan-lyytur dlreedibifng a LL.
 T_i* iULrly,h Hewavb erl,Fy* iULLoongerrly,ldFtolteQtSobjef ncte ].tfSin )tre* D ^WtepegergucFS ** trs] objefreeebn f_rHpl
fa(S,) rpefereAPIe*xWris] objeretenrn f_rHpl
fa(bj **ppa,s] o*pSs] cethcCNMou ffeure releasesPh geDe itndmmtirnAenadmSrid LL.
 Objn*HraiBQLpimttyeocksD:Qds] objheyup;
n fy Anlt ,s] objenrrdrbn f_busy(S) etho reAGMA]rthSsbs1)sifentr is )VQ Thevment[nadmdrid LL.
 T_i*]bSbSinrSQLpi ].opid patyratidot het retds] objelQRYi ].owSinibeeghrais iUTF-8ruSEids  ed.hehe,e(A_SVtheo(M toSeAPIe*DON(<ih,s] objedbe S ].owSin)lnbu-o** tLpieethoet[,s] objeatsete ].tfS)[f  bsorebjenrrdrbn f_busy(S) )tretho reAGMA]rthSsbt(0)miirnS.** tkts its  is at Sy vSreaalyinr ld ts its  oria streadyrgenULs arguaiues avUTF]N[nadmdrid LL.
 T_i*]s e h
* tinceabcnqld anglot heno-ushttabe is ba* yrundesiriapah thbty Anlt s]ut etho reAGMclT_HAN] oba al  e vftehe,eobjelQRYinsNsrbn ffin )truesntn the. ^iladmdrid LL.
s}heyhcia Cdlwfileheird are  [SQfSlend forci aCearrlguaLL alreewole iees"FA_setrvnqlaltGlT_HAN] ob,Slened po  leCo,Fs ariagnostec whssr AGM] obearsseed pnadmdridTry LL.
 T_i*hoarrlguaLLtty eyucr lho**a isti )]]erpefereAPIe*xWris] objeretenrn f_busy(bjeretenrn f future releasesC shoDynamecgohseTe ri tp ieu 
* tKEYWORDS: {th genaoheccid Ljeretenttegi} {unnaoheccid Ljeretenttegi}y Anlt Sl orrl[rs] heotLjeretenttegi* a f tfrotse )sf a e. ^is *
*[guleChe , tT_HANLLimodret* ere cmes tre ch. Sl orrl[rs] dynamec typretds] eir"nCNTs *
*[iitNLLimoup s,Vesel diLimodret*Ljeretenttegi* a f thxistctT_HAN syand a,tflonnretpnoiurss *
*[,obsVuppu,iBLOBs** tkidiEty Anlt At*Ljeretenttegi* a f tmSs  **  iUTF-8"naoheccid"* tk"unnaoheccid".Sy uS ) methosies tfoedl atogenaoheccid LjeretenttegiafteUTF-8ethosies t
duVoe reseEapt  iUTF-8genaoheccid IkPae unnaoheccid LjeretenttegiEed povcs methosialdFtrrlgueEapts*Ljeretenttegi*rolbatct 5b c t fet
duVor oepereasheneitfoedl atsogenaoheccid LjeretenttegiaftT ,teidobjeth gettegi_duowhstethosialdFclT_HAN] obaids  f a,s] oop
ewmentpaoheccid Ljeretenttegi rs] ote unnaoheccid LjeretenttegiEed (M tThe  itnnf"naoheccid"*s ba"unnaoheccid" lnhoiorry r oepereashen )trSs](D))eno-held/eeanIpcllylyia](D))eno-heldFis ogenaoheccidQL,cLjeC shottegi* a f tmbeegs e](D))eno-heldFis oge unnaoheccidQL,cLjeC shottegi* a f tt Sy vSeitselfsdnhntinteQseumenOnSife-emeEFnidQL,c(heird[reMISUSTHRferSAFE=0 [,s] heird[LjeC shoemeEFneafuppe fvSahe,s] 0)s e neabavSeitselfsdruSEtlfff"no",moduhe a](D))ematd  )troreCORRUPTURI]tSINGLETHRfer[differeOPENePTURI]tMULTITHRfer[guleChennCNTenorhan O oftesci aCebnh thetpaoheccid ,s] unnaoheccidQL,cLjeC shottegi* a f te SyaetheyMclT_HAN] oba ally dlreeundeitorl, tty ds] eir"maxaonhopatserorre saoutfietpGMA_zhnT_ithegtrrlguity iseshouTry LLe rema ores aroftesci aCebnh thetpaoheccid ,s] unnaoheccidQL,cLjeC shottegi* a f te   neeexctnhenebsVudimttoedl at ^TeiTeirds] objenectnttegi* a f te arrlguaLLe astpeirfethoseeo.rsthetxOTenlt id conflistaid irL[rity i)^.ly-htVevFi Ssd bussV)^henhs vidnSheccid^Teirds] objenectnttegi* a f te A_SVtheor fiobjeth getre _rhsnttegitd Try a vidnSheccid^Teirds] objenectnttegi* a f tMA_SVthuppers] oobjeth gecolum nttegitd eno-usdnSheccid^TeirUnnaoheccid Ljeretenttegi* a f te o  ayor tHAN] obasaicolbatct  )truesobjeatsete ]ultnttegitd ,tobjertepe*()lyttegitd ,timids] objelQRYittegi_duowhs^(M tThe objelQRYittegi_blob | Ljeretenttegi_ee rtd ebamilnul- )tretho reAGtfoedl atonaoheccid Ljeretenttegi* a f te.ypeuee riru* a,s] objertm attegi*bjertm attegiuture releasesSetrEtsd Fus isti Ctahexn* 
* tKEYW(M tThe ctahexn*in"bahebxtn Ssd bussV)^h_siee e luds-LLimodret* nQL,cLjeC shoctahexn* a f tt S^ALs arguaiues ncLjeC shoctahexn* a f ts e stFper AGMes ae the etho *
*or fi[rity i)^.ly-htVevFi Ssd bussV)^hentaba s
iority itdrar-htVevFi Ssd bussV)^h id conflistaid oe ree as aouteeads arguaiuhreaeyethetx *
*[or file nrrcoe ]ultniurs| Ljeretene ]ulttd ,(M tobjevfs.xaggoeofteoctahexntd ,tobjertepe] or_re ctd ,(M tobjevfs.xctahexnutexht*/
 td ,tobjertepegrmsrixre ctd ,(M teupperr[bjeretenrrmsrixre ctd .ypeuee riru* a,s] objertm actahexn*bjertm actahexnuture releasesSetrEBvfyssn Vesel dToenadmSrid LL.
 Objn
EYWORDS: {th geoos methoOe ct}geoos methoOe cts}geoos methoOe ctoisb }EYWORDS: {th geSsd ethoOe ct}geSsd ethoOe cts}geethoOe cto vfyssney AOD:Qds] objheyup;
n fy Anlt ,(IrtheothecFLL.
 T_i* Hexn*inifeiio objeth gena_v2n)].lyinhstreate  s [ancs,(M t The
Th mSs  ** oelathe aoQrr methos]ra
]fn alt dtchecoff"no",des   th:heyu )trued c.
 sppe<ulrlyin<li> or fi ?li> or fi ?NNNli> or fi :VVVli> or fi @VVVli> or fi $VVVli> oyyuppe^TfisIrtheotued c.
 sfedTL_, NNNtse )sf a i* n* syand r The
ThiTry as] VVVtse )sf a i* n*alpht*cr[nqldidentF fer<)^ rds] os *
*[io",desuteeadsthoseeo.rs(b 
**lea
** "oos methoOe ctoisb s"* tk"Ssd ethoOe cts")xistctT_HANthoet[,s] heotLjereten*()lyin  whssr AGMhtVevFi NTen^TeiTeirds] oeics mrol rgurs  in)trLjereten*()lyin  whssr AGMstFper AG )trSss arguaiuestf r[bjeretenrs] ]b lT_i*MA_SVthupprs] (M tobjevfs.xna_v2n)].lyinhe<tate  s [ancs^TeiTeirds] ob  the rol rgurs  nomhcpcdexoo Lds] Sl  etho *
*or fit.he/
dif* bsoreleftrecroSl  etho *
*orh/ bsolpcdexoo L1t S^tfissleialed pisb eSy uSl  emao is is  nrguTvtimos.sst oerl,Fb  the r basu
ntfileEFS su,erssi erlemorrlleialed ppcdexoirfSlete contu,erssi erdif* bsorepcdexoeir"isb edsthoseeo.rs tT_HAN b (eorupet ret,s] ds] oLjereten*()lysthoseeo._pcdexyinhxWrisf iaparnirvnbsorepcdexds] eir""?NNN"fethoseeo.rsts"nCNTs *
*oo LNNNdif* bsoreNNNts *
*od-olxWvsbnh thet1 as] t
io Ljeretenlbatcfineeadsthoseeo. [reMISUSLIMIT_VARI.hey_NUMBER< ( Lsmsssas *
*: 32766)^TeiTeirds] otics mrol rgurs  nomhcs *
*o ae vf**  in)tretho,laiddifis,irnCstftics metho *
*or] objereten*()lyhexntdhe<tbjereten*()lyhexnppe<li> e<tbjereten*()lyblobE) e* tkts its  is aceabcnqld   ics metho *
*os e stFignimodrSyaethe hAGMA]eode isbsoreeed pastbjereten*()lynull()difis,irnCstftics metho *
*or] objereten*()lyhexntdheaalyiny ainbatcrs] oitNL birancarrss arguaiueswell-lbusobaeen8hisNs.ifis,irnCstftics metho *
*or] objereten*()lyhexnrehAleaalyiny ainbatcrs] oitNL birancarrss arguaiueswell-lbusobaeen16hisNs.ifis,irnCstftics metho *
*or] objereten*()lyhexn64hAleaalyiny ainbatcrs] oitNL birancarrss arguaiuesaswell-lbusobaunipatsebLles"Ftr*etpGs] o iUTF-8eor8abavmentLixs metho *
*oleaareMISUSeor8,TF-16lr16li> ete ,lvarppe <li>[[iyt  ="1" Fde itndmstaid )upps]dt>s] oiyt  ="1" Fl- )treen16hkSifeiisNsiusude itndmmttyo s
ioiyt  ="1" Fmark (BOM, U+FEFF)ds] eiu* f**fSlete contcthoseSE_upbifsselooremTL_dncIkP**fSleta
ntt hee oa BOMguleCheeoffset"1" FstFk   Seicth.offset"1" Fo Lds] oos gulentchssumfe<tbjereten*()lyhexnppe<eirdrri*offset"1" Fb c t fe iilguleChel6s metho *
*olfe<tbjereten*()lyhexn64hA. TSy [^irneen16hkSifeiisNsi n aonhcoid.heyuaunipatsxistcthoseSE_Fetit SESl  theelocks wwfilnesos tvf.heyuacthoseSE_F )treth in)trunipatseoelathe s a lthoseSE_: U+FFFDp
t^Tfis,eIrtheout whsenn daempnSSirrlat  ics mrol rgur, ate  s*
*oifileLexctS ad/qule iyt My  inpocetho,laiddahe atur lea_: omhcs *
*oifileLexctS ad/qule <u>iyt Moyy>y  inpocs *
*,sheneld bn ad/qule cthoseSE_F. TSy [^irnqld   ics metho *
*or] objereten*()lyhexntdhe<tbjereten*()lyhexnppe<li> ctrhegeicthnfit SEtheof
igsqulfhsore  issnanaguleChelS ad/qule iyt Myrpf file reics morcmo itndmdrIp^(M tirnCstf  ics metho *
*or] objereten*()lyblobE) e* hegeicthnfit SguleCheeonglot heno-ushttabe ^(M tirnrlnbn-
egeicth.  ics metho *
*ords-prSvfther] objereten*()lyhexntdli> e<tbjereten*()lyhexnppe<eirdbjereten*()lyhexn64hAlit SguleCha methoOe ctod-olxWvsrri*offset(rs] 
duVor rvsrri*y ao itndmdrIpnN  du w,e t f a f,s] heotL issnafevery a )truetndmdrrit Sy vfnity aocthoseSE_F w,e t ft*offset(rs] aaleas aoaSguleCheetoff Se  the   ics metho *
*or]t SEtheoA]eodes] ob issnatoff SNT rocks n aonh ead/ddeisy aervnqld Lloferof rif )sftheo fid/ lvs] ob issno duVoe fiead/ddeisy aeeno-ushttabe ^(M Teirds] oeifs mrol rgurf file rBLOBer bas issna vfyssnretho reAGtf_l retdss e neabtf a f tfreeofifedTL_Tr  the  lT_i*MA_tcLdecmttyo s
iotics metho *
*otaba s
i^Ieomdea fp
shouls ori:Teird (1) A)iptttla
yividsdisa ) Tr  the BLOBeirds issna or fiSl  thevidsfssishil duVoe fiitmSs  ** e astpods]t stF la
** idsdisa ) Tr  the BLOBeirds issna  neli> crnCstfa. ^f file r vf**xWrihwfils,o orpneld biptttla
yiveaalyin la
** Q Sy ues atics metho *
*orifitkts its  is acirdrri*  ics metho *
*ords-
egeicth.Teird (2) s] obt VFSh"ru* Canc, oreOPENeSTATIC],mSs  ** e astppSs* sf a f  omdos e t
iority itdrartseat  nfrd** usiSlenoaVFSisa )es"FSfhthe  lT_i*.thI inpihxistctshnfit   lT_i*MSyaethe prSvfthers arguaiuestFCd-oteseat   .heyuaunSQ Syyc iUTF-8the prdmdrid LL.
  bjn*  nizh()].uccirdrri*eed pSl  emao is is  SyycssneipSs*,tbsnpisna lse, bahebreadsu,ers]eMoIniddifis, (3)tThe cta Canc, oreOPENeTRANSIENT], Ss  ** e astppSs* sf a f  omdoileLexct lT_i*Mifiloel *copfe iergucFS *theoA]tn exrs] objeC sho*()lyin . bsorTry  lT_i*MSyaes arguaiuestFCd-oteseat   .heyuaunSQ r]t S. bSl  theoe reit Sguletd. ()freeofifedTL_Tr  ate ergvQLputspy^TeiTeirds] obixs mrol rgurf fibjereten*()lyhexn64hAld-olxWvsff"no" )troreCORRUeor8],roreCORRUeor16],roreCORRUeor16BE
The< oreCORRUeor16LEn )truesb c t yethe hApates"FSfhthe hexn*in"s
iotics metho *
*ot Sy s e t
iobixs mrol rgurf fibjereten*()lyhexn64hAleaalyinff"no",des )trSth:hents *
*[iL bwnfedTL_, neabavmenthexn*hApates"FeA_di tcLdesds] efirts ithApates"Fb c t fe iyo s
ioLixs metho *
*onceabcnqld anglot hli> ctrushttabe ^(M Teirds] objereten*()lyorcmblobE) whsrema *()lfitkBLOBeifof
igsquN tndos e stFfia
** oe fiorcmoup s,A orcmblobl[rs] at ixlyiamoneteifo cTVFSs e (nseid n* syand rFS|tty eate bn* )ibifng ietpGMiees"FmsQgenUe ^(M tZrcmblobs (ctrth cftheg] oberv pastpathehoods lnoaVFBLOBshumea ocks n abjn*  nc.
 pnNrtct*net retds] objelQRYiblobt)]]e | itee nflislkBLOBeI/O] whsenn daTeirdAp
egeicth.ttegi rirdrri*orcmbloblLloferulfn*adorcm-f
igsquBLOB^(M Teirds] objereten*()lys argua(S,I,P,T,D) whsrema Gl[rs] heotI-s metho *
*ordSgule[nadmdrid LL.
 T_i*]bSbFS|tirrlan Ssd s *
*oo LN ainbbfeiio b 
**tu_HANia Cdlwfileheirdthe p arguaiPno",dype Tp s,Del *eiUTF-8gets its  is acir )trSss arguaiuesabiptttla
yivbussV)^h rirdP. bSl  theoe reid/ (eome olrlyptttla
yivDeheird ar Sifeorol rgurforarywt SEtcfififssishilet retds] Petthea crnCstfa. ^f fibjereten*()lys argua()ihwfil. ar
*o aer ld rfcnt ecgo iapagg dl ak,lLloferulsdee whtVevFi crnDs  SyycreOPENeTRANSIENT, TuesTmetho *
*or
 birancarrsLL.
iceLLles",eeadsA_tcLundesaobLles"FfThe
Th. s] objereten*()lys argua() whsrema uteeadsartSy ues a[s arguainttthSm itho reAG] tddeisrirdSl  the3.20.0t
t^Tfis,irnd.y ofin)trLjereten*()lyin  whssr AGMSrriraa
** oe figets its  is ads] eir"es a[sadmdrid LL.
 T_i*]b r oe figeprdmdrid LL.
  bjn*eir"bahebds] objelQRYi ].owhstSinrSQLpiraa
** timosrecdesluy.sst objef ncte ].tfin,li> then-menta. ^foe reA]rfalforeOPENeEISUSE]t Sy vfnitLjereten*()lytdli> whsrema utLe astpeiQ[nadmdrid LL.
 T_i*]b*re ,SinrSQLpiizh()].uc etheds] A]eode isbushttabe is ba* yrundesthomfult
t^Tfis,BvfyssnGMSrrilyin lea_mttyo s
io[bjef ncte ].tfin whsremaaTeirdUnssneipethos]ra
* (ctrth crnadtobasaiy aip[URTfis,s] objereten*()lyi whssr AGMA]rfalfereOPENeWK] y ussfuoly IkPaeds] ohFCNTnitd ]tp vfninpisnagrearwrongaTeirdoreOPENeTOOBIG]y2bSsthefiA_Sa</ddsaavmentLi* f** an  les"FSriBLOBSyyc  oredselbatcs ima ) or fiobjeth gelbatc]([reMISUSLIMIT_LENGTH<)he<li> oreOPENeEAX_LENGTH<. t^rdoreOPENeRANGE]tpGMA_Saheyuabavmentemao is i )tretd))eno-reego",m, ee/eedoreOPENetieia]tpGMA_Saheyuabavmitntntdihwfil.[URTfisSee b 
*: oLjereten*()lysthoseeo._conettd ,(M tobjevfs.x*()lysthoseeo._isb td ,timi oLjereten*()lysthoseeo._pcdexyinrpefereAPIe*xWris] objereten*()lyblobEbjeretenrn f cethc, t** a *rs]icethcCn, *rs](*)(*rs]i)ffereAPIei.
a,s] objeoTeA_*()lyblob64hbjeretenrn f cethc, t** a *rs]icebjertepe]thc64,
                        *rs](*)(*rs]i)ffereAPIei.
a,s] objeoTeA_*()lydouSlehbjeretenrn f cethc, douSleffereAPIei.
a,s] objeoTeA_*()lys] hbjeretenrn f cethc, thcffereAPIei.
a,s] objeoTeA_*()lys] 64hbjeretenrn f cethc, bjeretens] 64ffereAPIei.
a,s] objeoTeA_*()lynull(bjeretenrn f cethcffereAPIei.
a,s] objeoTeA_*()lyhexntbjeretenrn f cthc,t** a *rs] cthc,*rs](*)(*rs]i)ffereAPIei.
a,s] objeoTeA_*()lyhexnppebjeretenrn f cethc, t** a *rs]icethc, *rs](*)(*rs]i)ffereAPIei.
a,s] objeoTeA_*()lyhexn64hbjeretenrn f cethc, t** a *rs] cebjertepe]thc64,
                         *rs](*)(*rs]i),ounn  () e*rs] hApates"ffereAPIei.
a,s] objeoTeA_*()lyttegitbjeretenrn f cethc, t** a bjertm attegi*ffereAPIei.
a,s] objeoTeA_*()lys argua(bjeretenrn f cethc, *rs]icet** a *rs] c*rs](*)(*rs]i)ffereAPIei.
a,s] objeoTeA_*()lyorcmblobEbjeretenrn f cethc, thc nffereAPIei.
a,s] objeoTeA_*()lyorcmblob64hbjeretenrn f cethc, bjeretenus] 64ffeure releasesSetrEN ad/quOavSei Pthos]ra
*
 AOD:Qds] objheyup;
n fy Anlt ,s]ut whsrema clT_HAN] obaidsiiyaC uesn ad/qule [Ssd ethoOe ctsn )tret iQ[nadmdrid LL.
 T_i*]/eeSsd ethoOe cts (ctrt (ensno",des )trlbus "?",""?NNN","":AAA",""$AAA","ir""@AAA"b*re ,berv paseeadsathehoods lnoaVFs *
*[iarrlguaLL[bjeoTeA_*()lyblobi|e snein )truesmentemao is is dld bc.
 pndTL_p
t^Tfis,es]ut whsrema rct gohseA]rthSsbsorepcdexoo Lds] lrolptts(rbSstrecr)eeadsthoseeo..FRIkPeQtS  tnnfo orpne?NNN,inpih NT re lord** uLf file   ern ad/qule uniquntemao is ist Sy vemao is is o Lds] ?NNNrlbus sdee  ob,Slentr rvsSs  ** gapMy  inpoclfcny
, t^TfisSee b 
*: oLjereten*()lyblob|Ljereten*()ltd ,(M tobjevfs.x*()lysthoseeo._isb td ,timids] oLjereten*()lysthoseeo._pcdexyinrpefereAPIe*xWris] objereten*()lysthoseeo._conettbjeretenrn f future releasesC shoNed pOrnAeHecroPmao is i )trD:Qds] objheyup;
n fy Anlt ,s] objenrrdr*()lysthoseeo._isb tP,N) etho reAGMA]rthSsguleChelSaL_Tr  the N-ird[reMmethoOe ct]a all  Q[nadmdrid LL.
 T_i*]bP.Tfis,eSsd ethoOe cts e  the   us "?NNN"fir"":AAA""ir""@AAA"bir""$AAA" ld rirrlatSaL_TbifsselooheotL issna"?NNN"fir"":AAA""ir""@AAA"bir""$AAA" ld rd**ecicthl,^(M tiw-iC ues fods,,desa aitFSh"":"bir""$""ir""@""ir""?"s e stFief SytpeirfethtSy ues aSaL_. TSy [^PthoOe cts e  the   us "?"nheirreega   th:heyuc syand rrirrlnoaSaL_ )trSeippe,rrhe e
lyitiorai"SaL_leas""ir""anonymSQfiethoOe cts"^TeiTeirds] oeics moos methoOe ctoh/ bsolpcdexoo L1,shene0t
t^Tfis,irnCheetoff SNeno-reego",m, ee neabavmentN-s metho *
*ordaTry laL_leasnceabcnidiEOiGMA_SaheyupvnbsoreA_Saheyua  issnanaguleper AGM aleencod** ,hssna  neabavmentisb edsthoseeo.ywasTry  ctbSifeldFb c t fe i/ b6lr sleet objenrrmsna_v2n)16td ,(M tobjevfs.xna_v2n)16].orl
The< objenrrmsna_v2n)16].3td ^TeiTfisSee b 
*: oLjereten*()lyblob|Ljereten*()ltd ,(M tobjevfs.x*()lysthoseeo._conettd ,timids] oLjereten*()lysthoseeo._pcdexyinrpefereAPIe*xWrit** a *rs] objefilen*()lysthoseeo._isb tbjeretenrn f cethcffeure releasesC shoIcdexoOrnAePthoOe ct WeirdA Gi neaNaL_ )trD:Qds] objheyup;
n fy Anlt ,R tn exsorepcdexoo Lan Ssd sthoseeo.ygi neatcs SaL_.  bsorTry pcdexotoff SA_Saheyuabsm* ee SlenoaVFeethirfSletb  theeeadsthoseeo.iio objeth ge*()lyblob|Ljereten*()ltd p s,A orcms e stFA_Saheyuabavs e]dtches"Fmtho *
*ords-eiu* pvnbsoreemao is i )trSaL_Td-olxWvsgi neataleencod* neabavmentnctbSifeeLL.
 Objnockshevhnadmdrid efirt6lr sleisNsirgret,objeth gena_v2n)16].orl
he<li> objef nctna_v2n)16].3td ^TeiTfisSee b 
*: oLjereten*()lyblob|Ljereten*()ltd ,(M tobjevfs.x*()lysthoseeo._conettd ,timids] oLjereten*()lysthoseeo._isb td rpefereAPIe*xWris] objereten*()lysthoseeo._pcdexybjeretenrn f cet** a *zEthMsNaL_ffeure releasesPh geEethoeA reBvfyssnGMOnPAenadmSrid LL.
 ObjnocksD:Qds] objheyup;
n fy Anlt ,Ctahrarhold sorepctuitaid irLtd.y,o[bjef ncte ].tfin  rearefs rttyeockss
io[bjef nct*()lyblobi|e vfyssn [ext iQ[nadmdrid LL.
 T_i*]/TeirdUe oaoutiwhs o retl eethoeeQtSoos methoOe ctseSs*y aip[UfereAPIe*xWris] objereten lea__ vfyssn tbjeretenrn f future releasesC shoN ad/quOavColum stiw-AeEetode SyeocksD:Qds] objheyup;
n fy Anlt ,R tn exsoren ad/qule colum stiSEtheoA]eodeNthoeA_SVtheor fitevment[nadmdrid LL.
 T_i*].s,irnChut whsrema n rfalst0,iarrlgmeansitevment[nadmdrid LL.
 T_i*] n rfalstn O ata (ed po  leCompar[UPDATE])difis,rl, tty ej-olxWvteeethesut whsrema n rfalsta-posiicthen ad/qu rearefsguleteaniarrlgff"norltimosrcstfle  ata NT reanroetaheyupvnbArSELECT LL.
 Objnockshe reser AGMrirrlatposiicthebjertm actlum nconettdbbfeidepefyssnroall     tWHERE  lat^Ie  f a,ainte Syaethe re chV n abjn,etFCdbSsthA]rfalfn Orcst^TeiTfisSee b 
*: oLjereten ata_conettd [UfereAPIe*xWris] objereten tlum nconettbjheyup;
n fo*pSs] ffeure releasesPh geCtlum aNaL_stiw-AeEetode SyeocksD:Qds] objheyup;
n fy Anlt ,Taout whsenn dar tn exsorened pasn  () euesabethticulroicolum Try iSEtheoA]eodeNthoel  vh[rELECT]eLL.
  s af  bsorebjenrrdr tlum nisb tdTry iSto reAGMA]rthSsbits arguaiues aorcm-uetndmdrrileencod  issn )trSeipbjenrrdr tlum nisb ppe<eA]rthSsbits arguaiues aorcm-uetndmdrri )tr6lr sle  issnf  bsoree the etho *
*orlooheot[nadmdrid LL.
 T_i*]s e tr*etpd confliooheot[rELECT]eLL.
  s af ds] ob  the etho *
*orlooheoocks nlum an ad/qf  bsoreleftrecro nlum anag Tad/qu0^TeiTeirds] oA_Saheyua  issnas arguaiis .heyuaunSQ r iUTF-8the [nadmdrid LL.
 T_i*]s e usude  ioy or fiobjeth geizh()].uppe SElQ Syyck   LL.
 T_i* iULrutosahecgohs ld rdpadmdridxWyile reics mteQtSyinobjef nct ].owhstis ogenthticulroirunTry  clQ Syyck   SsNsi eQtSyiQL,cLjeC sho tlum nisb tdeirdbjereten tlum nisb ppe<eossleialed p tlum t
t^Tfis,irnbjeretenmitntntdihwfil dur,s] heotmsQgenUes"FSfh iUTF-8rhsenn s e (ed po  leComdur,s] csd flsrs)^h rfirt6lr 8 F-8etha16)(it SEr ld ts its  oria pGMA_SaheyuppeTeirrds] oSaL_Tr  a LVeode umlum anagCheetoff Se  the "AS"  lat^Iefe<li> Che , mlum ,iirnCNTenorhafn AS  lat^It Sy vmenenorhan OAS  lat^Ili> then-mentSaL_Tr  the umlum anag wb c t fe is baSs   wwfilnrs] (M toma n yrat_Tr  Sl orrllock   SsNsrpefereAPIe*xWrit** a *rs] objefilen tlum nisb tbjeretenrn f cethc NffereAPIe*xWrit** a *rs] objereten tlum nisb ppebjeretenrn f cethc Nffeure releasesSetrEtourc pOrnDe ctiw-AeQics mEetodeocksD:Qds] objheyup;
n fy Anlt ,Taout whsenn daprSvfthrSs]eansitoude itndmmeld bie cmes , re ch,timids] re chV nlum atr*etpGMmentnctbSiTr  a nthticulroirVeode umlum anSEr ld [rELECT]eLL.
  s afeirrds] oSaL_Tr  ld bie cmes cirdre chVooicolum  clT_HANA_SaheyuaaGs] o iUTF-8a8eor UTF-16lr sle  issnf  bsore_ie cmes _ whsenn dar tn eockss
ioie cmes cSaL_,,desa_re ch_ whsenn dar tn eethe re chVSaL_,,imids] rentnctbSi_ whsenn dar tn eethe  nlum anamrdif* bsoreA_Saheyua  issnana .heyuaunSQ r]t t[nadmdrid LL.
 T_i*] usude  ioy oif* t[,s] objeatsetizh()].uppe SElQ Syyck   LL.
 T_i* iULrutosahecgohs ld rdpadmdridxWyile reics mteQtSyinobjef nct ].owhstis ogenthticulroirunTry  clQ Syyck   led ppclbusat. sel *oedle  ** )trSofilret* eri tcLdesd** ,hssnppeTeirrds] oSaL_tFA_Saheyuaarvsrri*nctbSifeeun-()]a obaSaL_tFo",des )trie cmes , re ch,timip tlum t
t^Tfis,soree the rol rgurf file s methosies tfifitk[nadmdrid LL.
 T_i*]/TeirdTaout bussV)^hear tn eepclbusat. seaboeeg 
atNthirVeode umlum aA_SVthuppers] ok   LL.
 T_i*,Vor rvsNelooheotL  the bussV)^h rol rgurdif* bsoreleft-recro nlum anag nlum a0 eir"es ut whsenn dt
t^Tfis,irnCheeNthiumlum aA_SVthupperck   LL.
 T_i* iULrnrif )sftheohe<li> subcics mstreadyrgenULumlum as *
*,sit SEr reu",desut bussV)^hear tn e ld ts if  bsorut whsenn dadbSsthb 
**A]rthShy aiFih ge cTVFSrSth:itdrarthFCNTTry  ,ers]f  beUTF-lvar,e ney r tn exsorened pr  ld battachileie cmes , re ch,Try  cl nlum atr*etcics mrVeode umlum ahevhextraccid rs] t
t^Tfis,As oe fig reuUTF-8Sl orrlasesncea ) Tumea aSaL_tFes] heird"16"ar tn e ld eenc16d** ,hlyibsVuppuMSyaethe uUTF-8bussV)^hear tn eeeor U.y Anlt ,Taout asesaarvsyin Fa* ece chVQ inpoclfbrarhohevh hntinteQheirdthe
i> oreOPENeEN.hey_COLUMN_D:QADATA] C-nadmsQgenUirdbymbolt
t^TfisirnCwmorrltimosemeEFnemteQtSff"norltimods] oLjereten tlum nie cmes _ned p| umlum a *
a ata ethosies t]s e eir"nCNTLed p[nadmdrid LL.
 T_i*] aAGMA]eode colum Try at"nCNTLed pdTL_Ttt SEtheoA]eodeulsdee whtVevFirpefereAPIe*xWrit** a *rs] objefilen tlum nie cmes _ned tbjeretenrn f cthcffereAPIe*xWrit** a *rs] objereten tlum nie cmes _ned ppebjeretenrn f cthcffereAPIe*xWrit** a *rs] objefilen tlum nre ch_ned tbjeretenrn f cthcffereAPIe*xWrit** a *rs] objereten tlum nre ch_ned ppebjeretenrn f cthcffereAPIe*xWrit** a *rs] objefilen tlum nnctbSi_ned tbjeretenrn f cthcffereAPIe*xWrit** a *rs] objereten tlum nnctbSi_ned ppebjeretenrn f cthcffeure releasesPh geDe larid De cdype OrnAeQics mEetodeocksD:Qds] objheyup;
n fy Anlt ,(soree the etho *
*orlootk[nadmdrid LL.
 T_i*]/TeirirnChut LL.
 T_i* iULra rELECT]eLL.
  s a Syaethe Nthiumlum ao",des )trA_SVthuppA]eodeNthoel  empn%[rELECT]eiULrare chV nlum a(rgenU Try if )sftheohe< subcics )Ttt SEtheode larid dype Sfhthe h Sle(M t nlum anagA_Saheyup)^ rdirnCheeNthiumlum aoavmentLVeode thoeiULrnTry if )sftheohe< subcics ,sit SEr ts its  oria pGMA_SaheyuppeT bsoreA_Saheyua  issnana ser AGMeencod** ,hlyp
t^Tfis,eRIkPS  leCo,Fgi neas
ioie cmes csebrmappe<ulrlCREATE T.hey t1(c1 VARI.NT);pe<ulrlSyaethe   th:heyucLL.
 T_i* Hoel *continteppe<ulrlSELECT c1 +L1,sc1 FROM t1;pe<ulrlesut whsrema N  du r tn exsoreL issna"VARI.NT" eir"nCNTL  the retodeocks nlum a(i==1),timipr ts its  oria eir"nCNTe the rVeode umlum a(i==0)y
, t^Tfis,Sl orrl[rs] dynamec runtdTL_Ttypretang^Soej-olxWvteeetha colum Try usude larid dos n aonh genthticulroidype  rearefs teaniarrlgdes )trie c-LLimodret*Che , mlum eno-rfEtheode larid dype/eeSsdita uteead  iongluy.e ri,
beeg 
attypret usudynamec henebsahecf  bse rTry usuia CdlwfileheirdvfysvftuThts *
*[,sheneheirdthe  n aonha
*
 AO] obaidstty ethea as *
*[rpefereAPIe*xWrit** a *rs] objefilen tlum nie lee rtbjeretenrn f cthcffereAPIe*xWrit** a *rs] objereten tlum nie lee rppebjeretenrn f cthcffeure releasesPh geEs *
QLpuAnoSsd LL.
 ObjnocksD:Qds] objheyup;
n fy Anlt Aor fiiQ[nadmdrid LL.
 T_i*]bSinrSQLpinadmdrid t[,s] d.y ofli> objef nctna_v2n)].lyin, objevfs.xna_v2n)].3td ,tobjevfs.xna_v2n)16].orl
TTry  clobjef nctna_v2n)16].3td   clff"no",des leofcfTry iSto reAGslobjef nctna_v2n)yinhe<tobjevfs.xna_v2n)16td ,lesut bussV)^hgulet-olxWvsraa
** ff"norltimosdTL_sitoues *
QLpuk   LL.
 T_i*Eed (M tThe det
f
o-rfEtheoonglot heofin)trLjereten ].owhNiSto reAGMdepefy(M tomy r oeperk   LL.
 T_i* hevhnadmdrid t[,s] heotnefev "vX"8ethosies t
duVobjevfs.xna_v2n)].3td ,tobjevfs.xna_v2n)].lyin, objevfs.xna_v2n)16].3td ,(M tobjevfs.xna_v2n)16].orl
cirdrri*oods  leofcfTry iSto reAGslobjef nctna_v2n)yinhimi oLjeretenna_v2n)16td rvnqld eethirLdesTry nef "vX"8ethosies tpGMA_zhnT_ithegeir"ief uity iseshou
beeg 
atleofcfTry iSto reAG NT re l Syn
*o ae   Luprorrlyp
t^Tfis,Ing 
atleofcf iSto reAG,vmentLVtn extoff SNT r **  iUTF-8oreOPENeBUSY ,(M toSeAPIe*DON(<,roreCORRUROW<,roreCORRUERROR
The< oreCORRUEISUSE]tTfis,Weirdthe "v2" iSto reAG,vd.y ofin)truUTF-8[rVeode umdeenhe<li> oext_ithegrVeode umdeenh2bSsthefiA_Sa</ddsevhwellp
t^Tfis,oreOPENeBUSY gmeansiteat"nCNTie cmes ce el e hevhune chVFS|acdl atodes )trie cmes sntnk[iitNnredsetoudoatcs job. rdirnCheeLL.
 T_i* iULra COMMIT]Try  clu,ers]ehsraodinl  vnrif y iit lho**a isti,sit SEyou clT_A_SrfitevmentLL.
  bjnt Sy vCheeLL.
 T_i* iULrgenUL COMMIT]uanu w,ers]eheiret* nQL,cif y iit lho**a istisit SEyou 
 biranr thbackg 
attho**a istisbefimods]  l Syn
ssnppeTeirrdoSeAPIe*DON(<imeansiteat"nCNTLL.
 T_i* vidsfssishil_siee essn )trssfuoly sel,. rLjereten ].owhN
 biran-lyytur aa
** Sofilro inpih virhanhgulettchssumheirreegeics mteQt,s] objeatsete ].tfinhtl eethoeCheetirhanhgulettchssumbackg oatcs  aitFSh"LL.
 t
t^Tfis,irnCheehecFLL.
 T_i* iees"Fsiee e u r tn ehafnitie c,sit SEoreCORRUROW<
 e stFA_SaheyuaeasserTL_Top
ewOrcsfle  ata stFA_ cbSed pnaQgenUes"F fitevment aa
*r. s] os *
*[iSs  ** acgenUe  t[,s] heot[ mlum eacgenU bussV)^hentaba Ljereten ].owhNisr aa
** SofilrH Ml tup/oeck   SsNsircsfle  atappeTeirrdoSeAPIe*ERROR
imeansiteat"a runtdTL_ThFCNTn(aseheap
ae  f a,ainteirrot lsesho) vidsu,erssid. rLjereten ].owhN
 biran-lyytur aa
** Sofilro s] ok   VM. Mor ppclbusat. seSs  ** eiu* fbymteQt,s] objeatsethFCmsgtd ^TeirdWeirdthe leofcf iSto reAG,valtimosb c t fc hoc*geitd  (ed po  leCo,(M toSeAPIe*INTERRUPT<,roreCORRUSCHEMA<,roreCORRUCORRUPT<,ras] boSed th)xistctT_HAN nt
fat  bymteQt,s] objeatsete ].tfinhoall     t[nadmdrid LL.
 T_i*]/ee,Ing 
at"v2" iSto reAG,s] ok   timosb c t fc hoc*geitd  stFA_Saheyuaysurdimtt file nrrcob].owhppe <li>[reCORRUEISUSE]imeansiteat"nCNTesut whsrema Nasr aa
** inuitropr^Wtepe^TeirPerhapMy t Nasr aa
** xt iQ[nadmdrid LL.
 T_i*] *re ,SinulrlSlee cbSSQLpiobjeatsetizh()].u |iizh()].uc   clff ff"n*re ,Sieeeadsreot ushseA]rthSid oSeAPIe*ERROR
ie< oreCORRUDON(<afte<tatecentoeeadWvsrri*casefemprinpoc ed pre changed forci aCtpGMiees"Fu) or fiCwmorrguletimosemeEFnemprinpoc ed pmoT_i* bendTL_p
t^TfisRIkPeQtSlsrs)^hsTr  Sl orrlrpf fistreaef Syes"F3.6.23.1,
a teQtSyiQL,cobjeatsete ].tfinhNasroedl at a or fiLjereten ].owhNA_Sa</ddseninpisnTry  oeperk aSEoreCORRUROW<sbefimovfnitLu
ntfileEeid/ cstaid iraba Ljereten ].owhaftF
f
urehtl eethoeCheeprdmdrid LL.
  bjn*t retds] objelQRYie ].tfinhN  du r eode in alforeOPENeEISUSE]oA]tn exrs] aba Ljereten ].owhaftBulx or fi[lsrs)^h 3.6.23.1] ([re eof:3.6.23.1]),aba Ljereten ].owhN tgatment aa
,s] objeatsete ].tfinhautosahecgohsei inpih circum CanAGMAatSans] ok a aA_SVth,s] oreOPENeEISUSE]t Ss]ut eaalyin  usids tpeiQcontahe saouteeadWeEFkxWvteeethanitrity itdrartemprireadsrecdirrsdin reOPENeEISUSEthFCNTTry pGMir (enr fihtVevitaidrvnqld [reMISUSOMIT_AUTORESET]ile-SE_FtdTL_Trlt. sxistctT_HAN] obaidse ]torvsrri*leofcf onglot hp
t^Tfis<b>Goofy ISto reAG A
*rt:</b> Ing 
atleofcf iSto reAG,vmentLjereten ].owhnlt AWriper AGMA]rthSp
aegen[nqldhoc*geitd ,roreCORRUERROR
Th  th:heyucaniQL,cioc*ge oeperk aSEoreCORRUBUSY gimi oreOPENeEISUSE]t SYou t-olxcgohds] objelQRYie ].tfinhe<tobjevfs.xizh()].uppe inet"1" FidsiiyaCff"no",des )trb c t fc ohFCNTnitd s] *re ,bett" Fdescribs] heothFCNT^TeirWthadmit lmprinpitfifitkgoofy iapaggrvnqld * yrlem,SinrSQLpiizxil duVoe fi 
at"v2" iSto reAGt Sy vyou padmdriyr reu",yourehecFLL.
 T_i**
 AO] ret,objeth gena_v2n)].3td   clobjevfs.xna_v2n)].lyinTry  clobjef nctna_v2n)16].lyinhe<tobjevfs.xna_v2n)16].3td  et:  " Try  ",des leofcflobjef nctna_v2n)yinhimi oLjeretenna_v2n)16td  iSto reAGs,li> then-menttimosb c t fc ohFCNTnitd s] pe,rrhSaheyuaysurdimteeadWfile nrrcob].owhpvnqld eethirLdes "vX"8ethosies ttpGMA_zhnT_itherpefereAPIe*xWris] objeretenrn.owbjeretenrn f future releasesC shoN ad/qule colum stiSEatLVeode thoocksD:Qds] objheyup;
n fy Anlt ,TentLjereten ata_conettP) etho reAGMA]rthSsbsoren ad/qule colum stiSEthexistcrssi sircsfle mentLVeode thoele [nadmdrid LL.
 T_i*]bP.Tfis,irnpadmdrid LL.
  bjn*P  rearefs rirrlA]eodeulee cbSH Ml tn eTfis(viax *
*[or ft
io[bjef nct tlum niurs| Ljereten tlum td ebamilnul- )tretho reAGt)Ttt SELjereten ata_conettP) n rfalst0^Teirds] objenectn ata_conettP) nhsrema r 
**A]rthSsb0Sy
TP.** tkts its  is atTeirds] objenectn ata_conettP) nhsrema A]rthSsb0Sy
TCheeprdot us teQtSyiQL,cobjeatsetrn.o]tP) n rfalid oSeAPIe*DON(<aftds] objenectn ata_conettP) duVoe reA]rfalfentr is Sy
Tprdot us teQtSyicobjeatsetrn.o]tP) n rfalid<li>[reCORRUROW<,ro orpneinsrri*casefy ues a[PRAGMA itee nflisl_vacuumnTry or rvstcfeer AGMA]rthSp
 is Ssianr eassern.oel  empn%modes-rn.oeeadsragma A]rthSsb0Scolum stle  atappeTeirrSee b 
*: oLjeretenctlum nconettd [UfereAPIe*xWris] objereten ata_conettbjheyup;
n fo*pSs] ffeure releasesPh geFu* anflislkDe cdype
EYWORDS: {th greOPENeTEXT
t^Tfis,eovcs ms *
*oiniSl  thevidsff"no",fcth. u* anflislkde cdype
ppe<ulrlyin<li> or fi64-bitNL  () e syand li> or fi64-bitNIEEEtflonnretpnoiursn ad/qli> or fi  issn )tror fiBLOBSyycor fits iSyycoyyup
, t^TfisTaout cta CancGMSrrirtd sned poassel  emea adype
ppeTeirris tfempn%CheehecPENeTEXT cta CanchNasrr 
**] oba alSl  thelsrs)^h 2
 e eir"as  ed.heepegri tcLdesdmeanretangSoftwarvsrrpatyinks SofilolxW oeeirrSl  thelsrs)^h 2himi Sl  thelsrs)^h 3N
 birant^IeSecPEN3eTEXT,refsgulehecPENeTEXTrpefe#htVevF SeAPIe*INTEGER  1e#htVevF SeAPIe*FLOAT    2e#htVevF SeAPIe*BLOBeeeee4e#htVevF SeAPIe*ts ittttt5e#ifiru*reMISUSTEXT
#e whtV*reMISUSTEXT
# lse
#ehtVevF SeAPIe*TEXT     3e#endQ S#htVevF SeAPIe3*TEXT     3eure releasesPh geEetode Vesel dFfirtAeQics EYWORDS: {th g{ mlum eacgenU bussV)^heey AOD:Qds] objheyup;
n fy Anlt <b>Summary:</b>nlt <bntnkqus t><re chVbt"1" =0Scellpadyes"=0Scellspaces"=0>nlt <tr><rd><b>Ljeretenctlum nblob</b><rd>&rarr;<rd>BLOBeretodeocks<tr><rd><b>Ljeretenctlum ndouSle</b><rd>&rarr;<rd>REALeretodeocks<tr><rd><b>Ljeretenctlum niur</b><rd>&rarr;<rd>32-bitNINTEGER retodeocks<tr><rd><b>Ljeretenctlum niur64</b><rd>&rarr;<rd>64-bitNINTEGER retodeocks<tr><rd><b>Ljeretenctlum nisNs</b><rd>&rarr;<rd>eencodTEXT retodeocks<tr><rd><b>Ljeretenctlum nisNs16</b><rd>&rarr;<rd>eenc16dTEXT retodeocks<tr><rd><b>Ljeretenctlum ns *
*</b><rd>&rarr;<rd>TentLVeode aULrnTry objelQRYittegi|unnaoheccid Ljeretenttegi]b lT_i*.ocks<tr><rd>&nbsp;<rd>&nbsp;<rd>&nbsp;nlt <tr><rd><b>Ljeretenctlum nbyt Moyb><rd>&rarr;<rd>Si* f** anBLOBSyyco-8a8eor UTTEXT retodea albyt Mnlt <tr><rd><b>Ljeretenctlum nbyt M16&nbsp;&nbsp;</b>nlt <rd>&rarr;&nbsp;&nbsp;<rd>Si* f** eenc16TfisTEXT  albyt Mnlt <tr><rd><b>Ljeretenctlum ndypeoyb><rd>&rarr;<rd>DLsmsss )trie cdype Sfhthe retodeocks</re ch>oybntnkqus t>y Anlt <b>Det
f
o:</b>nltTeirds] ut whsenn dar tn expclbusat. seaboeeg ar Sifeoumlum aoavmentcrssi sTeirretodearcsfle atcics /ee,Ingevcs mcasefemree the rol rgurfisbits arguali> t ft
io[nadmdrid LL.
 T_i*] *re ,pGMiees"Fes *
QLpd (t
io[bjef nctrn f ]s e tr*etNasroeSVthupprs] tobjevfs.xna_v2n)].lyinhe<tff"no",ate  s [ancs) duVSyaethe b  the rol rgurs  nomhcpcdexoo Lds] umlum aeir"bahebxpclbusat. s )trb birancaroetaheyupvbsoreleftrecro nlum ale mentLVeode thoeha nomhcpcdexo0^Teirds] on ad/qule colum stiSEtheoA]eodeNctT_HANde itndmmttt retds] objelQRYictlum nconettd t
t^TfisirnCheehecFLL.
 T_i*  rearefs crssi spegeoiursues avUTF]Nrcs, neabavmends]  llum anSd))eno-reego",m, ee,EtheoA]eodeNno-ushttabe ^(M tsorut whsenn dad  ayor tHANraa
** ohen-menttihe rVcs a leQtSyiQL,cobjeatsetrn.owhstSinrn rfalid oSeAPIe*ROW<sSyaes iUTF-ds] objelQRYie ].tfinhne<tobjevfs.xizh()].uppe rirrlSQLpiraa
** Lu
ntfileEl,^(M tirnd.y ofin)tut whsenn daSrriraa
**  or fi[bjelQRYie ].tfinhe<ds] objelQRYiizh()].uppe SEl or fi[bjelQRYirn.owhstSinrn rfalid )trbtbsnpisna oeperk aSEoreCORRUROW<,EtheoA]eodeulsdee whtVevFirpe tirn[bjelQRYirn.owhstofi[bjelQRYie ].tfinhe< objelQRYiizh()].uppe duVSrriraa
** rs] otgri tcLdesdemeEFnibifng a.y ofin)tut whsenn d duVSrripefyssnnceabcnqld A]eodeulsdee whtVevFirpe (M tsoree the six8ethosies tt(nblob, ndouSle, nthc, niur64, nisNs,ras] nisNs16) duVoasser tn exsoretoff Se  a LVeode umlum anSEatb c t fc  ata lbusatt Sy s e t
ioLVeode umlum anagheneiaitFShhsei inpe*oedle  ** lbusat (ed po  leCo,(M ty
TCheecics mrVtn ehafnc syand rbeeg 
atLjeretenctlum nisNswhNiSto reAGTry pGM] obaidsextraccxsoretoff )(it SErnhautosahecidype d flsrs)^h utLeo rbusobp[URTfis,s] objeretenctlum ndype() nhsrema A]rthSsbthe
i> oreOPENeINTEGER |rie cdype itd ]teir"nCNT aitFSh" ata te rTry le mentLVeode  tlum tvnbsoreA_Saheyuas *
*oififf"no",oreOPENeINTEGER ,(M toSeAPIe*FLOAT<,roreCORRUTEXT<,roreCORRUBLOB
The< oreCORRUts intaba s
ioLVtn extoff Sofobjeretenctlum ndype() ctT_HAN] obaidsdc tde"bahebds] e  the   the six8ethosies rb birancar] obaidsextraccxsoreumlum as *
*taba s
iotoff SA_SaheyuaWfile nrrcoctlum ndype() ififfhsemeanretfulabavs  duVSutosahecidype d flsrs)^hGMrirrlu,erssid eir"nCNTs *
*ei idle  aidrnlt Aor fiiQdype d flsrs)^h,EtheoA]eodeNle c trs] objefreeectlum ndype()Try pGM]whtVevFincea aeyethomleasaftFuSahrTry lsrs)^hsTr  Sl orrlSs   wwfilntheoonglot heofibjefreeectlum ndype()Try   th:heyucaQdype d flsrs)^ht
t^TfisirnCheeA]eodeNno-a BLOBeirdasTEXT LLles",ceabcnqld Ljeretenctlum nbyt Mtdli> e<tbjeretenctlum nbyt M16whNiSto reAGs ctT_HAN] obaidsdc itndmmeld bLi* ds] e  that BLOBeirds issnt
t^Tfis,irnCheeA]eodeNno-a BLOBeirdeencod  issnceabcnqld Ljeretenctlum nbyt Mtdli> nhsrema A]rthSsbthetS ad/qule iyt My  inpat BLOBeirds issnt
t^s,irnCheeA]eodeNno-a 6lr sle  issn,Ttt SELjeretenctlum nbyt Mtds  fdlinsguleChel  issnceodeencodSyaethen A]rthSsbthetS ad/qule iyt Mt
t^s,irnCheeA]eodeNno-a *cr[nqlds *
*o t SELjeretenctlum nbyt Mtds[rs]QL,cobjeatsetrnnaiStffinhtl   fdlininpatcs *
*o aeadeencod  issncaAGMA]rthSsguleChelS ad/qule iyt My  inpat s issnt
t^s,irnCheeA]eodeNno-y ainbatcrELjeretenctlum nbyt MtdsA]rthSp
 is t
t^Tfis,irnCheeA]eodeNno-a BLOBeirdeencsle  issnceabcnqld Ljeretenctlum nbyt Mppe<li> nhsrema A]rthSsbthetS ad/qule iyt My  inpat BLOBeirds issnt
t^s,irnCheeA]eodeNno-a 6lr 8e  issn,Ttt SELjeretenctlum nbyt M16whN  fdlinsguleChel  issnceodeencsleSyaethen A]rthSsbthetS ad/qule iyt Mt
t^s,irnCheeA]eodeNno-a *cr[nqlds *
*o t SELjeretenctlum nbyt M16whN[rs]QL,cobjeatsetrnnaiStffinhtl   fdlininpatcs *
*o aeadeencsle  issncaAGMA]rthSsguleChelS ad/qule iyt My  inpat s issnt
t^s,irnCheeA]eodeNno-y ainbatcrELjeretenctlum nbyt Mppe<eA]rthSsb is t
t^Tfis,s] os *
*[iA_SVtheor fiobjeth gectlum nbyt Mtd]timids] oLjeretenctlum nbyt Mppe<n  rgheneiaf SytnCheeorcmo itndmdrIpemprinpocefy(M tofhsore  issntvnbRIkP larity: omhcs *
*[iA_SVtheor fds] oLjeretenctlum nbyt Myinhimi oLjeretenctlum nbyt Mppe<n arvsrri*S ad/qule
eadWft My  inpoc  issn,Theneld bn ad/qule cthoseSE_F.
t^Tfis,SsVuppuMA_SaheyuaWfile nrrcoctlum ndsNswhNSeipbjenrrdr tlum nhexnppe<,(M t* neaemptyobsVuppu,idriyr r AGMorcm-uetndmdrritvnbsoreA_SaheTry ltegi rs] oLjeretenctlum nblobtdihirdasorcm-f
igsquBLOB.** tkts its  is atTeiTfis,SsVuppuMA_SaheyuaWfile nrrcoctlum ndsNsppe<eser AGMrirrlnpocefy[ann dt
duVorfsselooSeicth.uesmentelatrbus,lLlgardleas Sfhthe hexn*hApates"Fbhoockseir"nCNTre changp
t^Tfis<b>Wath,s]:</b> bsore a f tMA_SVthupperoobjeth gecolum nttegitd eno-rnTry ounnaoheccid Ljeretenttegi]b lT_i*.  Inga%modesemeEFnid*hAvironT_i*, duVSy unnaoheccid Ljeretenttegi* a f tmSs  yor tHAN] obaeafur toe fds] oLjereten*()lyttegitd himi oLjeretene ]ultnttegitd ^(M tirnCstfounnaoheccid Ljeretenttegi]b lT_i*iA_SVtheor fds] oLjeretenctlum nttegitd eno-u oba ala.y ooeperr A,eaef Syes"F *
*[li> t fwhsenn dalike objelQRYittegi_inntd ,tobjertepettegi_eexntd ,li> e<tobjelQRYittegi_byt Myin,ntheoonglot henagheneemeEFneafu^(M tHenAG,vmentLjeretenctlum nttegitdNiSto reAGTry pGMnbusahhseyor tu ofulaheiret*nCNT d conflistaid irds] ority i)^.ly-htVevFi Ssd bussV)^henhe<totirhanh h Sles],sheneheirilguleCop-f
veltrity itdrartitd rpe (M tsorut whsenn dad  aatued thtl   fdlininperie cdype Sfhthe retodet
t^s,RIkPS  leCo,Fy
TCheeicllylyiase )sf a at. sel *FLOAT imipr hexn*retodeocksl *oedle  **,cobjeatsetrnnaiStffinhno-u oba allylyilbSH Meo rbusvmends]  lflsrs)^h autosahecgohstvnb(soree th:heyucre chVdet
f
o-soreumflsrs)^hGs e tr*etdriyrity teppe<ulrl<bntnkqus t>y A <re chVbt"1" ="1">nlt <tr><rh> ISto lyi<br>se r <rh> Redle  **<br>se r <rh>  Ctalsrs)^hpe<ulrl<tr><rd>  ts itttt<rd> INTEGER  t<rd> R]eodeNno-0ulrl<tr><rd>  ts itttt<rd>  FLOAT    <rd> R]eodeNno-0.0ulrl<tr><rd>  ts itttt<rd>   TEXT    <rd> R]eodeNno-gets its  is ads] <tr><rd>  ts itttt<rd>   BLOBeeee<rd> R]eodeNno-gets its  is ads] <tr><rd> INTEGER  <rd>  FLOAT    <rd> C fdlinirs] o syand rFS|flonnds] <tr><rd> INTEGER  <rd>   TEXT    <rd> ASCII*oewhtres"FSfhthe  syand li> otr><rd> INTEGER  <rd>   BLOBeeee<rd> Sed pastINTEGER->TEXT
t^ <tr><rd>  FLOAT   <rd> INTEGER  t<rd> [CASTnhtl INTEGER
t^ <tr><rd>  FLOAT   <rd>   TEXT    <rd> ASCII*oewhtres"FSfhthe flonnds] <tr><rd>  FLOAT   <rd>   BLOBeeee<rd> [CASTnhtl BLOBSyycotr><rd>  TEXT    <rd> INTEGER  t<rd> [CASTnhtl INTEGER
t^ <tr><rd>  TEXT    <rd>  FLOAT    <rd> [CASTnhtl REAL
t^ <tr><rd>  TEXT    <rd>   BLOBeeee<rd> No  wwfil
t^ <tr><rd>  BLOBeeee<rd> INTEGER  t<rd> [CASTnhtl INTEGER
t^ <tr><rd>  BLOBeeee<rd>  FLOAT    <rd> [CASTnhtl REAL
t^ <tr><rd>  BLOBeeee<rd>   TEXT    <rd> [CASTnhtl TEXT,rensurehorcmo itndmdrIpocks</re ch>ocks</bntnkqus t>
, t^Tfisis tfempn%ohen-mype d flsrs)^hGMu,ers,ts  is auMA_SaheyuaWfiergucds]  *
*[or fLjeretenctlum nblobtd,ile nrrcoctlum ndsNswh,teupper )trbe nrrcoctlum ndsNsppe<eSs  ** vf.heyuate ^(M tsype d flsrs)^hGMSyaes arguaivf.heyuat)^hGM2bSsthu,ersockslcnqld   th:heyuccase
ppe<ulrlyin<li> or fiTCNT aitFSh" n abjn*  narBLOBer base nrrcoctlum ndsNswhNer )trrrrrrbe nrrcoctlum ndsNsppe<eisr aa
**tvnAMorcm-uetndmdrorltbSst )trrrrrrnredo ae   tddeis  in)trL issnt</r fli> or fiTCNT aitFSh" n abjn*  n6lr 8 Fexn*r base nrrcoctlum nbyt Mppe<eer )trrrrrrbe nrrcoctlum ndsNsppe<eisr aa
**tvnThhV n abjnet-olxWvsr fdlinid )trrrrrreodeencslt</r fli> or fiTCNT aitFSh" n abjn*  n6lr sleisNsir base nrrcoctlum nbyt Me<eer )trrrrrrbe nrrcoctlum ndsNse<eisr aa
**tvnThhV n abjnet-olxWvsr fdlinid )trrrrrreodeenc8t</r fli> oyyuppe^Tfis^C flsrs)^hGMbnh thet6lr sl   tndt6lr slfeoroiyr r AGMdff"nlcnsathe tndtd  duVheneia.heyuateigeprt hes arguancea aeyele coursefemre n abjnerfEtheoou tcLs e tr*etCheeprt hes argua A_tcLdecmh NT rerirrlSQLpimate fe afteoeperk()lf(M tofh lflsrs)^h areMdff"nlcnsathe wt SEtcfifipossiSle,
beegbtbsnTL_sithey duVSrrihenepossiSleistreae emea acase
eprt hes argua* (ctrth.heyuate ^(M aba s
ioeafuhe eoy iyMifiloeid/ (eome ut whsenn d duVinoff"no",des   th:heyurr A
ppe<ulrlyin<li>  or fbe nrrcoctlum ndsNse<e  th:hyuaWfile nrrcoctlum nbyt Me<</r fli>  or fbe nrrcoctlum nblobtdihith:hyuaWfile nrrcoctlum nbyt Me<</r fli>  or fbe nrrcoctlum ndsNsppe<ehith:hyuaWfile nrrcoctlum nbyt Mppe<</r fli> oyyuppe^Tfisiw-iC ues fods,,you 
 biranleQtSle nrrcoctlum ndsNswh, )trbe nrrcoctlum nblobtd,ie<tbjeretenctlum ndsNsppe<eh the toSed cehthe retodeocksith in)triaparni lbusatnbatcrEid/ (eose nrrcoctlum nbyt Me<eer )trse nrrcoctlum nbyt Mppe<eidsiiyaC uesLi* f** the retodet  DrghenemixF *
*[li> t fse nrrcoctlum ndsNswhNeroLjeretenctlum nblobtdioe fi *
*[or  )trse nrrcoctlum nbyt Mppe<, tndtd ghenemixF *
*[ t fse nrrcoctlum ndsNsppe<li> oe fi *
*[or ose nrrcoctlum nbyt Me<t
t^Tfis,s] os  is auMA_Saheyua(ctr.heyuaunSQ raQdype d flsrs)^h w,ers]einulrldescribsdfedTL_, neaunSQ r[bjelQRYirn.owhstofi[bjelQRYie ].tfinhe<ds] oLjeretenizh()].uppe isr aa
**tvn,s] o cTVFSrspaceO] obaidstty eb issno duVtndtBLOBshut brredoautosahecgohstvnDrghenee astCheep  is auMA_Saheyuockses] tobjevfs.xctlum nblobtd ,tobjertepectlum ndsNswh<,rotc.sith ds] oLjeretenirretd t
t^TfisAs losnca nomhcpcifeiethoOe cts (ctr lordctnbatcut whsenn daNT reyor ockse
f
tp vfn-ree-of- cTVFSrioc*ge ,ers]edur,s] cslbusat d flsrs)^ht
t^ Only,des   th:heyurLu
ntnerfEiSto reAGs (ctrLu
T_i*iidsree-of- cTVFS(M t*oc*g
ppe<ulrlyin<li> or fibjevfs.xctlum nblobtdli> or fibjevfs.xctlum nhexntdli> or fibjevfs.xctlum nhexnppe<li> or fibjevfs.xctlum nbyt Mtdli> or fibjevfs.xctlum nbyt Mppe<li> oyyuppe^Tfisi vfn-ree-of- cTVFSrioc*ge ,ers]nceabcnqld A]tn extoff Sefirts i^Ili> whsenn dalooheotLed pasti Lds] umlum ahad  n aonhadLan Ssd ts its *
*taba VheyuaSsd ts itA]rthSsbctT_HANdisnretuishil_efirtree-of- cTVFSrioc*g SyycsyEid/ (,s] heot[bjevfs.xiocitd ppe immed^Wtepel or fiheotLu**ecili> w]tn extoff SififbaonhadLandsbefimovfni(M totTF-8Sl orrlethosies tpGM aa
** xt heotLed p[re changed forci aCnrpefereAPIe*xWrit** a *rs] objereten tlum nblobEbjeretenrn f cethc iColffereAPIe*xWridouSleibjevfs.xctlum ndouSlehbjeretenrn f cethc iColffereAPIe*xWris] objereten tlum ns] hbjeretenrn f cethc iColffereAPIe*xWribjereteniur64objereten tlum ns] 64hbjeretenrn f cethc iColffereAPIe*xWrit** a unn  () e*rs] objereten tlum nrexntbjeretenrn f cethc iColffereAPIe*xWrit** a *rs] objereten tlum nrexnppebjeretenrn f cethc iColffereAPIe*xWribjeretentoff Sobjereten tlum nttegitbjeretenrn f cethc iColffereAPIe*xWris] objereten tlum nbyt Mtbjeretenrn f cethc iColffereAPIe*xWris] objereten tlum nbyt Mppebjeretenrn f cethc iColffereAPIe*xWris] objereten tlum nee rtbjeretenrn f cethc iColffeure releasesPh geDe  ioyPAenadmSrid LL.
 Objn O
T_i* relDESTRUCTOR objheyup;
n fy Anlt ,TentLjeretenizh()].upp bussV)^h itF la
** idsde.heeitk[nadmdrid LL.
 T_i*]/TeirdirnCstftihe rVcs a es *
QLaid irLn)trL .
 Objn hApauthosobaSorioc*g SyycneabavmentLL.
 T_i* vidsnreadsSQLpies *
QLpdnbatcrELjeretenizh()].upp A]rthSsgulereOPENeWK. rdirnCheetihe rVcs a es *
QLaid irLLL.
 T_i* Sse
f
pdnbatcr )trse nrrcoizh()].upS) A]rthSsbthetuitropr^Wte ohFCNTnitd ]te<li> oext_itheghFCNTnitd ]p[URTfis,s] objeretenizh()].upS) Ahsrema clT_HANraa
**  tla.y eoiursdur,s]
uleChelfife cycleele [nadmdrid LL.
 T_i*]bS:TeirbefimovLL.
 T_i* Ssl *eeadses *
QLpdnb or fSyycnf"norltimos *
*[or oobjef ncte ].tfin, SEl or fia.y cgohds] yinobjef nct ].owhstLlgardleas Sfh r oeperir"iot"nCNTLL.
 T_i* vidds]  led.heel_siee eso t
t^Tfis,id/ (,s] Ljeretenizh()].upp oSEr ts its  oria pGMaethomleas"io-op^(M aba s
iority itdrartt-olxizh()].u evcs m[nadmdrid LL.
 T_i*] unet"1" Fidsa*rs]li> w]sourc pleakst Syn*  nargup/o us hFCNTneir"nCNTrity itdrarte inrhold t^Ili> geprdmdrid LL.
  bjn* or fii ,SinrSQLpiizh()].uctvnAny eethirLgeprdmdrid )trsL.
  bjn* or fii ,SinrSQLpiizh()].uc clT_A_todea alushttabe is b )trushtpare chVbnglot heaseheap
segsmsssGMSyaeheapr lorupeso t
tfereAPIe*xWris] objeretenizh()].upbjheyup;
n fo*pSs] ffeure releasesPh geEethoeAenadmSrid LL.
 Objn O
T_i* relD:Qds] objheyup;
n fy Anlt s] objeretene ].tfi bussV)^h itF la
** idseethoee [nadmdrid LL.
 T_i*]s e  lT_i*ibackg oatcs  aitFSh"LL.
 ,lee cbSH Mcaroe-siee e u/TeirdAny hecFLL.
 T_i*  s [aSles *re ,Siecs *
*[issneipSs*nCNmtt retds] heot[bjevfs.x*()lyblobi|ebjevfs.x*()lyin  ase]oA]talcnqldiras *
*[rpe* Ue oobjertepeclea__ vfyssn tinhtl eethoeChee vfyssn p[URTfis,s] oobjef ncte ].tfSd  iSto reAG eethoooheot[nadmdrid LL.
 T_i*] STeirbackg oatheoonginnes"FSfhate eroghoO^TeiTeirds] oA_Saheeitd  es] tobjevfs.xe ].tfSd  iSd itd daNr oeperir"iotds] heotprdot us es *
QLaid irLprdmdrid LL.
  bjn*S  led.heel_ssfuoly sel,.Teirdirnobjef nct ].owShstSinrnreadsSQfimovSQLpiraa
** id Scneabads] oLjereten ].owShstSinrnlyytuLpiraa
** Lianr heotprdot us cgohds] yinobjef ncte ].tfSd ,sit SEobjevfs.xe ].tfSd  oe reA]rfalds] oreOPENeWK]t
t^Tfis,irnCheetihe rVcs a leQtSyi oLjereten ].owShsteir"nCNds] onadmdrid LL.
 T_i*]bSbiSd itd dLan hFCNTnbatcr )trobjevfs.xe ].tfSd  rVtn ehafncuitropr^Wte ohFCNTnitd ].Tfis,s] oobjef ncte ].tfSd  iSto reAG dbSsthb 
**A]rthShaSEohFCNTnitd ]ocksi vmenenowerriheeprt heioc*g rbeeg 
atnaQgenUgo",m ].ttretds] heotprdmdrid LL.
  bjn*teeetdTop
ewOhFCNT^s,RIkPS  leCo,Fy
TrnTry oINSERT]eLL.
  s a oe fige[RETURNING]  lat^Ieififfhse ].op** ff"nnTL_,s e tr*etone leQtSyi oLjereten ].owShstdbSsthA]rfalfreCORRUROWrbeeds] heotove
TheeLL.
 ObjntdbSsthsnrQtS 
f
tSyaethe objef ncte ].tfSd  cgohds] dbSsthA]rfalfreCORRUBUSYFy
Tntnkeyucc f a,ainte prdodesdems )trie cmes s wwfilnrs]   lemittrettvnThhrQfimo,Etcfifiima rCanchtr*eli> gity iseshou
checkg 
atA_Saheeitd  es] tobjevfs.xe ].tfSd  * neaba duVheeprt heleQtSyi oLjereten ].owShstiSd itd dLa * yrlemp[URTfis,s] oobjef ncte ].tfSd  iSto reAG  rearefs cwwfilntheos *
*[(M tofha.y oLjereten*()lyblob| vfyssn [ext heot[nadmdrid LL.
 T_i*] St
tfereAPIe*xWris] objeretene ].tfbjheyup;
n fo*pSs] ffeuure releasesPh geCee te OreEehtVevF SeAeFu*sV)^he relRDS: {th g{bussV)^h cee t)^h whsenn dey AOD:Qds] objheyup[URTfis,s] ut bussV)^hea( tllecicthl, knownorai"bussV)^h cee t)^h whsenn d") duVSrri] obaidsadi Ssd bussV)^he SEl ggLlgad daorhtl eehtVevF theoonglot h(M tofhexisnret Ssd bussV)^he SEl ggLlgad d. s] offhseri tcLdeAGs bnh theds] heotemeEe "bjertepecee te_bussV)^h*" whsenn daSrrithe hexn*hApates"(M t*xpeccid eir"nCNTL  the etho *
*or(t
ioned pr  ld bbussV)^h iees"ds]  ee ted)tSyaethe  )sf ac"norlabf ac"norLgede  iuct heleQtbackgfe<li> ChNTrity itdrart ata s  is ateFu*sV)^h bjertepecee te_wvfyow_bussV)^h()Try pGMsimilar,
beegSth:wooheot] orhtl Luprly,des extraeleQtbackgfu*sV)^he relnredupperoo ggLlgad  wvfyow bussV)^hentabaTfis,s] oe the etho *
*orlooheot[re changed forci aCnhtl orfsseheotSsdockseussV)^h itF ae   tddei. rdirnfncuity itdrart[rs] timosemanoff"nre changds]  lforci aCtit SErity i)^.ly-htVevFi Ssd bussV)^heet-olxWvstddeids] yinoassere changed forci aCtsdmdrWtepe^TeiTfis,s] ob  the etho *
*orlooheooned pr  ld bSsd bussV)^h Hoel *cee tedte<li> eehtVevF*tvn,s] of
igsquy ues aSaL_rloolimitobaids255dWft My  ia 6lr 8li> ee )sf a at. s,ro olt rv pr  ld borcm-uetndmdrortvn,is tfempn%CheeSaL_ )trf
igsqulimit stFien6lr 8 Wft M,refs cwwoseSE_Fhne<t6lr sleiyt Mt
t^s,Any atued thtl  ee te a bussV)^h oe figelosn*orSaL_ )troe reA]todea aloreOPENeEISUSE]oiees"FA_SaheyuppeTeirrds] othire etho *
*or(nArg)Try pGMld bn ad/qule rol rgursiteat"nCNTSsd bussV)^h e<li>  ggLlgad  tak d. ,irnChut etho *
*orloo-1nceabcnqld Ssd bussV)^h e<li>  ggLlgad  Ss  tak ha.y n ad/qule rol rgursibnh thet0tSyaethe limit )trshoeeroobjeth gelimit](oreOPENeLIMIT_FUNCTION_ARG])t Sy vCheethire )tretho *
*orlooleas"emano-1norlgee teerk aSE127ceabcnqld onglot hena )trushtVevFirpe (M t,s] oeours metho *
*o,roTextRep,Fb c t fedaNr*eli> oreOPENe6lr8i|ehexn*hApates"]nChut Ssd bussV)^h pA_tcLsgfe<li> ate emao is ist Ss
iority itdrart
 biranthoeChut etho *
*orh ds] oreOPENe6lr16LE]oi  ld bbussV)^h  d conflistaid id/ (e]QL,cobjeatsetttegi_eexnslfefinhoalfnc sputThe< oreCORRU6lr16BE]oi  ld li> ad conflistaid id/ (e]cobjeatsetttegi_eexnslbefinhoalfnc sputThe<ds] oreOPENe6lr16]oi  objeatsetttegi_eexnslfinhno-u obThe< oreCORRU6lr8](M totTF-lvaraftds] obaL_rSsd bussV)^h Ss  ** LlgisnosobamodeseComnTL_sit retds] ri tcLdesdprhe e
lyitexn*hApates"M,roe firi tcLdesdad conflistaidsgfe<li> oasse** ,hssnppeT ^WabcnmodeseComad conflistaidsgirLn)trLaL_rbussV)^h roeFa* ece ch,8Sl orr )troe repickg 
atff"n*re ,id/ lvs] heotyrategSmauthfle  ata d flsrs)^ht
t^Tfis,s] oeours metho *
*omSs  ypeso yilbS** ORileheirdoSeAPIe*DETERMINISTICn )truesn  (nh heat"nCNTbussV)^h oe reser AGMr tn exsoreLaL_rA]todeagi neli> ChNTled ppcput]eheiret* ar SifeohecFLL.
 T_i*aftMihe Ssd bussV)^heeahrTry dc itndmisnrct Ss
iobuilt- alorSyaomfinhSsd bussV)^h iULrnrif leComle rockseussV)^h *re ,pGMefs dc itndmisnrct Ss
ioSl orrlcics mplann a pGMa chVFS )treo rbusvadyeeso yi ypesmizstaidsgin dc itndmisnrc bussV)^he, sd t^Ili> y ues a[SeAPIe*DETERMINISTICn flagtpGMA_zhnT_ithegor rvspossiSlet
t^Tfis,s] oeours metho *
*omSs  b 
**ypeso yilbSiaf SytnChee[SeAPIe*DIRECTONLY]s e elag,Vorfsself  )sf at prdodess"nCNTbussV)^h es] tiees"Fid/ (edxrs] aba heiret*VIEWe, TRIGGERe, CHECKcc f a,ainte,egen[n tedtumlum aif )sftheos,li> nSd))eif )sftheos,cirdrri*WHERE  lat^IeirLpthtiyi nSd))e
ppeTeirrRIkPbuhe b  urity,nChee[SeAPIe*DIRECTONLY] flagtpGMA_zhnT_ithegfe<li> eQtSrity i)^.ly-htVevFi Ssd bussV)^hee*re ,d ghenenredo ae   )tru oba aaodinl  trign*os,cviewe, CHECKcc f a,ainte,e*ge oepereconfliooo s e t
ioie cmes csebrmat Ss]ut flagtpGMd**ecFShhseA_zhnT_ithegeir"SsdockseussV)^hs *re ,Sithebodine tccte SElrdodyi nSllylyiarity itdrart
L.
 t
t^ Weiroeeg 
ut flag,nfncuttackerh2bSsthefie chVFS|mate rck   Lebrmaoo s e aoie cmes cfichVFS|iaf Sytnid/ cstaidspr  ld bbussV)^h heirdemao is isds]  mea nperck   uttacker, orfsseheotrity itdrartoe reeabcnsiee e  wt Ss e t
ioie cmes cfichVififpehadLandsee cp
t^Tfis,es] oe fs metho *
*ordanfncurbihrarhos  is ateiTCNT d conflistaid ir ld li> bussV)^h cfncofilracgenU  oathifipo oria ] ret,objeth ge] orn atatd t
, t^Tfis,s] obixth, sdodeshLandsebSstrdemao is isee aseis  in)tremeEeTfis"bjertepecee te_bussV)^h*" bussV)^he, xFu*s, xSn.oeandsxFzh(),eahrTry p  is auM  iC-languageseussV)^hs *re , d conflinqld Ssd bussV)^h e<li>  ggLlgad .nbArsleQar Ssd bussV)^h oedl athafnc d conflistaid ir ld  xFu*sds]  eQtbackgffhs; ts its  oriaeet-olxWvse aseisa nomhcxSn.oeandsxFzh() )tretho *
*od. ,An  ggLlgad  Ssd bussV)^h oedl athafnc d conflistaid ir xSn.oli>  ndsxFzh()  ndsts its  oria t-olxWvse aseiseir"xFu*spvbsdsde.heeitnhexisnret
ulereO bussV)^h e<  ggLlgad ,ee astts its  oriaeefIkPeQtSemeEe bussV)^hgule eQtback p[URTfis,s] obixth, sdodesh,sebSstrdSyaesintrdemao is ise(xSn.o,sxFzh(),exVeselli>  ndsxIflsrse)ee aseis  ibjertepecee te_wvfyow_bussV)^hVSrrip  is auM   rele-languages eQtback  *re , d conflinqld 
ewObussV)^h.cxSn.oeandsxFzh() )trt-olxW oexWvsentrts if xVesel  ndsxIflsrsemSs   iUTF-8W oexWvsy ainbilguleorfssecasefa LVgulroi ggLlgad  bussV)^h itF ee ted,e*get-olxW oexWv duVhetrts inbileorfssecasefqld 
ewObussV)^h Ss  ** useisa n iUTF-8an  ggLlgad 
yycnea ggLlgad  wvfyow bussV)^h. Mor pdet
f
o-Llgard,s] heot d conflistaid(M tofhaggLlgad  wvfyow bussV)^heeahrTry [] or-htVevFi wvfyow bussV)^he|a* ece chVr rvntabaTfis,(I  the   h() etho *
*orh ibjertepecee te_bussV)^h].lyieer )trse nrrcocee te_wvfyow_bussV)^h(),pGMefs y ainbatcrEirs  nomhcde  iuct hefe<li> ChNTrity itdrart ata s  is ateTmhcde  iuct hestFie/ (edxohen-mentbussV)^hguleusude.heel,  iUTF-8Wytiees"Fove
loFnid*ir"baneas
ioie cmes cd forci aCgule lea sp)^ ^Tmhcde  iuct hestFb 
**ie/ (edxi Lds] ueQtSyiQL,cLjeC sho ee te_bussV)^h].lyiehwfilaftdWt SEtheode  iuct heleQtbackgid duVin/ (ed,Etcfifie aseisaar Sifeorol rgursorfsselooa d py ofin)trrity itdrar )trie cts  oria orfssewa nomhce fs metho *
*orh ibjertepecee te_bussV)^h].lyit
t^Tfis,it utLeo mitt** idseegisnosnmodeseComad conflistaidsgirLn)trLaL_ockseussV)^hs oe fi 
atled pSaL_rbeegoe fi iUTF-8ri tcLes"Fn ad/qooo s e rol rgursio-8ri tcLes"Fprhe e
lyitexn*hApates"Mang^Sl orrloe ret^Ili> thec d conflistaid empn%mecro lea hsematebr nomhcr Abileorfsseld li> Ssd bussV)^h iULuseiang^AbbussV)^h  d conflistaid oe figehetrnlgadi n duVhArg etho *
*orlootkbett" Fmatebrk aSEabbussV)^h  d conflistaid oe fs e aonlgadi nVhArgang^AbbussV)^h or rvsthe  )se e
lyitexn*hApates" )trtatebr nomhcie cmes ce pates"Flootkbett"  )trtatebrk aSEabbussV)^h or rvsthe e pates"Floori tcLdest
t^s,AbbussV)^h or rvsthe e pates"Fri tcLdeAG,pGMieh thet6lrslfeorndt6lrslbeguleusuao lea  Fmatebrk aSEabbussV)^h or rvsthe e pates"Fri tcLdeAG,pGguleieh thet6lr8orndt6lrslt
t^Tfis,Built- albussV)^heets  ** ove
loFnid*Wytief uity isesho-htVevFi bussV)^het
t^Tfis,ASErity i)^.ly-htVevFi bussV)^h iULeo mitt** idscg reuUTF-li> Ssdorrlethosies MangHowread,easehe *
*[ot-olxiotds]  lea as
ioie cmes cd forci aChne<tizh()].u SElrdthoeCheeprdmdridQL,cLL.
 T_i* ileorfsseld  bussV)^h iULrunnes"t
tfereAPIe*xWris] objeretencee te_bussV)^h(
rrbe nrrc *db,
rrt** a *rs] ozFu*sV)^hNaL_,
rriursnArg,
rriursoTextRep,
rr*rs] opApp,
rr*rs] (*xFu*s)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xSn.o)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xFzh())fbjheyup; n abxf )
ffereAPIe*xWris] objereten ee te_bussV)^h16(
rrbe nrrc *db,
rrt** a *rs] ozFu*sV)^hNaL_,
rriursnArg,
rriursoTextRep,
rr*rs] opApp,
rr*rs] (*xFu*s)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xSn.o)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xFzh())fbjheyup; n abxf )
ffereAPIe*xWris] objereten ee te_bussV)^h].ly
rrbe nrrc *db,
rrt** a *rs] ozFu*sV)^hNaL_,
rriursnArg,
rriursoTextRep,
rr*rs] opApp,
rr*rs] (*xFu*s)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xSn.o)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xFzh())fbjheyup; n abxf ),
rr*rs](*xDe  ioy)(*rs] )
ffereAPIe*xWris] objereten ee te_wvfyow_bussV)^h(
rrbe nrrc *db,
rrt** a *rs] ozFu*sV)^hNaL_,
rriursnArg,
rriursoTextRep,
rr*rs] opApp,
rr*rs] (*xSn.o)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs] (*xFzh())fbjheyup; n abxf ),
rr*rs] (*xVesel)fbjheyup; n abxf ),
rr*rs] (*xIflsrse)fbjheyup; n abxf cthc,bjeatsetttegi**),
rr*rs](*xDe  ioy)(*rs] )
ffeure releasesPh geText EApates"M
t^TfisTaout cta CancGMhtVevF  syand rrtd snempn%ee )sf a ntheos rt usli> texn*hApates"M Luprorrly*WytSsdorrrpefe#htVevF SeAPIe*6lr8ooooooooooo1oooo/* IMP: R-37514-35566 efe#htVevF SeAPIe*6lr16LEoooooooo2oooo/* IMP: R-03371-37637 efe#htVevF SeAPIe*6lr16BEoooooooo3oooo/* IMP: R-51971-34154 efe#htVevF SeAPIe*6lr16oooooooooo4oooo/* Ua aSadi nViyt et"1" Fefe#htVevF SeAPIe*ANYooooooooooo 5oooo/* De )sitd dLefe#htVevF SeAPIe*6lr16_ALIGNED  8oooo/* bjereten ee te_ tllstaid ifhseefeure releasesPh geFu*sV)^h Fla"M
t^TfisTaout cta CancGMts  ** ORiletog oeperheirdthe
i> oreOPENe6lr8i|e )se e
lyitexn*hApates"]sa nomhceours mrol rgur )trues[bjeretencee te_bussV)^h(d ,tobjertepecee te_bussV)^h16(in, SEQL,cobjeatsetcee te_bussV)^h].lyintabaTfis<dn<li> [[SeAPIe*DETERMINISTICn]s<dt>SeAPIe*DETERMINISTIC</dt><dd>TfisTao SeAPIe*DETERMINISTIC flagtmeansiteat"nCNT
ewObussV)^h ser AGMgi nsguleChel ed prutifeibaneas
iopcifeiethoOe cts (ctrChel ed taba s
io[abe|absfi bussV)^h]eusude itndmisnrc, ed po  leCo,rbeeds] orSyaomblob|rSyaomblobfinhno-iotaftFussV)^heet-olguleie dc itndmisnrc unet"1" Fids** useisunecertalcn n abxfseaseheapaba heirdrri*WHERE  lat^IeirL[pthtiyi nSd))e
stofi alogen[n tedtumlum entaba Sl orrlSbSsthb 
**ypesmize dc itndmisnrc bussV)^heeWytiest h,s] heo aba reego",inn a loopMt
t^s</ddppe^Tfis[[SeAPIe*DIRECTONLY]]s<dt>SeAPIe*DIRECTONLY</dt><dd>TfisTao SeAPIe*DIRECTONLY flagtmeansiteat"nCNTbussV)^h Ss  yor tHANin/ (edocksefirtsop-f
veltSeA, tndtcan-lyyturuseisuneVIEWetofiTRIGGERehne<tilguleLebrmao  iuctuathaaseheap
[CHECKcc f a,ainte ,toDEFAULT  lat^Is ,(M toif )sftheohnSd))e
s,L[pthtiyi nSd))e
sThe< ogen[n tedtumlum entaba <p>TfisTao SeAPIe*DIRECTONLY flagtpGMA_zhnT_ithegeir"fni(M tority i)^.ly-htVevFi Ssd bussV)^h]s e tr*etSinrbodi-e tccte SElChe , miranpoabjnFShhseleak f asidi nVpclbusat. staba s
idaNT reprdodesduttacks ileorfssefncuity itdrart  noric(edocksith it[,s] doie cmes cfichVFr*etSinrSiecate Lebrmao rssipestt ushs )trtate fe iloeid/ (eome Erity i)^.ly-htVevFi bussV)^h inrr A
 tr*etdri )trthomfultaba <p>TfisSomripeoeComs Abit utLgooddsrasV)chVFS|thoeSeAPIe*DIRECTONLY ^h sel(M tority i)^.ly-htVevFi Ssd bussV)^h
sThLlgardleas Sfh r oeperir"iot"nCNy duVSrrib  urity f asidi n,eap
do,s] Lo prdodess"nCout bussV)^heaes] tiees"Fuseiocksitaodinl  t
ioie cmes csebrma,tSyaethus ensuresiteat"nCNTie cmes gule entHANinspeccid Syaetate fe it[,s] gen[nqldtoo*[o(aseheap
Chee[CLI])s e tr*etd gheneSitheacgenU  oath Erity i)^.ly-htVevFi bussV)^hMt
t^s</ddppe^Tfis[[SeAPIe*INNOCUOUS]]s<dt>SeAPIe*INNOCUOUS</dt><dd>TfisTao SeAPIe*INNOCUOUS flagtmeansiteat"nCNTbussV)^h pGM]wlikehs )tridscgt^Ie* yrlems * neabalSbsuseiangAh innocu us bussV)^h 
 biranSith duVheebodine tccte r bas biran-lyydepefyhoalfnycs *
*[i oeperk aSEitd duVinifeiethoOe cts. s
io[abe|absfi bussV)^h]eusurnrif leComle rhguleunnocu us bussV)^htaba s
io[loFn_ext_is)^h(),Ssd bussV)^h]anagheneianocu us WvteeethSfhateguleLodine tcctetaba <p> SeAPIe*INNOCUOUS pGMsimilarridsSeAPIe*DETERMINISTIC,
beegnaghenaba if dimttChel ed tvnqld [rSyaom|rSyaomfi bussV)^h]eusurnrif leComle rockseussV)^h *re ,pGMianocu us WutMefs dc itndmisnrctaba <p>SomrihebSstehadLb  urity f ttretegule(oreOPENeDBCONFIG_TRUSTEDUSCHEMA<himi oPRAGMA  iu  **_sebrma=OFF])s e dise chVFhd eethirLSsd bussV)^heeitaodinviewetSyaetrign*osistreaeguleLebrmao  iuctuathaaseheap
[CHECKcc f a,ainte ,toDEFAULT  lat^Is ,(M toif )sftheohnSd))e
s,L[pthtiyi nSd))e
sThimi ogen[n tedtumlum enM]wl dt
duVnCNTbussV)^h pGMtagn*leheirdSeAPIe*INNOCUOUSaftMihe built- albussV)^he duVSrriianocu ustvnD
velopcts (ctradvi obaidsa*rs] t[,s] heoaba Sl PIe*INNOCUOUS flagteir"fity i)^.ly-htVevFi bussV)^hMM]wl dt ld li> bussV)^h SinrSQLpic(ct sel, audicid SyaefsneipSs*** eeEe irLpoabjnFShhsguleL  urity-advsrsembodi-e tccte streaelbusat. s-leakst
t^s</ddppe^Tfis[[SeAPIe*SUBTYPE]]s<dt>SeAPIe*SUBTYPE</dt><dd>TfisTao SeAPIe*SUBTYPE flagtpSd itd daidsSeAi tfempn%abbussV)^h SbSsthcgohds] objelQRYittegi_subdype()]iloeidspecctChel ub-dype
FSfhate rol rgurstaba s
idaflagtpS  iuctssSeAi tfe**ymit btbsr lon[n-casefypesmizstaidsgtr*eli> SbSsthdisrupeg 
atfp[n taid ir ld  objelQRYittegi_subdype()]ibussV)^h,gule et[,s] itSH Ml tn ehorcmoAatSanrk aSEds] ulordct subdype()rnlt All Ssd bussV)^hee*re ,id/ (eoobjelQRYittegi_subdype()]i
 biranSithathif )trerfp[ntyt Sy vCheeSeAPIe*SUBTYPE erfp[ntyVififmitt**nceabcnqld A]tn e )trtoff SefirtobjelQRYittegi_subdype()]idbSsthstbsnTL_sibehorcmo* neaea aeys e aonntr is Ssubdypeewa nb c t fedperck   bussV)^hVSrl rgursif )sftheo.pe^Tfis[[SeAPIe*RESULT*SUBTYPE]]s<dt>SeAPIe*RESULT*SUBTYPE</dt><dd>TfisTao SeAPIe*RESULT*SUBTYPE flagtpSd itd daidsSeAi tfempn%abbussV)^h SbSsthcgohds] objelQRYie ]ultnsubdype()]iloeteeethal ub-dypeF ae   tssoci tedtheirdateguleretodet
t^sovcs meussV)^h *re ,pd/ (e]cobjeatsete ]ultnsubdype()]i
 biranSithathif )trerfp[ntyt Sy vi*  rearefsnceabcnqld leQtSyi oLjeretene ]ultnsubdype()]li> SbSsthb_zhn_Top
o-opoi  ld bbussV)^h  s useisa nao itna ala.(M toif )sftheohnSd))<aftecnqld  oeper aSd, Ssd bussV)^hee*re ,nreadspd/ (eds] objelQRYie ]ultnsubdype()]i
 birana*rs] f ttretathifiprfp[nty,eap
Che )treurposefy uesifiprfp[nty itF aedise chVcertalcnypesmizstaidsgtr*etdri )trincontahe letheirdsubdypes.pe^Tfis[[SeAPIe*SELFORDER1]]s<dt>SeAPIe*SELFORDER1</dt><dd>TfisTao SeAPIe*SELFORDER1 flagtpSd itd daieat"nCNTbussV)^h pGMan  ggLlgad 
yyc*re ,pdllylyilbSt"1" sntheos *
*[iprfvideis  in)tre the rol rgurtvnqld
yycneds tp-thoeeggLlgad  Ssd efsstaid oe figer SifeoORDER BYo itna entHA
yyc] obaidsid/ (eomeis bussV)^ht Sy vCheeneds tp-thoeeggLlgad  efsstaid na )truse* xt iQeussV)^h *re ,lack  *rut flag,ntt SErnhhFCNTnpGMAaiseianis t
yyc*re ,Cheeneds tp-thoeeggLlgad  syntaxeififfhsea* ece chVi  Sl orrlpGguleiuilt t[,s] heo -DSeAPIe*ENABLE_ORDEREDUSET_AGGREGATESile-SE_FtdTL_Trlt. st
t^s</ddppe^s</dn<life#htVevF SeAPIe*DETERMINISTIC    0x000000800e#htVevF SeAPIe*DIRECTONLY       0x000080000e#htVevF SeAPIe*SUBTYPE          0x000100000e#htVevF SeAPIe*INNOCUOUS        0x000200000e#htVevF SeAPIe*RESULT*SUBTYPE   0x001000000e#htVevF SeAPIe*SELFORDER1       0x002000000eure releasesPh geDe )sitd dLFu*sV)^he relDEPRECATED
t^TfisTaout bussV)^heeahr [de )sitd d].  Ingt"1" FidsmaintaaegulebackwardsQcontahe saout oe fioldegeitd ,rtaout bussV)^hee n ainelli>  ae   LuprorrlyangHowread,eief uity iseshosi
 birana*rs]
duVnCNTeethirLdesut bussV)^hetvnqo hApaurageseroghoOm auM  ia*rs]
duVnCNut bussV)^he, wrloe reefs if laileore ,Chey  rrpefe#ifwhtV*reMISUSOMIT_DEPRECATED
reAPIe*xWriSeAPIe*DEPRECATEDis] objereteneggLlgad _conettbjheyup; n abxf );
reAPIe*xWriSeAPIe*DEPRECATEDis] objeretenif arniwbjeretenrn f futreAPIe*xWriSeAPIe*DEPRECATEDis] objeretena,ansfe__ vfyssn tbjeretenrn f cebjeretenrn f futreAPIe*xWriSeAPIe*DEPRECATEDis] objeretenglobal_A_zhead(*rs]futreAPIe*xWriSeAPIe*DEPRECATEDi*rs] fjeretenameEFnecleanup(*rs]futreAPIe*xWriSeAPIe*DEPRECATEDis] objereten cTVFS_eQarm(*rs](*)(*rs] ,bjeatsetiur64,iur),
rrrrrrrrrrrrrrrrrrrrrr*rs] ,bjeatsetiur64fut#endQ Sure releasesPh geObaonhret Ssd V *
*[(M tD:Qds] objheyup;veselli>pe^s<b>Summary:</b>nlt <bntnkqus t><re chVbt"1" =0Scellpadyes"=0Scellspaces"=0>nlt <tr><rd><b>Ljeretenttegi_blob</b><rd>&rarr;<rd>BLOBeveselli> <tr><rd><b>Ljeretenttegi_douSle</b><rd>&rarr;<rd>REALeveselli> <tr><rd><b>Ljeretenttegi_iur</b><rd>&rarr;<rd>32-bitNINTEGER veselli> <tr><rd><b>Ljeretenttegi_iur64</b><rd>&rarr;<rd>64-bitNINTEGER veselli> <tr><rd><b>Ljeretenttegi_s  oria</b><rd>&rarr;<rd>P  oria veselli> <tr><rd><b>Ljeretenttegi_isNs</b><rd>&rarr;<rd>eencodTEXT veselli> <tr><rd><b>Ljeretenttegi_isNs16</b><rd>&rarr;<rd>eenc16dTEXT s *
*ei 
duVnCNTSadi nViyt t"1" li> <tr><rd><b>Ljeretenttegi_isNs16be</b><rd>&rarr;<rd>6lr sl   TEXT veselli> <tr><rd><b>Ljeretenttegi_isNs16le</b><rd>&rarr;<rd>6lr slfeoTEXT veselli> <tr><rd>&nbsp;<rd>&nbsp;<rd>&nbsp;nlt <tr><rd><b>Ljeretenttegi_byt Moyb><rd>&rarr;<rd>Si* f** anBLOBSyyco-8a8eor UTTEXT  albyt Mnlt <tr><rd><b>Ljeretenttegi_byt M16&nbsp;&nbsp;</b>nlt <rd>&rarr;&nbsp;&nbsp;<rd>Si* f** eenc16TfisTEXT  albyt Mnlt <tr><rd><b>Ljeretenttegi_iypeoyb><rd>&rarr;<rd>DLsmsss )trie cdype Sfhthe veselli> <tr><rd><b>Ljeretenttegi_*cr[nql_iype&nbsp;&nbsp;</b>nlt <rd>&rarr;&nbsp;&nbsp;<rd>Buhe *cr[nqldie cdype Sfhthe veselli> <tr><rd><b>Ljeretenttegi_*ocwwfil&nbsp;&nbsp;</b>nlt <rd>&rarr;&nbsp;&nbsp;<rd>Trueti Lds] umlum apGM]wcwwfilba ala. UPDATEs e aofilolxa tirhanh h Sle.li> <tr><rd><b>Ljeretenttegi_efir vfy&nbsp;&nbsp;</b>nlt <rd>&rarr;&nbsp;&nbsp;<rd>Trueti Lttegi* rigdmdrri rs] otg[ssneipethoOe ct]pe^s</re ch>oybntnkqus t>y Anlt <b>Det
f
o:</b>nltTeirTtcut whsenn daextraccxsype,sLi* , tndtcn abjn* clbusat. sers] aba [naoheccid Ljeretenttegi]b lT_i*etvnPaoheccid Ljeretenttegi* a f te duVSrri] obaidse astetho *
*orlclbusat. seith in)trbussV)^hee*re  )trid conflinority i)^.ly-htVevFi Ssd bussV)^henhimi otirhanh h Sles]rpe (M tsorut whsenn daworkgffhseheirdonaoheccid Ljeretenttegi]b lT_i*etnlt Any atued thtl useome ut whsenn dhoalfncounnaoheccid Ljeretenttegi] )triagheneemeEFneafu^(M  )trds] ut whsenn daworkgj-olxlike ds] ulordspofyssn [ mlum eacgenU bussV)^he]aba ifceptc*re ,Cheut whsenn datak haer Sifeoonaoheccid Ljeretenttegi]b lT_i* )tre arguaivfstEFni** an[bjef nctrn f ]re arguaiimiprnc syand r mlum en ad/qp[URTfis,s] objeretenttegi_eexnslfi iSto reAG extracco-a 6lr sle  issn )trinVnCNTSadi nViyt -t"1" FSfhthe hihe machnn aftds] guleLjeatsetttegi_eexnslbefiir base nrrcottegi_eexnslfefilethosies Maba iftraccx6lr sle  issn]ein big-efy[anir ba nrt_Ftefy[anird**ecicthl,t
t^Tfis,irn[Ljeretenttegi]b lT_i* Vewa n aitFSh].uc )trusret,objeth ge*()lye argua(S,I,P,X,Dhstofi[bjelQRYie ]ultne argua(C,P,X,Dhs duVSndxi LXVSndxYVSrrib issn]eChe , mmmdri eqanh acgord,s] hoib icmp(X,Y),s e trcrELjeretenttegi_s  oria(V,Y) oe reA]rfaleCheep arguaiPaftdeoepelvar,guleLjeatsetttegi_s  oria(V,Y) rVtn ehaf ts if s] objereten*()lye argua(<li> nhsrema ut ethnerfEtheo[p arguaie ases"Fidhosies ] tddeiseir"Ssdorrl3.20.0p
t^Tfis,es] oLjeretenttegi_iype(Vi iSto reAG A]rthSsbthe
i> oreOPENeINTEGER |rie cdype itd ]teir"nCNT aitFSh" atadype Sfhtheds] objelQRYittegi]b lT_i* V. s
ioLVtn eeuas *
*oififf"no",oreOPENeINTEGER ,(M toSeAPIe*FLOAT<,roreCORRUTEXT<,roreCORRUBLOB
The< oreCORRUts int
, t^teoeperiSto reAGs SbSsthcwwfilntheo atadype eir"fn Ljeretenttegi* a f ttnlt RIkPS  leCo,Fy
TChee atadype i n aitFShly reOPENeINTEGER s b )trse nrrcottegi_eexn(Vi itF la
** idsiftraccxr hexn*toff SeSElChe  )trinyand nbatcrELu
ntfileEi *
*[or ose nrrcottegi_iype(Vi dbSsthA]rfalaba Sl PIe*TEXTaftWr oeperir"iot"aLeo sisnon ,pdllylyirie cdype italsrs)^hpe<e ,ers]epGM]whtVevFi Syaets   wwfilnefirtrma A]yratthirLSsdi tfe**nCNT
extp
t^Tfis,es] oLjeretenttegi_*cr[nql_iypefi iSto reAG atued tuM  iaprlyTfis*cr[nqldaff aityfe**nCNTs *
*t Ss]ut meansiteat"fncutted thpGgulemadehtl   fdlininpers *
*o aeanc syand re<tilonnes"Fp argt Sy s e asehea d flsrs)^h utLeossiSleiweiroeegloas Sfhlclbusat. se(ineuUTF-li>  fods,,ifhthe veseleusuao  issnceae ,lookdalike aen ad/q)s e trcrEds] ulflsrs)^h utLeo rbusobpfteoepelvarVheed flsrs)^h w,ers]taba s
io[reOPENeINTEGER |rie cdype]* or fiulflsrs)^h utLA_Saheyup
, t^Tfis,Weiret*nCNT[xUpuate] bsnponi** an[tirhanh h Sle ,sit  )trse nrrcottegi_*ocwwfil(Xi iSto reAG A]rthSsbtrueti LafyhoalbSi s e t
io mlum eulordspofyssn  aeXapGM]wcwwfilbaerck   UPDATEtfp[n taid
yyc*re ,CheexUpuate bsnponileQtSwa n a/ (edxidsid conflinSndxi s e t
ioprt he[xCmlum ] bsnponileQtSempn%oa n a/ (edxidsiftraccs e t
iotoff SeSElChe o mlum eLVtn eeuaweiroeegf ttretaa LVeode (* yr SlyTfisWvteeethitlcicsfedpobjelQRYith S_*ocwwfil(d himi fsneipSre ,Chee mlum li>  aGM]wcwwfiret)aftdWeiret* nT[xUpuate] bsnpon,lfnycs *
*SeSElbahebds] se nrrcottegi_*ocwwfil(Xi isbtruetoe reih sel  oeperrd**ecisiaprearli>  ae   a ts its *
*t Sy vse nrrcottegi_*ocwwfil(Xi isb a/ (edxfnyor rvsuUTF-li> k aSEweiret* nT[xUpuate] bsnponileQtSeir"fn UPDATEtLL.
 T_i*nbatcr )trqld A]tn e veseleusuarbihrarhoSyaeteanretleasa[URTfis,s] objeretenttegi_efir vfy(Xi iSto reAG A]rthSsbnntr is Si  ld li> veseleX* rigdmdrri rs] off"no",des objeth ge*()lyiSt|bjeth ge*()l()]li> ethosies Mang,irnX, mmeeaes] tan Ssd eth rnh vesel, SEl cre chV mlum ,li> e<ta aif )sftheonbatcrELjeretenttegi_efir vfy(Xi A]rthSsb is t
t^TfisPyratthps  pthticulroi tabjnFarte in)trbaccxso*etCheep argua A_Saheyuockses] tobjevfs.xttegi_blobtd ,tobjertepettegi_eexntd , SEQL,cobjeatsetttegi_eexnslfinh entHANin.heyuate aercaELu
ntfileEi *
* h ds] oLjeretenttegi_byt Myin,noLjeretenttegi_byt M16(in, objertepettegi_eexntd ,li> e<tobjelQRYittegi_eexnslfinrpe (M tsorut whsenn dad-olxWvsrla
** efirts il ed pemeEFneapaba tld Ssd bussV)^h npat suity te ld  objelQRYittegi ]rethoOe cts.
t^TfisAs losnca nomhcpcifeiethoOe ct itF lordctnbatcut whsenn dacaneyor ockse
f
tp vfn-ree-of- cTVFSrioc*ge ,ers]edur,s] cslbusat d flsrs)^ht
t^ Only,des   th:heyurLu
ntnerfEiSto reAGs (ctrLu
T_i*iidsree-of- cTVFS(M t*oc*g
ppe<ulrlyin<li> or fibjevfs.xttegi_blobtdli> or fibjevfs.xttegi_hexntdli> or fibjevfs.xttegi_eexnslfili> or fibjevfs.xttegi_eexnsllefili> or fibjevfs.xttegi_eexnslbefili> or fibjevfs.xttegi_byt Mtdli> or fibjevfs.xttegi_byt M16(ipe^s</yuppe^Tfisi vfn-ree-of- cTVFSrioc*ge ,ers]nceabcnqld A]tn extoff Sefirts i^Ili> whsenn dalooheotLed pasti Lds] umlum ahad  n aonhadLan Ssd ts its *
*taba VheyuaSsd ts itA]rthSsbctT_HANdisnretuishil_efirtree-of- cTVFSrioc*g SyycsyEid/ (,s] heot[bjevfs.xiocitd ppe immed^Wtepel or fiheotLu**ecili> w]tn extoff SififbaonhadLandsbefimovfni(M totTF-8Sl orrlethosies tpGM aa
** xt heotLed p[re changed forci aCnrpefereAPIe*xWrit** a *rs] objeretenttegi_blobtbjelQRYittegi ffereAPIe*xWridouSleibjevfs.xttegi_douSletbjelQRYittegi ffereAPIe*xWris] objeretenttegi_iurtbjelQRYittegi ffereAPIe*xWribjeatsetiur64objeretenttegi_iur64hbjeretenttegi ffereAPIe*xWri*rs] objeretenttegi_e argua(bjeretenttegi ,rt** a *rs]*ffereAPIe*xWrit** a unn  () e*rs] objeretenttegi_hexntbjeretenttegi ffereAPIe*xWrit** a *rs] objeretenttegi_rexnppebjeretenttegi ffereAPIe*xWrit** a *rs] objeretenttegi_rexnppletbjelQRYittegi ffereAPIe*xWrit** a *rs] objeretenttegi_rexnppbetbjelQRYittegi ffereAPIe*xWris] objeretenttegi_byt Mtbjeretenttegi ffereAPIe*xWris] objeretenttegi_byt Mppebjeretenttegi ffereAPIe*xWris] objeretenttegi_ee rtbjeretenttegi ffereAPIe*xWris] objeretenttegi_*cr[nql_iypefbjeretenttegi ffereAPIe*xWris] objeretenttegi_*ocwwfil(bjeretenttegi ffereAPIe*xWris] objeretenttegi_efir vfy(bjeretenttegi ffeure releasesPh geEerorrnomhcpcllylyirhexn*hApates"FbL.
 mle rh Ljeretenttegi* a f t(M tD:Qds] objheyup;veselli>pe^s,es] oLjeretenttegi_hApates"(Xi iSto reAG A]rthSsbff"no",oreOPENe6lr8],(M toSeAPIe*6lr16BE]The< oreCORRU6lr16LE]oacgord,s] hoids] urssia ntexn*hApates" )trSfhthe vesel X,eapsumssnceae ,X Sinrdype TEXTa)^ Sy vse nrrcottegi_iypefX)li> w]tn eshstbsnhes"FotSanrk aSESl PIe*TEXTnceabcnqld A]tn extoff Sefirds] se nrrcottegi_hApates"(Xi iseteanretleasang,C*
*[or  )trobjertepettegi_eexntXin, objertepettegi_eexnppeXin, objertepettegi_eexnppbeeXin,QL,cobjeatsetttegi_eexnslleeXin, objertepettegi_byt MtXd , SEQL,cobjeatsetttegi_byt MppeX)]idbSsthcwwfilntheohApates"FSfhthe vesel X s b )trthus cwwfilntheoA]tn exefirtLu
ntfileEi *
*[or ose nrrcottegi_hApates"(Xirpe (M tsoutLAhsrema ut iStoithegeir"] obaercaity iseshosiso*etCuhe ands.heyuateaba tld Ssdorrled conflistaidt Ss]ut Ahsrema ut iSdl a,s] cboueg 
atfpaqueli> ethosnSh"LL.
 mle rh objelQRYittegi]b lT_i*pfterd,sarhoSity iseshosi
 biraTfis*enenredo aeknoweore ,Che ethosnSh"LL.
 mle rh Ljeretenttegi* a f t pGManaTfishdeAG,s biran-lyynredo aeuseomeut iSto reAGt
tfereAPIe*xWris] objeretenttegi_hApates"(bjeretenttegi ffeure releasesPh geFvfyssnsTao SubdypeeOf Ssd V *
*[(M tD:Qds] objheyup;veselli>pe^ss] oLjeretenttegi_subdype(Vi bussV)^h A]rthSsbthetsubdypeefe<li> entority i)^.ly-htVevFi Ssd bussV)^h]VSrl rgursVtvnqld subdypeli> etlbusat. sectT_HAN] obaidse astaolimitobaSmauthfle  n abxfSefirds] on bSsd bussV)^h HoeanotSantvnUa as
iooLjeretene ]ultnsubdype()]li> Ahsrema FS|thoethetsubdypeefe<nqld A]tn extoff Sle rh Ssd bussV)^hrpe (M tovcs mority i)^.ly-htVevFi Ssd bussV)^h]V*re ,pd/ (e]cmeut iSto reAGds] s biraniaf SytnChee[SeAPIe*SUBTYPE]iprfp[nty icnqld abxf(M t*Apates"Frol rgursoren-mentbussV)^h pGMobjeatsetcee te_bussV)^h|Llgisnosobntaba IfnChee[SeAPIe*SUBTYPE]iprfp[nty ififmitt**nceabcnLjeretenttegi_subdype()li> dbSsthA]rfalf is SifstEFni** nCNTepstee mtsubdypeeicnbtbsr lon[nacase
t
tfereAPIe*xWriunn  () es] objeretenttegi_subdype(bjeretenttegi ffeure releasesPh geC py AndsFeEe Ssd V *
*[(M tD:Qds] objheyup;veselli>pe^s,s] objeretenttegi_dup(Vi iSto reAG mak doa d py ofin)trobjelQRYittegi]ds] olT_i* Veandseetn ehaf p argua hoidsat d pyaftds] oobjelQRYittegi]bA_Saheyuocksusuaoonaoheccid Ljeretenttegi]b lT_i* * neabalomhcpcifeino-iotape^s,s] objeretenttegi_dup(Vi iSto reAG eetn ehats itbalVino-ts itneabavrocks cTVFSrSth:itdrarthwfilaf,irnVsusuaoon  oria vesel]nceabcnqld A]todeockso vse nrrcottegi_dup(Vi is a ts its *
*t[URTfis,s] objeretenttegi_efee(Vi iSto reAG efees rh objelQRYittegi]b lT_i* )trerdot uslbStbaonhadLes] tobjevfs.xttegi_dup()]ang,irnV is a ts itn  orias e trcrELjeretenttegi_efee(Vi iGMaethomleas"io-op^(M/ereAPIe*xWribjeatsettoff S*bjevfs.xttegi_dup(t** a bjeretenttegi ffereAPIe*xWri*rs] Ljeretenttegi_efee(bjeretenttegi ffeure releasesPh geObaonh AggLlgad  Fu*sV)^h Cn abxf(M tD:Qds] objheyup;cn abxf(M aba Id conflistaidsgirL ggLlgad  Ssd bussV)^hseuseomeutli> Ahsrema FS|Sth:itd o cTVFSrfe<nst h,s] heoirt
L.
 t
t^Tfis,s] oh the timtrChel jheyup;eggLlgad _co abxf(C,N) Ahsrema ut  aa
**ockseSEl cpthticulroi ggLlgad  bussV)^h,8Sl orr|Sth:itd tli> NdWft MyirL cTVFS,f is  Myiucxso*et cTVFS,fandseetn ehaf p arguali>  aetCNT
ewO cTVFSaf,Onob  the r basu
ntfileEi *
*[or ds] se nrrcoeggLlgad _co abxf() eir"nCNTLed paggLlgad  bussV)^h ia Canc_,s e trNTLed pou tcL utLA_Saheyup  Se nrrcoeggLlgad _co abxf() no-iousahhsgule aa
** xtceefe<noasseid/ cstaid ir ld  xSn.oeleQtbackgSyaethenoff"gulelahe timtroren-mentxFzh() leQtbackgidb a/ (edang,(Wt SEno AhwsFmatebli> entaggLlgad  cics , ld  xSn.o()  eQtbackgffin)trrggLlgad  bussV)^h
*> ad conflistaid inrnreadsraa
**  ndsxFzh()(i itF la
** if dimttxtcetaba Ie emea acase
, se nrrcoeggLlgad _co abxf() 2bSsthefirla
** eir"nCNds] h the timtres] tweiret*xFzh()(it
, t^Tfis,s] objheyup;eggLlgad _co abxf(C,N) Ahsrema rVtn ehaf ts i p arguali> oren-h the rla
** bavNrlooleas"emanoe<noqanh  ae is Sneabavr  cTVFS(M tSth:itdrartioc*ge ,ers]p
t^Tfis,es] oSmauthfle spaceOSth:itd uaWfile nrrcoeggLlgad _co abxf(C,N) inulrlde itndmlbaerck   NiethoOe ct xt heoth the ssfuoly se rla
angCwwfiret ld li> veseleoavNrlalfnycLu
ntfileEi *
* h  se nrrcoeggLlgad _co abxf() weirets e trNTLed paggLlgad  bussV)^h ia Canc_loe reefs A]ti* ftrNT cTVFS(M tSth:itdrara)^ SWeiret*nCNTxFzh() leQtback,Etcfificustosarhold tholi> N=0sunec*
*[or ose nrrcoeggLlgad _co abxf(C,N) soidsat nS )tre argleas" cTVFSrSth:itdrarse ,ersp
t^Tfis,Sl orr|Sutosahecgohs efees trNT cTVFSOSth:itd uaWfds] se nrrcoeggLlgad _co abxf() oren-mentaggLlgad  cics   n f Sytsrpe (M tsoroe the etho *
*ort-olxWvst d py ofin)tQL,cobjeatset n abxfS|bSsd bussV)^h  n abxf]V*re ,ps heoth the etho *
*oli>  aetCNTxSn.oeir"xFzh() leQtbackgAhsrema Fre , d conflis-mentaggLlgad ds] hussV)^hrpe (M ts]ut Ahsrema d-olxWvsrla
** efirts il ed pemeEFneileorfsss e trNT ggLlgad  Ssd bussV)^h iULrunnes"t
tfereAPIe*xWri*rs] objereteneggLlgad _co abxf(bjeatset n abxf cethc nBft Mffeure releasesPh geUa  FDe ctRIkPFu*sV)^he relD:Qds] objheyup;cn abxf(M aba ,s] objheyup;] orn atatd iSto reAG eetn ehat d py ofs e trNTp argua hmpn%oa ntrNTpUa  De ctetho *
*or(t
io5s metho *
*o) )trSfhthe [bjeretencee te_bussV)^h(d li> end [bjeretencee te_bussV)^hslfinhwhsenn datr*etorigdmdhhsguleLlgisnosobatrNT ity itdrart tVevFi bussV)^hrpe (M ts]ut Ahsrema d-olxWvsrla
** efirts il ed pemeEFneileorfsss e trNT ity i)^.ly-htVevFi bussV)^h iULrunnes"t
tfereAPIe*xWri*rs] objereten] orn atatbjeatset n abxf ffeure releasesPh geDe changeC forci aChRIkPFu*sV)^he relD:Qds] objheyup;cn abxf(M aba ,s] objheyup;cn abxf_db_ aSdfefilethosies  eetn ehat d py ofs e trNTp argua haetCNT[re changed forci aCnh(t
io1he etho *
*o) )trSfhthe [bjeretencee te_bussV)^h(d li> end [bjeretencee te_bussV)^hslfinhwhsenn datr*etorigdmdhhsguleLlgisnosobatrNT ity itdrart tVevFi bussV)^hrpe/ereAPIe*xWribjeatseSobjereten t abxf_db_ aSdfefbjeatset n abxf ffeure releasesPh geFu*sV)^h AuxiliarhoDe c relD:Qds] objheyup;cn abxf(M aba Taout bussV)^heeSs  ** useiserc(nntreggLlgad ) Ssd bussV)^hser ds] tssoci te|Suxiliarhoie ctoe figol rgursvesellafIrLn)trLaL_rrol rgur )trtoff Sifie aseis  imodeseComad/ cstaidspr  ld bbaL_rSsd bussV)^h dur,s]
ulecics  siee eso ,M]whtrnbtbsr ircum Canc_s-mentassoci tedtSuxiliarhoie cli> dbSsthbe  )sf rveiangAh if leComle or rvsthis dbSsthbe use se stFienaguleLlgulro-if )sftheohmatebret bussV)^ht Ts] um-SE_Fd lsrs)^h wfnqld A]gulro(M t*f )sftheohctT_HANst heisa nauxiliarhoie cttssoci tedtheirdtrNTp tabrno  issntaba s
inorailosnca nomhcp tabrno  issn A]mainooheotLed ,s e trNTum-SE_Fd LVgulroi*f )sftheohctT_HANreuse* xt modeseColi> et/ cstaidspr  ld bbaL_rbussV)^hrpe (M t,s] objheyup;get_aux atatC,N) ithosies  eetn ehat p argua haetCNTSuxiliarhoie cli> tssoci tedterck   bjheyup;set_aux atatC,N,P,Xi bussV)^h heirdtrNTNs mrol rgur )trs *
*o aetrNT ity i)^.ly-htVevFi bussV)^htvn,i stF is Seir"nCNTleft-mecrds] hussV)^h rol rgurtvn,irnChere no-ioTSuxiliarhoie cli> tssoci tedtheirdtrNThussV)^h rol rgur,ck   bjheyup;get_aux atatC,N) ithosies li> w]tn eshf ts i p arguarpe (M t,s] objheyup;set_aux atatC,N,P,Xi ithosies  savs] Psa nauxiliarhoie cteir"nCNds] N- figol rgursofin)trrity itdrar-htVevFi bussV)^htvn,Su
ntfileEgule aa
[or ose nrrcoget_aux atatC,N) A]rfalfP efirts iltihe rVcs ads] se nrrcoset_aux atatC,N,P,Xi  *
* balomhcauxiliarhoie ctpGMsnrQtS.heyu SEQL,cts itbalomhcauxiliarhoie ctSinrSQLpidiscard u/TeirdAor fioasse *
* h  se nrrcoset_aux atatC,N,P,Xi or rvsGctpGMsnrQtS.het_auxaL_rSsd  gaetCd u/TeirdAor fioasse *
* snArg(oth tfe*xWris] objeretenttegi_be chayt,ntaggLlgad oie ctpGMsnrQtS.hu/TeirdAor fioGguleiuilLpoabjchVcereirdLlgad oie ctpGMsnrQtted tye tr*enChee[Sino: or fibjevfs.x^(wulflsrs)^hssn  aeXapGMnArg(oth is] objereheoA]ts)^objeatsevfs.x^(wulflte ].tfSd  iStojelQRYie ]ultnepbjheyup;taftFuir"nCNds] h the tiiiiiiST_i*aftMihe )^objeatsevfs.x^(wulflset_aux atatC,N,P,Xi (edxfnyor rvsenU  ed p[re chae tiiiiii*o) )trSfht^objeatsevfs.x^(slbusatueli>sguleLllset_aux atatC,N,P,Xi (n a/ (osncaM tSth:itdrrrrrrartioc*ge ,ers]p
t^Tfis,eperiSvfs.x^(slbusatueli>sguleLllset_aux atatC,N,P,Xi (n a/ ussV)^h  s useiitdrrrrrriLaid irLp rvslbusatann a pGMa sies ] nCNTepstslbusatann a  ,M]whtrnbitdrrrrrras_sibehorcmoh>  a 
atled SUBTYPE]RDEREDUSTAT4eoep^Tfisi vfn-ren%CheeSemtrorenwo bu"nCtleLlgroi ggLlgaubdypeloasse *
* sXebrmao  et_aux atatC,N,P,Xi or rvsGcirla
** eir"nCNdepel or fih,fni(M tot nrrcottegi_*oatatC,N,P,Xi (e extracco-mhcpf ts i ad,eiran-ltegi_*oatatC,N,P,Xi raniaf Sytn* eir"nCNdnearates"FSTepstee m  d conflistaid oe fs e off"gulV)^h rol rguristaid oe fs e lyynredo aemn ad/qulesut buPeotLu*rrcottegi_*oatatC,N,P,Xi (ic(ct sel, "nCN)^heer-ioTmifiimaQL,cLjeC sho ee te_bgtatC,N,P,Xi (gdmdhhM]whtVepel or fiheotLu**a)^hssn  aeXapGMyinobjef ncttegi_*oatatC,N,P,Xi (rQtS 
f
tSya efirtsomhcauxif- cTVFSrioc*ge [or oaeXats]taba s
r rvslbusatyup;set_aux atatC,N,P,Xi (n a/  cTVFSgulV)^h rol rgurisseiocksid irLp rvslbusatann a pGMa sies aSEds] ulorlecics  siee eso ,M]whtrn,(I  the   nhVFS|thoe,d oie ctpGMsnrQtS.hiangAh ift6lr8ornd  n abxf]Vse nrntoritynArg(oth is] objerri )trincotdTL_Trlt. st
GMts  ** enChee[Sino vesel, *o aetrNTlbusat[is] objerrneipSreos,cirdrritdTL_oss il ed pemeEFneis,s] objhT X s b )tpstee mN*orh ibjertepetsV)^hGs (ctrLu
Taf Sytn* edi n duVhArgPS  leuehea"FShntasntaggLseismn adesut buVhArgang^NaetrNTlbchVcAPIe*SnewS  lkindbbaL_  n abxf]VsssV)^hena )trusorut whsenn dad-olxWvsrla
** efirts il ed pemeEFneapaba tls e trNT ity i)^V)^h iULrunnes"t
tfereAPIeut whSeeesmiz:Yie ]ultnegtatclitag
, t^Tferetencee te_bstatclitag
, t^TfPIe*xWri*rs] objereten] orn atgtatC,N,P,Xi n abxf cethc nBft MffNe*xWri*rs] Ljeretenttegi_efstatC,N,P,Xi n abxf cethc nBft MffN,jeatsetxIflsrse
ffeure eleasesPh geDe changeC forci aChRIkPFu*sClitaglD:Qds] objheyup;cn abxfaout bussV)^heeSs  ** uaidsadi Ssd b|SuxiliarreOPEranoff"goe duM   rele-h thSifeoOged forci aCnrpefereAPIe* A se nrrcoset_aux atatclitag
, t^D *
* balomosemagua haetCNT[Pbjef ncber, orfhi Ssd ged forci aCnh(t
io1heDbjeth ggoe fNrcoeEgule aa
[or ose nrrcoget_aux atatclitag
, t^D *]rfaleCheep arfin)tQL,cohaetCNT[Pbjefticuloria t-olxWvsino-ioTSuwoTSunoxCmlum ds] se nrrcoeggLlgadstatclitag
, t^Tatled pSaL_rbeeetrNTlb,coDits  oPIe* iurssincotdTL_LL.
bjeth g,Y),s e nrrco ed talnthma,tS,eap
do,emea athf ts i p0 ed se rla
nrrcos int
, OMEMM torithwfilaf,irnVheaPIeut whIbuPeorcoXo ed duVhenbileorfsstde  iuct heleQtbackX(edxohen-mentonlgadi ofin)trrPh the ssfuoly pstee m rLu
ntnerba s
r tass:eriSvr fibjevfs.xA- cTVFSrioc*ge ,ers]edur,s] cslbusatsrs)^,cLjeC shooooooeggLlgadstatclitag
, t^Tatuity i  iaprlyTfinmodeseCoPaftdeoepeibjevfs.xAleEi *
* h  se nrrcoeggLlgadatatclitag
, t^D *
* balhbe adae tiiiiiitled pSaL_rbeeDits  octs.
t^TfisAs levfs.xypelod forci aChne<tizh(^ ^Tmhc oGguleiunceabcnqemn ad/qulgus.
tdeWft Myrrrrratfpaqueli>the hefncuity  heleQtbacsincotdirts ,s e t
 )trinnobjeffffff heleQtbacsifaleC* efirts ixtcetaba Ie ttedcum CPaftdcslbusatsrsbjeffffff d forci aChne<tizh(^ ^T e
lyiocfis,s] ^Tfisi vfn-reGguleiunceabcnqedntvnySanrk tled clitagMsnrQtaSEitd duVin objelQRY heleQtbacsi the ssclitagMsnrQtthosnSh>  roCmld. ,ii [rSyaom|geir"] olQRYesuts] hclitagMsnrQtse chVs  in)tcaM theoAismebds] r>  ar vebrariel ed poa naux yi ypesmizs. sectT_HAN]atfpaqussV)^leiund forci aChne<tizhsorut whsenTSuxiliarSmaut (aSEitd duVihVi  Sl oroc*ge )i the sse rol rgurst
t^s,Ab[or olitagMsnrQtM   rele-(tcLdesdad conflgoe s (gdmdheuse* x, orfhi Ssd ds] onaoheccnd forci aChne<tizhsd,eief uityeino-staid inrnreadsra dc itndl cpthticsrs)^,sut bua )tnerbnaba IOPEranwo sdad conflolitagMsnrQtgoe sPIe* Ahosi
 biraTfts   r>  ar vebrarielincotcereroghoO il ed jeth gmM tot f )sft IOPolitagMsnrQtgoe 
* h sorut whsenTSuxiliarrfssccs iypefaCheeSemolitagMsnrQtM   releci tedtheirdtrNThussacnd forci aChne<tizhsd,Te mN*orh ibjerteuse* xe aonnse nrrcona alsecf t keyd flsrgdmdhhnabaimmergdmdh ,Chd ,s e ecf t keydFS )tre ed poaoath Erii tedtSuxiliarnd fPIeut whSe ttreteWarnino: ussV)^hGs (ctrLu
Taf SytnseisuneeosoIEWetofscripreO busss eQtbacsgen[n taSEitdanc_s-mentassotpGMsnut   )sf rveiweiroeegPDATEtci te2bSsthefeome Erity i)m leCoheogs rt umdheusee Erity i))^hGs (ctrLu
[or osn TfisWvteesmize Sifecethrol pstee myiocfis,s] [or Dd forci aChne<tizh(^ itagMsnrQtse ece chVi  Sl orrrl3.20.0p*o aefnqld A3.44.0 (ged eof:3.44.0] nrrcolaM t,s] objhSeeesmiz:Yie ]ultneatatC,N,P,Xi feretencee te_bgtatC,N,P,Xi fPIe*xWri*rs] objereten] orn atgtatclitag
, t^] orn a*,s]*ffereAPIe*xWrit** a unetenttegi_sustatclitag
, t^] orn a*,rs]*ffereAPI,jeatsetxIflsse
ffeure eleasesPh geDe changCMts  ** ODAPIeV *
*eA_zhn DheleQtbackBna )truaout bussV)^h_i*iieA_zhn etrNTlbhticsrs) heleQtbackheoth th imodesin)treurposefho *
* ofin)trrTfind-olxWvs ad/qne ]ultnsubdype(tobjerthere no-io) heleQtbacgadi ofin)trrisSELFORDERTAgnaghut  t"nCNTbussV)^h clbusatt-olxWvsis
GMts  **[bjerete A]ti*
**  neoA]t nrrfsnceabcnqe   )tru ob) heleoyt SEnoT PIe*INNOCUOUTRANSIENi 
duVnC t"nCNTbussV)^h clbusat A]titridsctheoA]tnNTSadi nViyearafuehea"aChee mluV)^leiuaf Sytnmn adrgurown TfivaChe e trNTp argua  clbusatni(M tof ts ireAPIeut whTe mreteSUSOsraa
cfisholi> NlxlikaroOe ct* neaballcn n abxfsPh g++tdTL_TrlrAPIe*xreteSUSOIflsrsee ]ultns heleQtbacli> w
ffeure ; SeAPIe*SELFORDERTAgnaffffff((e ]ultns heleQtbacli> w
0) SeAPIe*SELFORDETRANSIENi ff((e ]ultns heleQtbacli> w
-1)easesPh geDe changS LVeodeTe mR yr SlOfxA- V)^hF s useiitdrbjheyup;cn abxf(M aba Taout bussV)^hnd-olxWvsaidsadi Sjheyup;jheyu() leQtbackgAhsrematrid conflinority i)V)^hser ds] tsrrco ) Ssd buhc oGeeatset n abxfS|ssV)^h(d li> end eretencee te_bussV)^hslfinhwhsenn  cpthticyi ypesmizs. sectT_HANsorut whsenn ds oe fi 
atxlikty i)mflsr ulordspo[is] objer tbjeret],irmiltrNTp arseuseomeutli>)tru oindaetrNTlbchVhnn ais] objerriLlgrL,cLL.
i*aftMihe sPIe* Rtexn[re changV)^ht]pe^s</resnccud inrnreadhticyi ypesmizs. sectT_HANsorut wheyup;set_aux ubdype(tobjers  savs] PsaeggLlgad* yr Slon bSsd a)^.ly-htVevFi bussV)^h iULeo miru ob)lgadelli>we
, seclbusat.a ] ret,dbjef ncby ,s e ecoe ct]pe^s</rerete a d py oirL cTVFomhcptpGMsnNh the ep arguir ct]pe^s</rsorut wheyup;set_aux ubdype("nCNtobjefalfPrrcottegi_eeubdype("nCNtobj64efalfonflis (ctrLu
Taubdypee* yr Slity itdrar-htVevFi bussV)^htvn,Su
niru obSsd adelli>dLan Ssrgurs]ti"nCNTL cTVFts  ocL cTVFtofstndsorut wheyup;set_aux ubdype(jelQRYirs  savs] PsaeggLlgad* yr Slon bSsd a)^.ly-htVevFi bussV)^h iULeo miru ob)a"Fp argt Sy s e 
duVnCdperck   Ssd ,s] ggL2rco en,irnChorut wheyup;set_aux ubdype(ers]e(fPrrcottegi_eeubdype(ers]eo reAe duVSrriianolcicsfeino-staid inussV)^h]V*re ,p[re chrowsftheo ,ChOnly,desSutosaheosemagua ]mainoo] ret,df ncby ,s ,des2e ct]pe^s</rercottegi_duubdype(ers]e(fPs] htegi_eeubdype(ers]eo reci tedagua sd bud bussers]edmfish]t nrSutosahe  savrL,ggLlgaders]eci tmfish]t ]mainoontfileet_aux ubdype(ers]e(fPrsEXT  a.rSutosahonflis (crL,ggLlgad]mainoontfileet_aux ubdype(ers]eo reArsEXT  16 jeth p argua  chang" FSfhthe hlbaerck rnreadru(M tCKcc eet_aux |bjetnrpe (M tsorure no-io)guir ct]pe^s</rrrcoeggLlgadubdype(ers]e(fbjefticeet_aux ubdype(ers]eo reAsraa
Argang^tde  **nCNT
e py ofgLlgaders]eci tmfish]t e nrrd buup chroonnhe ssfuoly "nCNTreAPac</rsorure no-io)guir ct]pe^s</rrrcoeggLlgadubdype(ers]e(fe nrrcocee te_wubdype(ers]eo reAsraai n duVhArg^tde  **nCNT
e py oVFS,fatTF-8SlL cTVF(cnqereAPac</rs (l ed peme2e ct]pe^s</refgLlgaders]edmfish]t t wheyup;set_aux ubdype(ers]e(fPrrcottegi_eeubdype(ers]eo ret whad-olxWvsrSifeooTfivaChe e trNTLlgaders]edmfish]trrd buni(M tp arguayof ts iad,eiran,tsrs)^,cLapGMnArg(oth osn deo cTVFSrf]eci tmt[,syagua sd buotLu**eciyof ts igf ttreta"io- t wheyup;set_aux ubdype(ers]e_immed^MnArg(oth oeoA]tsLlgaders]edimmet whaweiroeegrrpefe#htona al* yr SlitynpGMAaiseiV)^h *re ,la nrSByVcAPie cTum-SE_Fders]edimmerisSELFORDEERRORssV)^heEi *
* h  se nrrcoeggLlgadubdype(ers]e(fbjefticeet_aux ubdype(ers]eo reA  iStsLlgaders]edimmeIe*DETERMINERRORsorut wheyup;set_aux ubdype(ers]e_toobigirs  savs] Psomosema**nCNT
extp
rowsftt whMAaiseiVieat",X Sinrdyceae ,looackBlli>se choFomhcpTfinmtheos rsorut wheyup;set_aux ubdype(ers]e_nomemirs  savs] Psomosema**nCNT
extp
rowsftt whMAaiseiVieat",X Sinrdyceth:itdrarthwfilaf,irnVAor fit wheyup;set_aux ubdype(QRYirs  savs] PsaeggLlgad* f Sle rh Se nrrco itdrar-htVevFi bussV)^htvn,Su
niru obo itdNTEGER ] objereteilon
o aetrNTleChenabxf(M t2rco en,irnChoruheyup;set_aux ubdype(QRY64ers  savs] PsaeggLlgad* f Sle rh Se nrrco itdrar-htVevFi bussV)^htvn,Su
niru obo itdNTEGER ] objereteilon
o aetrNTleChenabxf(M t2rco en,irnChoruoruheyup;set_aux ubdype(nullers  savs] PsaeggLlgad* f Sle rh Se nrrco itdrar-htVevFi bussV)^htvn,Su
niru obo objeoruoruheyup;set_aux ubdype(ren-me,;set_aux ubdype(ren-o re,rrcocee te_wubdype(fili> or f,Prrcottegi_eeubdype(fiir base nGs (ctrLu
[or aubdypee* f Sle rh Ssd b itdrar-htVevFi bussV)^htvn,Su
niru obSsd adsd buae ,loo a d py onmtheos rxiliarXT  a,EXT  16 yt et"1" Fefe#htV,rrcoXT  16 ly[ani d**eciCORRUXT  16 big d**eciCOthl,t
t^Tfis,irnheyup;set_aux ubdype(ren-64ers  savs] PsaeggLlgad* f Sle rh Sleunnocu u.ly-htVevFi bussV)^h iULeo miru ob)a"sd buae ,looUpuate )trSfhthe vdperck   bussV)^hVifth (rrcolast)ct]pe^s</r,o a d prla
** eahe timENe6lr8],(M toSeAU6lr16LE]oacgoeAU6lr16LE]oacgooreCORRU6lr16LE]oacgord,y,desSutosahee py oVFa sd bu* yr Slon bb itdrar-htVevFilon bSsd peme2e ct]pe^s</reaL_rbusset_aux ubdype(ren-es Mang,irnX,orure no-io)3r ct]pe^s</rrrco/qulaL_rbusset_aux ubdype(ren-es Mang,irnX timESEitd duViset_aux ubdype(ren-64ers raa
Argang,^tde  **nCNT
dTL_utel ed prutie ,loolengleretoelfrrcoeearssV)^hpeme2e ct]pe^s</rehticsrs)fuoly ed "nCNTreAPac</rsorure no-io)3r ct]pe^s</rrrcorbusset_aux ubdype(ren-es Mang,irnX timsraai n duVhArgnhhFCNTnsfatTFlL cTVF(cnqereAPac</rs (aL_rbusD:Qds] o] ret,df ncby ,s e2e ct]pe^s</refrhee pyn)treurpu.ly-htVevFi bussV)^p arseuseome
t^sovcseneds tp-3r ct]pe^s</rrsraai n duVhArgnhhFCNTisthdisla
** e tp-" FefeffaubdrbussV)^hae ,loo aeed taba ob aerck rnds] *enenred>  ae  ussV)^hae ,loo GMsnNob aerck rnt SEne-of-ynNob reAPac</rsdur,s]onflissV)^hae ,loordyce" Fefeffaubdheoth thnoe<noqanht X s b )tpstee m3r s] o]]pe^s</r,otA]todeockso vsth g,Y)nrk tl nrdLan Ss embe"SsdoNobs off"gulV)^h* yr Slityeos,cirdrritd
yyc*rnerbneChe , mmThussembe"SsdoNobs evFi Syaets sorure no-io)4xWris] objerercorbusset_aux ubdype(ren-es Mang,irnX timticeet_aux ubdype(tobjomleasnbileorftt-olxWv,^tde  **nCNT
ds] se d confl rol rgur,scsrs) heleQtbackoxf(M t*ApaoackBlli>* yr SlwFCNTis(ic(osefho irtreeo -DSeAPabu* yr Ssorure no-io)4xWris] objerercorbusset_aux ubdype(ren-es Mang,irnXPEranorrcocee te_wubdype(tobjomlerbusseA_zhn GMts  **SELFORDERTAgnaghtde  **nCNTci tedtumnCNTbussV)^h*ApaoackBlli>* yr SluleLlgGMts  **Sh:itd uff"nceabcnqianole trgua  clbusatpstee mys] objerenum ds] sacnheleQtbackoxf(M t clbusaianowFCNTis(ic(fho irtreeo -DSeAPabu* yr Ssorure no-io)4xWris] objerercorbusset_aux ubdype(ren-es Mang,irnX timticeet_aux ubdype(tobjomlerbusseA_zhn GMts  **SELFORDETRANSIENi ed pru  **nCNT
d py ofin)trobjelQRY* yr Slubussh:itd Les] tobosefhvfs.xttegi_dumarthwnd eni(M toithf ts i eoruoruheFed paggLet_aux ubdype(ren-o re,ocee te_wubdype(fili> or f,Prrcrrcocee te_wubdype(fili> ase nad-olxWv,eipSre iceet_aux ubdype(ren-64erianowFCNTlgaderol rgurtS.het_ toS,pcifeino-iotapoacgoenigi 
atled a-8SlL cTfhthe hmark (BOM,EX+FEFF)otA]todeocBOMpy onmmovs il ed pemrrcoce ,loorff"gulY* yatpstee mae ,looUslis (crL,gxili hoids] urssia -8SlL cTfhthe hdperck   bussV)^hBOMobjelQRYL cTfhthe hdperck   bus ed prutBOMpussV)^hnigi nhe vesel X *ApaoavMAaidy oVFa L cTfhthe he vdperck   bussV)^h  savs] PsyiocfdheaPnrSuo,seid/ y
TChee atrrcocee te_wubdype(fili> or f(edxohen-mentonl *ApaoAPabunigi 
ianowonl L cTVF0xfee 0xff (r[anir ba nrtL cTfhthe hmark)otA]todeoosefhororenwo b cTVFS,f-iotap_i*iiki  adorff"gulY* m Ssrgur-iota timsrais (crL,gxilis oacgoor *ApaeoruoruheFed oacgoe-iotap*ApaoAcorbusset_aux ubdype(ren-o re,rrcocee te_wubdype(fili> bere,ocee te_wubdype(fili> or f,Prrcrrcocee te_wubdype(fili64ersad-olxWv,eisel X *ApaodLan Sssate aercrrcoXT goereAPac</rstyeino-e aerc reAPac</rsdirla
** eipers *aodinl  AcorbusuniimmeInmtlaasntag reAPac</r,EX+FFFDeoruoruheyup;set_aux ubdype(s b )irs  savs] PsaeggLlgad* yr SlNTp argua .ly-htVevFi bussV)^h iULeo miru ob)a"n)tQL,cobjeatsetcid Ljeretenttegi] )triagh* neabaldperck   bussV)^h2e ct]pe^s</ruleLjeatsetttegi_eeubdype(s b )irs  savs] Psd py ofin)trobjelQRYittegi]ds] olT_i* VnS )tre lQRYittegi]ds] olT_ldperck   bissV)^hort-olxWvstlnefirtrma]eci tob) huaWfds] seotLu**ttegi_eeubdype(s b )irsf ts i pf ttreta"io- t wheAcid Ljeretenttegi]b lT_i* * neabaltlnealwaysserc(nntr aeed f )sfthcid Ljeretenttegi] )triagh* neabaly onmcbous ,snS eit aSEweikindmENe6ttegi] )triagh* neabal obaidse asttled pSreAGt
tfereAPIeuoruheyup;set_aux ubdype(C,P,X,Dhs duT,Drs  savs] PsaeggLlgad* yr Slrco/q
e*INNO*
*t[URTfis,ke ds] ulorne ]ultnsubdype(nulleC,cobre ,Cheut whisthdismizeedtSuxiligLlgadhnn -s eQtbacoPaftdeoepPErana)^ Sttled pS confl
*t[URTfisd flsrgdmdhV)^hoaftdeoeeuse* xt e ,evasttledtoif )sfth.ly-htVevFi Ssd bussV)^h]V*re ,pd/jeth ge*()lye aargua(bjereten tsorure no-io)Dct]pe^s</rrsraait_auxaLhhFCNTisomleashaetCNTSuxia) heleQtbacgadihticsrs)Pct]pe^s</ruleLutosahe  ut iStDttled iliarrguroce ch)trs *
*o awru  **nCNT
i(fho irtreetled isd,Te mTct]pe^s</rraf Sytn* eai*afticrrcoce ,loorff"rL,fyycvteestie ,loolesel, ereten*()lye aubdype(C,P,X,Dhrema ut ethnerfEtheo[p arguaie ases"Fidhosies ] tddeiseir"Ssdorrl3.20.0p
t^Tfis,es] oLjIbussV)^hnd-olxWvsaidsfirts il ed tledtoif sdad conflpaba tp arguanht X  IOPoLan Ssrgurgua .ly-htVevFi bussV)^h iULeo mirPabu* ceArgTeethirLdt n abxfS|bSsd b]tt-olxWv,^tded* yr Svsaidsa Syaets sor*xWri*rs] objereteset_aux ubdype(tobje n abxf cethc nBfts] objeretBft MftxIflsse
ffeure eleWri*rs] objereteset_aux ubdype(tobjtenttegi ffcethc nBfs] objeretBfrrrrrrrrrrrrrrr*rs] ,bjoooooeggLlgaduQRY64,Iflsse
ffeure eleWri*rs] objereteset_aux ubdype(jelQRYittegi ffcethc nBftjelQRYeleWri*rs] objereteset_aux ubdype(ers]e( n abxf cethc nBfts] objreAPI,jQRYeleWri*rs] objereteset_aux ubdype(ers]etenttegi ffcethc nBfts] objeretBft MfeleWri*rs] objereteset_aux ubdype(ers]e_toobigi n abxf ffeure releWri*rs] objereteset_aux ubdype(ers]e_nomemi n abxf ffeure releWri*rs] objereteset_aux ubdype(ers]e_immed n abxf cethc nBft MfeleWri*rs] objereteset_aux ubdype(iup; n abxf );
reAPIft MfeleWri*rs] objereteset_aux ubdype(iuptenttegi ffcethc nBfeset_aux iendQ SuWri*rs] objereteset_aux ubdype(nulle n abxf ffeure releWri*rs] objereteset_aux ubdype(atset n abxf cethc nBfts] objreAPI,jQRYtxIflsse
ffeure eleWri*rs] objereteset_aux ubdype(fili64e n abxf cethc nBfts] objreAPI,eggLlgaduQRY64,rrrrrrrrrrrrrrr*rs] ,bjoooooIflsse
ffeure , e*rs] objereteerol rgueleWri*rs] objereteset_aux ubdype(filitenttegi ffcethc nBfts] objeretBft MftxIflsse
ffeure eleWri*rs] objereteset_aux ubdype(fililQRYittegi ffcethc nBfts] objeretBft MftIflsse
ffeure eleWri*rs] objereteset_aux ubdype(fililQbYittegi ffcethc nBfts] objeretBft MftIflsse
ffeure eleWri*rs] objereteset_aux ubdype(s b )ittegi ffcethc nBfeset_aux ereAPIe*xWri*rs] Ljeretenttegi_efubdype(C,P,X,Dhttegi ffcethc nBfeeretBfs] objreAPI,Iflsse
ffeure eleWri*rs] objereteset_aux ubdype("nCNtobje n abxf cethc nBft Mffne*xWrit** a unetenttegi_suubdype("nCNtobj64ettegi ffcethc nBfeset_aux uQRY64fne*xeasesPh geDe changS LVeodeTe mOf Ssd V *
A- V)^hF s useiitdrbjheyup;cn abxf(M aba Taout bussVnttegi_suubdype(bjeretenC,T^MnArg(oth omosemagua icnbtbsrNTp argua * yr Slon bb itdh.ly-htVevFi Ssd bussV)^h]V*re ,pd/tonlgadit n abxfS|bSsd b]tCiru obo itdRTfisdeper   th:heylows"F8[anri] obpstee macnbtbsrTsaidsiangAh iftLlgGexn*hApefnqld s tfe**nCNT><rd>hrlaonnesder tbtlincotcereirdAor fiossVne rol rguracnbtbsrb cTVFiangAh ift6rpefe#htoirla
*inussVshonflisafuehea"irLSsdis tfe**nCNTovcs mority i)^.ly-htVevFi Ssd bussV)^h]V*re ,pd/ (e]cmeut iSto reAGds] s biraniaf SytnChee[SeAPIe*SUBTYPE]UBTYPE   0x001ty icnqld abxfnri] obates"FbL.
 mlesoren-mentbussV)^hV)^h iULrunnes"gadit n abxfS|ssV)^h|Llgisnosobntaba IfnC [SeAPIe*SUBTYPE]UBTYPE   0x001ts] o]ififmitt**nceabcnLlon bb itd iULeo mirPabumeut iStttegi_suubdype(bjeretencrELjereten lon[nacaasemagua itegi_suubdype(bjeretencoirla
*fn-re> N=0sunecgua * yr Slbjerete,es] oLjIbu**nCNT
i(f LVgulroitled -DELFORDERTRICE   0x001=1nhhFCNTnTF-8SlV)^h npat suity temeut iSto a itegi_suubdype(bjeretencoGds] s biraniaChee mlunceabcnqeharg^tde UBTYPE]UBTYPE   0x001o]ififmittfaleChaisiraniaChMAais)^heeehea"efnqld s tfe**nCNToirla
*enSl or-DELFORDERTRICE   0x001=1-8SlL VcAPie csor*xWri*rs] objereteset_aux ubdype(bjeretenttegi ffcethc nBfes] objereteeleasesPh geDe changeAPIe*SNew Collc*rnerS*
* hcQds] objheyup;veselliIeuoruheyup)^heeSs  ** uadd,onmmovs,PErano[,syaaeacgelae ,pd/edtSuxiliaianowonl PIe*Sed forci aCnh(t
io1hedperck   bathe etho *
* en,irnChoruoruheyup;goe 
olum ahad lrnreadsraTEXT  altrinVnCNTSe iceet_aux |ssV)^had lrnrea(fPrrcottegi_ee|ssV)^had lrnrea_v2reci terco   issn]ein bign loyt et"1" Fefe#htVSe iceet_aux |ssV)^had lrnreao resorureCd lrnreadgoe s mdri eqanh acgord,s] hoib icmp(Xtrn f ]re arni,s e ursVeianoles] dT ity u obo itd changoe ,es] oSmauthflguir csoren-men(eTc nRep)prla
** eahe
olum ahadts  ** :eriSvr fibjevfs.x6lr8],(M toSeAPIe*vfs.x6lr8],(M togord,APIe*vfs.x6lr8],(M togoBd,APIe*vfs.x6lr8],(M togo]objeatsevfs.x6lr8],(M togo_ALIGNED],s] ^TfisieperiSeyup;eTc nRepcsoren-menlbaerck  sTlgaderol rgurgurahe , mm imodeunecgoum ahad lrnrpGMnArg(oth ostcfificuxCqanh a,irnheyup;6lr8],(M togo]eretenlr8],(M togo_ALIGNED] etrNTlbhticeTc nRepCNTSe ic]eChe , mmmu oboXT goewonl yt et"1" Fefe#htV,irnheyup;6lr8],(M togo_ALIGNED] etrNTbhticeTc nRepSe ic]seChe , mmmu obgi )sft IiaChMhena" Fefaddrfis,s] objeretenfoer-ir,ck   bjhepArg,fishdedrart tVevFi bnrQtM   rel heoth th imodeunecguroonnhathe etho *
* en,irnCcgoum ahad lrnrpGMnArg(oth ostcfifi,s] oh the timtf-ir,ck   bjhexCqanh a,omleashaetCNTSuxim ahad lrnrpGMnArg(oth,irnheMad/ cstaad lrnrpGMnArg(othseeuse* xt atrNT ityo -DSeAPtd changoe  bta timtcLdesdad confleTc nRepSis] objerrirrcos iiaetCd u/icsf a d 
** p arseuseome
t^cbousthe etLSsdtle spaceOStbnrQttranssectT_HANsorure no-io)xCqanh ai ofin)trrisS
*t[Utulflsrs)^h lrnrpGMnArg(oth  itndmlblent SEn^AhwsFa nrdL lrnrpGMnArg(othsea )tnerAPtd changoe  ncotcblent rELjere eLVtnlrnreadsranoFomhcercai <tr><rdoh the tiad lrnrpGMnArg(oth ostcfifi(edxohen-mentonl fin)trobjelQRYpArg
u u.ly-htVevFi bnrQtM   rel rete Anl PwoeChe , mmiNTlgaderol rgurdperck   Ssd ,s]tup;eTc nRepcsoren-mesd,Te mPwoeeteilon is] objerri xim ahad lrnrpGp arseuseome
gSyaethenoed tabalengleresel X *woeChe , mft Mrb cTV-SE_Fd l lrnrpGp arseuseome
rla
*heep arf re<tilonnheoth th duVhArgnh"nCN,PErapoap
do,onflifhe etho *
*ae ,looUslnoe<noqan,ae is Sne,PEragssV)^rrguanht X  ecoe ,V)^h* y,t
t^Tfis,  A sd lrnrpGMnArg(oth rla
*alwayssheep arguai rgur nsw* p areChenaguai rgur-iotasC [SeAPwoPEranoff"dL lrnrpGMnArg(othsear xt atrNT itunecgoum ah rgurcd lrnreadgoe  (o -DSesdad confleTc nRepSetrNTl)otA]tonnobjefrla
*eCheiaChMcboetri s e sw* owFCNTihen-mentonl Mcboetri s Che , mr fiossVnsd lrnrpGMnArg(oth rla
*obeth:heyurLu
ntner]ififmiiTlbhticnnobjefChe , mmA, B,eipSrCyin<li> oo fibjevfs.xSeAA==BotA]toB==A.ibjevfs.xSeAA==BoipSrB==CotA]toA==C.ibjevfs.xSeAA&lt;B THEN B&gt;A.ibjevfs.xSeAA&lt;B ipSrB&lt;CotA]toA&lt;C,s] ^Tfosi vfn-ree-ofnsd lrnrpGMnArg(oth irnVso/qulaL_rbusabovshadts hai** OaChee mlianole lrnrpGMnArg(oth  ixt atrNT ityaChee as,otA]todeocena )tru tfe**nCNT timsrai Syaets soruoruheyup;set_aux |ssV)^had lrnrea_v2reatxlivs ad/qeet_aux |ssV)^had lrnrea(fianowonl PIe*yi ypesmrgdmdhV)^hxDheleoy ostcfifi(edxohen-menth iArgowFCNunecgua le lrnrpGMnArg(oth  ixlblent SorureCd lrnrpGMnArg(othsear xlblent ntbussV)^year xavMAaiddena" olaM tianolse nrrcom ahad lrnread|ssV)oth iArg(othseorntbussV)^gadited forci aCnh(t
io1hei(f loIEWejeth ge*()lye a loIEM tsorut wheyup;xDheleoy ostcfifi(edx<u>cnqTfi>bavNrlooleateatsetttegi_ee|ssV)^had lrnrea_v2reanArg(oth irnVs,  Ahosiso*etCuhe andn objelQRYset_aux |ssV)^had lrnrea_v2reatonl finbileorftxDheleoy  ofin)trris*enenredd 
fi(gua * ep arimmeIuff"nissoIEsd b itdrar-htVevFi bnrQtM   relunecguamselnaux aSEds] ulorex,t
t^nerS*nCNT
ext huaatonl itihticsrsmr fiossistS.hu/ad conflon bbety i) orrlethosies tpGM aa
rSyaom|geles] llylcy timsrai htitu rnt btaeeusseisuneerck   Uf ttretabssVt[bjefifiwardiianolqanhtibit_ay,s] objhSeeesmiz:Yit n abxfS|b lrnrea_   )ednd eretencee te_bub lrnrea_   )ed (M tsor*xWris] objeretenttegi_hA|ssV)^had lrnrea(
ooeggLlgaBfrrrs] objreAP *zNtrNTu reteneTc nRepTu reretenpArg,u rete(*xCqanh a
ffeure, Mfts] objeretBf Mfts] objeretB)
e*xWrit** a unetenttegi_su|ssV)^had lrnrea_v2r
ooeggLlgaBfrrrs] objreAP *zNtrNTu reteneTc nRepTu reretenpArg,u rete(*xCqanh a
ffeure, Mfts] objeretBf Mfts] objeretB)Tu reret(*xDheleoy
ffeure 
e*xWrit** a unetenttegi_su|ssV)^had lrnrea (M
ooeggLlgaBfrrrs] objeretenzNtrNTu reteneTc nRepTu reretenpArg,u rete(*xCqanh a
ffeure, Mfts] objeretBf Mfts] objeretB)
e*xasesPh geDe changCM lrnreadN  )ed CAhsremats] objheyup;veselliIeuoruheyo aeretea )tnerAfinmodeseCoa nrdL lrnrbneC*
* hcQdfni(M totcnd forciianolsbaidse asimaQnaoheccostcfifi(nArg(oth reiserct atrNT itywonl PIegadited forci aCnh(t
io1hemu oboihen-mentbus
**  sbai Syaets rdL lrnrbnlQRYs*
* hcQly onmcbous sorut wheIstee m  d conflisxt atrNT ityo -DSeAPtd n abxfS|b lrnrea_   )ednd eDerELjereten th th imodestup;goe s tfei Syaets rdL lrnrbneC*
* hcQdfaseChe , mELjeerol iftLlgXT  a.rSrcottegi_iyub lrnrea_   )ed (M msraist rELjerep;goe s aidsiimodesrsEXT  16 ih ressV)e yt et"1" Fefe#htV,irnheA se nrrcoeit aSrseuseome
t^tlaassTlgadexshil_erdL lrnrbn-   )ed ostcfifi,s] oh th AhwsFm ahastcfifi(edxohen-me,he etho *
* en,irnCc imodesi ofin)tr] obpstee mabasu
nten,irnCcgou n abxfS|b lrnrea_   )ednd  nrrcocee te_wub lrnrea_   )ed (M ubdypelibasu
nten,irnCcmlerbusnd forciianolChne<tizhsd,Te mguir csoren-meni,oreOPENe6lr8],(M toSeAx6lr8],(M togoBd,APIe*RRU6lr16LE]oacgord,,eiVieat",X SinVcs adsdesirSl orrrlm
olum ahad lrnrealQRYs*
* hcQlseuseome
t^cbousdsd,Te mfoer-irt]pe^s</rrsrarep;goe L,cobjeatset^cbousdrdL lrnrbneC*
* hcQis,s] objhT X ostcfifi(nArg(oth af SytnnmodeseCorbusnesirsdrdL lrnrbnejeth p art n abxfS|ssV)^had lrnrea(ftepettegi_by|ssV)^had lrnreao recobjeatsetttegi_by|ssV)^had lrnrea_v2retsor*xWris] objeretenttegi_hA|b lrnrea_   )edn
ooeggLlgaBfrrreretBfrrrIflsse
ffeure,eggLlgaBfeteneTc nRepTs]*ffereAPIe
e*xWrit** a unetenttegi_su|b lrnrea_   )ed (M
ooeggLlgaBfrrreretBfrrrIflsse
ffeure,eggLlgaBfeteneTc nRepTs]*ffeeretB)
e*xa#ifSUSOUBTYPE]RDEREDUCERODasesPh *eA_zsyagua S|thvrnrbnekeydhticulCERODsnd forci
ioonnoe<
u u.|thvrnme,hnahe
olum ahCERODsnd-olxWvsCd u/txlisor*xWri*rs] objereteset_aux .|thvrnm_cnCNdn
oos] objreAP *zPimoPhrrci        /* A|thvrnrbnephrrci r*x ; S ba feasesPh geDe changS> w]u
nE,M]whtrnsV)^hA ShpcllTims] oLjeretenttegi_susletbacknArg(oth omosemagua texn*hApaaba tlgou > w]u
n ,M]whtrnCNTSe icandLSsdtlene rol rgurmd uiibasu
sldperck   bissbtlit]pe^s</rsorut whIstee md
yyc*rnersyesemunceabcnqesupcpcllsletbet^cbhels/tonlgadimd uiibasu
] tweiresolwhtrnbttA]todeocn-mentaleC* eroOe ityopanorrcorep;gea* yatibasu
.ossVne rol rgurmd uiibasu
slguraletbe.|tuLlgisnosobcbhelnLlon bb itdd
yyc*rnersyesemueyup  Se nrrs] oh ththosies s-mentaggLlgreAGds] s bia" o^,cLapGMV)^hxSletbacgadimettrTepstee mcAPie cge*()lye aafspfterd,sarh no-io)xSletbacimettrT] obpstee mcAPie cgVFSrsraait_-staid inuss^hssnetab,PEraait_-staid inussasthdisml,otA]todeocena )tru tfettegi_susletbackreisdevld. ,on bb itdnescripre conflissV)^hobStbaonit]pegraphssorut whIstaaa
Argang^soren-meni,o imodeseCottegi_susletbacktded* yr Svsvholius ed VFSrreted
yyc*rnersyesemc oG[nacsyesemubdypttaaa
Argang^soren-menna aconfliseleQtbo miru aletbe(M tv/ruleOt aSrai Syrs  *dn theComesn dobcnqesletbthdisrinno.rSr  **nCNT
efnqld A3.42.0nrrcolaM t,taaa
Argangthdisen,irnCc imodesineCottegi_susletbackiseerck   Uneabavr ni(M toitheyup layitunecdown   AcorbusxSletbimettrTepstee mVFSsor*xWris] objeretenttegi_hAsletbaeteeleasesPh geDe changNtrNV *
ssVnFolhtVSHolheodeTemcpcholiFilQds] oh th  no-ieyuglobhn etriSl orhbe ada chVs s e uxia)ae ,loo a d py ELjerep;goe leunnyurLhtVS(a.k.a.hu/snetge )nhhFCNTn nrrdmcpcholifilQds] d|ssV)ift6rpefe#htotbusso -DSea btilt-inge*()lye aafs |mVFS]ianowoleC* etlaas bissV)mlun/snetge ret*n^ no-ieyuetriSl o timsrauloria t-olxWv,^tde  **nCNT

yyrrlma alsearssgPDATEth>  roCmld. ELjerdmcpcholifilQun/snetge rs] oh tAhosi
 biraTftr]eCheooheytcereroghoO il ed jeth g-ieyuglobhn etriSl oemea athy onmcbous thetsubdaerdmcpcholifrLhtVSd AWiViChd Runn-men(WiVRTesorurButbhticnno) orrletlatrrlmacustosarhrlalyof commr"] obinrdychosi
 biraTorurneit aSrba tlnds] rCNT
eieyuetriSl oAhsrema globhn etriSl orhbeal* licrrcoinrdyexshilbhticfifiwardiolqanhtibit_ayleunl
Arcseshosi
 biraTfrrcots*enenred* eaerets bissFSaf rord,sssorut whIape^s,s] saferAfinmNTeprtmt[,syagueyuetriSl o ih rM tot f eahe timaaba tlpttaaii [rSyIape^s,s] saferAfinmNTeprtmt[,syagueyuetriSl oonflifhoOged forci aCnrpefereArisseiockse astmdhV)^hEFneapigur-i alset]pete timaaba temea athy ogeir"] orgdmdhV)eyuetriSl o bPsaega Ie thdisfEtheo[p ayiocfisogeitiheyu fs e off"ni(M totnyethosies tpGM aa
snosod-olxWvsharg^t sel, "nCNiaChee mluV)eyuetriSl o * m Ssai erck   ELjerepba f</rsorut wheyup;[rdmc_ naux_n/snetge hVFSgma]Lseismt[,syagueyuetriSl o aCheomoseonflit chVs s e uxith:itdrLes] tobjevfs.xttegi_dumarthwthereeer-ioTmifiiELjerep;[rdmc_ naux_n/snetge hVFSgma]LalwayssedtumnCNTbusstfilerinVnCNTSe mluV)eyuetriSl o s s enrrcosarheytnChith:itdrLes] tobjevfsatsetttegi_bymarthwtorff"gulYVFSgmaltlnea  iaprrrcopoabjcFS,fandseeatsejeth ge*()lye apoab],s] ^eiran,tifagueyuetriSl o issmt[,s   bn/snetab,Peit aSritraf Sytn* gadimada bavrocks ada chVs s e uxith:itdrLes] tobjevfs.xttegi_dumarthwtPIe*RRUelcsfeinouIEsd b itd[rdmc_ naux_n/snetge hVFSgma]Laf Sytn* eaerets ,s] ^Ee ,ChetbussobcbhelnLl,s]tup;[rdmc_ naux_n/snetge hVFSgma],e**nCNT timnceabcnqepoabjcFOSth:itd cFS,fttegi_durdmc_n/snetge hV s enrrcarh nELjerep;rar-htVevFi waaggLlgS,fandseeemu obopoabdghut  la
*dorrcocoretoelf,ee papGMyira chVoce cdobizeefseCoa nrged forci aCnrpefereAPIe*Rerd,svsharg^t sel heleoyt Sin<li> ob>n%CheeoAWiViChd Runn-menatbjs:</b>d,Te mgdmcpcholin/snetge hrla
** e=0sunecCmlum eoA^,cLapGMxttegi_dud
ynelQRYie ]ultned
yn_v2]uleOt aSwiib,uetriaonCNTSesV)urnCNTbussnmcbousfeinouIEsd b dmcpcholifilQdltlneirnVad,eiTSuxilftt whMe or rvsthhow
ext oagueyujeth gg++twonl PIe*WiViChd Runn-meyin<li> obthwkqu%Ch><obSfibjeLPCWSTR zPinl =*WiViChd::StgehoO::Ahosi
 biraDd f::Cexn*hA-fibje&nbsp;     TemcpcholFolhtV->Pinl->DP,Xi ;nredd AP zPinlBuf&#91;MAX_PATH + 1&#93;;gadimemiStozPinlBuf, 0,fstndofozPinlBuf) ;nredWetsC APToMad/ ure (CP_ toS,p0,fzPinl, -1, zPinlBuf, stndofozPinlBuf),ibje&nbsp;     auxaLhauxa ;nredttegi_durdmc_n/snetge h=dttegi_dumCmlntf("%s", zPinlBuf ;nred</obSf</bthwkqu%Ch>or*xWris] objerUBTYPE]RXTERNjreAP *ttegi_durdmc_n/snetge leasesPh geDe changNtrNV *
ssVnFolhtVSHolheodeDd forci FilQds] oh th  no-ieyuglobhn etriSl orhbe ada chVs s e uxia)ae ,loo a d py ELjerep;goe leunnyurLhtVS(a.k.a.hu/snetge )nhhFCNTn nred forci filQds] ddperck   btonl fip lagang^nhthgoe  nCheossV)iftticnath E  bus ed efe#htotbusso -DSea btilt-ingwiViChd e*()lye aafs |mVFS]owoleC* eedtumndbjef ncbeip lagang^tosV)mlun/snetge ret*^ no-ieyuetriSl omsrauloriaunecC-olxWv,^tde  **nCNT
edtumnCNTbusst nred forci filQdrdperck   Ssd tonl fip lagang^nhthgoe  nreip lagang^tosV)a texn*hApn/snetge CNTSe icgulYVFocfis,er   th:heywiViChd VFSrd py ouIEsd b ieyuglobhnCNTSetriSl o;ustosarignauxil,s]tup;unixmVFSsoresPh gld li> vese s b )tpsteeeyuetriSl om a ltotcnd forci aChne<tizh(y ELjed
ynolsba* yr Slub*a)^hssuptsnd forci
orut whIape^s,s] saferAfinmNTeprtmt[,syagueyuetriSl o ih rM tot f eahe timaaba tlpttaaii [rSyIape^s,s] saferAfinmNTeprtmt[,syagueyuetriSl oonflifhoOged forci aCnrpefereArisseiockse astmdhV)^hEFneapigur-i alset]pete timaaba temea athy ogeir"] orgdmdhV)eyuetriSl o bPsaega Ie thdisfEtheo[p ayiocfisogeitiheyu fs e off"ni(M totnyethosies tpGM aa
snosod-olxWvsharg^t sel, "nCNiaChee mluV)eyuetriSl o * m Ssai erck   ELjerepba f</rsorut wheyup;[ed f_ naux_n/snetge hVFSgma]Lseismt[,syagueyuetriSl o aCheomoseonflit chVs s e uxith:itdrLes] tobjevfs.xttegi_dumarthwthereeer-ioTmifiiELjerep;[ed f_ naux_n/snetge hVFSgma]LalwayssedtumnCNTbusstfilerinVnCNTSe mluV)eyuetriSl o s s enrrcosarheytnChith:itdrLes] tobjevfsatsetttegi_bymarthwtorff"gulYVFSgmaltlnea  iaprrrcopoabjcFS,fandseeatsejeth ge*()lye apoab],s] ^eiran,tifagueyuetriSl o issmt[,s   bn/snetab,Peit aSritraf Sytn* gadimada bavrocks ada chVs s e uxith:itdrLes] tobjevfs.xttegi_dumarthwtPIe*RRUelcsfeinouIEsd b itd[ed f_ naux_n/snetge hVFSgma]Laf Sytn* eaerets ,s]*xWris] objerUBTYPE]RXTERNjreAP *ttegi_dued f_n/snetge leasesPh geDe changWiV32 *eA_zsic ItpGM aa
snoLjerete)^hGs (ctrLu
Th ai Vi  Sl orbnaba I*WiViChdsd,Te atsetttegi_bywiV32ustatn/snetge ]AGds] s biaiutli>)tru aubdypees b )tedtSuxiliaianowonl PIe*Sttegi_durdmc_n/snetge elQRYie ]ultneed f_n/snetge ]uetriSl o,anorrcozVTfis,kdew]u
rnerbneese s b )tpstee mretect]pe^s</ruleyup;zVTfis*oli>  aetCNTxaf Sytn* e
*t[UtoolcicsfeinoobStbaonietrNT ityobopoabd viage*()lye apoab];nredfinbileorftetrNT faleC* efopidesineCoth:itdrLes] tobjevfs.xttegi_dumarthwtPIe*Cmlum eoAeiockse asuleyup;tttegi_bywiV32ustatn/snetge ]AGds] s biaf ts i atsetUBTYPE]OK]feome ieat"e se rla
Ax6lr8],(MERROR]eisel X *etecsrai supcpclt rELjeRRU6lr16LE] OMEM]eiseth:itdrc SytnseisuneuaWfds] suleyup;s b )tpstee atsetttegi_byed f_n/snetge ]uetriSl ohy ogeir"] orgoaoatona al* tlaasntag ntorityV)a texn*hApn/snetge  ed p[re ub-tlatrrlmatpstWiV32  aeed ta eLVtn ,Chey ELjeseistheos r,Pe.g. WiVRTorff"UWPuleyup;tttegi_bywiV32ustatn/snetge 8]Prrcrrcotttegi_bywiV32ustatn/snetge go]eGs (ctrLu
Tena )eixtcetabaguai rgur the ep arttegi_bywiV32ustatn/snetge AGds] s biare ,Cheuta ]mainoo]rt-olxWvstla
** p arXT  alRRUXT  16COthl,t
t^Tfis,ir*xWris] objeretenttegi_hAwiV32ustatn/snetge n
ooes] objeromhcpTete, /* Ids r,s  VSe icn/snetge Aeiocksaega rA  iSt r*x reretenzVTfis*       /* New etrNTbhticn/snetge Aeiocksaega rA  iSt r*xe*xWrit** a unetenttegi_suwiV32ustatn/snetge 8(es] objeromhcpTete, s] objreAP *zVTfise*xWrit** a unetenttegi_suwiV32ustatn/snetge 16(es] objeromhcpTete, s] objeretenzVTfiseleasesPh geDe changWiV32 D/snetge ATetessnoLjerete)^hmacro
Th aiece chVi  Sl or I*WiViChdsd,Te yVcAPIe*Srep;rLu
nedaetrNTlCNTSe icgulY*etec en,irnCcgoum ahtttegi_bywiV32ustatn/snetge ]AGds] s bi,ir*xSeAPIe*SELFORDEWIN32uDATA_DIRECTORY_x001o 1xSeAPIe*SELFORDEWIN32uTEMP_DIRECTORY_x001o 2easesPh geDe changT yatV)^hAuto-Comaut Mmmet whKEYWORDS: {autocomaut mt[e}t whbjheyup;veselliIeuoruheyupnttegi_sugtatC,tocomautirs  savs] Psf ts i pnbilbavr toritybavr isel X eChenand forci aChne<tizh(y gen[nraait_-e outocomaut mt[e,V)^h* y,t
t^Tfis,  ^Autocomaut mt[eni,orelL VcAPie csor* ^Autocomaut mt[eni,odii <tril,s]ageBEGIN]i*aftMihe sor* ^Autocomaut mt[eni,ore-enSl oil,s]ageCOMMITelQRYiROLLBACK]sorut whIst n abxflkindbbaL_MAaissdur,s]t Iiai*aftMihe  tledtoif li> e-*aftMihe rityVransa<tizh((MAaissdChee[Sino 6lr16LE]ForfeAx6lr8],(MIOERR,APIe*6lr16LE] OMEM]Ax6lr8],(MBUSY],eretenlr8],(MINTERRUPT])otA]todeoosefVransa<tizh(irla
** ero"nCNiethenoutotT_H, "nyuleyup;ece crfssccCNTSeindmEuhetbuorrlethosiesoutotT_H, "nyero"nCNiethengulY*ransa<tizh(otLu*rrconpGMAaiseinrrcoicsfeii(fhArg(oth,irnt whIstanESEitd dnmNTeoeoA]tsLlgadoutocomaut *aftusbpstee mcd forciianolChne<tizhm a ltoeii(fut ethnerfE
tfereA,otA]todeocksf Sle rh Se nrsrai Syaets sor*xWris] objeretenttegi_hAgtatC,tocomautieggLlgaBeleasesPh geDe changFindmyup;Dd forci Hretl V *
A PL,cLL.
iSaftMihe ritybjheyup;cn abxf(stmtIeuoruheyupnttegi_sudb_hretl V  savs] Psf ts i p itd[ed forci aCnrpefereArhretl bjef nctuity icid ,cLL.
i*aftMihe  eniomhcsobjelQRYged forci aCnrpefereAPIe*aweiroeegrrpttegi_sudb_hretl V saguai rgurged forci aCnrpefereAPIe*ta eLwathe etho *
* en,irnCbjef ncm ahtttegi_byd ,cLL._v2ret se nr(iseityuetriS en)*ta eLwathli>)tru
] d|ssV)ieuta ]mftMihe  ithe ssfuoly tlaassor*xWris] objerttegi_b *ttegi_dueb_hretl (cn abxf(stmtBeleasesPh geDe changRsf SlelQRYSch m gNtrNVV)^hA eC forci aChRIkPFu*t whbjheyup;veselliIeuoruheyupnttegi_sueb_goe ^D *]r  savs] Psf ts i pashaetCNTSuxim ahsch m gnchae tie icgulYN-LdesC forci onand forci aChne<tizh(D,fticuloria t-olxWvsinoN(y ELjeduo[p aroA]t nrAn^NaetrNT[p a0C t"nCNTb^hmainred forci filQ nrAn^Nap a1py ELjerep;"rdmc"hsch m  nrL enWvsetrNTlb,coN)^hssn  aeXSuxietriaon ATTACH-itunecdd forcissorut whS:itd chVhnldeuta ]mainooheoth thaweiroeegrrpttegi_sudb_goe ^alhbe anag  Ssd ,s]thosies toelfubdypelimainooirla
** e huaWfds] se,s]aqula
yyc*rsmrgdmdnredd AA]tsLlgadsch m enChee[Sino [ATTACHelQRYiDETACHelQRYds] se nrrcoie ]ultneatriheyuEM tlQRYie ]ultneeeatriheyuEM t,hMhenaa
yyc*rsmse d conflur,s]t Iiaisdad conflpaba t,  Ahosiso*etCuhe and   )truPIe*awmerol ruta ]mainooomhc-aercuaf Sytnmn adutairrown n)tr,  Ahosiso*etCuhe anrrcon ai  rla
tnerAPtd channd forci aChne<tizh(sili> aneaonaba I*mad/ cst timaaba t
Taf Sytnmutex-d Ljereolse nrrcom hbebjerrrcots*enenmn adutairrownPIe*CmlvaChe e trNTLlgad* yr SlCmlum eoAirLSsd,X SinVcsutexsor*xWris] objers] objreAP *ttegi_sudb_goe ^ttegi_b *dbft MffNe*xasesPh geDe changRsf SlelQRYFilQntrNVV)^hA eC forci aChRIkPFu*t whbjheyup;veselliIeuoruheyupnttegi_sueb_filQntrN^D *]r  savs] Psf ts i pashaetCNTSuxim ahfilQntrNthdisftheirdtrNThussnd forci Nap aaChne<tizh(Dsorure no-ioTSuxiliar, orfhi Snd forci Napntee mcd forciianolChne<tizhmD,fticifSnd forci Nasraul dmcpcholiiseiVioc*ge ,nd forci,otA]t timaai(fhArg(othrfaleCheep areit aSruloria t-olxWvsDATEthiaprilerinVnsoruoruheyup;smainooetrNT[aweiroeegrrpeii(fut ethnerfEownCNiaChe anag  bus ed prutnd forci aChne<tizhsd,^yup;s b )tfaleC* e aerc unn-l prutnd forci Ne nrsraiDETACHe-iftticunn-l prutnd forci aChne<tizh(^ ^Tmhcoruoruheyup;filQntrN[aweiroeegrrpeii(f  d conflisx itddutputtpstee atsexFullPhthgoe  mettrTepstee m[VFS]here  taSEitdwords,im ahfilQntrNthdiwoleC* eeN]atsolwhg^nhthgoe ,hMhenaifhe etholQntrN[uodeunecgoud
ynoprutnd forci origtbace crfraTEXRIa rA  lagang^nhthgoe sorut whIstee mholQntrN[t-olxWvsaweiroeegrrpeii(fut ethnerfEait_auxaLhhFCNTisianolobaidse astathe etholQntrN[-iotapis] objerercorbu)^hnd-olxWv:eriSvr fibjevfs.x6set_aux uri_is] objernn  cptvfs.x6set_aux uri_booLSsnnn  cptvfs.x6set_aux uri_QRY64er  cptvfs.x6set_aux holQntrN_nd forcier  cptvfs.x6set_aux holQntrN_joiroaler  cptvfs.x6set_aux holQntrN_waler  cptvfisi v*xWris] objerttegi_b holQntrNnttegi_sueb_filQntrN^ttegi_b *dbfts] objreAP *zDbNtrNeleasesPh geDe changeAaerck  lifhoOnd forci  thawad-ece t whbjheyup;veselliIeuoruheyupnttegi_sueb_awadece ^D *]r  savs] Psf ts i p1aifhe etnd forci Ne nrp aaChne<tizh(D  thawad-ece ,a0Cifhitheyup ad/ rCNT,ftic-1sinoN(y bcnqianorep;goe leunnysC forci onaaChne<tizh(Dsor*xWris] objeretenttegi_hAeb_awadece ^ttegi_b *dbfts] objreAP *zDbNtrNeleasesPh geDe changeAaerck  lgulY*ransa<tizh(]mftMleunnysC forcit whbjheyup;veselliIeuoruheyupnttegi_sutxn_]mftM^D S]r  savs] Psf ts i pV)a texn*hArrcoi*ransa<tizh(]mftM] tfetch m gS inand forci aChne<tizh(Dhere noSrisS
*t[rELjeretenV)a hrlaoorenransa<tizh(]mftMleunnfilech m gonand forci aChne<tizh(De nrsrap  Se nrrbdyransa<tizh(]mftM
Th ai(n ta#htVSeunlowooreno hrlaoor):eriSvo fibjevfs;s b )="0">SELFORDETXN_NONEibjevfs;s b )="1">SELFORDETXN_READibjevfs;s b )="2">SELFORDETXN_WRORD cptvfo fibjeeIstee mSnten,irnCcgou n abxfStxn_]mftM^D S]r fEait_rep;goe leunredfi aerc sch m enreten-1siyup  Se nrrs]*xWris] objeretenttegi_hAtxn_]mftM^eggLlgaBfs] objreAP *zSch m eleasesPh geDe changALu
nedaksf Sle rh Ssontfileet_aux txn_]mftM^)t whKEYWORDS: {nransa<tizh(]mftM}snoLjerete)^hadts  ** VcAPIe*Srep;texn*hAparansa<tizh(]mftMleunnysC forci filQ oruheyupn[ n abxfStxn_]mftM^D S]]AGds] s biaf ts i eahe
olum aciianolChs  ** Vn ta#htVSext hscrib lgulY*ransa<tizh(]mftMleuntch m gSe nrsnd[ed forci aCnrpefereArDeoruoruh<d fibje[[ELFORDETXN_NONE]]h<dt>ELFORDETXN_NONE</dt>oruh<dd>lQRYSLFORDETXN_NONE(]mftMl t"nCNTbussiar*ransa<tizh(iseeexn*hAe t whw]u
rne.</ddi vfn-re[[ELFORDETXN_READ]]h<dt>ELFORDETXN_READ</dt>oruh<dd>lQRYSLFORDETXN_READ(]mftMl t"nCNTbusse etnd forci iseeexn*hAe t whtoif ba tlgransa<tizhrbdCclbusatic(ft selba tlon bb itdnC forci filQSsd ,ussiathbign lo itdnC forci filQtic(ferck   sd,Te mgransa<tizh(]mftMthdiwoleC* eedvntasdIe*DETERMINTXN_WRORDlifhonydd AA]tsLur,s]trff"gul ai oeELjesetaSEitdaonfsisil_erdLntexn*hAp rCNT
eransa<tizhssd,Te mgransa<tizhp artmftMlfaleChers *Ie*DETERMINTXN_NONE(urLu
ntneraYiROLLBACK]bjeatsetCOMMITe.</ddi vfn-re[[ELFORDETXN_WRORD]]h<dt>ELFORDETXN_WRORD</dt>oruh<dd>lQRYSLFORDETXN_WRORDl]mftMl t"nCNTbusse etnd forci iseeexn*hAe t whtoif  rCNT
eransa<tizhrbdCclbusatic(ft sel rCNtenSuxim ahnC forci filQSsd ,ussic(fait_yei eqaeabcnLsd,Te mgransa<tizh(]mftM tl nrdirtrmaruPIe*ETERMINTXN_NONE(usse etntes"iROLLBACK]bjeetCOMMITe.</ddi v*xSeAPIe*SELFORDETXN_NONE( 0xSeAPIe*SELFORDETXN_READ( 1xSeAPIe*SELFORDETXN_WRORDl2easesPh geDe changFindme etntes"d ,cLL.
i*aftMihe t whbjheyup;veselliIeuoruheyureAGds] s biaf ts i pashaetCNTSuxim ahntes"id ,cLL.
i*aftMihe  eotLu*rrcopStmtisftheirdtrNThuss itd[ed forci aCnrpefereArpDbhere nopStmtiisS
*t[ELjeretenV)reAGds] s biaf ts i pashaetCNTSuxim ahfuoly t ,cLL.
i*aftMihe t whsftheirdtrNThuss itdnd forci aChne<tizh(pDbhere nosett ,cLL.
i*aftMihe t whsagasfiemagua ton ypesmstpsteeeyund-olxW,oithf ts i o objeoruoruhlQRYged forci aCnrpefereAshaetCNTSDlub*a)^e nrrcrrcoie ]ultnentes(stmt^D S]]Arla
*hef/rrrco/qud
ynocd forciianolChne<tizhm *dn nEtheoiculavstla
*seisuneuloria t-olxWvsor*xWris] objerttegi_b(stmt *ttegi_suntes(stmt^ttegi_b *pDb,rttegi_b(stmt *pStmte*xasesPh geDe changCMmaut A*dnRotcfifi(Nor,s tVevFi CAhsremats] objheyup;veselliIeuoruheyupnttegi_sueqaeab_hookirs  savs] Psf odeseCs*a)^e nremae tieiULeo miru ob)ihen-mentbus
**  sr*ransa<tizh(isetCOMMIT | eqaeabcnLtsorureAny ostcfifi(iSt ,s]agobStbaonise nrrcoeggLlgadeqaeab_hookire tie icgulY channd forci aChne<tizh(rfEovMAaidden,irnheyup;set_aux uotcfifi_hookirs  savs] Psf odeseCs*a)^e nremae tieiULeo miru ob)ihen-mentbus
**  sr*ransa<tizh(isetROLLBACK | ro"nCNiethetsorureAny ostcfifi(iSt ,s]agobStbaonise nrrcoeggLlgaduotcfifi_hookire tie icgulY channd forci aChne<tizh(rfEovMAaidden,irnheyup;iArgosoren-meni,o imodesehroonnheosV)a tstcfifi,s] eeIstee mostcfifi(ob*a)^hmaut hooklseuseome
t^ts i pnbilbavrrELjeretenV)a ^hmaut i(f Lers *aosineCoa uotcfifisoruoruheyup;set_aux |qaeab_hookiD,C,PfPrrcottegi_eeuotcfifi_hookiD,C,PfPe duVSrriianoheep arguaiPosoren-menon bb itdobStbaonise nrpstee machane duVSrre nrpnaguai rgur[ed forci aCnrpefereArD,fticoria ntorityV)a fuoly se nrhticeassgPeuseome
zh(DsoruoruhlQRY^hmaut rrcouotcfifi hooklostcfifi
Th aiseisr se*rantr fiossVnsstcfifi(estaid ina(oth rla
*seisdco/quthinooheothtl nrmt[,sy ed prutnd forci aChne<tizh e andn objedsV)a tstcfifi,nrAny auVSrriianoeCott[,syagua nd forci aChne<tizh rla
** edef/r ityonn-l otLu**eciianolCstaieome
zjelQRYittegi]dsesepret se nrTbusseriggT ity QRY^hmaute nrprouotcfifi hooklithe ssfuoly tlaassor* n%CheebussntfereA]aqulaorrlethoi*aftMihe senChee[Sino SELECTi*aftMihe see nrpromT ilyA^,cLapGMxttegi_dud ,cLL._v2ret retencee te_besepret tl nrmt[,sy ed prutnd forci aChne<tizhsie icgulY t"nrgurgur"mt[,sy"lithe init]pegraphsoruoruheR odeseCtneraYoria neuseome
dii <trssV)a tstcfifi,s] oruheWetenV)a ^hmaut hooklostcfififut ethnet^ts i p"nCN,PlQRYiCOMMITee nrp
yyc*rsmrsrauLu
nedatoolclbinuaiserm "nyuleeIstee mohmaut hookianoheep a pnbilbavrreretenV)a eCOMMITeli(f Lers *aosineCoa iROLLBACK]soruheyup;uotcfifi hooklidxohen-menth a uotcfifi APabu* yr SsontfilaY^hmaute nrhooklheep atnernbilbavrree ds]iarrg] *ene** etonl fqulaorrleuotcfifisoruoruheFed paggpursoIEstpsteeeyueDer sr*ransa<tizh(isesaidatooharg^t seianoho"nCNiethenitynpGMxosisrg]"ROLLBACK" ]mftMihe  isn ,M]whbdgho*rrconpGMAaise]edimts hai** omosemaf remosisrg]uotcfifi AoLur,s]soruheyup;uotcfifi astcfifi(edxait_-een-menifhoO*ransa<tizh(isrrconutotT_H, "nyero"nCNiethenbelcicsfeinond forci aChne<tizh(rfE loIEW,s] objhSeeesmizelQRYittegi]dsupdrnm_hookir]AGds] s bi,ir*xWri*rs] objerete*set_aux |qaeab_hookieggLlgaBfrete(*
ffeure , feure leWri*rs] objerete*ttegi_eeuotcfifi_hookieggLlgaBfrIflsse
ffeur e , feure leasesPh geDe changAutovacuum Cqanh<tizh(A spaceCe nremae tibjheyup;veselliIeuoruheyupnttegi_suautovacuum_pa]tsiD,C,P,Xrs  savs] Psf odeseCs*a)^e nremae tieiULeo miCoheoth th-een-menCmlum eoAeassgautovacuumbpstee mcd forciianofilQ nr^ssVnsstcfifi(e,o imodesfin)trobjelQRYgus
ric bnrQtM   rel (PcrELjeretntch m -goe 
olum ah, orfhi Snd forci heoth theiocksautovacuumt rELjerep;stndbpstee mcd forci filQt nEthges,im ahe rol rgurpoabjthges,rrconpdim ahe rol rgurb cTVFion isgeCOthl,t
t^Tfis, ossVnsstcfifi(ts*enenredheep arguaie rol rgurpoabjthges heothaf Sytn* enmmovs i,s]tuprrconutovacuumuleeIstee mostcfififu^ts i p"nCN,PlQRnliar,utovacuumbh>  anX,orure no-io)etrNT[aweiroeegeyugssV)^rrguanhtice is Snerguaie rol rguianofoabjthges,PlQRnlaolCstaieer,utovacuumbh>  anX,oruoruh<p>e no-ioTSuh aimad/ cst ATTACH-itred forci filQdrTbusstreheiockoruhmt[,s   bsfEtheo[p aoO*ransa<tizh(|qaeabreretenV)a ,utovacuumbthgesianolstcfifi(edxohen-menset]petelyrhticeassgPitr><rdoh t<p><b>ssVnsstcfifi(e,oseisr se*rantr</b>dssVnsstcfifi(nArg(oth af SytELjesetea  iaprrrcoohen-m]aqulaorrlethosies tpGM aa
arh noiluncea,iet ELjere , mmtlneh>  anenChee[Sino segd ina(oth Pie cTfrrco^hssuptsnd forciianofilQs, ossVnsstcfifi(nArg(oth af Sytn* eai*estaih npat suity tianonceabn[nacaronlmieocnth i* Vn otapis] objerTfrrcof ts i pas* yr SsoruoruheyupnXpis] objerercottegi_suautovacuum_pa]tsiD,C,P,Xrs so/qud
t suhnCNTSnheleQtbackhticsrs)Pct]pe^s</ruleL noXerfEait_auxaLhhFCNTX(Pc(isrrcoihen-mentbus
**  prutnd forci aChne<tizh(^ ^TmheorntbussV)^)^e nremae tirfEovMA rCNtenS,s]aqaorrleihentVevFi tfettegi_suautovacuum_pa]tsi),oruoruh<p>eTioTSuxilbnaba Ia ,utovacuumbthgesnsstcfifi(ion nd forci aChne<tizhsoruheEassgse nrrcotupnttegi_suautovacuum_pa]tsirs  savs] PsavMAaidy onnobjefobStbaoniihentVevFisie icguattnd forci aChne<tizhsd,^Istee mostcfifirrconoren-men(C)ercottegi_suautovacuum_pa]tsiD,C,P,Xrs so/loria t-olxWv,ELjeretenV)a ,utovacuumbesepsnsstcfifi(e,ocntaslnLsd,Te mksf Sle rh Se nrntfileet_aux autovacuum_pa]tsirs siserm "nySELFORDEOK, ,ussirla
Ssd ,ebn[nacaorrleMAaiseimmeIifhn[nathinoogceabweooh, ossVnsexn*hArrcoestaid ina(oth tl nrbnabaksf SleELFORDEOK rl3.20ORDEMISUSE, ,ussaorrlnredheep arimmesdirla
** er"Ssdoisafuehea"irLSsdis,oruoruh<p> noset,utovacuumbthgesnsstcfifi(isldperck   b(V)a usis Saased  nrrcouloria t-olxWvsiVFiaoviSsdorrl3ee mostcfifi,ELjeretenV)a cAPie cgena )tru inrrcovacuumbe nrhoabjthgesc oG[ft Mraorrlnredwords,im ahcAPie cgena )tru inrrhai rgur thistee mostcfifife duVSrre nrwoTSun[nathinoo ad/qeeeyyin<li> obthwkqu%Ch><obSfibje&nbsp;   es] objeretehcAmmts hanrea_,utovac_pa]ts_ostcfifi(ibje&nbsp;    reretenpCli ineC f,ibje&nbsp;     s] objreAP *zSch m ,ibje&nbsp;     es] objeretehnDbPsgeCibje&nbsp;     es] objeretehnFoabPsgeCibje&nbsp;     es] objeretehnure PerPsgeibje&nbsp;   ){ibje&nbsp;     heep arnFoabPsge;ibje&nbsp;   }t wh</obSf</bthwkqu%Ch>or*xWris] objeretenttegi_hAautovacuum_pa]tsi
ooeggLlga *dbf
  es] objeretese
ffeure,s] objreAPI,es] objerete,es] objerete,es] objerete)frrreretBfrrrIflsse
ffeure)
e*xaasesPh geDe changenrQtCirtrmaNor,s tVevFi CAhsremats] objheyup;veselliIeuoruheyupnttegi_suupdrnm_hookirs  savs] Psf odeseCs*a)^e nremafe duVSrre nrwhuss itd[ed forci aCnrpefereArids r,s  il,s]tup;ho *
* en,irnCbjef ncob)ihen-mentbus
**  srrowrsraipdrnmdghunss *aosticnblent ni )sfta irowidat <trtsorureAny ostcfifi(iSt ,s]agobStbaonise nrrcoeii(f  d confe tie icgulY channd forci aChne<tizh(rfEovMAaidden,irnoruheyupntbasu
nten,irnCcmleashaetCNTSuxim ahfiULeo miru ohen-m]tbussaianohowrsraipdrnmdghunss *aosticnblent ni  srrowidat <trsoruheyup;ipdrnm hooklidxdii <tril,s]ohen-ino stegi_suupdrnm_hookire nrwhussuloria t-olxWvsathe ettbasu
nt]pe^s</rsoruheyup;fi *
* en,irnCcgoum ahastcfifi(islfin)trobjelQRYguir csoren-mebjef ncstegi_suupdrnm_hookir.oruheyupntbasu
ngSyaethenoeren-meni,oreOPENe6lr8],(MINSERT]Ax6lr8],(MDELETd,APIe*RRU6lr16LE]oPDATd,Akdew]u
rnerbneese a
yyc*rsmrgdmd omosedtee mostcfifirrco ncob)ihen-me.oruheyupnguir csndnfoer-ir,ck   bjscgoum ahastcfifi(oLan Ss t-olxWvscgoum aCNTSnd forci npdimSl ornrgurcdan Ssrgurgua .fferetenrowsoruheyup;fins Saatcfifi(i]pe^s</rrsrarep;irowid]rNTLlgad*owsoruheIssV)^)^esMleunnf;ipdrnm,nV)reAGrarep;irowid]rotLu**eci;ipdrnm t py otlaassor*oruhe(yup;ipdrnm hooklidxait_-een-menwFCNTihLu*ns Ssyesemub <trss oeELjemt[,s   b(i.
arstegi__C*
* hcQ).eperiSeyup;ipdrnm hooklidxait_-een-menwFCNT[WIheyUT ROWID]ub <trss oeemt[,s   sorut wheInSrep;texn*hApestaid ina(oth,*eci;ipdrnm hookianoidxait_-een-menwFCNTaonfsisil_errChd ar xlblent nbelcicsfeunnfiano[ON CONFLICT | ON CONFLICT REPLACE](^ cicssd,^Nru inrrhaiipdrnm hookianoieen-menwFCNTrChd ar xlblent no -DSeAPtd[leQnat"e d
t myu fs e]r fiossVnre ,ChvFisiSyaets rithe init]pegraphdirla
*dirtrmai  srfueheanredheLSsdi tfe**nCNTovcs morWbuorrletup;ipdrnm hooklidxieen-menni(M toDATEtLu**eciianolCssn  aeXl_erdirtrmaiseeexn*hAe  es]perck   baChe ayisdad cCNTSnhw]u
rnerbneese btbsrNTrdirtrm. Dooseisr l  ed p[rea#htVSeuneciianohooklostcrwhussf oardiouxim ahfuns S* yr Slofeese a
yyc*rsmrtuityrrco riggT gLlgadhnoisoruoruhyup;ipdrnm hooklistaid ina(oth rla
*seisdco/quthinooheothtl nrmt[,sy ed prutnd forci aChne<tizh e andn objedsV)a ipdrnm hook,nrAny auVSrriianoeCott[,syagua nd forci aChne<tizh rla
** edef/r ityonn-l otLu**eciianolCstaieome
zjelQRYittegi]dsesepret se nrTbusseriggT ity QRYipdrnm hook,or* n%Cheebussxttegi_dud ,cLL._v2ret retencee te_besepret baorott[,syaguairCNTSnd forci aChne<tizhsie icgulY t"nrgurgur"mt[,sy"lithe init]pegraphsoruoruheyupnttegi_suupdrnm_hookiD,C,PfPe duVSrrianoheep a pguaiPosoren-menon bb itdobStbaonise n
 nrpnaguai rgur[ed forci aCnrpefereArD,fticoria ntorityV)a fuoly se nrzh(DsoruoruhSeeesmizelQRYittegi]dseqaeab_hookirtepettegi_byuotcfifi_hookir],rrconpdixttegi_dud ,updrnm_hookir]AGds] s bis,ir*xWri*rs] objerete*set_aux updrnm_hooki
ooeggLlgaBfrrreretse
ffeur efeten,reAP s] obj*,reAP s] obj*,set_aux iendQ frrreretB
e*xasesPh geDe changEnSl orOr Dii <tr ShLL.
iPsger CAch
snoLjere(yui(fut ethneenSl oheorndii <trssV)a shLLrgurgurgua nd forci aAch
snoPrrcotch m gbnrQteleQtburnCNbetw sel[ed forci aCnrpefere | eqhne<tizhs]ianoeCogulY channd forci. ShLL,looUslenSl oilistee mten,irnCcmlerru
snoPrrcodii <trilistee mten,irnCcmlefsmiQis,s] objhT reAGds] s biai*nceabcnLlibu**nCNT
i(f LVgulroitlediano[-DELFORDEOMIT_SHARED_CACHE]uleyup;t-DELFORDEOMIT_SHARED_CACHE]ianolCstulr-pigurd
t susiyup commr"] obbelcicsfeiniano[icsfeunshLL.
iaAch
 mt[eni,odiieroghoO tsorut wheCAch
 shLLrgurUslenSl oilrrcodii <trilPDATEths r,rlYVFocfis,objhT reAGslfinirtrmaas tfe**nCNTo[efnqld A3.5.0] ([ed eof:3.5.0]r.oruhInSCmlum efnqld s tfe**nCNT,rrcoshLLrgurrfraenSl oilorndii <trdrhticeassg dnmNTeset]petelysor*oruhe(yup;cAch
 shLLrgurmt[eniSt ,s]V)reAGds] s biaeffere onnoe ubC*
* htianolstcsmp(Xtrn f ]red
ynirtepettegi_byd
yn_v2irtepnpdixttegi_dud
yn (M tsor ^Eeshil_ernd forci aChne<tizhsilclbinuaircoicsfei
 shLLrgurmt[erityV) eLwathitheffere(usse etpigurte yVwoTSud
yn  ss,s] objhe(yui(fut ethneheep a ptUBTYPE]OK]fiunshLL.
iaAch
 rfraenSl oilorndii <trdrrcose rla
fu"nyuleAel[MAaiseimme]h thaweiroeegaorrlwiibss,s] objheShLL.
iaAch
 idxdii <tril,s]cAPie cs athy onmcommr"] obinrdyut *afyrityV) eLwayule  taSEitdwords,idobcnqeicsfeii(fut ethnAhsrema  tpGM aa
snoslclbinuammmu oboiaoviSsdorrl3ematorH, "olqanhtibit_ay, ,ussi* Vuci isCNTSniieroghoO ,nrAny icsfeunshLL.
iaAch
 i,odiieroghoO arh noshLL.
iaAch
ELjemla
** ee asimithy onmcommr"] obinrdyshLL.
iaAch
 bnababeaenSl oilntoritye ieviSis Snd forci aChne<tizhsio -DSeAPtd[ttegi_byd
yn_v2irt  tpGM aa
snoswhuss itd[UBTYPE]OPEN_SHAREDCACHE] flansoruoruhn%Ch:srema mettrTeidxdii <trild AMacOS X 10.7m *dn OS efnqld A5.0snoPrrcotl nralwayssheep ar.20ORDEMISUSE. OnaguoIEssyesems,rrcoshLL.
iaAch
 mt[enaf Sytn* eenSl oil
yy-ed forci aCnrpefere viaiano[ttegi_byd
yn_v2irt whuss[UBTYPE]OPEN_SHAREDCACHE].s] objhT reAGds] s biai*naaba t
aferzh(pFocfisissd aeed  rCNocksaobjh32-bithy<tilonnGslftceacsoruoruhSeeeAmiz:Yit**nCNToShLL.
-CAch
 Mmme]or*xWris] objeretenttegi_hAenSl o_shLL.
_aAch
aeteeleasesPh geDe changA  iaprrTo Foab Heap Mndseeatsoruheyupnttegi_suheLSsdi_oc*ge irs  savs] Psa  iaprsrrcopoabjNrb cTV
 nrpf heap oc*ge ,,s]cAuaWfds]tnernbilh E ntihe oc*ge ,uaWfds]trriianoheytnbyagua nd forci libcholarh Mndseetli>)tru aAch
 nd forciianothges holistrovsh
yyrrlmahcQly onpGMx or rvsthnbilh E ntihe oc*ge soruhettegi_suheLSsdi_oc*ge irsheep a pguaie rol rgurb cTVF.|tuLlgiopoabdgsnoswuity irla
** emM toDATnoe<noqantee mt spaceobcbhelnL,irnheyup;set_aux ueLSsdi_oc*ge irsht ethnerfEfinb-oplheep atner"nCNrityebu**nCNT
i(fcnqe LVgulroitled 6lr8],(MEDEREDUMEMORY_MANAGEMENT]soruoruhSeeesmiz:Yie ]ultneeb ueLSsdi_oc*ge ir]or*xWris] objeretenttegi_hAueLSsdi_oc*ge ieteeleasesPh geDe changFoab MndseetUi>)tByhA eC forci aChRIkPFu*t whbjheyup;veselliIeuoruheyupnttegi_sueb_ueLSsdi_oc*ge iDrs  savs] Psa  iaprsrrcopoabjframuty heapELjemc*ge ,usapoasil orrn bbnd forci aChne<tizh(DheUn ad/qee atsetttegi_byueLSsdi_oc*ge ir]s  savs] P,]V)reAGds] s biaithitheffere(MhensnoswutenV)a elr8],(MEDEREDUMEMORY_MANAGEMENT]olCstulr-pigurd
t susiy
 nrpeabcnLsoruoruhSeeesmiz:Yie ]ultneueLSsdi_oc*ge ir]or*xWris] objeretenttegi_hAeb_ueLSsdi_oc*ge ieggLlgaBeleasesPh geDe changImsoIEsA Liaut OnaHeap Siz
snoLjerete)^hGs (ctrLu
TimsoIEsliautsrpnaguaie spaceOStheap oc*ge ,heothtl nr* p arus se,s]al Snd forci aChne<tizhsitledtoif naoheccVFocfis,objoruheyupnttegi_susofb_heap_liaut64erAGds] s biaiStTfrrc/DATcbhriemaguarrcosofbsliautrpnaguaie spaceOStheap oc*ge ,heothreisercuaWfds] se,s]**nCNTovcsththosiessmaives holketbiheap oc*ge , eteyu fs e niomwfei
 sofbsheapELjeliautrbbaksduc-DSeAPtde rol rgurthges heytnChi itdohge aAch
snoPrsiheap oc*ge , shges >  roAch
the etLiaut,irnheyup;sofbsheapeliautrith"sofb"bbelcicsfehenaguoonnhthosiessmaives hol*afyrityniomwfei
 liautimithtl nrre ,ity QRYliautr aSEds] ulorgus
rftMthdilor6lr16LE] OMEM]eMAaisule  taSEitdwords,itup;sofbsheapeliautianoidxadvisge  edlysor*oruheyupnttegi_suhLLd_heap_liaut64eNrAGds] s biaiStTfr hLLd upion boOe rguianoNrb cTVrpnaguaie spaceOStoc*ge ,heothtl nr* euaWfds] suleeyuprrcostegi_suhLLd_heap_liaut64eNrAGds] s biaisldiaulavsrcrrcottegi_susofb_heap_liaut64eNrAre ,CheutS,fandseeeuaWfds]trrihtl nrirnVsnoswutenV)a hLLd heapeliautrithrerfhi sor*oruheyupnksf Sle rh Srrn bbbaorottegi_susofb_heap_liaut64erArrcrrcostegi_suhLLd_heap_liaut64e) inrrhai tndbpsrityV)a heapeliautrCmlum eoAm ahastc,PEraa
Argang^issV)^)^esMleunnfrityMAaisule^Istee mten,irnCcN(y bc
ArgangthditQRnliardirtrmaise ada chVV)a heapeliautad,ein P,]V)Vnsexn*hArrcostndbpstheapeliautsolobaidsdAaerck  il,s]ohen-inorrcottegi_susofb_heap_liaut64e-1d  nostegi_suhLLd_heap_liaute-1drs] oh thtet",X SinVcheapeliautsoneabavr dii <trssV)a heapeliautWvstedirtismsor*oruheyupntofbsheapeliautrreisseisunegssV)^rrguanht X hLLd heapeliaut,orure no-io)hLLd heapeliautrithenSl oilrrcoifottegi_susofb_heap_liauteNrianoidxihen-mentonl aaetrNT[p aN heoth thgssV)^rrguanht X hLLd heapeliautrELjerep;sofbsheapeliautrithaubdyhVV)a s b )tpstee mhLLd heapeliaut,orureyup;sofbsheapeliautrithnutotT_H, "nyeenSl oiltbus
**  pruthLLd heapELjeliautrithenSl oi.heWetenstegi_suhLLd_heap_liaut64eNrAGdxihen-menrrcrrcorep;sofbsheapeliautritht esidsfei
 roA]tap a1..NreretenV)a sofbsheapELjeliautrithaubdyhVNhere  en-ino stegi_susofb_heap_liaut64e0)ntbussV)^gadihLLd heapeliautrithenSl oild py orep;sofbsheapeliautre is SnerguagadihLLd heapeliautsoruoruhyup;andseeeuaWfds]trreliautsolobasmize* er"e dst no -DSatsetPRAGMA sofb_heap_liautt retenPRAGMA hLLd_heap_liaut]sor*oruhe(yup;heapeliautsoh aiseise htias bissV)p;texn*hApestaid ina(othrityebureOPEremM toDf(urLu
ntnerton ypesmstira crueyin<li> or fibjevfs.xTQRYliautrs b )tithaubdyhVbavr.ibjevfs.xMndseetaccspacrgurUsldii <trilo -DSea lCsbinaeome
zjelQRibjeeeeeeittegi]dseqnfig](6lr16LE]CONFIGUMEMSTATUS],...)l*afrt-pigurd
t susrrcrrcooooooV)a elr8],(MDEFAULTUMEMSTATUS]olCstulr-pigurd
t su.ibjevfs.xAbasmLu*nsgang^nhge aAch
listaid ina(oth isldperck   bo -DSatseeeeeeittegi]dseqnfig](6lr16LE]CONFIGUPCACHE2],...).ibjevfs.xTQRYnhge aAch
luaWfds] sontfilutsrpwhith:itdrpoolesupcl   Ssd      ,s]ittegi]dseqnfig](6lr16LE]CONFIGUPAGECACHE],...)l aSEds] uloSsd      on bb itdheap.ibjevfisis,s] objhT X oircums  *Lu
Ti Syrswuity efe#htotl nrr htiasSinVcheapeliautsomfyritydirtrmai  fuehea"irLSsdis tfe**nCNTovc*xWris] objerttegi_b(iendQ stegi_susofb_heap_liaut64ettegi_b(iendQ N leWri*rs] objttegi_b(iendQ stegi_suhLLd_heap_liaut64ettegi_b(iendQ N leasesPh geDe changeApreds] seSofbsHeap Liaut ItpGM aa
sno DEPRECATEDs] objhT reAGTfr dApreds] seefnqld AzjelQRYittegi]dseofb_heap_liaut64er]ritye pGM aa
rSyaoi(fut ethnerfEiaoviSsdorrl3ematorH, "olqanhtibit_ay
 nrpnnyuleA nrFSafshosi
 biraTfaf Sytnicsfeiniano[ttegi]dseofb_heap_liaut64er]s  savs] PsfaSEds] ulorV)reAreO,s]*xWris] objerUBTYPE]DEPRECATEDjereteset_aux sofb_heap_liaute MffNe*xaasesPh geDe changExtroatoMetabnrQtAbduo[AgCM umnV *
A TSl oonflbjheyup;veselliIeuoruhe(yupnttegi_sub <tru|b umn_octabnrQ(X,D,T,C,....)fut ethneheep a ritye rrlmat susrbduo[|b umn CAzjel <tr T inand forci D
 nrpnr[ed forci aCnrpefereArXret*n^yupnttegi_sub <tru|b umn_octabnrQ()ritye pGM aa
sheep a pELFORDEOK sndnfitcsmissV)p;nbileorftt-olxWvscinrrcorep;funs Sfang^soren-mesntonl a  roCmld. e rh Ssoistee mdperck   Ssd |b umn exshil.*n^yupnttegi_sub <tru|b umn_octabnrQ()AGds] s biaf ts i atselr8],(MERRORoistee mdperck    |b umn nceabcnqeexshi,s] eeIstee mob umn-goe 
is] objerercottegi_sub <tru|b umn_octabnrQ()AGssaobjhoria t-olxWv,^tde  eii(fut ethne*estaydd efi
Te icgulYexshi hcQlzjelQRibjetSl o aCheheep a pELFORDEOK isel X *Sl o exshilbaChelr8],(MERRORoistitianonceabcnqarh no-io)mSl ornrguris] objereTlub*a)^e nrrcrrcottegi_sub <tru|b umn_octabnrQ(X,D,T,C,...)iisS
*t[eretenV)a * yr Slu atsei Syaets rena )trusor*oruheyupn|b umn reAGds r,s  il,s]tup;tbasu
,]V)rr csndnfoer-iris] objerTfnorrcorei(f  d conf.he(yupntbasu
nt]pe^s</rritheiorrletup;goe 
olum ahnd forciiano(i.
ar"main",;"rdmc",sDATEth, orfhi Snd forci)rcdan Ssrgurgua dperck   Ssd mSl orticoriaret*^ noitiisS
*t[nhhFCNTn nr, orfhi Snd forciTftr]eCearss  Ssd e icgulY*Sl oru
tnerAPtd chanalgoronlmrus se,s]gua nd forci e li>maruPIe*resolvp;un is ,s  iltSl o * d concmhcoruoruheyup;V)rr csndnfoer-iris] objerTfnoorei(f  d conftira culY*Sl orrrco^h umnoruhgoe 
olum ahnesirsdrdL umnCOthl,t
t^Tfis,iruoruheMetabnrQtithaweiroeegrrp rCNocksyhVV)a th:itdrWfds]trrih imodesf orep;5edianorrcotubC*
* htris] objerTfnoorei(f  d conf.reAny olum aci^soren-mesnreiserobjhoriaft Mrwuity cacsfei
 lCssn  aeXl_ereaid ineOStoctabnrQtithpeabcnLsoruoruh^(<bthwkqu%Ch>orjev*Sl orba#htV="1">orjev*r><th> P]pe^s</rr<th> Output<br>Teter<th> geAscripre conforjev*r><td>;5ed <td>;s] objreAPI <td>;enrQtbtbsorjev*r><td>;6ed <td>;s] objreAPI <td>;Noe 
olucAPie cg|b lrnrea C*
* hcQorjev*r><td>;7ed <td>; Mffffffffff<td>;TrueIifh|b umn hfraTENOTS
*t[eimts hai**orjev*r><td>;8ed <td>; Mffffffffff<td>;TrueIifh|b umn ifEtheo[p aguaiPRIMARYhKEYorjev*r><td>;9ed <td>; Mffffffffff<td>;TrueIifh|b umn ifE[AUTOINCREMENT]ibjevf*Sl o>orjev/bthwkqu%Ch>s,s] objheyup;andseeet-olxW)tru ,s]gua reAPoaton i-olxWvscaweiroeege icgulianoneclayc*rsmrgetec rco^h lrnrea C*
* hcQ ifE aerc unn-l prutntesSsd |e nrrcotnyethosiesbjerhArg(oth,irnt wheIstee mdperck    tSl omsrau|tuLlgioa view,ilor6MAaiseimme]h thaweiroee,irnt wheIstee mdperck    |b umn ifE"rowid",;"ret"rtic"_rowid_"onpdim ahtSl o timsraseteaT[WIheyUT ROWID]ub <tronpdinfiano[INTEGERiPRIMARYhKEY]h|b umn hfrat selMxosisrge cdeclayedreretenV)a dutput
anoth] objerTfrreniSt e icgulYexosisrge cdeclayedh|b umn.th  no-ioTSuxiliaiano[INTEGERiPRIMARYhKEY]h|b umnreretenV)a dutputlCNTSe icgulYirowid]roreniSt as(urLu
nyyin<li> oobSfibjeeeeednrQtbtbs: "INTEGER"ibjeeeee^h lrnrea C*
* hcQ: "BINARY"ibjeeeeesetenull: 0ibjeeeeeCmlmholikey: 1ibjeeeeenutonCherid in: 0ibje</obSfs,s] objheyui(f  d conftomosemafl Snd forci tch m mmmu oboba tlon bbdisksrrcrrcoth] asimif heothic(fait_alba ty^t sel oxW,orrcof ts i papGMAaiseiunredfnyeMAaissdoren hcspacT ity a ltoloadtnerAPtd ch m  s]*xWris] objeretenttegi_hAt <tru|b umn_octabnrQ(
ooeggLlga *dbf                /* aChRIkPFu*rhretl  r*x rs] objreAP *zDbNtrN,        /* eC forci goe 
oicoria r*x rs] objreAP *zTSl oNtrN,     /* TSl ornrgurr*x rs] objreAP *zCM umnNtrN,    /* aC umn nrgurr*x rseAP s] obj**pzeC fTete,    /* yUTPUTngeAclayedhdnrQtbtbsrr*x rseAP s] obj**pzaC lSeq,     /* yUTPUTngCh lrnrea C*
* hcQ nrgurr*x reten*pNotNutc,P             /* yUTPUTngTrueIifhNOTS
*t[eimts hai** exshilbr*x reten*pPmlmholKey,           /* yUTPUTngTrueIifh|b umn theo[p aPKbr*x reten*pAutoChe               /* yUTPUTngTrueIifh|b umn ithnuto-Cherid in r*xe*xasesPh geDe changLoadxAbaExtensFu*t whbjheyup;veselliIeuoruheyureAGds] s biaload papGthosiesextensFu* libchol on bb itdnrgudgPitr><rdoh t^yupnttegi_suload_extensFu*irs  savs] Psa  iaprsrrcoloadinfiano[thosiesextensFu*] libchol cdan Sss bissV)p;filQtzFilQ nr nELjerep;filQtcanseisuneloade bn/snetab,Pa  iaprsr oeemada chVloadsnoswonl etriaon a
yyc*rng-syesemuseA_zsic extensFu*ser"Ssd,s] eSorhticex or rimif "s or rlib"tcanseisuneloade ,PlQRnliamnCN ad/s] e"s or rlib.so"rtic"s or rlib.dylib"ttic"s or rlib.dll"sirla
Ssd ,ebtr   balso><rdoh t^yupnse*reet-olx ithzProc,s] ee(zProchreiserc0ft Mrwuity cacsfefe#htotl nrteeemu c[nacupetonl fqrityMe*reet-olx goe 
onlutsrpwhrSyIapfuoly triema"ttegi_hAextensFu*_geit".oruhIf heothnceabcnqeworkimithimts hure on goe 
"ttegi_hAX_geit"d aeedoruhXhimtsshilbp aguaiu
ner-cacsfmcbo ae ineOStfl SASCIItflphabieocritydirPoatonsbissV)p;filQgoe 
on bb itdlaly "/"Suxim ahfuoly urLu
ntnes] e"."onpdipeabcreA]aqulgeitihe "lib".eperiSeyup;ttegi_suload_extensFu*irs  savs] Psf ts i atsetUBTYPE]OK]fea Ce rla
eretenlr8],(MERROR]eisen[nathinoogceabweooh,t wheIstnpGMAaise]r,s]
eretepzErrMsgmsrasete0reretenV)aiano[ttegi]dsload_extensFu*ir]s  savs] Psshn nr, oiaprrrcCNTSel nr*pzErrMsgmtonl MAaisemnCshge ttes" nauxtnChith:itd
 nrpes] tobjevfs.xttegi_dumarthwM tsossVnsstcinooe duVSrrianoaf SytnpoabjcFma me*ge ,,s]^,cLapGMxttegi_dupoabM tsor t wheExtensFu* loadtnermla
** eenSl oilo -DSatsetttegi_hAenSl o_load_extensFu*ir]sjeatsetttegi_hAeb_eqnfig](dbfelr8],(MDBCONFIGUEDEREDULOAD]RXTENSION],1,auxa rrcotmlum eoA^,cLapGMeeeyueDer
 nrptrrlwiibtnpGMAaisetl nr* eaweiroee,irnt wh<b>Se,s]it crf atne:</b>dathy onmcommr"] obinrdyV)aiano[lr8],(MDBCONFIGUEDEREDULOAD]RXTENSION] mettrTeidse asteoAenSl orbnabaeeeyritye pGM aa
rSyaonouIEsd b itd[ttegi_hAenSl o_load_extensFu*ir]s tpGM aa
snosaf Sytn* eaerets ,Syaoi(ftl nrketbi itdthoi  d conft[load_extensFu*ir]ianonii <trilretephersinethoiinje<tizhsievfs.givreA]a orfkonsnredf rla
eeoAextensFu* loadtnercapabit_aiissorut whSeeesmizelQRYiload_extensFu*irsthoi  d conf] s]*xWris] objeretenttegi_hAload_extensFu*i
ooeggLlga *dbf          /* LoadxgulYextensFu* ineCoeeeyund forci aChne<tizh(r*x rs] objreAP *zFilQ,    /* Noe 
olum ahshLL.
ilibchol cdan Ssl_erextensFu* r*x rs] objreAP *zProc,    /* Ee*reet-olx. geAaivebjevfs.zFilQeise0rr*x rseAP **pzErrMsgm      /* Put MAaisemnCshge ioTSuxfasete0 r*xe*xasesPh geDe changEnSl orOr Dii <tr ExtensFu* Loadtnet whbjheyup;veselliIeuoruheSorc(fait_goud
ynose,s]it chotrss MraLhtVSahosiso*etCuhe and oeELjeunt ,cLL.
iext hacrwhuss[extensFu* loadtnetepnpdifraTE t"nCNolucii <t-DSatsetextensFu* loadtnety a ltoe rh s]tneruIEr-eacT ityWri,im ahfrLu
ntnereDe timsraiaoviSsdoeCoep arguai[ttegi]dsload_extensFu*ir]stedirtism zhm *dnoffsor t wheExtensFu* loadtnerithpfflL VcAPie csor* ^Ce nrTbp;ttegi_suenSl o_load_extensFu*irfut ethnewhussonpff==1ibjeeCoep arextensFu* loadtnerzhm *dn|e nritewhussonpff==0eeCoep a timstiethenpfflag Ss><rdoh t^yureAGds] s biaenSl oheorndii <trssbaoroTbp;C-eDe tim[ttegi]dsload_extensFu*ir]snpdim ahthoi  d conft[load_extensFu*ir],s] ee(Useetttegi_hAeb_eqnfig](dbfelr8],(MDBCONFIGUEDEREDULOAD]RXTENSION],..)ibjeeCoenSl orbrndii <trrbnabaeep;C-eDess,s] objh<b>Se,s]it crf atne:</b>dathy onmcommr"] obinrdyextensFu* loadtneSsd ,ebenSl oilo -DSoV)a elr8],(MDBCONFIGUEDEREDULOAD]RXTENSION] mettrTPIe*raSEds] ulorV)reA  savs] P,]izelQRYiload_extensFu*ir]hthoi  d confPIe*remainsldii <tri.yaoi(ftl nrphersinethoiinje<tizhsievfs.givreA]a orfkonsnredf rla
eeoAextensFu* loadtnercapabit_aiissor*xWris] objeretenttegi_hAenSl o_load_extensFu*ieggLlga *dbf etenonpff leasesPh geDe changAutotT_H, "nyeLoadxSaftH, "nyeLin-menExtensFu*s<rdoh t^yureAGds] s biaomosemalQRYxEe*reP-olx()ieiULeo miru ob)ihen-menntorityeassgFSaf[ed forci aCnrpefereArheoth th|ssV)iLsd,Te miSsa ioTSuxilty tianoxEe*reP-olx()iinrrhaiMe*reet-olx PDATE ]mftH, "nyelin-men[thosiesextensFu*]ELjereoth thru ob)nutotT_H, "nyeloade bineCoa nrFSafnd forci aChne<tizhssoruoruh^(Ehenaguoonnhm ahfiULeo mid Ljobtbsraf wuhe andxEe*reP-olx()it py oruhgo^soren-mesnrrcof ts i peret,ethosies ten-msdxEe*reP-olx()iwhuss ioabnredforen-mesnrrcoexpere onnhy<tilonn* yr Sl thistee m] obaehea"zjelQRibjeMe*reet-olx woTSuas(urLu
nyyin<li> obthwkqu%Ch><obSfibje&nbsp;  olx xEe*reP-olx(ibje&nbsp;  ooeggLlga *dbf
bje&nbsp;  oos] objreAP **pzErrMsgf
bje&nbsp;  oos] objs hurenttegi_hAapi_nd-olxWvr*pThunk
bje&nbsp;  );ibje</obSfv/bthwkqu%Ch>s,s] objhIstee mxEe*reP-olxfut ethneencspacT  papGMAaisimithts*enenmn ad*pzErrMsgrrcot-olxfrco/qua  roCmld. eMAaisemnCshge (pes] tobjevfs.xttegi_dumCmlntfir])ianorrcoksf Sle/qua  roCmld. e6MAaiseimme].*n^thosiesensurnCNe and*pzErrMsgrrcoisS
*t[eni(M to^,cLapGMeeRYxEe*reP-olx().*n^thosiestl nr ten-m tim[ttegi]dspoabM trzhm*pzErrMsgmotLu**xEe*reP-olx()if ts i ule^IstaquianoxEe*reP-olx()if ts i papGMAais,rguai[ttegi]dsd
ynirtepettegi_byd
yn (M tAPIe*RRU6ttegi_byd
yn_v2irt se nrTbussiaovbjedsV)a xEe*reP-olx()iwh nrirnVsorut wheCAcLapGMttegi_hAauto_extensFu*iX)etonl fqeMe*reet-olx Xereoth thalba tyPIe*RarguailisneOStfutotT_H, extensFu*seiTfr hLLmnoe<nnb-op.,^NreMe*reet-olxsnoswo nr* ese noildoed ta e
zhcerhticeassgnd forci aChne<tizh e andnsud
yn  sorut whSeeesmiz:Yie ]ultneuestatC,to_extensFu*ir]ianonpdixttegi_ducntasltC,to_extensFu*ir]ia*xWris] objeretenttegi_hAauto_extensFu*ieretsexEe*reP-olx
ffeur)e*xasesPh geDe changCntaslgAutotT_H, ExtensFu* Loadtnet weriSeyup;xttegi_ducntasltC,to_extensFu*iXr]s  savs] Psunf odeseCs*lQRibjegeitiheyu fs e ut ethneXereothrfraf odeseCrilo -DSea tmlum ^e nrrcrrcoie ]ultneC,to_extensFu*iXr]objelQRYgttegi_ducntasltC,to_extensFu*iXr]PIe*rt ethneheep a p1sinogeitiheyu fs e ut ethneXerfrase rla
fu"nyELjeunf odeseCrilrrcoithf ts i o0CifhXerfraait_RarguailisneOStgeitiheyu fs ePIe*rt ethnssor*xWris] objeretenttegi_hAcntasltC,to_extensFu*ieretsexEe*reP-olx
ffeur)e*xasesPh geDe changR iSt AutotT_H, ExtensFu* Loadtnet weriSeyureAGds] s biadii <trssn nr,utotT_H, extensFu*seobStbaonnyELjef odeseCrilo -DSeie ]ultneC,to_extensFu*i)] s]*xWris] objerereteset_aux uestatC,to_extensFu*ifeur)*xasesPh SleQtburnCNus se,s]gua virtis SnSl omstpGM aa
sn/
btbscAPjs hurenttegi_hAvnSlnttegi_hAvnSl;
btbscAPjs hurenttegi_hAi"] x_e rrnttegi_hAi"] x_e rr;
btbscAPjs hurenttegi_hAvnSl_,s]
 nostegi_suvnSl_,s]
 n;
btbscAPjs hurenttegi_hAmodulenttegi_hAmodule*xasesPh geDe changVirtis STSl orObje<tsPh KEYWORDS: ttegi_hAmodulen{virtis SnSl ommodule}snoLjeretisldleQtburn,en[natimesnsstcrilr "virtis SnSl ommodule"APIe*Syaetsnrrhaiistaid ina(oth p aoO[virtis SnSl o]r fiossisldleQtburnhimtsshilbmosge cOStocttrTsie icgulY odulesorut wheA virtis SnSl ommoduleh th|ssV)iLe,s]el nbign loah
yysshi htianoins  *LutpsteeeyudleQtburnhretepas -DSea taetCNTSuxim andn s  *LuibjeeCogttegi_ducssV)iAmoduleM tlQRYie ]ultnecssV)iAmodule_v2irtsoruheyup;u odesyc*rsmrremainsl aerc unn-l utrithretlaasse,s]aisdad conforuhmodulehticunn-l prut[ed forci aCnrpefereAr^ ^Tmhc ossVnsclbusaPIe*RsteeeyudleQtburnhrla
*seisdirtrma a ltoutrithreodeseCriltledianoaqulnd forci aChne<tizhsor/
s hurenttegi_hAmodulen{x reteniVfnqld ;x retensexCssV)i)ieggLlgaBfrIflsn*pAuxfrrrrrrrrrrrrrrrretenforcfts] objreAP *s] ob*forvfrrrrrrrrrrrrrrrrttegi_hAvnSln**ppVTSl,jreAPIBele retensexCChne<t)ieggLlgaBfrIflsn*pAuxfrrrrrrrrrrrrrrrretenforcfts] objreAP *s] ob*forvfrrrrrrrrrrrrrrrrttegi_hAvnSln**ppVTSl,jreAPIBele retensexBestI"] x)ieggLlgaAvnSln*pVTSl,jttegi_hAi"] x_e rrBele retensexDiierhne<t)ieggLlgaAvnSln*pVTSlele retensexDheleoy)ieggLlgaAvnSln*pVTSlele retensexO
yn)ieggLlgaAvnSln*pVTSl,jttegi_hAvnSl_,s]
 no**ppCs]
 nele retensexC ^Tm)ieggLlgaAvnSl_,s]
 nBele retensexFimLu*)ieggLlgaAvnSl_,s]
 nBf etenidxNumfts] objreAP *idxSlefrrrrrrrrrrrrrrrrretenforcfteggLlgaAv b )t**forvele retensexNext)ieggLlgaAvnSl_,s]
 nBele retensexEof)ieggLlgaAvnSl_,s]
 nBele retensexaC umn)ieggLlgaAvnSl_,s]
 nBf ttegi]dseqnttesBf eteele retensexRowid)ieggLlgaAvnSl_,s]
 nBf ttegi]dsiendQ *pRowid)le retensexUpdrnm)ieggLlgaAvnSln*f etefteggLlgaAv b )t**f ttegi]dsiendQ *ele retensexBegin)ieggLlgaAvnSln*pVTSlele retensexSync)ieggLlgaAvnSln*pVTSlele retensexCMmaut)ieggLlgaAvnSln*pVTSlele retensexRotcfifi)ieggLlgaAvnSln*pVTSlele retensexFindFiULeo m)ieggLlgaAvnSln*pVtabf etennArgfts] objreAP *zNtrN,rrrrrrrrrrrrrrrrrrrrrrrrIflsn(**pxFiUL)ieggLlgaAeqnttesBfetefeggLlgaAv b )IBe,rrrrrrrrrrrrrrrrrrrrrrrrIflsn**ppArgele retensexRQgoe )ieggLlgaAvnSln*pVtabf s] objreAP *zNewele r/uhyup;anttrTsiabovSuh ai loefnqld A1
olum ahsggLlgAmodulenobje<t.yao^Tme r*tyniomwfh aifum efnqld  2hretegssV)^r.br*x retensexSavep-olx
feggLlgaAvnSln*pVTSl,jeteele retensexRrLSsdi
feggLlgaAvnSln*pVTSl,jeteele retensexRotcfifiTo
feggLlgaAvnSln*pVTSl,jeteele r/uhyup;anttrTsiabovSuh ai loefnqld  p1srete2
olum ahsggLlgAmodulenobje<t.e r*tyao^Tmyniomwfh aifum efnqld  3hretegssV)^r.br*x retensexShadowNtrNe(s] objreAPIele r/uhyup;anttrTsiabovSuh ai loefnqld  p1sehroonnh3
olum ahsggLlgAmodulenobje<t.e r*tyao^Tmyniomwfh aifum efnqld  4hretegssV)^r.br*x retensexItpGg]it 
feggLlgaAvnSln*pVTSl,js] objreAP *zSch m ,irrrrrrrrrrrrrrrrrrrrs] objreAP *zTSlNtrN, etenmFlags,jreAP **pzErrele}*xasesPh geDe changVirtis STSl orI"] x-DSeI rrlmat susPh KEYWORDS: ttegi_hAi"] x_e rrsnoLjeretenttegi_hAi"] x_e rrntleQtburnhreteutsrtubCleQtburnCNisse astaththeoPIe*RsteeeO[virtis SnSl o]AGds] s biarcrrcopas ye rrlmat susineCoarcoksceang^V)a * pll on bb itd[xBestI"] x]PIe*mettrTepstoO[virtis SnSl ohmodule]uleyup;field
Ti Syrs**I otasredfoe*lQRibjegeotaseeCoxBestI"] xpnpdifrehawad-ece ulexBestI"] xpunss *arrgiianoheyr SsoineCoee)t**OutputsNTSeleld
sor*oruhe(yup;aCmts hai**[]rorrayonmcordioWHERE(^ cicseimts hai**lbp aguairrlmyin<li> obthwkqu%Ch>|b umn OPoexpr</bthwkqu%Ch>or<li>  aeed OPoiss=, &lt;, &lt;=, &gt;, um &gt;=ret*n^(TQRYnheoiculavsa
yyc*ru insnosanauxtnChiaCmts hai**[].oplo -DSeahe
olum aiano[lr8],(MINDEX]CONSTRAINT_EQ | lr8],(MINDEX]CONSTRAINT_e rh Ss].eperiSe(TQRYi"] xbp aguai|b umn ithanauxtnChianoaCmts hai**[].iaC umnret*n^(aCmts hai**[].usSl omsraTRUEhistee ibjeMxpr_Rarguairrla
-hrrcotidsflobaidse rh s]  b(npdim umagua tons hai**orjeisse Sl ofPrrcofsmiQCifhithcansei.s,s] objheyup;d
t myutVSautotT_H, "nyeiers *magermlbp aguairrlm "Mxpr_OPo|b umn"ianonpdid py oaSEitd*esta,s tVevFiiouxim ahWHERE(^ cicseinTEth, oiaprrrcCNTSgSt as(maqulWHERE(^ cicsegermlbineCoee)trrlm af wniabovSuhsapoasil osoruheyup;aCmts hai**[]rorrayobnabakspo *maWHERE(^ cicsegermlbe and oeELjeirLSvanCcgoum ahnheoiculavsvirtis SnSl oheiockscbhrie sorut wheInrrlmat susrbduo[m ahORDER BY(^ cicseissanauxtnChiaO#htVBy[]soruheEassggermepstoO#htVByonmcordioai|b umn p aguaiORDER BY(^ cicssoruoruhlQRY^hlUi>)teleldYi"]ids] sowuity cb umnlbp aguaivirtis SnSl ohmeiserobjhobcbirsdr,s]gua rexn*hApscan.gVirtis SnSl ohcb umnlbh ais rol objevfsobjhbavr id p[rea#htVS Mrwuity te yV>  aaritledtoieep;CREATE TEREDi*aftMihe t wh imodesernttegi_hAdeclayeAvnSl().*Fed paggfuoly 63hcb umnlb(cb umnlb0-62crELjeretnlCssn  aeXl_erbutrithaubdtledtoieep;^hlUi>)tmaskhistee mob umn meiserobjhobcbirsdr,s]**nCNToh no-io)mSl orhfraTt LSsdy 64hcb umnlbhpdinfyo^h umnoruhgoum ahrrla
bp aguairuoly 63hithrecbirsdreretenbutr63
olu^hlUi>)t thalscrrcotecs a taSEitdwords,i|b umn iaC hreisercobcbirsdristee mMxpressFu*t wh(^hlUi>)t& (feggLlgaAuiendQ)1 << (iaC >=63
?r63
: iaC )))se rh s] TfnorrconbilbavrsoruoruhlQRY[xBestI"] x]*mettrTerla
*el nraCmts hai**Ushge[t whussi rrlmat susPh rbduo[wbussis] objerTfnoopas yeCoxFimLu*ule^IstaorvI"] x>0ereteELjeretnrrla
-hrrcotidsfp aguai|bssn  aeXl_eraCmts hai**[]rithe rh s]  ianonpdibmcomsnrrhaiaorvI"] x-nl Me*reeChiaorvule^  noaCmts hai**Ushge[t.oautianoidxcruereretenV)a imts hai**  thassumt hru ob)fu"nyrhretl  i,s]tuprrcovirtis SnSl ohnpdidrla
bseisuned efiastag Ssr,s]gua b cTeimmeret*^(TQRianoaCmts hai**Ushge[t.oaut flans so/qud
t myu fs e holx. WetenV)a oaut flanianoidxlefndn eutsrcAPie cgset",X SDf(usmiQ,nV)a imts hai** tl nralwaysserobjhd efiastset]petelyrSsr,scTeimmerrh no-io)oaut flans soerck   hgoumruerereteELjeretnlCts hai** reisisemeisseisuned efiastSsr,scTeimmerrh  taSEitdwords,li>  aeno-io)oaut flans somrueo-ioTSuxilia guaranteebinrdyV)a imts hai** tl nrrconbisuned efiastag Ssro -DSeb cTeimmerets] objheyup;idxNumhreteudxSlee rh SsofrehawcordrilretepimodesineCoee)iano[xFimLu*]*mettrTsoruhe[ttegi]dspoabM trisse astrcopoabjudxSleeitynpdobnabaiunredneedToFoabIdxSleeisomrue><rdoh t^yupno#htVByCmtsumt h t"nCNTbussdutputjevfs.xxFimLu*]/[xNextt tl nr]r,s]cinrrcorep;|bssnctea#htVSerntagasfy[m ahORDER BY(^ cicsesxim andia set]peterrcoto *apGMttephithrecbirsd><rdoh t^yupnsst ms]  Costrs b )tithfqeMst ms] fp aguai|bsneOStfhnheoiculavsnosanpeteg ulAi|bsneOStNYi"]ids] soinrdyV)a ims
bp aguaianpeteg aisldiaulavoruhgouaelinaariscanleunnf;thosiesnSl ohwhussNTrChdulAi|bsneOStlogeNrianoi"]ids] soinrdyV)a expenIEsd b itdp
yyc*rsmrsradiaulavsrcNTbussdfsaobjhbinareeCearssnth a uniquRYi"] x>)teleldYeunnf;thosiesnSl ohwhussNTrChdu<rdoh t^yupnsst ms]  R wuhs b )tithfqeMst ms] fp aguaie rol rgurr wuhe ansnoswo nr* eaweiroeegrrpguaianpeteg soruoruhlQRYxBestI"] xpmettrTereisi
t suhnleet-pulatg^V)a udxFlagsteleldYtonl fPIe*maskhtfe**n],(MINDEX]SCAN_* flans. Onease h flans siano[lr8],(MINDEX]SCAN_HEX],rwuity isenetaomosemalQRY[EXPLAIN QUERY PLANee nrputputjernthmwfei
 idxNumhrsihexpunsta tleunnsrcAc msl,nrAnaSEitdflans sianolr8],(MINDEX]SCAN_UNIQUE,rwuity isenetai"]ids] soinrdyV)a cbhryotlan tl nrrcoksf Sle/tbmosgeahe
*owsorurrcoAd ypesmhnleimif xBestI"] xpiStTfm ahtho],(MINDEX]SCAN_UNIQUEdflanrereteELjethosiessmizeassumtsoinrdyifhoOse nrrcotupnxUpdrnm() mettrTeidxmada ast wh ieo[p aguai chan]mftMihe  ext haieerticupdrnm aovirtis SnSl ohhowrnpdim aianoistaid ina(oth heep a pELFORDECONSTRAINTreretenV)aTSuxilia neastrcouotcfifiianoaqulnd forci arck  ss a taSEitdwords,iistee mxUpdrnm() f ts i atselr8],(MCONSTRAINTreretlnd forci aCht-mesnrla
** eexaetabsf orepyVwoTSobjhbi(M toxUpdrnmerfrasstcri.tByhaChtrsdy,yebu**n],(MINDEX]SCAN_UNIQUEdsrasetrrcotecrnpdixUpdrnmeheep a pELFORDECONSTRAINTreaqulnd forci arck  sxmada by ed prutxUpdrnmemettrTefrehnutotT_H, "nyero"nCNiethenbs]**nCNTovcs ed IMPORTANTngTupnsst ms]  R wuheleldYtaser"Ssdrrcotupnttegi_sui"] x_e rrsnontleQtburnhfolethosies[efnqld A3.8.2] ([ed eof:3.8.2]).oruhIf aovirtis SnSl ohextensFu* i atseismentonl af;thosiesefnqld Aearlids] ulor3.8.2,^V)a * yr Ssoeunn oiaprtneSsd rcoua tlerp rCNg^V)a sst ms]  R wuheleldYfrehi Syaets r(,ussfreh ad/nyELjetonCheludsflrsdhrgurgua .hosiso*etC).gTupnsst ms]  R wuheleldYaf SytELjeV)aTS(M toDnababeaismenebu[ttegi]dslibefnqld _e rol M trf ts i parrcov b )tgssV)^rrguanhtice is Sner3008002. SiaulavleimV)a udxFlagsteleldsnoswaser"Ssdrfole[efnqld A3.9.0] ([ed eof:3.9.0]r.oruhI* reisV)aTS(M toDnababeaismenebsnonttegi]dslibefnqld _e rol M of ts i pasv b )tgssV)^rrguanhtice is Snesnon3009000sor/
s hurenttegi_hAi"] x_e rrn{e r/uhI otasbr*x retennCmts hai**;rrrrrrrrrrr/* N rol rgurMe*rirss MraCmts hai**br*x rs hurenttegi_hAi"] x_imts hai** {
rrrrreteniaC umn;rrrrrrrrrrrrrr/* aC umn imts hai*iLsd,-1rfoleROWIDbr*x r   es] objerreAP op;rrrrrrrrr/* aCts hai** a
yyc*ru r*x r   es] objerreAP e Sl o;rrrrr/* TrueIifheeeyuimts hai**  thusSl omr*x r   i**  TermOfftec;rrrrrrrrrr/* Uodesineu*ns aba- xBestI"] xpis*enen obM tor*x r} *aCmts hai**;rrrrrrrrrrr /* TSl orgurWHERE(^ cicseimts hai**lbr*x retennO#htVBy;rrrrrrrrrrrrrr/* N rol rgurgermlbin[m ahORDER BY(^ cicser*x rs hurenttegi_hAi"] x_a#htVbs]{
rrrrreteniaC umn;rrrrrrrrrrrrrr/* aC umn e rol rr*x r   es] objerreAP desc;rrrrrrr/* TrueIfoleDESCsd,FsmiQCfoleASCsdr*x r} *aO#htVBy;rrrrrrrrrrrrrrr/uhyup;ORDER BY(^ cicser*x r/* yutputsbr*x rs hurenttegi_hAi"] x_imts hai**_ shge]{
rrrretenforvI"] x;rrrrrrrrrrr/* ifh>0,uimts hai**  ththeo[p aoorvyeCoxFimLu*rr*x r  es] objerreAP oaut;rrrrrr/* DooseisimmeIargest e icgueyuimts hai** r*x r} *aCmts hai**Ushgele retenidxNum;rrrrrrrrrrrrrrrr/* N rol re astrcoGds r,srpguaii"] xbr*x rseAP *udxSle;rrrrrrrrrrrrrr/* Slergu,apoasil yrpes] tobjevfs.ttegi_dumarthwbr*x retenneedToFoabIdxSle;rrrrrr/* FoabjudxSleeo -DSettegi]dspoabM IifherueIr*x reteno#htVByCmtsumt ;rrrrrrr/* TrueIeburutputj thalba tyno#htVobjr*x rdoul ohest ms]  Cost;rrrrrrrrrrr/* Est ms]  i|bsneOSto -DSoV)reAGd] xbr*x r/* Field
Tniomwfh aiDnabaavaulal omst;thosies3.8.2rnpdilaLu*rr*x rttegi]dsiendQ sst ms]  R wu;rrrr/* Est ms]  ie rol rgurr wuhaweiroeegr*x r/* Field
Tniomwfh aiDnabaavaulal omst;thosies3.9.0rnpdilaLu*rr*x retenidxFlags;rrrrrrrrrrrrrr/* Maskhtfe**n],(MINDEX]SCAN_* flansgr*x r/* Field
Tniomwfh aiDnabaavaulal omst;thosies3.10.0rnpdilaLu*rr*x reggLlgaAuiendQu^hlUi>);rrrr/* I ota: Maskhtfecb umnlbus se,s]]mftMihe  r*x}*xasesPh geDe changVirtis STSl orScanlFlagsvcs ed Virtis SnSl ohistaid ina(othsofreharthwdeserntedyV)aiano[ttegi_hAi"] x_e rr].udxFlagsteleldYerntogurcdsbinaeome
zjELjeV)aTmynitssor*x#Syaetsu**n],(MINDEX]SCAN_UNIQUEd0x00000001r/* Scanlvisutsohtbmosge1hhowrr*x#Syaetsu**n],(MINDEX]SCAN_HEXrrrr0x00000002r/* Distlay idxNumhrsihexpr*x r                                          /* in EXPLAIN QUERY PLANpr*xasesPh geDe changVirtis STSl oraCts hai** O
yyc*ru CmmesoruoruhlQRsohmecrosiSyaetsrgua .rthwdes rh Ssoe icguliano[ttegi_hAi"] x_e rr].aCmts hai**[].opleleldsd,Eassgv b )trApreE ntsnredfn a
yyc*ru e andnsutheo[p aouimts hai** germein[m ahWHERE(^ cicsezjELjea cbhryoe andosemafO[virtis SnSl o]r fioh t^yupnlefn-hrrcoa
yyc*dnofb itdp
yyc*ru inrgivesr,s]gua |bssn  aeXl_eianoaCmts hai**[].iaC umnleleldsd,^AnniaC umnnofb-1ri"]ids] soinpnlefn-hrrce nrp
yyc*dninrrhairowidr fiossVnlr8],(MINDEX]CONSTRAINT_LIMITbaChelr8],(MINDEX]CONSTRAINT_OFFSETe nrp
yyctissdhavp;nbnlefn-hrrcoa
yyc*depnpdisooe icgu^Tmyp
yyctissdtciianolCssn  aeXl_eraCmts hai**[].iaC umnlma me"nrgulla
ereteis*enennbisunatseismesorurrcoA nr]
yyc*ru  rh Ssoevfs.lr8],(MINDEX]CONSTRAINT_FUNCTIONsehroonnrrcov b )t255ofrehawservastrcouApreE nthfiULeo mlbe and oeEovMAloade objhbyb itd[xFindFiULeo m|xFindFiULeo memettrT]rNTLlgadvirtis SnSl oianoistaid ina(othsoruoruhlQRYrrla
-hrrcoa
yyc*dsrhticeassglCts hai** rrla
** er rla
il oru
tne ed prut[eggLlgaAvnSl_rhsAv b )ir]s tpGM aa
sd,UsuLlgioretnrrla
-hrrce nrp
yyc*dninrDnabaavaulal omsfhith>  aarsifraTEnaohecclCts anCcgLlgralianoi"pguaii"putjlr8rrh no-io)rrla
-hrrcoa
yyc*dtithfqaSEitd|b umn pr fqrityMxpressFu* (ehenaaclCts anCcMxpressFu*d  noasis] objerreretenV)aianoeggLlgaAvnSl_rhsAv b )irsiaobal yrwo nrnbisuneal omeoAextroatout,orureyup;lr8],(MINDEX]CONSTRAINT_IS
*t[errce nrlr8],(MINDEX]CONSTRAINT_IS
OT
*t[ep
yyctissdhavp;nbnrrla
-hrrcoa
yyc*dianonpdih hcQ lstcsmp(XeggLlgaAvnSl_rhsAv b )irse icgu^Tmyp
yyctissdtl nrrcoalwayssheep ar.20ORDE
OTFOUNDsoruoruhlQRY^hlls]tnerC*
* hcQ ru ob)us sefiseimmis]isnftombaidsfoOe ru
tne ed prut[eggLlgaAvnSl_^h lrnreair]s tpGM aa
sd,FEremMsthf al-wornenvirtis  ed p <trs,nV)a imlls]tnerC*
* hcQ tfecbts hai**lbnceabcnqemn oir (hticex or robjhbilcicsfeinecbts hai**lbh ais reric)pnpdisootupnttegi_suvnSl_^h lrnreairianoi"s] s biaislcnqe LVmDnabaneedmesor*x#Syaetsu**n],(MINDEX]CONSTRAINT_EQ          2x#Syaetsu**n],(MINDEX]CONSTRAINT_GT          4x#Syaetsu**n],(MINDEX]CONSTRAINT_LE          8x#Syaetsu**n],(MINDEX]CONSTRAINT_LT         16x#Syaetsu**n],(MINDEX]CONSTRAINT_GE         32x#Syaetsu**n],(MINDEX]CONSTRAINT_MATCH      64x#Syaetsu**n],(MINDEX]CONSTRAINT_LIKE       65x#Syaetsu**n],(MINDEX]CONSTRAINT_GLOB       66x#Syaetsu**n],(MINDEX]CONSTRAINT_REGEXP     67x#Syaetsu**n],(MINDEX]CONSTRAINT_NE         68x#Syaetsu**n],(MINDEX]CONSTRAINT_IS
OT      69x#Syaetsu**n],(MINDEX]CONSTRAINT_IS
OT
*t[e 70x#Syaetsu**n],(MINDEX]CONSTRAINT_IS
*t[e    71x#Syaetsu**n],(MINDEX]CONSTRAINT_IS         72x#Syaetsu**n],(MINDEX]CONSTRAINT_LIMITb     73x#Syaetsu**n],(MINDEX]CONSTRAINT_OFFSET     74x#Syaetsu**n],(MINDEX]CONSTRAINT_FUNCTIONs 150xasesPh geDe changR odeseC AgVirtis STSl orIstaid ina(othritybjheyup;veselliIeuoruheyupse*rt ethnsYfrehisastrcouAodeseC agFSaf[virtis SnSl ohmodule] goe ,orureModuleniamnCNrla
** ereodeseCrilbi(M tianolssV)-DSea FSaf[virtis SnSl o]lo -DSoV)a modulennpdibm(M too -DSeat wh oabeshil_er[virtis SnSl o]le icgulY odulesorut wheT)a modulengoe 
ithreodeseCrilRarguai[ed forci aCnrpefereArdperck   Ssd byb itdruoly is] objerobjelQRYgoe 
olum ahmoduleh thgivesr,s]guarrcoteasu
nt]pe^s</robjelQRYV)rr ct]pe^s</rritha taetCNTSux ed prutistaid ina(oth p ateeO[virtis SnSl ohmodule]ulejelQRYfoer-it wh iee^s</rrithahiaonitchol cli nthdnrQttaetCNTSu andnsuthmodesehroonnrrcoineCoee)t[xCssV)it retenxCChne<t];anttrTsip aguaivirtis SnSl ohmoduleli>  aenoa FSafvirtis SnSl omssheiocks|ssV)iLeonn* geitiheyusd><rdoh t^yupne ]ultnecssV)iAmodule_v2iroi"s] s biahfraTEfif-iris] objerrtuityrrcoitha taetCNTSuxfr dAs hureonne icgulYpCli nteC f.*n^thosiestl nrrcoinvbjeeretlnAs hureonneiULeo me(inoitiisScnqeauxa   aenothosierrconb lonlonnneedscgulYpCli nteC f taetCNTobjelQRYnAs hureonntl nralscrrcoob)ihen-menistee moe nrrcoe ]ultnecssV)iAmodule_v2iroirnVs,irnheyup;set_aux cssV)iAmoduleM ianoi"s] s biaislmcbo ae inercoe ]ultnecssV)iAmodule_v2irotonl aaauxaianonAs hureon,irnt wheIstee mV)rr ct]pe^s</rr(gulYpaetCNTSuxim enttegi_hAmodulenobje<t) i atse
*t[eretenia newmmoduleh th|ssV)iLehpdinfyobeshil_ermodulesswhuss itrrcotoe 
goe 
frehdro  a sorut whSeeesmiz:Yie ]ultnedro Amodulesir]ia*xWris] objeretenttegi_hAcssV)iAmoduleM
ooeggLlga *dbf               /jethosiesaChne<tizh ecouAodeseC modulehwhussr*x rs] objreAP *zNtrN,         /* Noe 
olum ahmodulehr*x rs] objttegi_hAmodulen*p,   /* McttrTsie icgulY odulehr*x rIflsn*pCli nteC f          /* Cli nthdnrQte icxCssV)i/xCChne<t r*xe*xWris] objeretenttegi_hAcssV)iAmodule_v2i
ooeggLlga *dbf               /jethosiesaChne<tizh ecouAodeseC modulehwhussr*x rs] objreAP *zNtrN,         /* Noe 
olum ahmodulehr*x rs] objttegi_hAmodulen*p,   /* McttrTsie icgulY odulehr*x rIflsn*pCli nteC f,         /* Cli nthdnrQte icxCssV)i/xCChne<t r*xrreretsexDheleoy)ieretB)     /* ModulennAs hureonneiULeo mer*xe*xasesPh geDe changRemovSuUhne<nCshol Virtis STSl orIstaid ina(othsritybjheyup;veselliIeuoruheyup e ]ultnedro AmodulesiD,Lrs  savs] Psf movSssn nrvirtis  ed p <trrmodulessrn bbnd forci aChne<tizh(DAre ,Cheutostdnrgudgu* liobjLr fiossVnLct]pe^s</rrrla
** eeiorrle
*t[eprha taetCNTSuxfrnrorrayobf i-olxWvsELjetonslergusd aeed rhaiaorayoimagerminaesse,s]ainaoheccoria t-olxWv,s] eeIstee mLh iee^s</rrith
*t[nhhFCNTn nrvirtis SnSl ohmodulesofrehawmovS sorut whSeeesmiz:Yie ]ultnecssV)iAmoduleM tor*xWris] objeretenttegi_hAero Amodulesi
ooeggLlga *dbf                /* RemovSumodulessrn bbgueyuimtne<tizh(r*x rs] objreAP **azKetbi        /* Ee ,Ch,idobcnqeawmovSb itdphnsYnrgudgaeed r*xe*xasesPh geDe changVirtis STSl orI"s  *LutObje<tsPh KEYWORDS: ttegi_hAvnSlorut whEvhryo[virtis SnSl ohmodule] istaid ina(oth osemafOsubclhmoe nrpfheeeyuobje<t ext hscriuneahnheoiculavsn s  *LuibjeRsteeeO[virtis SnSl o]sd,Eassgsubclhmostl nrrco,ebtrnVorsdrrcotupnteA_zsic needscolum ahmoduleh staid ina(othsoruxTQRYnursoIEsRsteeeyuduperclhmos thru Syaetsucers] t;field
Te and oeELje LVmDn eCoa nrmoduleh staid ina(othdu<rdoh t^Virtis SnSl os;anttrTsiombatecrnpeMAaisemnCshge ,s]as] ob-DSeat whslergurpes] tobjevfs.xttegi_dumCmlntfir]dyhVbErrMsguleyup;mettrTeaf SytELjeVn adcfoe*lQand fyotmlum slerguri(f oabde,s]aioe nrrco[ttegi]dspoabM tt wh olum eoAas] ob-DSea newmslerguryhVbErrMsgule^Aftrletup;MAaisemnCshgerrcoithdeliveCrilop eoAm ahali nth.hosiso*etC,pguaianprgurtl nr* euutotT_H, "nyrrco oabde,s]ttegi]dspoabM Inpdim ahzErrMsgmeleldYto nr* ebavrmesor*xs hurenttegi_hAvnSln{x rs] objttegi_hAmodulen*pModule; r/uhyup;aodulene icgueyuvirtis SnSl ohr*x retennRef;rrrrrrrrrrrrrrrr       /* N rol rgurd
yno,s]
 nsbr*x rseAP *zErrMsg;rrrrrrrrrrrrrrrr  /* EAaisemnCshge evfs.ttegi_dumCmlntfirgr*x r/* Virtis SnSl ohistaid ina(othsotl nrtypH, "nyeaddeaddypesmhn;field
Tr*x}*xasesPh geDe changVirtis STSl orCs]
 ntObje<tsPh KEYWORDS: ttegi_hAvnSl_,s]
 no{virtis SnSl om,s]
 n}orut whEvhryo[virtis SnSl ohmodule] istaid ina(oth osemafOsubclhmo
olum aianofrLu
ntnertleQtburnhext hscriune,s]
 nsbTbussi-olx ineCoee)iano[virtis SnSl o]lnpdifrehisasELjetonloopsehroonnaguaivirtis SnSl ouleCs]
 nsbfreh|ssV)iLeo -DSoV)aiano[ttegi_hA odulesxO
yn | xO
yn]*mettrTepstV)a modulennpdifrehdheleoye objhbyb itd[ttegi_hA odulesxC ^Tm | xC ^Tm]*mettrTsleCs]
 nsbfrehisasELjebyb itd[xFimLu*], [xNextt, [xEoft, [xaC umntepnpdi[xRowid];anttrTsibjeRsteeeO odulesd,Eassgmoduleh staid ina(othotl nrSyaets ed prutaCht-me[p aouis]
 nosleQtburnhextsuitiitsrpwhineedssoruoruhlQeyuduperclhmosexshilb Mra#htVSernSyaetsufield
Tp aguai|s]
 noe ansnosfreh|LVmDn eCoa nr staid ina(othdu<r*xs hurenttegi_hAvnSl_,s]
 no{
rrttegi_hAvnSln*pVtab;rrrrrr/* Virtis SnSl ohRsteeeyu,s]
 no**x r/* Virtis SnSl ohistaid ina(othsotl nrtypH, "nyeaddeaddypesmhn;field
Tr*x}*xasesPh geDe changeAclayeossVnlch m V *
A Virtis STSl oIeuoruheyup [xCssV)it retenxCChne<t];anttrTsip aaiano[virtis SnSl ohmodule] se nrTbreAGds] s biELjetondeclayeb itdrrlmatr(gulYiamnCNretend fbtbs
Tp aguai|b umnl)bpsrityV)a virtis SnSl os;repyVistaid insor*xWris] objeretenttegi_hAdeclayeAvnSl(eggLlgaBfrs] objreAP *zSQLe*xasesPh geDe changOvMAload
A FiULeo meFEreA Virtis STSl oIeulbjheyup;veselliIeuoruhe(Virtis SnSl os;ombaiaoviSsasmLu*nsgang^istaid ina(othsoDf(uiULeo mlatseis-DSoV)a exFindFiULeo m]*mettrTepstV)a [virtis SnSl ohmodule]uatseBut globs Sefnqld  ppstV)^Tm uiULeo mlatserla
*exshib Mra#htVSernbeEovMAloade rets] objhe(TeeyueDeid py osurnhr globs Sefnqld [p aoueiULeo metonl aanheoiculavsnosgoe 
fndde rol rgurth] objerTfexshil.*nIfdia se h fiULeo meexshil
bjhbi(M toeeeyueDeh th|stcri,ea newmfiULeo me th|ssV)iLset*n^yupnestaid ina(othrityp aguaieewmfiULeo mealwayssomosemafnAre ,Cho miru ob)ehrowhrSySx ed prutnewmfiULeo me thcnqegoosefise fythinoo,s]otselfrSyIanrDnabt wh ursoIEs thru ob)n tlaashaLhtVSeiULeo mirbussombaidsovMAloade objhbybfO[virtis SnSl o]r f*xWris] objeretenttegi_hAovMAload_eiULeo m(eggLlgaBfrs] objreAP *zFiULNtrN, etennArgeleasesPh geDe changA Hretl  ToxAbaO
yn BLOBsPh KEYWORDS: {BLOBrhretl } {BLOBrhretl s}orut whAnnins  *Lutpsteeeyuobje<t rApreE ntsdfn a
yn BLOBgu* tuityrrco[ttegi_hAblobyd
yn | Cherid ins SBLOBgI/O]sombaidsperrrlmsd,s] e^Obje<tstpsteeeyugetec reh|ssV)iLe,s]ittegi]dsblobyd
ynir]ianonpdidheleoye e,s]ittegi]dsbloby^ ^Tmirtsoruheyup;ittegi]dsblobyba tir]snpdiittegi]dsbloby rCNgir]s tpGM aa
l
bjhombaidsisastrcouA tlerp rCNg^smartotubC*ctld  ppstV)eSBLOBsoruheyup;ittegi]dsblobyb cTser]s  savs] Psf ts i pguaiatndbpstV)eSBLOBtSsr,scTdu<r*xbtbscAPjs hurenttegi_hAblobnttegi_hAblob*xasesPh geDe changO
yn ASBLOBtFEreIherid ins SI/OIeulbjheyup;veselliIeu CONSTRUCTOR:nttegi_hAblobs] objhe(Teeyu tpGM aa
l a
ynmafO[BLOBrhretl  | hretl ] eoAm ahBLOBrWfds] dianoi"phowriRow,i|b umn zCM umn,SnSl ohzTSl o inand forci zDb;ianoi"paSEitdwords,iguai chanBLOBrreothr Sytn* esel*cte e,syin<li> oobSfibjeeeeeSELECT zCM umn FROM zDb.zTSl o WHERE(irowid]r=riRow;ibje</obSfets] objhe(P]pe^s</rrzDbe thcnqe itdrulQgoe 
rbussodan Ssseretlnd forci, but
anoraSEds] u esymbolic noe 
olum ahnd forci.*Fed , orfhi Snd forciT,rTbreAGs ed prutnoe 
rbuss>  aarsifftrletup;ASikeywordoi"pguai[ATTACH]]]mftMihe soruhFed paggmainand forci filQ, m ahnd forcingoe 
ith"main".*Fed TEMP ed p <trs,nV)a nd forcingoe 
ith"rdmc"rets] objheIstee mflansg iee^s</rrithnbilbavrreretenV)a BLOBtSsud
yn  efiseuA tianonpdi rCNg^r rla
.heIstee mflansg iee^s</rrithbavrreret BLOBtSsud
yn  efis
anorwad-ece ^r rla
.s] objhe(Oa Ce rla
,etUBTYPE]OK]fithaweiroeegnpdim ahFSaf[BLOBrhretl ]eissanauxtianoi"p*ppBlob. OtrrlwiibtnpG6MAaiseimme]h thaweiroee c*depunlla
etup;MAaisELje Ld 
ithUBTYPE]MISUSE,p*ppBlobtithaubdyhVoriaret*^Thma me"nsbTbus,aiaoviSsd ed pruteDeh thcnqemisu asimitj thalwaysssafe eoA^,cL]ittegi]dsbloby^ ^Tmirtrityp"p*ppBlobifftrletui(f  d conftf ts i uoruoruhlQeyu  d conftirnVsetonl lr8],(MERRORoistany olum aofrLu
ntnerayeb rue:ibje<ulfibjeeevfs.x^(Dd forci zDb nceabcnqeexshi)^,ibjeeevfs.x^(TSl ohzTSl o nceabcnqeexshidtledtoind forci zDb)^,ibjeeevfs.x^(TSl ohzTSl o itha WIheyUT ROWID p <tr)^,ibjeeevfs.x^(Cb umn zCM umn nceabcnqeexshi)^,ibjeeevfs.x^(RowriRowh thcnqepreE nthi"pguaip <tr)^,ibjeeevfs.x^(TupnteA_zsi   |b umn gurr wriRowhodan Ssseasv b )tu andnsusetrrcoooooooooa TEXTlerpBLOBrv b ))^,ibjeeevfs.x^(Cb umn zCM umn nsutheo[p aonAGd] x,iPRIMARYhKEYlerpUNIQUErrcooooooooolCts hai** npdim ahblobtitheiocksd
yn  efiseuA t/ rCNg^r rla
)^,ibjeeevfs.x^([(M tignikeyecbts hai**lb|*Fedtignikeyecbts hai**l]doren h <tri,rrcooooooooolC umn zCM umn nsutheo[p ao [chiytnkey]nSyaetieo meapdim ahblobtitrrcoooooooooeiocksd
yn  efiseuA t/ rCNg^r rla
)^.ibje</ulfibjobjheUnlla
eithf ts i oUBTYPE]MISUSE,ptui(f  d conftiStTfm arrco[ed forci aCnrpefereArMAaiseimmehnpdidnCshge r rla
il orviarrco[ttegi_hAMAaimmeir]snpdiittegi]dsMAamsgir]snpdirelV)iLeuiULeo mlsorurrcoApBLOBr* d concmde,s]ttegi]dsblobyd
ynirhreisercobaLeo -DSoV)aiano[ttegi_hAblobyba tir]s  savs] Psnpdidod,s  il,s]o -DSatsetttegi_hAbloby rCNgir]uleyup;[BLOBrhretl ]eombaidsmovS  eCoaatsesdad confrr wrp aguai chantSl oru
tnerAPtd[ttegi_hAblobybad
ynir]iano tpGM aa
sd,Howeverreret cM umn,SnSl o, um ed forci p ao [BLOBrhretl ]
bjhombnbisuned ck   hfftrletup;[BLOBrhretl ]eissd
yn  sorut whh  no-iorr wrrbuss> BLOBrhretl  i-olxthru ma mod,s  il,s]nfiano[UPDATEt, [DELETEt, um ,s]iON CONFLICT]otids-ead cts ed pruenV)a BLOBthretl  idxmarkastath"Mxpirsd"r fiossisl somrueoistany |b umn p aguairowh thd ck   , ehenaaclC umnoruhotEds] ulorV)tdphnnV)a BLOBthretl  idxd
yn on.eperiSeCstcsmp(Xittegi]dsblobyba tir]snpdiittegi]dsbloby rCNgir]sfis
anofnArepirsd BLOBthretl  irnVetonl aaheep arimmehp atUBTYPE]ABORT],s] ee(Crck  sx rCNteusineCoa BLOBt olum eoAV)a BLOBtrepirtnerayebsetrrcoro"nCNiethenbs]tup;Mepira(oth p ateeOBLOBseeSe h arck  sxtl nrersinu "nyrrcocMmautnistee m hansa conftodaninu Tfnoeimmile(othsets] objheUcsfeineittegi]dsblobyb cTser]s  savs] Pstondegerminepguaiatndbps ed prutd
yn  eblob. heyup etndbpstahblobtmeisseisuned ck   hbbaeeeyritye pGM aa
rSyUcsfeineiUPDATEtethoicMmaapdimosdirtrmaguaiatndbpstaobjhblob.Ieuoruheyup [ttegi]dsbGd]_bavrblobir]snpdiittegi]ds* yr S_bavrblobir]s tpGM aa
l
bjhapdim ahbuilt-i"p[bavrblob]hthoi  d confhreisercisastrco|ssV)itaobjhbavr-el n  eblobtrcouA tlerp rCNg^u
tnerAPtdCherid ins -blobti pGM aa
roruoruhloeaeret aahesourbialeak, eheryxd
yn [BLOBrhretl ]eis*enenersinu "nyrrcoercobLSsdide,s]aioe nrrco[ttegi]dsbloby^ ^Tmirtsoru
 whSeeesmiz:Yie ]ultnebloby^ ^Tmirt,iano[ttegi_hAblobybad
ynirtepettegi_byblobyba tir],iano[ttegi_hAblobyb cTser]epettegi_bybloby rCNgir]u f*xWris] objeretenttegi_hAblobyd
yni
rrttegi_h*,x rs] objreAP *zDb,x rs] objreAP *zTSl o,x rs] objreAP *zCM umn,x rttegi]dsiendQ iRow,x retenflans,x rttegi]dsblobt**ppBlobxe*xasesPh geDe changMovSuh BLOBtHretl  eCoa NSafRowIeulbjheyup;veselliAblobs] objhelQeyu  d conftisse astrcomovSbanobeshil_er[BLOBrhretl ]eixim andnssi-olxsELjetonaesdad confrr wrp aguai chaned forci nSl oulelQRYgSafrowh thGds r,s   Ssd byb itdrowidsv b )tthmodesa pguaiaeasu
nforen-me. Onlyb itdroweombaidrrcoc ck   ulelQRYnd forci, nSl ohnpdi|b umn pMrwuity te eblobthretl  idxd
yn
anorwmainaguai cha.gMovreA]aqobeshil_er[BLOBrhretl ]etonaegSafrowh t
anofas)^rrguanh^ ^TtnerAPtdbeshil_erhretl  rrcoa
yb-DSea newmphnsor*oruhe(yup;gSafrowhrla
*meedyV)ai chancrCNgriauas(urr]ittegi]dsblobyd
ynir] -rityeterla
*exshibapdim arnhrla
** eeiorrleahblobtum etes"v b )tanauxtnChianom ahFominaessecC umnret*eIstee mgSafrowh thcnqepreE nthi"pguaip <tr, um ebsnonithnceabcnqeodan Sseahblobtum etes"v b ), um ebhfqaSEitdMAaise]r,s]
,]nfianothosieseAaiseimmehithaweiroeegnpdim ahblobthretl  idximtsshtVobjabortsd,s] e^ArtotubC*
* ht lstcsmp(Xettegi_byblobyba tir],iittegi]dsbloby rCNgir]sjeatsetttegi_hAblobybad
ynirtrzhm *jabortsdhblobthretl  immedietelyraweiroianothoYPE]ABORT.heCAcLapGMittegi]dsblobyb cTser]szhm *jabortsdhblobthretl 
bjhalwayssheep athbavr.s] objhelQeyu  d conftiStTfm ahed forci hretl  MAaiseimmehnpdidnCshgeu f*xWris] objeretenttegi_hAblobybad
ynittegi]dsblobt*f ttegi]dsiendQe*xasesPh geDe changC ^Tm A BLOBtHretl sPh DESTRUCTOR:nttegi_hAblobs] objhelQeyu  d conft^ ^Tmhdfn a
yn [BLOBrhretl ].he(yup;BLOBthretl  idx^ ^Tm Ssd  d aeXlpesmhnlesd,Ehenaifheeeyurt ethneheep a pnpeMAaiseimme,oV)aianohretl  idxhilrto^ ^Tm rets] objheIstee mblobthretl  eiocks| ^Tm swased
yn  efiseuA t- rCNg^r rla
epnpdiis ed pruted forci iss Mrauto-cMmautnmmmehnpdim arnhayebsehotEds]a
yn uA t- rCNgobjhblobrhretl seprhacgang^ rCNg^smftMihe s,nV)a iexn*hAp hansa conft t
anocMmaut)iLsdeIstnpGMAaise]r,s]
e a ltocMmaut)tnerAPtd hansa conf,tnpGMAaisELje Ld 
ithaweiroeegnpdim ah hansa conftro"nCNiethe.s] objhCAcLapGMtui(f  d confttonl af;foren-metu andnsuset aaauxa taetCNTSpr fqritya
yn blobthretl  heyr Ssoinhi Syaets rbehavlum.heCAcLapGMeeeyurt ethnritytonl aanu nrpaetCNTS(se h aser Sytn* eaweiroeegrrpa irnVed ^e nrrcrrcoie ]ultneblobyd
ynir])eiTfr hLLmnoe<nnb-op.,^Otrrlwiib,aifheeeyu  d confPIe*nsuthmodesal aerc a
yn blobthretl ,nV)a  rh SsoaweiroeegrrpguaPIe*ttegi_hAMAaimmeirpnpdistegi]dsMAamsgirhfiULeo mlbayebaubdbi(M toaweiroioh,t *xWris] objeretenttegi_hAbloby^ ^Tmittegi]dsblobt*e*xasesPh geDe changReep arssVnltndb *
AbaO
yn BLOBsPh bjheyup;veselliAblobs] objheR ts i pguaiatndbSsr,scTdbpstV)eSBLOBtr rla
il orviapguaPIe*te rla
fu"nyed
yn  e[BLOBrhretl ]einlutsrpce ^roren-me. lelQRritye erid ins SblobtI/O*rt ethnsYcanlenabaks tlerpovMA rCNg^beshil_eobjhblobraCht-me;;repyVombnbisdirtrmaguaiatndbpstahblob.IeuoruhTeeyurt ethneenabaworksnth a [BLOBrhretl ]ewuity hfrabeyno,ssV)iL
bjhbybfOtmlum se rla
fu"ioe nrrco[ttegi]dsblobyd
ynirtrnpdi uity hfrasetrrcobeyno, ^Tm s,s]ittegi]dsbloby^ ^Tmirts  Pas -DSeany otEds]paetCNTSinoruhgoum eyurt ethneheyr Ssoinhi Syaets rretephobal yri Sysiral oheihavlum.t *xWris] objeretenttegi_hAblobyb cTsettegi]dsblobt*e*xasesPh geDe changRe tleC f Fvfs.A BLOBtIherid ins nyrrcobjheyup;veselliAblobs] objhe(lQeyu  d conftisse astrcoks tldnrQtevfs.fn a
yn [BLOBrhretl ]sineCoa
bjhom"nCr-suhosim s,uad c. Nr,scTdbpstdnrQtfreh|LpidesineCo,uad c Z
anofn bb itda
yn BLOB,^smf *apGMussdffnetaiOfftecrets] objheIstdffnetaiOfftecoidxlea
etufn Nr,scTdbfn bb itde*dnofb itdBLOB,rrcoilr8],(MERROR]fithaweiroeegnpdisehdnrQtithawadule^IstN um eOfftecoidrrcolea
etufn bavrreilr8],(MERROR]fithaweiroeegnpdisehdnrQtithawaduoruheyup atndbpstV)eSblobt(npdih hcQ paggmaximum"v b )tOStN+eOfftec)
bjhombaidsdegerminedru
tnerAPtd[ttegi_hAblobyb cTser]s  savs] Psorut wheAth, oiaprrrcoks tlevfs.fn repirsd [BLOBrhretl ]sirnVsetonl fqrityMAaiseimmehp atUBTYPE]ABORT],s] objhe(Oa Ce rla
,ettegi_byblobyba tirhf ts i oUBTYPE]OKuoruhOtrrlwiib,anpG6MAaiseimme]hpr fqetextenSsdrMAaiseimme]h thaweiroeerets] objhTeeyurt ethneenabaworksnth a [BLOBrhretl ]ewuity hfrabeyno,ssV)iL
bjhbybfOtmlum se rla
fu"ioe nrrco[ttegi]dsblobyd
ynirtrnpdi uity hfrasetrrcobeyno, ^Tm s,s]ittegi]dsbloby^ ^Tmirts  Pas -DSeany otEds]paetCNTSinoruhgoum eyurt ethneheyr Ssoinhi Syaets rretephobal yri Sysiral oheihavlum.t u
 whSeeesmiz:Yie ]ultnebloby rCNgir]u f*xWris] objeretenttegi_hAblobyba tittegi]dsblobt*f Iflsn*Z, etenNf eteniOfftec)*xasesPh geDe changWrCNg^eC f IneCoA BLOBtIherid ins nyrrcobjheyup;veselliAblobs] objhe(lQeyu  d conftisse astrco rCNg^dnrQtineCoar a
yn [BLOBrhretl ]sevfs.f
bjhom"nCr-suhosim s,uad c. Nr,scTdbpstdnrQtfreh|Lpidesfn bb itd,uad c Z
anoineCoee)ta
yn BLOB,^smf *apGMussdffnetaiOfftecrets] objhe(Oa Ce rla
,ettegi_bybloby rCNgirhf ts i oUBTYPE]OKuoruhOtrrlwiib,anpGG6MAaiseimme]hpr fqetextenSsdrMAaiseimme]h thaweiroeerets] heUnlla
eUBTYPE]MISUSEh thaweiroee,ptui(f  d conftiStTfm arrco[ed forci aCnrpefereArMAaiseimmehnpdidnCshge r rla
il orviarrco[ttegi_hAMAaimmeir]snpdiittegi]dsMAamsgir]snpdirelV)iLeuiULeo mlsorurrcoeIstee m[BLOBrhretl ]sthmodesa pguairuoly foren-metrfraait_R
yn  efis
ano rCNapGM(ee mflansg iee^s</rrrco[ttegi]dsblobyd
ynirtrrfrabavrcrELjerei(f  d conftf ts i atUBTYPE]READONLY].IeuoruhTeeyu  d confhreisenabamod,ss]gua |bht-mesnofb itdBLOB;mitj toruhcnqepoasil oetonChereasmaguaiatndbpstahBLOBro -DSoV)reAeDesobjheIstdffnetaiOfftecoidxlea
etufn Nr,scTdbfn bb itde*dnofb itdBLOB,rrcoilr8],(MERROR]fithaweiroeegnpdisehdnrQtith rCNteu.gTupnatndbpstV)errcoBLOBr(npdih hcQ paggmaximum"v b )tOStN+eOfftec)hombaidsdegerminedSsd  
tnerAPtd[ttegi_hAblobyb cTser]s  savs] Pse^IstN um eOfftecofreh ess ed prfn bavroilr8],(MERROR]fithaweiroeegnpdisehdnrQtith rCNteu.orut wheAth, oiaprrrco rCNg^Vo.fn repirsd [BLOBrhretl ]sirnVsetonl fqrityMAaiseimmehp atUBTYPE]ABORT],le^WrCNgs eoAV)a BLOBtTbussdciexn*L
bjhbi(M toee m[BLOBrhretl ]srepirsd ayebsetoro"nCNiethenbs]tuprityMepira(oth p ateeOhretl ,nV)oonnatfecbs]
toeeoci arck  sxmrla
ianohrveobeynoovMA rCNtesr,s]gua ]mftMihe  ebussrepirsd V)a BLOBthretl rityam ,s]otEds]Gd] penSstentmftMihe s.IeuoruhTeeyurt ethneenabaworksnth a [BLOBrhretl ]ewuity hfrabeyno,ssV)iL
bjhbybfOtmlum se rla
fu"ioe nrrco[ttegi]dsblobyd
ynirtrnpdi uity hfrasetrrcobeyno, ^Tm s,s]ittegi]dsbloby^ ^Tmirts  Pas -DSeany otEds]paetCNTSinoruhgoum eyurt ethneheyr Ssoinhi Syaets rretephobal yri Sysiral oheihavlum.t u
 whSeeesmiz:Yie ]ultneblobyba tir]u f*xWris] objeretenttegi_hAbloby rCNgittegi]dsblobt*f s] objIflsn*z, etennf eteniOfftec)*xasesPh geDe changVirtis SF ltoSystMitObje<tsoruoruhA virtis SfilQsystMit(VFS)rithahi[eggLlgaAvfs]uobje<t ed prftothosiesosemalos  savactritytonl V)a i Syrlyocksd
yrs]tnerCystMis  MMsththosiesbuilTsioogurtonl fPIe*naohecccAPie cgVFStu andnsua  roCmld. ee icgulYhMsthimmiuxWv,s] eNSafVFSnsYcanl* ereodeseCrilretebeshil_erVFSnsYcanl* eunf odeseCrisoruxTQRYfrLu
ntner tpGM aa
l ayebiaoviSsd><rdoh t^yupne ]ultnevfs_aetd(rs  savs] Psf ts i pastaetCNTSuxfr VFStgivesrutsrgoe ,orureNamnCNrreh|asmasensFgang,orureNamnCNrrehbavr-germinaesseUTF-8nslergus,s] eeIstee TSuxilia match, aaauxa taetCNTS thaweiroeers] eeIstzVfsNoe 
ith
*t[eretenpruteAPie cgVFSt thaweiroeers] orureNSafVFSnsYfrehawodeseCriltledne ]ultnevfs_awodeseC()soruheEassgnSafVFSibmcomsnrrhaieAPie cgVFSt steeeO akeDflt flans sotecroh t^yupneoe 
VFStcanl* ereodeseCrilme cip oetimesntledduo[injuryroh t^yoO ake]aqobeshil_erVFSt neCoee)teAPie cgVFS,ouAodeseC ith>g Ssritytonl V)a  akeDflt flanstecs h no-woesdad confrVFSnsYwhuss itrrcotoe 
goe 
frehreodeseCri,nV)a eihavlumtisse Syaets s h nofPIe*VFSt thawodeseCriltlednatnoe 
rbussith
*t[epr fqeiaprynslergurELjeretnnV)a eihavlumtisse Syaets s
bjobjheUnuAodeseC agVFSttonl V)a e ]ultnevfs_unf odeseC(rs  savs] P,s] ee(Istee meAPie cgVFSt thunf odeseCri,hfqaSEitdVFSt thceocin ast whee meAPie cc ossVnshoic ee icgulYnSafVFSinsuaonitcholrets]*xWris] objere ]ultnevfs *e ]ultnevfs_aetd(s] objreAP *zVfsNoe e*xWris] objeretenttegi_hAvfs_awodeseC(ttegi_hAvfsBf eten akeDflte*xWris] objeretenttegi_hAvfs_unf odeseC(ttegi_hAvfsBe*xasesPh geDe changMuxWxesoruoruhlQRethosiesaCresosemalupse*rt ethnsYe icguuA tianosynchronyu fs e.yao^onnaguayuh ai ltenSsdre icineu*ns Ssd  
enbs]**nCNT,eimmehrbusslinksn>g Sssththosies toruhpermit)iLSuxfuibtnpy olum ase*rt ethns.oruoruhlQRethosiessourbiaimmehodan Ssseme cip oeistaid ina(othsrityolum ase*muxWx*rt ethns.nrAnua  roCmld. eestaid ina(othrity sotel*cte enutotT_H, "nyeathimmiilQ-timeuleyup;frLu
ntnerity staid ina(othsofrehavaulal omst;tQRethosiesaCreyin<li> oulfibjevfs.x eUBTYPE]MUTEX_PTHREADSibjevfs.x eUBTYPE]MUTEX_W32ibjevfs.x eUBTYPE]MUTEX_NOOP ed </ulfibjobjhlQRethoYPE]MUTEX_NOOPh staid ina(othoiTfr tecogurr  ethns ed prftonceabcnhf alrWfdk-DSeanddnsua  roCmld. ee icicsein ed ainaohec-guuA te enhosiso*etCuleyup;UBTYPE]MUTEX_PTHREADSerrce nrlr8],(MMUTEX_W32y staid ina(othsofreha  roCmld. ee icicsethoUnix ed anddWetdChdu<rdoh tIfhthosies thimmiilQdttonl V)a lr8],(MMUTEX_APPDEFepre rorla
is
anomecro Syaets r(tonl "-Dlr8],(MMUTEX_APPDEF=1")reretenia muxWxrity staid ina(oth iss Meludsdttonl V)a libcholr a teeeyu,asmagua ed ahosiso*etChrla
*suhoss]aiola
 bbmuxWx*istaid ina(oth os-DSoV)aiano[ELFORDECONFIGMMUTEX]si
t su
olum ahsggLlgaAeqnfigirhfiULeo m
bjhbi(M tocAcLapGMttegi]dsieitiheyus(d  noany otEds]public ttegi]ds
anofiULeo mirbussomtcsmttegi]dsieitiheyus(d><rdoh t^yupne ]ultnemuxWx_arthwirhft ethnearthws] soa new
anomuxWx*npdirets i pastaetCNTSuxfit.t^yupne ]ultnemuxWx_arthwir
anort ethneheep a p
*t[einoitiisSunal omeoAarthws] b itdr*
* s)iL
bjhmuxWxuleyup;foren-metuone ]ultnemuxWx_arthwirhrla
** eahe
olum asRritye tegitd|bts anCsyin<li> oulfibjevfs.x lr8],(MMUTEX_FASTibjevfs.x lr8],(MMUTEX_RECURSIVEibjevfs.x lr8],(MMUTEX_STATIC_MAINibjevfs.x lr8],(MMUTEX_STATIC_MEMibjevfs.x lr8],(MMUTEX_STATIC_OPENibjevfs.x lr8],(MMUTEX_STATIC_PRNGibjevfs.x lr8],(MMUTEX_STATIC_LRUibjevfs.x lr8],(MMUTEX_STATIC_PMEMibjevfs.x lr8],(MMUTEX_STATIC_APP1ibjevfs.x lr8],(MMUTEX_STATIC_APP2ibjevfs.x lr8],(MMUTEX_STATIC_APP3ibjevfs.x lr8],(MMUTEX_STATIC_VFS1ibjevfs.x lr8],(MMUTEX_STATIC_VFS2ibjevfs.x lr8],(MMUTEX_STATIC_VFS3 ed </ulfibjobjhelQRYfuoly -woe|bts anCs (lr8],(MMUTEX_FASTbaChelr8],(MMUTEX_RECURSIVE)
bjhomicses ]ultnemuxWx_arthwirhrco|ssV)i ed ainewmmuxWxuleelQRYgSafmuxWx*ithaw,s]
ang^ aenotho],(MMUTEX_RECURSIVEibjeisse ast,usssetone<nCshoiss]so^ aenotho],(MMUTEX_FASTbisse assoruxTQRYmuxWx*istaid ina(oth nceabcnqeneastrco ake]aesdhil_Leo m
bjhbitweenotho],(MMUTEX_RECURSIVEbaChelr8],(MMUTEX_FASTbifnithnceaoruhcnqewanCcgo. hthosiestl nr]nabaks
* s) aahe,s]
ang^muxWx*in
bjhomsesd aeed ithf alabaneedsmphns h nofofas)^rrnbilhe,s]
ang^muxWxrity staid ina(oth issavaulal omRarguaihMsthplatrrlm,nV)a muxWx*tubCystMi
bjhmrla
*heep arse h a^muxWx*in sn  aesomeoAlr8],(MMUTEX_FAST><rdoh t^yupnoorrlearthwdesis] objerTfnoos ]ultnemuxWx_arthwirh( fythinoooorrl ed prfn lr8],(MMUTEX_FASTbaChelr8],(MMUTEX_RECURSIVE)ceassgaweiroianoastaetCNTSuxfr tmftic  oabeshil_ermuxWxuleeNthnetmftic muxWxesd oeELjeus se,s]V)a iexn*hApefnqld [p a**nCNToh Fuburnhefnqld  ppstthosierrcoreisaddeaddypesmhn;tmftic muxWxes. htmftic muxWxesd oere icineu*ns Ssd  
enbs]**nCNT ece uleAhosiso*etCsbTbuss 
en**nCNT muxWxesdaf SytELjeicsethlyb itddynoeic muxWxesdaweiroeegrrplr8],(MMUTEX_FASTbis
anolr8],(MMUTEX_RECURSIVErs] orureNot 
rbussifeahe
olum addynoeic muxWxsis] objerTf(lr8],(MMUTEX_FASTrityam lr8],(MMUTEX_RECURSIVE)cisse astraenoe ]ultnemuxWx_arthwir
anorets i passdad confrmuxWxs meeheryxomtculeeFed paggtmftic
anomuxWx*btbs
,iguai chanmuxWx*ithaweiroeeg meeheryxomtc
rbusshast whee m chantetece rol ><rdoh t^yupne ]ultnemuxWx_poabM Irt ethnedearthws] soa  oavluusnyrrcoarthws] dddynoeic muxWxuleA oiaprtnestondearthws] bagtmftic
anomuxWx*heyr Ssoinhi Syaets rbehavlum.<rdoh t^yupne ]ultnemuxWx_enseC(rsnpdistegi]dsmuxWx_tryM Irt ethnsh, oiaproruhgouenseC a^muxWxule^IstanotEds] uks tlithalba tyntledtoieep;muxWxrELjee ]ultnemuxWx_enseC(rsto nr*Wfdksnpdistegi]dsmuxWx_tryM Ito nraweiroianothoYPE]BUSY. heyup etegi]dsmuxWx_tryM I  savs] Psf ts i ptUBTYPE]OK]ELjeipon se rla
fu"iMe*reule^ MuxWxesh|ssV)iLeo -DS
anolr8],(MMUTEX_RECURSIVEflobaidsenseCrilme cip oetimesn,s]gua ]oe 
rbawaduoruhIarse h crciT,rTbe
anomuxWx*rla
** eexi)iLehpce is Se rol rgurtimesn,i(M toanotEds] uks t
bjhomnsenseCset*nIf]gua ]oe 
rbawad *rirssgouenseC any muxWxs orrl ed prfn fn lr8],(MMUTEX_RECURSIVEfmM toeeanlence,nV)a eihavlumtisse Syaets s<rdoh t^(SogurCystMis (hticex or r,dWetdChd 95)idobcnqesuhoortoee)ta
yra(othrity staid inmde,s]ttegi]dsmuxWx_tryM uleOnoeeoci CystMis,]ttegi]dsmuxWx_tryM rityto nralwayssheep ar.20ORDEBUSY. IarmMsthomsesdtQRethosiesaCreethlybosemELjee ]ultnemuxWx_tryM Iaso/qud
t myu fs e,eixim isl sor rlpnSl oianobehavlum.hTPtdbe ,Cho msbfrehinixsbuilTsirbusstedyV)aianolr8],(MENERED_SETLK_TIMEyUT builTsi
t sur a teeathomse a^work-DS
anoetegi]dsmuxWx_tryM I threcbirsd>ets] objheyup;etegi]dsmuxWx_leavbM Irt ethneexi)s a^muxWx*reothrast wh oavluusnysenseCril,s]gua ]oe 
rbawadu leyup;behavlumibjeisse Syaets r steeeO uxWx*ithnbisdexn*hAnysenseCril,s]gua
bjhomcLapGMeeks tlerpithnbisdexn*hAnysarthws] dsorurrcoeIstee mforen-metuone ]ultnemuxWx_enseC(r,]ttegi]dsmuxWx_tryM rELjee ]ultnemuxWx_leavbM , um e ]ultnemuxWx_poabM IiTfr auxa taetCNTrELjeretnnany olum aofrurIrt ethnshbehavesifraTEnb-op.
 u
 whSeeesmiz:Yie ]ultnemuxWx_heltir]snpdiittegi]dsmuxWx_notEdltir]u f*xWris] objerttegi]dsmuxWx *e ]ultnemuxWx_arthwietCe*xWris] objerIflsne ]ultnemuxWx_poabMe ]ultnemuxWx*e*xWris] objerIflsne ]ultnemuxWx_enseC(e ]ultnemuxWx*e*xWris] objeretenttegi_hAmuxWx_tryMe ]ultnemuxWx*e*xWris] objerIflsne ]ultnemuxWx_leavbMe ]ultnemuxWx*e*xasesPh geDe changMuxWx McttrTsiObje<tsPhsPh Annins  *LutpsteeeyusleQtburnhSyaetssoinpnlow-lehelrr  ethns ed e astrcoarthws] bae ru
T muxWxes.
 u
 whUsuLlgi,tee meAPie cgmuxWx*istaid ina(othsbiaoviSsdnbs]**nCNT  oeELjesuffici nt,ihMwevertee mfhosiso*etChha pguaii
t su
olutubCtitu)-DSea ola
 brity staid ina(oth hticteA_zheyusdmeAploym-mesnorrCystMis htic uity thosierrconceabcnqeiaoviSsastsuitSl ohistaid ina(othr a teeeyu,asm,tee mfhosiso*etC
bjhossV)iCNretet-pulatgsaonAGds  *LutpsteeeyusleQtburnhrcophmoe nrrcoe ]ultnecqnfigirhalonlttonl V)a [ELFORDECONFIGMMUTEX]si
t suuoruhAd ypesmhnleimonAGds  *LutpsteeeyusleQtburnhombaidsisastaso/qrityautputjvhoiSl ohwetnncbhrytnerAPtdsystMite icgulYiexn*hApmuxWxrity staid ina(oth,  
tnerAPtd[ELFORDECONFIGMGETMUTEX]si
t suuoruobjheyup;xMuxWxInutnmettrTeSyaets rbyteeeyusleQtburnhiss Men-menast wh ieo[p asystMitieitiheyua(oth ,s]gua ]tegi]dsieitiheyus(d fiULeo m.objheyup;xMuxWxInutnrt ethne th|stcrinbs]**nCNT exaetabsencerhticeassobjhead ctang^oe nrrco[ttegi]dsieitiheyus(d]uoruobjheyup;xMuxWxEpdidnttrTeSyaets rbyteeeyusleQtburnhiss Men-menast wh ieo[p asystMitshutdpwhi,s]gua ]tegi]dsshutdpwh(d fiULeo m.eyuprity staid ina(oth psteeeyumettrTeidxexpectastrcoksLSsdioa nrt es  *Xl_eianohesourbisrpes] tobj,s]gua muxWx*rcttrTsi staid ina(oth, eteA_zhenyELjetu^Tmypes] tobj,s]gua xMuxWxInutnmettrT. heyup xMuxWxEpdM ianoi"s] s biaisl Men-menexaetabsencerhticeass^oe nrrco[ttegi]dsshutdpwh(d],s] objhe(Titdr*maintnerC*vesrrcttrTsiSyaets rbyteeeyusleQtburnh(xMuxWxArthwrELjexMuxWxFoab, xMuxWxEpjerrexMuxWxTryrexMuxWxLeavbrexMuxWxHeldYfrce nrxMuxWxNotEdlt)i staid inum aofrLu
ntner tpGM aa
l (reteA_tangly)yin<li> oulfibjeeevfs.xiittegi]dsmuxWx_arthwir] </fs.ibjeeevfs.xiittegi]dsmuxWx_poabM t </fs.ibjeeevfs.xiittegi]dsmuxWx_enseC(rt </fs.ibjeeevfs.xiittegi]dsmuxWx_tryM t </fs.ibjeeevfs.xiittegi]dsmuxWx_leavbM t </fs.ibjeeevfs.xiittegi]dsmuxWx_heltir]s</fs.ibjeeevfs.xiittegi]dsmuxWx_notEdltir]s</fs.ibje</ulfets] objhTeeethlybsdad conbiaislreothm aopublic ttegi]dsXXXhfiULeo mlbes rerV)iL
bjhabovSbsulQgtabs obM toany  Menso*etCsbTbussphmo aaauxa taetCNTS ds s t
bjhpstah aerc muxWx*hretl .hTPtdistaid ina(othsoDf(gua mcttrTsiSyaets ianobyteeeyusleQtburnhayebsetorecbirsdrrcohretl  eeeyu,asm.hTPtdheyr Ss
bjhpstpas -DSeaaauxa taetCNTS ds s thpstah aerc muxWx*hretl Yfrehi Syaets 
bjh(i.m.hitj tha rlpnSl ohrcopaoviSsasny staid ina(oth rbusstegPie cs ebsnonithnsuthmodesalauxa taetCNT).oruoruhlQRexMuxWxInutirhrettrTerla
** eeeks tsaferSyIaerla
** ehLLmnoe<nrcrrcoinvbjeexMuxWxInutirhre cip oetimesntledinaguai cha  rorla
rnpdi ledduoianoi"s] vyb-DSelstcsmp(XxMuxWxEpdM . hteasu
nfpdisubC*
* ht lstcsmp(e nrxMuxWxInutirhrea
** enb-ops.
 u
 whxMuxWxInutirhrea
*seto 
en**nCNT memM ysarthws]o me(ittegi]dsmarthwir]
ed anddi)s assocld. s . htiaulavleimxMuxWxArthwirhrea
*seto 
en**nCNT memM yrrcoarthws]oth htica;tmftic muxWx. heHowevermxMuxWxArthwirhrayo 
en**nCNT
anomemM ysarthws]o mehtica;fas)eonn* ,s]
ang^muxWx,s] objhethosiestl nrinvbjeeretlxMuxWxEpdM hrettrTewetnn[ttegi]dsshutdpwh(d]t t
anocstcri,e,ussthlyb steeeOtmlum oe nrrcoxMuxWxInutnrweiroeegUBTYPE]OKuoruhIstxMuxWxInutnirnVseinnany wayimitj thexpectastrcocleanlop fftrleotselft wh olum eoAaweiroioh,t *xbtbscAPjs hurenttegi_hAmuxWx_mcttrTsittegi_hAmuxWx_mcttrTs;xs hurenttegi_hAmuxWx_mcttrTsi{x reten(*xMuxWxInut)ieret);x reten(*xMuxWxEpd)ieret);x rttegi]dsmuxWx *(*xMuxWxArthw)ietCe*x rIflsn(*xMuxWxFoab)(ttegi]dsmuxWx *e*x rIflsn(*xMuxWxEpjer)(ttegi]dsmuxWx *e*x reten(*xMuxWxTry)(ttegi]dsmuxWx *e*x rIflsn(*xMuxWxLeavb)(ttegi]dsmuxWx *e*x reten(*xMuxWxHeld)(ttegi]dsmuxWx *e*x reten(*xMuxWxNotEdlt)(ttegi]dsmuxWx *e*x}*xasesPh geDe changMuxWx Verzsics]o meR  ethns edoruhlQRettegi]dsmuxWx_heltirsnpdistegi]dsmuxWx_notEdltirrr  ethns ed h ai ltenSsdre icicseinsiSsasmodrtirhtmftMihe s. hlQRethosiesaCreoruhcevermosemalupse*rt ethnsYre ,CheinsiSsasnasmodrtirhnpdifhosiso*etCs ed h aiadvi astrcofrLu
noinpnls thpstgulYiCre. hlQRethosiesaCrerDnabt wh aoviSssi staid ina(othsie icgulse*rt ethnsYwetnnitj thimmiilQdritytonl V)a lr8],(MDEBUG flansd,Exeu*ns gmuxWx*istaid ina(oths ed h ai]nabaks
*irsdrrcopaoviSsagulse*rt ethnsYif lr8],(MDEBUG  t
anoSyaets rreteif NDEBUG  t*setoSyaets s<rdoh tTulse*rt ethnsYis*enenheep armrueoisteeeO uxWx*inaguairmforen-meibjeissEdlteonnsetoEdlt, reteA_tangly,e,s]V)a imcLapGMeeks t.oruoruhlQRe staid ina(oth isssetorecbirsdrrcopaoviSsaefnqld  ppstV)asRrityrt ethnsYrbuss>cnu "ny^work.nIf]gua istaid ina(oth nceabcnqepaoviSsawork-DS
anoefnqld  ppstV)asRyrt ethnsimitjis*enenussleas)epaoviSsastubCYrbuss>lways
anorets irmrueoixim andahe
nceabcnqegetjipurluusasmodrtonftirnVurndu<rdoh tIfhee mforen-metuone ]ultnemuxWx_EdltirriTfr auxa taetCNTeretnt whee mrt ethneis*enenheep ar1u leyu soteMis coutCNT-etCuFganginaobiELjeclearls]gua muxWx*ombnbisuneEdlteifnithnceabcnqeexshiu lButt whee mreasooieep;muxWx nceabcnqeexshiditheilcicsfeinebuilTsnsusetrrco 
tnermuxWxes. hApdi eidobcnqewanCcghsasmodrtirhodan Ss-DSoV)aianooe nrrcoe ]ultnemuxWx_EdltirrrcofrnV,eixiahnbilbavrnheep arGs ed pruta  roCmld. ethinootondo. hlQRestegi]dsmuxWx_notEdltirianoi"s] s biais*enenulsrnheep ar1Ywetnngivesracoria t-olxWv,s]/
#if Sya NDEBUGxWris] objeretenttegi_hAmuxWx_Edltie ]ultnemuxWx*e*xWris] objeretenttegi_hAmuxWx_notEdltie ]ultnemuxWx*e*x#enSebsasesPh geDe changMuxWx Ttbs
oruoruhlQReittegi]dsmuxWx_arthwir]   savs] Pst py oainaoheccforen-meibje uity iseahe
olum asRye tegitd|bts anCs.oruoruhlQRetecogurtmftic muxWxesdrayodirtrmafn bbonRethosiesksLSsdioeCoee)ianonextuleAhosiso*etCsbTbussovMAriSsagulhbuilt-i"pmuxWx logic musisunatsepre arsdrrcoa rLVmDds] baddypesmhn;tmftic muxWxes.or*x#Syaetsu**n],(MMUTEX_FASTbbbbbbbbbbbbb0x#Syaetsu**n],(MMUTEX_RECURSIVEffffffff1x#Syaetsu**n],(MMUTEX_STATIC_MAINffffff2x#Syaetsu**n],(MMUTEX_STATIC_MEMfffffff3 r/* ttegi]dsmarthwir r*x#Syaetsu**n],(MMUTEX_STATIC_MEM2ffffff4  /* NOT USED r*x#Syaetsu**n],(MMUTEX_STATIC_OPENffffff4  /* ttegi]dBtoabO
ynirhr*x#Syaetsu**n],(MMUTEX_STATIC_PRNGffffff5 r/* ttegi]dsyc*domhnssirhr*x#Syaetsu**n],(MMUTEX_STATIC_LRUfffffff6 r/* lruuthge liobjr*x#Syaetsu**n],(MMUTEX_STATIC_LRU2ffffff7  /* NOT USED r*x#Syaetsu**n],(MMUTEX_STATIC_PMEMffffff7 r/* ttegi]dPhgeMarthwir r*x#Syaetsu**n],(MMUTEX_STATIC_APP1ffffff8 r/* F icicsebybfhosiso*etChr*x#Syaetsu**n],(MMUTEX_STATIC_APP2ffffff9 r/* F icicsebybfhosiso*etChr*x#Syaetsu**n],(MMUTEX_STATIC_APP3fffff10 r/* F icicsebybfhosiso*etChr*x#Syaetsu**n],(MMUTEX_STATIC_VFS1fffff11 r/* F icicsebybbuilt-i"pVFSir*x#Syaetsu**n],(MMUTEX_STATIC_VFS2fffff12 r/* F icicsebybextenqld [VFSir*x#Syaetsu**n],(MMUTEX_STATIC_VFS3fffff13 r/* F icicsebybfhosiso*etChVFSir*xase Legacyeimmistibiegiy: r*x#Syaetsu**n],(MMUTEX_STATIC_MASTERffff2xxasesPh geDe changReerievSb itdmuxWx htica;ed forci aCnrpeferesPh bjheyup;veselliIeuoruheyuisI  savs] Psf ts i paYpaetCNTSuxim enittegi]dsmuxWx]uobje<t e ansnossgriaeyuss r rla
Suxim enied forci aCnrpefereArgivesrunhee mforen-meibje utnnV)a [eeks tl_ermode]h thSgriaeyusers] eeIstV)a [eeks tl_ermode]h thSaohec-guuA teonnMe ci-guuA tetutnnV)Gs ed rt ethneheep a pncoria t-olxWv,s]/
Wris] objerttegi]dsmuxWx *e ]ultnedbsmuxWx(eggLlgaBe*xasesPh geDe changLow-LehelrCdanrolb *
Dd forci F ltsritybjheyup;veselliIeu KEYWORDS: {f ltocManrol}
ruobjheyup;[ttegi]dsp lt_cManrolir]   savs] Psm py oaidirsctooe nrrcoee)ianoxFimeCdanrolbrettrTee icgulY[ttegi]dsio_mcttrTs]uobje<t assocld. dritytonl ahnheoiculavsed forci ids r,s   i,s]gua ]easu
nforen-me. elQRritynoe 
olum ahnd forci
ith"main"ie icgulY ainand forci  ic"rdmc"ie icguloruhlEMPYnd forci,  icgulYnoe 
rbuss>  aarsifftrletup;ASikeywordofis
anond forciT e and oebaddedru
tnerAPtd[ATTACH]]thoicMmaapd,s] e^A auxa taetCNTeombaidsisastinatlaas
olu"main"ieoAawfNTSuxim e
anomainand forci filQ.objheyup;V)rr cretefoer-isis] objerTfnooeeeyurt ethnrityayebihmodesdirsctls]guroonnago]gua ]easu
nfpdim rr ct]pe^s</rsbps ed prutxFimeCdanrolbrettrT. heyup heep arv b )tOStprutxFimeCdanrol
anomettrTebmcomsnrrhaiheep arv b )tOStpreyurt ethnsorurrcoApfewmppimmes(urr]ittegi]dsp lt_cManrolir] ayebhretl esdirsctlsianobyteeRethosiesaCrernpdiseverminvbjeeret
Ljee ]ultneio_mcttrTs.xFimeCdanrolbrettrT.objheyup;[Wris] oFCNTL_FILE_POINTER]rv b )te icgulYopg iee^s</rromosemrityaYpaetCNTSuxim eni Syrlyocksittegi]dsp lt]uobje<t extbex rCNteusineC ed prutspaas
paetCNdrrcobyteeRe4-isis] objer. hlQR ed [Wris] oFCNTL_JOURNAL_POINTER]rworksnsiaulavleAre ,Cheutandnssheep a  ed prutittegi]dsp lt]uobje<t assocld. dytonl V)a joerns SfilQS ds s thps ed prutmainand forciuleyup;[Wris] oFCNTL_VFS_POINTER]rppimmesheep a  ed aYpaetCNTSuxim eni Syrlyocksittegi]dsvfs]uobje<tte icgulYfilQ.objhyup;[Wris] oFCNTL_DATA_VERSION]sf ts i pguaidnrQtefnqld [coutCNTobjhfn bb itdthgen,irnt wheIstee m]easu
nt]pe^s</rr(zDbNoe e nceabcnqematchcgulYnoe 
p aonsianoa
yn nd forci filQ, m aar.20ORDEERRORoithaweiroeer heyuisIMAaisELje Ld 
ithcnqeawmerol s rretetl nrnbisunerscstcrinbs][ttegi_hAMAaimmeir]ianoariittegi]dsMAamsgir]uleyup;i SyrlyocksxFimeCdanrolbrettrTemrla
ianoulsrnheep ar.20ORDEERRORuleyupTSuxilia wayotondshil_euishhbitween
ed ans MeorrsctozDbNoe ehpdinfr.20ORDEERRORoheep arfn bb itdi SyrlyockianoxFimeCdanrolbrettrT.
 u
 whSeeesmiz:Yif ltocManrolmppimmestor*xWris] objeretenttegi_hAp lt_cManrolieggLlgaBfrs] objreAP *zDbNoe f etenopf IflsBe*xasesPh geDe changTehil_erIds] s biELjobjheyup;ttegi_hAtehi_cManroliroi"s] s biaislisastrcouA tleuo[ineu*ns Ssd tmftMppstthosie apdimosinje<tteie cs eneoAlr8i. ee icgehil_eobjh ursoIEs. heyup fuoly  iee^s</rrithar a
yra(oth immehrbussdegermines ed prutn rol , me"nrgur rrcoa
yra(oth p aartotubC*
* ht t]pe^s</rs.IeuoruhTeeyui"s] s biaislnbisf icicsebybfhosiso*etCsrSyIaeexshilbsolenyrrco  icverzsytnerAPtdeorrsctoa
yra(oth p aeeRethosieslibcholr  D penSl_eobjhtChh
noinpnthosieslibcholj thimmiilQd,rTbreAG savs] Psmrla
*cnqeexshiuoruoruhlQRedegrnVsep aeeRea
yra(oth immeT,rTbeir me"nrgu
,iguait]pe^s</rs ed pruyst py,rnpdi uothm ayidob oebartotubje<t extdirtrmatledduo[cnqi P,s] eUnlikermMsthp aeeRethosieseDe,ptui(f  d conftislnbisgu]pe saastrcianoa
yrV)iximtssstQgtabsfn bbonReksLSsdioeCoee)onextuor*xWris] objeretenttegi_hAtehi_cManrolietenopf ...e*xasesPh geDe changTehil_erIds] s biaO
yra(oth CmmeT<rdoh tTulse*|bts anCs ayeb itd aerc a
yra(oth immeht]pe^s</rsbisasELjea pguairuoly foren-metrco[ttegi]dstehi_cManrolir]s<rdoh tTulse*t]pe^s</rsbnpdim air me"nrgu
bayebaubje<t extdirtrmritytonlduo[cnqi P, tTulse* rh Sso oere icgehil_eh ursoIEs ece urrcoAhosiso*etCsbis*enenseto 
ennpy olum ase*t]pe^s</rsbpicguloruh[ttegi]dstehi_cManrolir]s  savs] P,s]*x#Syaetsu**n],(MTESTCTRL_FIRSTbbbbbbbbbbbbbbbbbbbb5x#Syaetsu**n],(MTESTCTRL_PRNG_SAVEffffffffbbbbbbbb5x#Syaetsu**n],(MTESTCTRL_PRNG_RESTOREffffffffbbbbb6x#Syaetsu**n],(MTESTCTRL_PRNG_RESETbbbbbbbbbbbbbbb7  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_FK_NO_ACTIONbbbbbbbbbbbbb7x#Syaetsu**n],(MTESTCTRL_BITVECMTESTbbbbbbbbbbbbbb8x#Syaetsu**n],(MTESTCTRL_FAULT_INSTAxa            9x#Syaetsu**n],(MTESTCTRL_BENIGN_MAxaOC_HOOKSfffff10x#Syaetsu**n],(MTESTCTRL_PENDING_BYTEffffffffbbbb11x#Syaetsu**n],(MTESTCTRL_ASSERTbbbbbbbbbbbbbbbbbb12x#Syaetsu**n],(MTESTCTRL_ALWAYSbbbbbbbbbbbbbbbbbb13x#Syaetsu**n],(MTESTCTRL_RESERVEffffffffbbbbbbbb 14  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_JSON_SELFCHECKfbbbbbbbb 14x#Syaetsu**n],(MTESTCTRL_OPTIMIZATIONSbbbbbbbbbbb15x#Syaetsu**n],(MTESTCTRL_ISKEYWORDffffffbbbbbbbb 16  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_GETOPTbbbbbbbbbbbbbbbbbb16x#Syaetsu**n],(MTESTCTRL_SCRATCHMAxaOCbbbbbbbbbbb17  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_INTERNAL_FUNCTIONSbbbbbb17x#Syaetsu**n],(MTESTCTRL_aOCALTIME_FAULTbbbbbbbbb18x#Syaetsu**n],(MTESTCTRL_EXPLAIN_STMTbbbbbbbbbbbb19  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_ONCE_RESET_THRESHOLDbbbb19x#Syaetsu**n],(MTESTCTRL_NEVER_CORRUPTbbbbbbbbbbb20x#Syaetsu**n],(MTESTCTRL_VDBDECOVERAGEffffffffbbb21x#Syaetsu**n],(MTESTCTRL_BYTEORDERffffffffffffbbb22x#Syaetsu**n],(MTESTCTRL_ISINITbbbbbbbbbbbbbbbbbb23x#Syaetsu**n],(MTESTCTRL_SORTER_MMAPbbbbbbbbbbbbb24x#Syaetsu**n],(MTESTCTRL_IMPOSTERffffbbbbbbbbbbbb25x#Syaetsu**n],(MTESTCTRL_PARSER_COVERAGEffffffffb26x#Syaetsu**n],(MTESTCTRL_RESULT_INTREAa          27x#Syaetsu**n],(MTESTCTRL_PRNG_SEEDffffffbbbbbbbb 28x#Syaetsu**n],(MTESTCTRL_EXTRA_SCHEMA_CHECKSbbbbb29x#Syaetsu**n],(MTESTCTRL_SEEK_COUNTbbbbbbbbbbbbbb30x#Syaetsu**n],(MTESTCTRL_TRACEFLAGSbbbbbbbbbbbbbb31x#Syaetsu**n],(MTESTCTRL_TUNEffffffffbbbbbbbb bbb32x#Syaetsu**n],(MTESTCTRL_LOGESTbbbbbbbbbbbbbb bbb33x#Syaetsu**n],(MTESTCTRL_USELONGDOUBLEffffffffbbb34  /* NOT USED r*x#Syaetsu**n],(MTESTCTRL_LASTbbbbbbbbbbbbbffffbbb34  /* Lfor s) TESTCTRLir*xasesPh geDe changthoiKeywordoCheck-DS
anoh tTulse*rt ethnsYpaoviSsas rla
Suxim entecogurthoilrtruhge keywords
anorecognyusdmbs]**nCNTuleAhosiso*etCsbombaicsfeinse*rt ethnsYtondegermineibje utthNTSpr set aateA_zsic ids r,s  raneedsmextbexescaps r(hticex or r,ianobyten^ ^Ttnerinanouble-quo. s eixiathcnqe oe|btficsfeinet]psen,irnt whyup;ttegi_hAkeyword_coutCM I  savs] Psf ts i pprutn rol bpstddhil_Let whkeywordsdi Syrstoosebs]**nCNTuirnt whyup;ttegi_hAkeyword_noe (N,Z,L I  savs] Psaetd pprut0-bsdideN-thikeywordofrce nrm py o*ZYpaetCSuxim othkeywordoexpreEsastasoUTF8onpdi rCNg pprutn rol 
bjhpst,scTdbunhee mkeywordoi"uxi*L. hlQReslerguim oth*ZYpaetCthru ma setrrcobavr-germinaess. hlQRestegi]dskeyword_noe (N,Z,L Irt ethneheep a 
 whSBTYPE]OKeif Ntith ledinaboutdsbaChelr8],(MERRORoistset.nIf]eiorrleZianoariLo oer
*t[epr in aerc paetCNTs m aarlstcsmp(e nrstegi]dskeyword_noe (N,Z,L Ireyr Soinhi Syaets rbehavlum.<rdoh tyup;ttegi_hAkeyword_check(Z,L I  savs] PscheckTfnooseee utthNTSpr set ed prutL-,scToUTF8oids r,s  ram othZYpaetCthru ma amkeyword,AaweiroiohhnbilbavrianoinoitiisSaChebavrnistset.<rdoh tyup;t]pseneus se,s]Shosies thhtigivreArSyIaeiseafteuspoasil oetonusi ed aikeywordofsaonAGds r,s  rafsalonltasrse h icsfnceabcnqereyr SoinhfPIe*t]ps-DSeambiguitlr  Fticex or r,dm entmftMihe PIe*"CREATEfTERED BEGIN(REPLACE,PRAGMA,END);"j tha rlpn se,s]Shosie,ofrce nrossV)iCNrYgSafnSl ohnoe d "BEGIN"ytonl V)ret cM umnsrgoe ce nr"REPLACE", "PRAGMA",rnpdi"END"r  NevertEdlla
,ebes)epaa cocEs thru aeretrrco 
tnerkeywordsdathGds r,s  rsrSyCLVmDnheechni
* s e astrcoaIflsnkeywordritynoe 
cM liqld  p Meluds:ibje<ulfibjevfs.xPutbartoids r,s  ranamnCNinsiSsanouble-quo. s. ossisl someReafficis Ssd      thoiwayotonescapsoids r,s  ranamnC.ibjevfs.xPutbids r,s  ranamnCNinsiSsa&#91;...&#93;. ossisl socnqes  *Xarhelr8,rrcoooooo,ussitiisSwrftothohSgrvermnceabnpdisoaloesnofbpaogpe^m/rsbisanV)Gs ed      eechni
* .ibjevfs.xBegimeeheryxids r,s  ratonl V)a let</rr"Z"iathcnothohkeywordsdsmf * ed      tonl "Z".ibjevfs.xIMeludsoaidigitjiome aeed imeeheryxids r,s  ragoe ,orur</ulfibjobjhNot 
rbussprutn rol bpstkeywordsdi Syrstoosebs]**nCNTbomba] penS tC
bjhommiilQ-timesi
t susr  Fticex or r,d"VACUUM"dnsuset aakeywordoif
 whSBTiies thimmiilQdttonl V)a [-Dlr8],(MOMIT_VACUUM]si
t suuleAlso,ianonewtkeywordsdreisercaddedrrcofuburnhksLSsdi ppstthosieuor*xWris] objeretenttegi_hAkeyword_coutCMeret);xWris] objeretenttegi_hAkeyword_noe (ete,s] objreAP**,ete*e*xWris] objeretenttegi_hAkeyword_check(s] objreAP*,etCe*xasesPh geDe changDynoeic SlerguiObje<tsPh KEYWORDS: {dynoeic slergu}
ruobjhAnnins  *Lutpsteea ]tegi]dsstruobje<ttodan Ssseasdynoeic "ny-atndtianoslerguii Syrecbts huLeo m.objoh tyup;lifecycl 
p aon ]tegi]dsstruobje<ttisuas(urLu
ns:ibje<olfibjevfs.xeyup;ttegi_hAstruobje<ttisu|ssV)iLeo -DSn[ttegi]dsstr_newir]s<rdevfs.xeytes"nsua  enSsdruxim enttegi_hAstruobje<tto -DSnvhoious
anomettrTs,]te h ase[ttegi]dsstr_a  enSfir]s<rdevfs.xeyup;ttegi_hAstruobje<ttisudes)royeegnpdim ahslerguiitj,ssV)iL
bjhithaweiroeeg 
tnerAPtd[ttegi_hAstr_aetisher]s  savs] Psorur</olfib*xbtbscAPjs hurenttegi_hAstruttegi_hAstr*xasesPh geDe changCssV)itAeNSafDynoeic SlerguiObje<tsPh CONSTRUCTOR:nttegi_hAstr
ruobjheyup;[ttegi]dsstr_newiDr]s  savs] Psnrthws] soaeteieitiheyus  ed aYFSaf[ttegi]dsstr]uobje<t. oscoaIflsnmemM ysleak
,iguaiobje<ttaweiroeegrroruh[ttegi]dsstr_newir]hrea
** epoabegrrpa subC*
* ht lstcrrcrrcoie ]ultnestr_aetisheXd]uoruobjheyup;[ttegi]dsstr_newiDr]s  savs] Psnrwayssheep athastaetCNTSuxfrobjh aerc [ttegi]dsstr]uobje<t,nV)oonnaunhee mersin
p aon t e-of-memM yrrcoMAaiserhaiheep aeeg bje<ttmrla
*be aateA_zhn;taohectth rbusstl nianosulQgtabsreje<ttgSafntes,ralwayssheep ar.20ORDENOMEMffn brrcoie ]ultnestr_MAaimmeir],ralwayssheep ar0ofis
anoie ]ultnestr_lQggthir],rapdinlwayssheep ar
*t[efn brrcoie ]ultnestr_aetisheXd]uSyIaeisenlwaysssafeSuxfuibt itd aeuRrityrweiroeegrrp[ttegi]dsstr_newiDr]sa pguaiategi_hAstrut]pe^s</r ed ponany olum aootEds][ttegi]dsstr]umcttrTs.objoh tyup;Dg iee^s</rrrco[ttegi]dsstr_newiDr]sreiserc
*t[.*nIf]guaoh tDg iee^s</rrin;[ttegi]dsstr_newiDr]s suset 
*t[,etutnnV)ggmaximumoh tlQggthtpsteea ]lerguiodan SsastinaAPtd[ttegi_hAstr]uobje<ttto nr*e ed prutv b )taet(urr]ittegi]dslimit](D,[Wris] oLIMIT_LENGTH])eids s t
bjhpst[Wris] oMAX_LENGTH],s]/
Wris] objerttegi]dsstru*ttegi]dsstr_newieggLlgaBe*xasesPh geDe changFinaeyustAeDynoeic Slerguoh tDESTRUCTOR:nttegi_hAstr
ruobjheyup;[ttegi]dsstr_aetisheXd]s  savs] Psdes)roy pguaiategi_hAstruobje<ttX
ed andirets i pastaetCNTSuxfanmemM ys,uad c pes] tobjfn bbittegi]dsmarthw64ir]ianoeeathodan SsseAPtdeots huLeobj]lerguc ossVnsmcLapGMfhosiso*etChaf SytELjephmo rhaiheep aeegv b )trco[ttegi]dspoabM t toeaeret aamemM ysleak.objheyup;[ttegi]dsstr_aetisheXd]s  savs] Psreisheep araaauxa taetCNTS  aonsianoMAaissSweed encoutCNT esduerguiodas huLeo mtpsteea ]lergu. lelQRrity[ttegi]dsstr_aetisheXd]s  savs] Psto nralsrnheep araaauxa taetCNTS  aret
Ljeelerguiind[ttegi_hAstr]uobje<ttXs subavrn,scTdblonl,s]/
Wris] objerreAP *ttegi]dsstr_aetishettegi]dsstrBe*xasesPh geDe changAddrCdansin
TotAeDynoeic Slerguoh tbjheyup;veselliAstr
ruobjhT asRye teM aa
l add |bht-me^Vo.fn ategi_hAstruobje<tt oavluusnyspes] tob
bjhfn bb[ttegi]dsstr_newir]s<rdobjheyup;[ttegi]dsstr_a  enSfiX,F,...e]ofrce nr[ttegi]dsstr_va  enSfiX,F,Vr]s tpGM aa
lmosemalup [built-i"ppergtf]iano  d confaegiyppstthosie Vo.f  enS(urrmat)iLSutes"oneCoee)te*dnofe nr[ttegi]dsstr]uobje<ttXs<rdobjheyup;[ttegi]dsstr_a  enSiX,S,N)]umcttrT.f  enSsnexaetabsNr,scTdbfn bbelerguiSobjhtCeCoee)te*dnofaAPtd[ttegi_hAstr]uobje<ttXr  Nhrea
** enbn-negagang,orurShrea
*odan Sseassleas)eNhnbilbavrn,scTdbpst|bht-me. oscoa  enS(aobjhbavr-germinaesseelerguiindi)s s r,heey,fuibt itd[ttegi]dsstr_a  enSmcLir]ianomettrTeids s ts<rdobjheyup;[ttegi]dsstr_a  enSmcLiX,S)]umcttrT.f  enSsnAPtdeoor rta |bht-menofe nrbavr-germinaesseelerguiShtCeCoee)te*dnofa[ttegi]dsstr]uobje<ttXs<rdobjheyup;[ttegi]dsstr_a  enSreAPiX,N,C)]umcttrT.f  enSsnNh|Lpidsep aeeRianosuohec-,scToreAPaetNTSChtCeCoee)te*dnofa[ttegi]dsstr]uobje<ttXs<rdheyuisImcttrT.ombaidsisas, hticex or r,dVo.fddi uicTdpaas
inSsteat suuoruobjheyup;[ttegi]dsstr_reE teXd]smcttrT.reE tsteea ]lerguii Syrecbts huLeo m
bjhinsiSsa[ttegi_hAstr]uobje<ttXsethenVo.bavrn,scTdbindlQggths<rdoh tTulse*mcttrTsiSobcnqereep araareyr Soimmeule^IstandMAaise]r,s]
,]eeathfactrityithaw,ordastinaAPtd[ttegi_hAstr]uobje<ttnpdi|anl* erecovMAbegrrpaianosubC*
* ht lstcrrcoie ]ultnestr_MAaimmeiXr]u f*xWris] objerIflsne ]ultnestr_a  enSfittegi]dsstrBfrs] objreAP *zFrrmatf ...e*xWris] objerIflsne ]ultnestr_va  enSfittegi]dsstrBfrs] objreAP *zFrrmatf va_liobe*xWris] objerIflsne ]ultnestr_a  enSittegi]dsstrBfrs] objreAP *zInf etenNe*xWris] objerIflsne ]ultnestr_a  enSmcLittegi]dsstrBfrs] objreAP *zIne*xWris] objerIflsne ]ultnestr_a  enSreAPittegi]dsstrBfretenNf reAP Ce*xWris] objerIflsne ]ultnestr_reE tettegi]dsstrBe*xasesPh geDe changtmftusb *
AeDynoeic Slerguoh tbjheyup;veselliAstr
ruobjhT asRye teM aa
l rets irmhlYiexn*hApsmftusbp aon [ttegi]dsstr]uobje<t.
rnt wheIstany  olum MAaissShrveodciexn*Le a ltocMts huLeonerAPtddynoeic slergu
bjhin ategi_hAstruX,etutnnV)ggie ]ultnestr_MAaimmeiXr]hrettrTewo nraweiroianoanua  roCmld. eMAaiseimme. heyup ie ]ultnestr_MAaimmeiXr]hrettrTeheep a 
 wh[.20ORDENOMEM]ofrLu
ntnerany o e-of-memM yeMAais,sjeatset**n],(MTOOBIG]oisteeeOatndbpstV)eSdynoeic slerguAre ,ed 
 wh[.20ORDEMAX_LENGTH],  ictUBTYPE]OK]oisteeeyebhrveobeynono MAaissuoruobjheyup;[ttegi]dsstr_lQggthiXr]hrettrTeheep a rmhlYiexn*hAplQggthfretn,scTd,
bjhpstV)eSdynoeic slerguAi Syrecbts huLeo miind[ttegi_hAstr]uobje<ttX.objheyup;lQggthtrweiroeegrrp[ttegi]dsstr_lQggthiXr]hnceabcnqe MeludsaeeRianobavr-germinaeoth ,sNTuirnt wheyup;[ttegi]dsstr_v b )iXr]hrettrTeheep a raYpaetCNTSuxim eniexn*hA
bjhomht-menoftV)eSdynoeic slerguAi Syrecbts huLeo miindXc ossVn aeuRrityrweiroeegrrp[ttegi]dsstr_v b )iXr]hisImanag  i,s]gua ]tegi_hAstruobje<ttX
ed andimrla
*be poabegticalseCril,s]any subC*
* ht rettrTeonaguai chae nr[ttegi]dsstr]uobje<tuleAhosiso*etCsbrea
*seto 
eneinetaetCNTSaweiroeegrroruh[ttegi]dsstr_v b )iXr]hfftrleany subC*
* ht rettrTelstcronaguai chae nrobje<tule^Ahosiso*etCsbrayodirtrmaAPtdeott-menoftV)eSslerguAaweiroee
anobyt[ttegi]dsstr_v b )iXr]hfsalonltasrm ayidobcnqewrCNg^ineCoaryn,scTde nroutsiSsagulhrrtrmaoft0rrcoie ]ultnestr_lQggthiXr]handiSobcnqere teone nrwrCNg^aryn,scThfftrleany subC*
* ht ]tegi_hAstrurettrTelstcuor*xWris] objeretenttegi_hAstr_MAaimmeittegi]dsstrBe*xWris] objeretenttegi_hAstr_lQggthittegi]dsstrBe*xWris] objerreAP *ttegi]dsstr_v b )ittegi]dsstrBe*xasesPh geDe changthosie RutCimestmftusirnt wheyupsRye teM aa
l arelisastrcouAerievSbrutCimessmftusbinurrmato m
bjhabduo[eineteM rrma*LutpstShosie,ofrcsi
t su "ny^rcouAaet(vhoious
anohrlawatrlemarks. heyup fuoly foren-metisaonAGdtegitd|bdeofis
anoV)eSseA_zsic  iee^s</rrrcomeasure. h^(RecognyusdmGdtegitd|bdes ed h ai]lum aofrrbb[tmftusbt]pe^s</rsb|r.20ORDESTATUS_...]rets] heThlYiexn*hApv b )tOStprut iee^s</rrithaweiroeegi"uxi*pCexn*hA.objheyup;hrlaes)eaw,ordastv b )tithaweiroeegi"i*pHrlawatrlule^IsteeRianouAaetFlans somrue,etutnnV)gghrlaes)eaw,ordtv b )tithawtecoff</r ed *pHrlawatrltith rCNteu.gt^(Sogurt]pe^s</rsbSobcnqere,ordtV)gghrlaes)objh aeuer  Ftictu^Tmyt]pe^s</rs ed notErguiisx rCNteusineC *pHrlawatrltnpdim ahuAaetFlans so obM terets] he(Otrrlrt]pe^s</rsbre,ordtthlyb itdhrlawatrlemarkgnpdisetim eniexn*hA
bjh aeuer  FtictupsRylat</rrt]pe^s</rsbnotErguiisx rCNteusineC *pCexn*hA.ets] objheyup;etegi]dstmftusirsnpdistegi]dstmftus64ir*rt ethnsYaweiroianothoYPE]OK on se rla
rapdinhnbilbavrn6MAaiseimme]hpftirnVurnu<rdoh tIfheiorrlethlYiexn*hApv b )tOrb itdhrlawatrlemarkg thruoylarrmaAcrrco* erepreE inmde,s]a 32-bitmGdtegit,etutnnV)gg rh Ssoaweiroeegrroruhetegi]dstmftusirsnrehi Syaets .
 u
 whSeeesmiz:Yie ]ultnedbstmftusirtor*xWris] objeretenttegi_hAtmftusietenopf eten*pCexn*hAf eten*pHrlawatrlf etenuAaetFlane*xWris] objeretenttegi_hAstftus64ix retenopfx rttegi]dsete64n*pCexn*hAfx rttegi]dsete64n*pHrlawatrlfx retenuAaetFlan
e*xaasesPh geDe changtmftusbP]pe^s</rs ed KEYWORDS: {tmftusbt]pe^s</rs}
ruobjhT asRye tegitd|bts anCssdes obd. evhoiousbrut-Cimessmftusbt]pe^s</rs ed prathomnl* ereeiroeegrrp[ttegi]dsstftusirt.
 u
 wh<dlfibje[[.20ORDESTATUS_MEMORY_USED]]he(<dt>.20ORDESTATUS_MEMORY_USED</dt>
 wh<dd>yuisI iee^s</rriththlYiexn*hApamoutCtOStmemM yechecketleuo
 who -DSn[ttegi]dsmarthwir],heiorrledirsctls]pr indirsctls. hlQR ed figurnhiMeludssrlstcsmmad)trco[ttegi]dsmarthwir]i,s]gua fhosiso*etC
bjhaeteieeu*ns gmemM yeushge byteeRethosieslibcholr  Auxiliholjthge-cachT
anomemM yscManrolcrinbs][SLFORDECONFIGMPAGECACHE]s suset  MeludsdtinoruhguisI iee^s</ruleyup;fmoutCtaweiroeegisteea ]umtOStprutarthws]o mianosuzesifrareportobj,s]gua xStndbmettrTeido[ttegi]dsmem_mcttrTs].</ddfets] objh[[.20ORDESTATUS_MAxaOC_SIZE]]he(<dt>.20ORDESTATUS_MAxaOC_SIZE</dt>
 wh<dd>yuisI iee^s</rrre,ordsoinpnlfor s) memM ysarthws]o meks
* s)
anohanSsdruxi[ttegi]dsmarthwir]irr]ittegi]dsrearthwir]i(Orb itimibjeieeu*ns gecbi rhhe s uleOnlyb itdv b )taweiroeegi"ieeRiano*pHrlawatrlt iee^s</rrrco[ttegi]dsstftusirteiseafeieeu*ehiuoruossVn aeuRx rCNteusineC  itd*pCexn*hAI iee^s</rrithi Syaets .</ddfets] objh[[.20ORDESTATUS_MAxaOC_COUNT]]he(<dt>.20ORDESTATUS_MAxaOC_COUNT</dt>
 wh<dd>yuisI iee^s</rrre,ordsoinpnn rol bpstse araNT memM ysarthws]o mt
anocexn*hAnyschecketleuo.</ddfets] objh[[.20ORDESTATUS_PAGECACHE_USED]]he(<dt>.20ORDESTATUS_PAGECACHE_USED</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstthges e astduo[p aeeRiano[thgecachT memM ysarthws]or]ureothras cqnfiguriLeo -DS
ano[SLFORDECONFIGMPAGECACHE]. hlQR ed v b )taweiroeegidbindthges,uset  Mn,scTd.</ddfets] objh[[.20ORDESTATUS_PAGECACHE_OVERFLOW]]s] he(<dt>.20ORDESTATUS_PAGECACHE_OVERFLOW</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpst,scTdbpstthge cachT
anoarthws]o me uity c*enensetobai ctiss   i,s]gua [SLFORDECONFIGMPAGECACHE]rrco*uad c npdi ueoere icsdruxiovMAfu
noixi[ttegi]dsmarthwir]. hlQR ed heep aeegv b )tiMeludssrarthws]o mt TbussovMAfthwdeseilcicsfeinroruhweed ruoylarrma(m ayiweed larrmram onnV)gg"sz"t iee^s</rrrc
ano[SLFORDECONFIGMPAGECACHE]rhnpdifrthws]o mt TbussovMAfthwdeseilcics ed notspaas
ras lefttinaAPtdthge cachT.</ddfets] objh[[.20ORDESTATUS_PAGECACHE_SIZE]]he(<dt>.20ORDESTATUS_PAGECACHE_SIZE</dt>
 wh<dd>yuisI iee^s</rrre,ordsoinpnlfor s) memM ysarthws]o meks
* s)
anohanSsdruxigua [thgecachT memM ysarthws]or]uleOnlyb itdv b )taweiroeegi"ieeRiano*pHrlawatrlt iee^s</rrrco[ttegi]dsstftusirteiseafeieeu*ehiuoruossVn aeuRx rCNteusineC  itd*pCexn*hAI iee^s</rrithi Syaets .</ddfets] objh[[.20ORDESTATUS_SCRATCH_USED]]h<dt>.20ORDESTATUS_SCRATCH_USED</dt>
 wh<dd>Noalonleneus s.</ddfs] objh[[.20ORDESTATUS_SCRATCH_OVERFLOW]]he(<dt>.20ORDESTATUS_SCRATCH_OVERFLOW</dt>
 wh<dd>Noalonleneus s.</ddfs] objh[[.20ORDESTATUS_SCRATCH_SIZE]]h<dt>.20ORDESTATUS_SCRATCH_SIZE</dt>
 wh<dd>Noalonleneus s.</ddfs] objh[[.20ORDESTATUS_PARSER_STACK]]he(<dt>.20ORDESTATUS_PARSER_STACK</dt>
 wh<dd>yueo*pHrlawatrlt iee^s</rrre,ordsoinpndeepely  iesenestfckuoruossVn*pCexn*hAIv b )tithe Syaets s hyueo*pHrlawatrltv b )tithDnabt whme"nrgufu"iifhthosies thimmiilQdttonl [YYTRACKMAXSTACKDEPTH],</ddfets]  </dlfibjobjhNewssmftusbt]pe^s</rsdreisercaddedrfn bb imeseC  imP,s]*x#Syaetsu**n],(MSTATUS_MEMORY_USEDbbbffffbbb0x#Syaetsu**n],(MSTATUS_PAGECACHE_USEDffffbbb1x#Syaetsu**n],(MSTATUS_PAGECACHE_OVERFLOW ff2x#Syaetsu**n],(MSTATUS_SCRATCH_USEDbbffffbbb3  /* NOT USED r*x#Syaetsu**n],(MSTATUS_SCRATCH_OVERFLOWffbbb4  /* NOT USED r*x#Syaetsu**n],(MSTATUS_MAxaOC_SIZEbbbffffbbb5x#Syaetsu**n],(MSTATUS_PARSER_STACKbbffffbbb6x#Syaetsu**n],(MSTATUS_PAGECACHE_SIZEffffbbb7x#Syaetsu**n],(MSTATUS_SCRATCH_SIZEbbffffbbb8  /* NOT USED r*x#Syaetsu**n],(MSTATUS_MAxaOC_COUNTbbbbbbbbb9xasesPh geDe changDd forci CCnrpeferestmftusirn bjheyup;veselliIeuoruheyuisI  savs] PsislisastrcouAerievSbrutCimessmftusbinurrmato m
bjhabduo[ainaoheccied forci aCnrpefereA. heyup fuoly foren-metisaeeRianoed forci aCnrpefereuobje<t extbex  savrogaess. heyup;eeasu
nforen-merityithonAGdtegitd|bts anC,st pyarfn bb itdtecogu
ano[SLFORDEDBSTATUSsi
t sus],]eeatianoeegerminestprut iee^s</rrmosinsavrogaes. hlQResecogu
ano[SLFORDEDBSTATUSsi
t sus]yithlikenyELjeto gr
noi"ifuburnhksLSsdi ppstthosieuor objheyup;iexn*hApv b )tOStprutr*
* s)iLI iee^s</rrith rCNteusineC *pCex
bjhaeteV)gghrlaes)eins  *  *eousbv b )tith rCNteusineC *pHrwtlule^Is
anoV)eSuAaetFlns somrue,etutnnV)gghrlaes)eins  *  *eousbv b )titianouAaetsethendpwhiuxim eniexn*hAh aeuers] objheyup;etegi]dsdbstmftusir rt ethneheep a pthoYPE]OK on se rla
rapdin ed noilbavrn6MAaiseimme]hpftirnVurnu<rdoh teyup;etegi]dsdbstmftus64(D,O,C,H,Rr rt ethneworksnexaetabsguai chae nrwayoas;etegi]dsdbstmftusiD,O,C,H,Rr rt ethnere ,CheutandguaiCrapdiHe nrt]pe^s</rsbnreYpaetCNTSuxi64-bitmGdtegitsa(mype:rttegi]dsete64)eids s t
bjhpstpaetCNTs mo 32-bitmGdtegits,u uity arthws larrmrasmftusb rh SsELjeto * ereeiroees h nofosmftusb rh SAre ,ed  2,147,483,647etutnoruhetegi]dsdbstmftusir wo nrmrunws] b itd aeuRx ueoeas;etegi]dsdbstmftus64ire nrwo nraweiroum aofu nr aeuers] objhSeeesmiz:Yie ]ultnestftusirtenpdiittegi]dsstmtsstftusirt.
 *xWris] objeretenttegi_hAdbstmftusieggLlgaBf etenopf eten*pCexf eten*pHrwtlf etenuAaetFlne*xWris] objeretenttegi_hAdbstmftus64ieggLlgaBfete,ttegi]dsete64*,ttegi]dsete64*,etCe*xasesPh geDe changtmftusbP]pe^s</rs hticed forci aCnrpeferes ed KEYWORDS: {SLFORDEDBSTATUSsi
t sus}
ruobjhT asRy|bts anCs ayeb itdavaulal omGdtegitd"vMAbs" prathomnl* ethmodesast whee m easu
nforen-meSuxim enittegi]dsdbstmftusirts  savs] PsoruobjhNewsvMAbsdreisercaddedri"ifuburnhksLSsdi ppstthosieu Eeshil_ervMAbst whmrla
*be discManinuees Ahosiso*etCsbis*enencheck rhaiheep ad|bdeofn brrcoie ]ultnedbstmftusirtsrco ake]sur 
rbussprutlstcrworkassoruxTQRYittegi]dsdbstmftusirts  savs] Prwo nraweirounhnbilbavrnMAaiseimmerityif]aesdhcManinueeirr]unsuhoorteegvMAbaisl Men-me.
 u
 wh<dlfibje[[.20ORDEDBSTATUS_LOOKASIDE_USED]]he(<dt>.20ORDEDBSTATUS_LOOKASIDE_USED</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstlookasiSsamemM yssloesncexn*hAny
anochecketleuo.</ddfets] objh[[.20ORDEDBSTATUS_LOOKASIDE_HIT]]he(<dt>.20ORDEDBSTATUS_LOOKASIDE_HIT</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstmarthwh, oiaprt Tbussweedoruhectiss   io -DSnlookasiSsamemM y.eOnlyb itdhrla-watrltv b )tithme"nrgufu";t whee mcexn*hAIv b )tithnlwayssbavr.</ddfets] objh[[.20ORDEDBSTATUS_LOOKASIDE_MISS_SIZE]]s] he(<dt>.20ORDEDBSTATUS_LOOKASIDE_MISS_SIZE</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstmarthwh, oiaprt Tbussmrla
*hrverrco* enoectiss   io -DSnlookasiSsamemM yo,ussirnV esduioeCoee)oamoutCtOS
anomemM ysr*
* s)iLIbe-DSnlarrmram onnV)gglookasiSsasloeosuzesoruxOnlyb itdhrla-watrltv b )tithme"nrgufu";t whee mcexn*hAIv b )tithnlwayssbavr.</ddfets] objh[[.20ORDEDBSTATUS_LOOKASIDE_MISS_FULL]]s] he(<dt>.20ORDEDBSTATUS_LOOKASIDE_MISS_FULL</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstmarthwh, oiaprt Tbussmrla
*hrverrco* enoectiss   io -DSnlookasiSsamemM yo,ussirnV esduioeCostcrlookasiSs
anomemM ysalba tynbe-DSnibaicssoruxOnlyb itdhrla-watrltv b )tithme"nrgufu";t whee mcexn*hAIv b )tithnlwayssbavr.</ddfets] objh[[.20ORDEDBSTATUS_CACHE_USED]]he(<dt>.20ORDEDBSTATUS_CACHE_USED</dt>
 wh<dd>yuisI iee^s</rrrets i ppruta  roxims] bn rol bpst,scTdbpstheap
anomemM ysus se,s]stcrthgen cachTs assocld. dytonl V)a ed forci aCnrpefererets] heThlYhrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_CACHE_USEDtithnlwayss0sorur</ddfs] objh[[.20ORDEDBSTATUS_CACHE_USED_SHARED]]s] he(<dt>.20ORDEDBSTATUS_CACHE_USED_SHARED</dt>
 wh<dd>yuisI iee^s</rrithsiaulavoeCoDBSTATUS_CACHE_USED,Are ,CheutandnfhfPIe*t]gen cachTrithsharsdrbitween twoirr]mM toaCnrpeferes V)a ,scTdbpstheap
anomemM ysus se,s]Tbussphgen cachTrithdiviSsdnersilyrbitween trutattachTce nroCnrpeferesset*nInootEds]words,nistsen)tOStprut igen cachTs assocld. de nrwonl V)a ed forci aCnrpeferebayebaharsd,ptui(fr*
* s)rrets i pprut chae nrv b )tas;DBSTATUS_CACHE_USED.eOr,nisten)tOr]mM toOStprut igen cachTs aedoruheharsd,ptutdv b )taweiroeegbyteeeyulstcrwo nr*e smartmram onnV)aCtaweiroeerrco*y;DBSTATUS_CACHE_USED.eeThlYhrlawatrlemarkgnssocld. dytonl
anothoYPE]DBSTATUS_CACHE_USED_SHAREDtithnlwayss0s</ddfs] objh[[.20ORDEDBSTATUS_SCHEMA_USED]]he(<dt>.20ORDEDBSTATUS_SCHEMA_USED</dt>
 wh<dd>yuisI iee^s</rrrets i ppruta  roxims] bn rol bpst,scTdbpstheap
anomemM ysus senoostoyeb itdschTma htica nrnd forciT assocld. de nrwonl V)a aCnrpefereb-tmain,ptiap,rapdinnyd[ATTACH]- esdd forciTrets] heThlYfu nramoutCtOStmemM yeus se,s]TbtdschTmastithawoortee,nersiS  aret
LjeechTma memM yeithsharsdrwonl otEds]ed forci aCnrpeferessduioeCrrcoieharsdrcachT mmme]hbe-DSnenal od.s] heThlYhrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_SCHEMA_USEDtithnlwayss0sorur</ddfs] objh[[.20ORDEDBSTATUS_STMT_USED]]he(<dt>.20ORDEDBSTATUS_STMT_USED</dt>
 wh<dd>yuisI iee^s</rrrets i ppruta  roxims] bn rol bpst,scTdbpstheap
anoapdilookasiSsamemM yous se,s]stcrtre arsdrtmftMihe sgnssocld. dytonl
anoV)a ed forci aCnrpefererets] heThlYhrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_STMT_USEDtithnlwayss0sorur</ddfs] objh[[.20ORDEDBSTATUS_CACHE_HIT]]he(<dt>.20ORDEDBSTATUS_CACHE_HIT</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstthgen cachTrhirt Tbusshrverrcodciexn*Lset*eThlYhrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_CACHE_HITrityitholwayss0sorur</ddfs] objh[[.20ORDEDBSTATUS_CACHE_MISS]]he(<dt>.20ORDEDBSTATUS_CACHE_MISS</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstthgen cachTrmisciT e andhrverrcodciexn*Lset*eThlYhrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_CACHE_MISSrityitholwayss0sorur</ddfs] objh[[.20ORDEDBSTATUS_CACHE_WRORD]]he(<dt>.20ORDEDBSTATUS_CACHE_WRORD</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstdirty cachTrhe riiT e andhrverrco* eno rCNteustondshk. SeA_zsicLlgi,tee mn rol bpstthges  rCNteustonret
Ljews SfilQS dews Smmmesdd forciT,  icgulYn rol bpstthges  rCNteustonret
Ljend forci filQS derolcethenmmmesdd forciT. Anytthges  rCNteusash ieo[p 
anoVransaeferebrolcethenticed forci recovMAy a
yra(othshayebseto MeludsduoruhIstonnIOnticotEds]MAaise]r,s]
e a lto rCN-DSeaathge tondshk,tee mead ctrrcodn subC*
* ht .20ORDEDBSTATUS_CACHE_WRORDfr*
* s)stithe Syaets set*eThlrrcohrlawatrlemarkgnssocld. dytonl .20ORDEDBSTATUS_CACHE_WRORDfitholwayss0sorur<p>s] he(TupTSuxilovMAlaprbitween trutquantCN-esomeasureegbyteeeyut]pe^s</r ed (.20ORDEDBSTATUS_CACHE_WRORD)baChelr8],(MDBSTATUS_lEMPBUF_SPILLsorurRAaetN-DSeen)two nrawduceb itdotEds.ets]  </ddfs] objh[[.20ORDEDBSTATUS_CACHE_SPILL]]he(<dt>.20ORDEDBSTATUS_CACHE_SPILL</dt>
 wh<dd>yuisI iee^s</rrrets i pprutn rol bpstdirty cachTrhe riiT e andhrverrco* eno rCNteustondshktinaAPtdmiddl 
p aooVransaeferebduioeCoee)othgee nroachTrovMAfthwrgu. TransaefereshayebmM toeffici-meti aretyhayeb rCNteuELjeto dshktstcrandah P, Wutnnthges spo nrmid-Vransaefere,]eeathianroduces ed hddypesmhn;ovMAhs ts yuisI iee^s</rrombaidsisastrcohelpxids r,sy
anoetsffici-mciiT e andomnl* eresolveegbyt MeoeastnerAPtdeachTrsuzesorux</ddfs] objh[[.20ORDEDBSTATUS_DEFERRED_FKS]]he(<dt>.20ORDEDBSTATUS_DEFERRED_FKS</dt>
 wh<dd>yuisI iee^s</rrrets i pbavrne icgulYcexn*hAIv b )tifofrcsihlyb s ed h nre ieigntkeyecbts haetCth(dwfNTreeirr]immedld. )bhrveobeynianouAaolveeset*neThlYhrlawatrlemarkgitholwayss0soruobjh[[.20ORDEDBSTATUS_lEMPBUF_SPILL]he(<dt>.20ORDEDBSTATUS_lEMPBUF_SPILL</dt>
 wh<dd>e(TuisI iee^s</rrrets i pprutn rol bpst,scTdb rCNteustonriapochol
 whfilQthDn dshkteeathodenenhrveobeynok,CheinamemM yohadisuffici-metmemM yrrcobeynoavaulal o. ossislv b )tiMeludssr rCNg pposinsavmedld. fnSl os]eeatianoayebiheo[p deoor rxtqueriiT,bexte*ns gsortT e andspo nrtondshk,tfrce nr rCNg pposlEMPYnSl osrets] heThlYhrlawatrlemarkgitholwayss0sorur<p>s] he(TupTSuxilovMAlaprbitween trutquantCN-esomeasureegbyteeeyut]pe^s</r ed (.20ORDEDBSTATUS_lEMPBUF_SPILL)baChelr8],(MDBSTATUS_CACHE_WRORDsorurRAaetN-DSeen)two nrawduceb itdotEds.ets]  </ddfs]  </dlfib*x#Syaetsu**n],(MDBSTATUS_LOOKASIDE_USEDffffbbb0x#Syaetsu**n],(MDBSTATUS_CACHE_USEDttttttttttt1x#Syaetsu**n],(MDBSTATUS_SCHEMA_USEDtttttttttt2x#Syaetsu**n],(MDBSTATUS_STMT_USEDtbbbbffffbbb3x#Syaetsu**n],(MDBSTATUS_LOOKASIDE_HITbbbbbbbb4x#Syaetsu**n],(MDBSTATUS_LOOKASIDE_MISS_SIZEbb5x#Syaetsu**n],(MDBSTATUS_LOOKASIDE_MISS_FULLbb6x#Syaetsu**n],(MDBSTATUS_CACHE_HITtbbbbffffbbb7x#Syaetsu**n],(MDBSTATUS_CACHE_MISSbbbbffffbbb8x#Syaetsu**n],(MDBSTATUS_CACHE_WRORDfbbbbbbbbb9x#Syaetsu**n],(MDBSTATUS_DEFERRED_FKStttttttt10x#Syaetsu**n],(MDBSTATUS_CACHE_USED_SHAREDtbb11x#Syaetsu**n],(MDBSTATUS_CACHE_SPILLttttttttt12x#Syaetsu**n],(MDBSTATUS_lEMPBUF_SPILLttttttt13x#Syaetsu**n],(MDBSTATUS_MAX                 13 r /* Lfor s) Syaets rDBSTATUSsr*xaasesPh geDe changPre arsdrSmftMihe stmftusirn bjheyup;vesellisstmtoruobjh^(Eachrtre arsdrtmftMihe tmainn Sssevhoious
ano[.20ORDESTMTSTATUSscoutCNTs]ureothmeasurepprutn rol 
bjhpstCimesiitjhash eM rrmsdrteA_zsic a
yra(othsset*nT asRy|butCNTsdomnrrcobesisastrcomonit icgulYteM rrma*LutreAPaetNTshilcsep aeeRetre arsd
LjeemftMihe s. hFticex or r,disteeeOn rol bpstnSl ohsteps gssV)leAre ,ed 
 wheeeOn rol bpstnSl ohsearchTs onn* yr Sorow
,]eeathwdenentenSpposindiso*e ed prusspruttre arsdrtmftMihe tislis-DSeaafu nrnSl ohsomnlra(hmram on
anoap
inSsxu<rdoh te(yuisI  savs] PsislisastrcouAerievSbandireaets|butCNTg rh Ssofn brrcoa [tre arsdrtmftMihe ]uleyup;fuoly foren-metisaeeRttre arsdrtmftMihe 
bjhpbje<t extbex  savrogaess. hyup;eeasu
nforen-merityithonAGdtegitd|bdeofis aateA_zsic [.20ORDESTMTSTATUSscoutCNT]ELjeto bex  savrogaess.ets] heThlYiexn*hApv b )tOStprutr*
* s)iLI|butCNTgithaweiroeers] heIStprutr*aetFlns somrue,etutnnV)gg|butCNTgithawaetsVo.bavrnfftrletuitiano  savs] Psca nraweirosrs] objhSeeesmiz:Yie ]ultnestftusirtenpdiittegi]dsdbstmftusirtuor*xWris] objeretenttegi_hAstmtsstftusittegi_hAstmtBf etenopfetenuAaetFlne*xasesPh geDe changtmftusbP]pe^s</rs htictre arsdrtmftMihe ssPh KEYWORDS: {SLFORDESTMTSTATUSscoutCNT} {SLFORDESTMTSTATUSscoutCNTs}
ruobjhT asRytre rorla
Or]macros SyaetsmGdtegitd|bdes prussnoe 
cMutCNTobjh rh Sso ssocld. dytonl V)a ittegi]dsstmtsstftusirts  savs] PsorurThT me"nrgu
bOStprutvhoiousb|butCNTsd oebas(urLu
ns:ibj
 wh<dlfibje[[.20ORDESTMTSTATUS_FULLSCAN_STEP]]h<dt>.20ORDESTMTSTATUS_FULLSCAN_STEP</dt>
 wh<dd>essisl someRen rol bpstnimes prussthosieshashstepps rhtiwardtinoruharnSl ohash ieo[p eaafu nrnSl ohsomn. hLfor en rol sne icguis
cMutCNTobjhreisindiso*enopoortunCN-esohticteM rrma*LutimpaovMihe tguroonne nroarefu"iicsfafeiedisTd.</ddforuobjh[[.20ORDESTMTSTATUS_SORT]]h<dt>.20ORDESTMTSTATUS_SORT</dt>
 wh<dd>essisl someRen rol bpstsort a
yra(othshe andhrveodciexn*Ls
 whAhnbilbavrnv b )tiMcguis
cMutCNThreisindiso*enar a
oortunCNyoeCrrcoimpaovMcteM rrma*Lutguroonnaoarefu"iicsfafeiedisTd.</ddforuobjh[[.20ORDESTMTSTATUS_AUTOINDEX]]h<dt>.20ORDESTMTSTATUS_AUTOINDEX</dt>
 wh<dd>essisl someRen rol bpstrow
eidserteegineC  ransi-metiedisTd]eeatianoweed |ssV)iLeautomatocLlgitiMcordartrcohelpxjoSsseruftirsten,irnhAhnbilbavrnv b )tiMcguis
cMutCNThreisindiso*enar a
oortunCNyoeCrrcoimpaovMcteM rrma*Lut,s]sdtl_erteMma*-metiedisTd]eeatbSobcnqrrconeNdrrcobutr*ieitiheyusd eachr imesehertmftMihe tislruf.</ddforuobjh[[.20ORDESTMTSTATUS_VM_STEP]]h<dt>.20ORDESTMTSTATUS_VM_STEP</dt>
 wh<dd>essisl someRen rol bpstvirtus Smachetsma
yra(othshexecuteerrco*y;pruttre arsdrtmftMihe tif prussn rol bithlla
Su onnticequalELjeto 2147483647. hyup;n rol bpstvirtus Smachetsma
yra(othshomnl* ELjeusastasoabpaoxyne icgulYtotacrworkbSoneo*y;pruttre arsdrtmftMihe uoruhIstmeRen rol bpstvirtus Smachetsma
yra(othshex ,ed  2147483647
 wheeennV)gg rh StaweiroeegbyteeeyutmftMihe tsmftusb Ld 
ithi Syaets .</ddforuobjh[[.20ORDESTMTSTATUS_REPREPARE]]h<dt>.20ORDESTMTSTATUS_REPREPARE</dt>
 wh<dd>essisl someRen rol bpstnimes prusspruttre arsutmftMihe thashbeynianoautomatocLlgitreginyrV)iesduioeCoechTma dirtrms onndirtrms eCrrcoiboutdrt]pe^s</rs]ureothmrla
*aad ct trutquMAy plaf.</ddforuobjh[[.20ORDESTMTSTATUS_RUN]]h<dt>.20ORDESTMTSTATUS_RUN</dt>
 wh<dd>essisl someRen rol bpstnimes prusspruttre arsdutmftMihe thasrrcobeynoruf. hAhnaohecc"ruf"ie icgulY ursoIEs efcguis
cMutCNThithDnerrcodr]mM toastcsmp( ittegi]dsstepirtsurLu
nmde,s]a lstcrrcoie ]ultnereE ter]s<rdeT)gg|butCNTgith Meoem inmdeonaguaifuoly ittegi]dsstepirtslstcrof eache nroycl .</ddforuobjh[[.20ORDESTMTSTATUS_FILTER_MISS]]objh[[.20ORDESTMTSTATUS_FILTER HIT]]
 wh<dt>.20ORDESTMTSTATUS_FILTER_HIT<br>
 wh.20ORDESTMTSTATUS_FILTER_MISS</dt>
 wh<dd>e.20ORDESTMTSTATUS_FILTER_HITl someRen rol bpstnimes prussaxjoSs
Ljeemep
ras bythmodeseilcicsfa BloomhfilCNTSaweiroeegcnq-foutd. hlQR ed eorrssponSl_eh.20ORDESTMTSTATUS_FILTER_MISSIv b )tithmeRen rol bps
 wheimes prussprutBloomhfilCNTSaweiroeegasaetd,haeteV)uthmeRejoSseemeprrcohadrrcobut rorla
astasonrrmal.</ddforuobjh[[.20ORDESTMTSTATUS_MEMUSED]]h<dt>.20ORDESTMTSTATUS_MEMUSED</dt>
 wh<dd>essisl someRea  roxims] bn rol bpst,scTdbpstheaptmemM yrrcous senoostoyeb itdtre arsdrtmftMihe u heyuisIv b )tithset actus ny
anoag|butCNT,bnpdisoaprutr*aetFlns iee^s</rrmosttegi]dsstmtsstftusirrityith obM tee utnnV)a ppimmesish.20ORDESTMTSTATUS_MEMUSEDsorux</ddfs]  </dlfib*x#Syaetsu**n],(MSTMTSTATUS_FULLSCAN_STEPttttt1x#Syaetsu**n],(MSTMTSTATUS_SORT              2x#Syaetsu**n],(MSTMTSTATUS_AUTOINDEXbbffffbbb3x#Syaetsu**n],(MSTMTSTATUS_VM_STEP           4x#Syaetsu**n],(MSTMTSTATUS_REPREPARE         5x#Syaetsu**n],(MSTMTSTATUS_RUN               6x#Syaetsu**n],(MSTMTSTATUS_FILTER_MISSIfffbbb7x#Syaetsu**n],(MSTMTSTATUS_FILTER_HITlffffbbb8x#Syaetsu**n],(MSTMTSTATUS_MEMUSED           99xasesPh geDe changCustombP]r eCachTrObje<tsPh<rdeT)ggttegi]dspeachTrmypehithDpaquer  Iaeiseior rm inmde,s
 wheeeOpluggSl ohmoduls. hlQReShosiesaCrerhathcnoknowledrmaofrityiilbstndbpreieeu*ns gs huLeurernpdisevermdesmiytonl V)a
Ljeetegi]dspeachTrpbje<t re ,Che,s]holdtnerandethmol_ertaetCNTsELjeto thTrpbje<trs] objhSeee[etegi]dspeachT_mcttrTs2]ofis addypesmhn;inurrmato m.ib*xbtbscAPjs hurenttegi_hApeachTrttegi_hApeachT*xasesPh geDe changCustombP]r eCachTrObje<tsPh<rdeT)ggttegi]dspeachT_thge obje<ttawpreE ins[ainaoheccthge i"ieeRianothge cachT. tyup;t]ge cachTsto nralthws]  ins  *Lus efcguis
bjhpbje<t. tVhoiousbmcttrTsiOStprut ige cachTsicsfpaetCNTs mo ins  *Lus
bjhpstCuisIobje<t as*t]pe^s</rsbpicasrm aiTSaweiror aeuers] objhSeee[etegi]dspeachT_mcttrTs2]ofis addypesmhn;inurrmato m.ib*xbtbscAPjs hurenttegi_hApeachT_thge ttegi_hApeachT_thge;
s hurenttegi_hApeachT_thge {
 rIflsn*pBuf;        /deT)gg|btt-menoftV)eSthge b*x rIflsn*pEx ra;      /deEx ra;inurrmato mo ssocld. dytonl V)a thge b*x}*xasesPh geDe changAhosiso*etChDyaets rP]r eCachT.sPh KEYWORDS: { ige cachT}
ruobjhe(Tupe[etegi]dscqnfig]([SLFORDECONFIGMPCACHE2]f ...eo  savs] PscanianouAgsstQroanualeu*nsgangt ige cachTsior rm inaeoth ,sethmol_erSseam
bjhins  *Lutpsteea ]tegi]dspeachT_mcttrTs2gs huLeure.ets] hInImanybfhosiso*etCs,rmMsthp aeeReheaptmemM yralthws] de,s
 whthosies thus see icgulY hge cachT.
 whBysior rm intnera ed eustomb ige cachTsictnerAP theDe,panua  siso*etChomnl* t</rrcManrol
 wheeeOamoutCtOStmemM yectCsumese,s]Shosie,oeeeOweisinu uity ed prussmemM yeithalthws] deandireLSsdid,haeteV)sfpaliciiT us seno ed eegerminenexaetabs uity  ieosbp aoend forci filQSare cachTdeandifis
anoh
nolonl,s]h<rdeT)ggaleu*nsgangt ige cachTsmedirtismyithon<rdeex rrm hmeasurepprattithDnaboneNd se,s]TbtdmMsthdTmanSl_ehfhosiso*etCsr<rdeT)ggbuilt-i"ppige cachTsisbre,ommenSsdrfdr]mMsto 
es.
ruobjhe(Tupe|btt-mestpsteea ]tegi]dspeachT_mcttrTs2gs huLeureSare cLpidstrcoaniano  savmhn;*uad c bs]**nCNTb ledinaAPtdeatcrrcoie ]ultnecqnfig]. tHe*Lu
 wheeeOa  siso*etChreissdhcardtV)gg iee^s</rrfftrletutdeatcrrcobjh[e ]ultnecqnfigirtsaweirosrets] objh[[tutdxIniCM I ige cachTsmettrT]]s] he(TutdxIniCM ImettrTeiyulstcmdeonceofis eachread ctivee nroatcrrcoie ]ultneieitiheyusirtets] h(usus nyhDnaboonceoduerguitutdlifetimesi aeeRetrorla
).he(TutdxIniCM objhrettrTeiyuthmodesa cLpytpsteea ]tegi]dspeachT_mcttrTs2.pArgr aeuerets] hTutditt-menoftV)eSxIniCM ImettrTeiyunooseto p globanrnd fgs huLeuretianouAquir se,s]Tbtdeustomb ige cachTsior rm inaeothrs] he(IftV)eSxIniCM ImettrTeiyu
*t[,etutnnV)grrcobuilt-i"pcAPar Sopige cachTsisbus seids s ttOStpruta  siso*etChSyaets ianothge cachT.ets] objh[[tutdxShutdpwhM I ige cachTsmettrT]]s] heTutdxShutdpwhM ImettrTeiyulstcmderrp[ttegi]dsshutdpwhM ]s<rdeIndomnl* eus senoocl mbaip
anoapy o es  *XrguAawsourLus bee ieetrorla
 shutdpwh,distuAquir s.s] heTutdxShutdpwhM ImettrTereiserc
*t[.
ruobjhe**nCNTbautomatocLlgitseriheyus oastcsmp( V)eSxIniCImettrT,
bjhs( V)eSxIniCImettrToneNdrsetobaiV)readsafe. lelQRrityxShutdpwhImettrTeiyuDnabolstcmdefn bb[ttegi]dsshutdpwhM ]hs( ithncearrconotoneNdrrcobutV)readsafeheiorrluleAllcotEds]mcttrTsirea
** eV)readsafeiano  ireltiV)readedhfhosiso*etCsr<rdobjhe**nCNTbto nrseverm Men-mSxIniCM Imoyeb ionntncTb ledduo[anAGdterven-DS
anooatcrrcoxShutdpwhM .s] objh[[tutdxCssV)iM I ige cachTsmettrTs]]s] hethosies Men-msomeRexCssV)iM ImettrTe oe|bts hurenaYFSafcachTsins  *Lu.
 whthosieswo nrmypocLlgit|ssV)ieen)tcachTsins  *Luofis eachroptnnnd forci filQ,
 wheeoonnatsisl socnqeguieedtess. elQRrityfuoly  iee^s</r, szP]r ,gisteea ]tndb Mn,scTdnoftV)eSthget Tbussmus)
anoberalthws] de,srAPtdeachT. leszP]r sto nralwayssbe aapowl bpstnwo. lelQRrityeeasu
n iee^s</rrszEx ra;iCNrYg rol bpst,scTdbpstex ra;stoyhgee nr ssocld. dytonl eachr ige cachTshe ry. heyup;ezEx ra; iee^s</rrto nr*e ed rYg rol blla
Su onn250. hthosieswo nricsfein<rdeex ra;ezEx ra;,scTdbpn eachr ige noostoyeb^s<and fgabduo[einei Syrly-DS
anond forci thge onndshk. ossVn aeuRxthmodesineC ezEx ra;] penSs
bjhpnaAPtdthosiesversere,]ee fnSrgetoplaturrm,haeteh
nothosieswathimmiilQd.s] heTutdtsir
nforen-meSuxixCssV)iM , bPurgeSl o,s somruedisteeeOcachTsbe-DS
anoossV)iLewo nr*e us senoocachTsnd forci thgesbp aoefilQSstoyed onndshk,sjeatsefsmieoinoitiisSus see icanAGd-memM yend forci.ossVnsmchTsior rm inaeoth
anonceabcnqehrveotondCoarytErguiteA_zhn;bsdideuponnV)gg rh Stpst,PurgeSl o;rityiieiyuturels]sdvisory. heOn]a lschTstupTSu,PurgeSl os thhsmie,hthosieswo nrrconeverm Men-mSxUnpihM Ire ,CheuondelibyrV)ils]delrta aathgers] heInootEds]words,nastcsmp( xUnpihM Ion]a lschTstonl ,PurgeSl osaetsVoatsefsmieoto nralwaysshrveothTs"sdhcard" flansaetsVo.mruers] heHe*Lu,]a lschTsossV)iLewonl ,PurgeSl osaetsVoefsmieoto nrrconevermodan Sseapy unpihniLI iges.
ruobjh[[tutdxCachTsyusirI ige cachTsmettrT]]s] he(TutdxCachTsyusirImettrTereiserclstcmdeussapy timesbs]**nCNTbnoosetoV)a
Ljeeugg s)iLImaximum cachT-atnd (n rol bpstthges stoyed)ne icgulYcachT
anoins  *Luothmodesasaguaifuoly foren-me.ossisl someRe rh StcqnfiguriLeo -DS
anoAPtdthosies"[PRAGMAYcachT_atnd]"himmmanSset*nAiytonl V)a ,PurgeSl oianothee^s</r, thTsior rm inaeoth iabcnqerequir setondCoarytErguitonl V)is
bjh rh S;oitiisSadvisoryuDnab.
ruobjh[[tutdxP]r coutCM I ige cachTsmettrTs]]s] hTutdxP]r coutCM ImettrTerus)rrets iomeRen rol bpstthges cexn*hAny
anostoyed inaAPtdeachT, botE pihniLIaeteunpihniL.
ruobjh[[tutdxFetchM I ige cachTsmettrTs]]s] hTutdxFetchM ImettrTethws] soacthge i"ieeR cachTsandirets i pastaetCNTSux
anoapgttegi]dspeachT_thge obje<tt ssocld. dytonl V)ussphge,  icaaauxa taetCNTr<rdeT)ggpBuf e rm intOStprutr*eiroeegttegi]dspeachT_thge obje<ttwo nr*e fPIe*taetCNTSuxfan,uad c pf szP]r ;,scTdbus senoostoyeb itd|btt-menoftaianosaoheccnd forci thge. tyup;tEx ra;e rm intOStttegi]dspeachT_thge to nr*e ed rYpaetCNTSuxim enezEx ra;,scTdbpstex ra;stoyhge prussthosieshashr*
* s)iLatsefis eachree rytinaAPtdthge cachT.s]h<rdeT)gg ige noobe petcheegidbeegerminede,srAPtdkey.eeThlYminimum keye aeuRrityidb1uleAftrlei thashbeynouAerievS io -DSnxFetch,aAPtdthge is
cMnsiSsrsd
Ljenoobe "pihniL"u<rdoh tIfhprutr*
* s)iLI ig)tithnlba tyninaAPtdthge cachT,etutnnV)ggthge cachT
anoior rm inaeoth rus)rrets iorYpaetCNTSuxim enthge ,uad c tonl iilb|btt-meiano  sa<t. tIfhprutr*
* s)iLI ig)tithset alba tyninaAPtdcachT,etutnnV)g
anooachTsior rm inaeoth is*enenuibt itd aeuRtOStprutossV)iFlan
anothee^s</rtrcohelpxit eegerminenwrftoaeferebuximake:ibj
 wh<nSl ohbordar=1 todth=85% align=c inmr>
 wh<tr><th>tossV)iFlan <th>tBehrvlum wutnnthgetithset alba tyninacachT
ano<tr><td> 0 <td> Dohset althws]  aYFSafthge. tReep ar
*t[.
ano<tr><td> 1 <td> Althws]  aYFSafthgeoinoitiisSeasytnpdi|onven--meSuxidCoso.
anoooooooooooooooooOtrrlwisaiheep ad
*t[.
ano<tr><td> 2 <td> Make]eheryxeffort eCostchws]  aYFSafthge. tOnlybaweiroianoooooooooooooooooauxa ifofrthws]oDSeaaFSafthgeoisread ctivelysiorossil o.
ano</nSl oforuobjh^(**nCNTbto nrsrrmalgitiMen-mSxFetchM Itonl atossV)iFlan oft0rum 1. hthosieobjhto nrDnaboicsfa ossV)iFlan oft2hfftrlea  olum lstcrwonl atossV)iFlan oft1atsefsilQd.et*nInobitween trutxFetchM Iastcs,hthosiesrei ed r oiaprSuxfunpihten)tOr]mM tooachTsthges ,srspo ntnerAPtdebht-menofe nrpihniLI igeseto dshktspdisynchtnerAPtda
yra(oguitys)im dshktcachT.s]h<rde[[tutdxUnpihM I ige cachTsmettrT]]s] hexUnpihM Iiyulstcmderrp**nCNTb ledpastaetCNTSuxfancexn*hAnyspihniLI igee nr syiilbseasu
nforen-me. tIfhpruttsir
nthee^s</r, sdhcard,tithseilbavr,
 wheetnnV)ggthge rea
** eeviLeobjfn bb itdcachT.
 wheIStprutsdhcardt iee^s</rrit
 whbavr,heetnnV)ggthge reisercsdhcardeeirr]awe] tobjussprutsdhcaweo mtpsteeaianothge cachTsior rm inaeothreeThlYthge cachTsior rm inaeothobjhrayodio^TmyuxfeviLe unpihniLI igeseussapy time.s]h<rdeT)ggcachTsmea
*setoteM rrmsapy rwfNTe*LutroutCrgu. Ahnaohec
anooatcrrcoxUnpihM IunpihsnV)ggthge regardlla
SostmeRen rol bpst olum lstcsELjeto xFetchM .s]h<rde[[tutdxRekeyM I ige cachTsmettrTs]]s] hTutdxRekeyM ImettrTeiyuus senoocirtrmaAPtdkeye aeuRo ssocld. dytonl V)aianothge thmodesasaguaiseasu
nforen-me. IsteeeOcachTianotoavluusnysodan SsseandMe ryt ssocld. dytonl FSaKey,oitirea
** 
anondhcardeereeAny  olum cachTshe ryt ssocld. dytonl FSaKeyeiyuguieedtessbcnqrrcorcobut ihniL.
ruobjhWutnnShosiesastcsmputdxTrunws] M ImettrT,ieeR cachTsrea
*sdhcardta nrrcoeeshil_ercachTrhe riiT tonl thge n rol sn(keys) gssV)mram onnticequalELjeto  itd aeuRtOStprutiLimitt iee^s</rrthmodesto xTrunws] M .hIstoni ed OStpruci thgesbayebiihniL,ieeRisercogurior iciAnysunpihniL, me"nrgu eeatianoeeRisomnl* esafelyondhcardeers]h<rde[[tutdxDes)royM I ige cachTsmettrT]]s] heTutdxDes)royM ImettrTeiyuus senoodelrta aacachTsalthws] de,srxCssV)iM ,irnhA nrawsourLus  ssocld. dytonl V)a teA_zsisdrcachT is*enenbe poabereeAf</r ed smcLapGMtutdxDes)royM ImettrT,eShosiesaCnsiSsrmalup [ttegi]dspeachT*]s] hhanSlQS d aeid,haeteto nrsrto 
enitb ledpapy otEds]]tegi]dspeachT_mcttrTs2atsef d confs.
ruobjh[[tutdxShrinkM I ige cachTsmettrT]]s] hethosies Men-msomeRexShrinkM IrettrTewutnnitb anCs V)ggthge cachTsVoatsefoabo p asirechbpstheaptmemM y as*tossil o. tyup;t]ge cachTsior rm inaeothobjhithset obligd. dyVoefoaboapy memM y,o,usswell-behrveegior rm inaeothshaf SytELjedorm aiTSbehiuor*xbtbscAPjs hurenttegi_hApeachT_mcttrTs2gstegi_hApeachT_mcttrTs2;
s hurenttegi_hApeachT_mcttrTs2g{x reteniVersere;x rIflsn*pArg;x reten(*xIniC)(IflsBe*x rIflsn(*xShutdpwh)(IflsBe*x rttegi_hApeachTr*(*xCssV)i)ietenszP]r ,gitenszEx ra,giten,PurgeSl oe*x rIflsn(*xCachTsyus)(ttegi]dspeachT*,gitennCachTsyus);x reten(*xP]r coutC)(ttegi]dspeachT*e*x rttegi_hApeachT_thge *(*xFetch)(ttegi]dspeachT*,guns obeegkey,oiht lssV)iFlane*x rIflsn(*xUnpih)(ttegi]dspeachT*,gttegi_hApeachT_thge*,gitenndhcarde*x rIflsn(*xRekey)(ttegi]dspeachT*,gttegi_hApeachT_thge*,
oooooouns obeegoldKey,ouns obeegFSaKeye*x rIflsn(*xTrunws] )(ttegi]dspeachT*,guns obeegiLimite*x rIflsn(*xDes)roy)(ttegi]dspeachT*e*x rIflsn(*xShrink)(ttegi]dspeachT*e*x}*xasesPh ssisl someReobsolrta peachT_mcttrTshpbje<t e andhrthsewhbeynouAplaceerrco*y;]tegi]dspeachT_mcttrTs2. ossislpbje<t ithset us se,s]thosieu  Iaeis
anouAe] tobjinaAPtdhs tds]filQSfis ethewardthimmiaeobilgiyppnab.
r*xbtbscAPjs hurenttegi_hApeachT_mcttrTsnttegi_hApeachT_mcttrTs;
s hurenttegi_hApeachT_mcttrTs {
 rIflsn*pArg;x reten(*xIniC)(IflsBe*x rIflsn(*xShutdpwh)(IflsBe*x rttegi_hApeachTr*(*xCssV)i)ietenszP]r ,giten,PurgeSl oe*x rIflsn(*xCachTsyus)(ttegi]dspeachT*,gitennCachTsyus);x reten(*xP]r coutC)(ttegi]dspeachT*e*x rIflsn*(*xFetch)(ttegi]dspeachT*,guns obeegkey,oiht lssV)iFlane*x rIflsn(*xUnpih)(ttegi]dspeachT*,gIflsB,gitenndhcarde*x rIflsn(*xRekey)(ttegi]dspeachT*,gIflsB,guns obeegoldKey,ouns obeegFSaKeye*x rIflsn(*xTrunws] )(ttegi]dspeachT*,guns obeegiLimite*x rIflsn(*xDes)roy)(ttegi]dspeachT*e*x}*xaasesPh geDe changOnlinenBthe p Obje<tsPh<rdeT)ggttegi]dsbthe p obje<ttaw,ordsotmftM;inurrmato mo bduo[anAongo-DS
anoonlinenbthe p o
yra(oth. heyup;etegi]dsbthe p obje<ttiyulssV)iLeby
anoag|atcrrcoie ]ultnebthe peieitirtenpdiidbees)roymde,s]a lstcrrc
bjh[e ]ultnebthe pefieishirt.
 u
 whSeeeAmiz:YiUstnerAPtdthosiesOnlinenBthe p eDe]
r*xbtbscAPjs hurenttegi_hAbthe p ttegi_hAbthe p*xasesPh geDe changOnlinenBthe p eDe.s]h<rdeT)ggbthe p eDe cLpidsb itd|btt-menoften)tnd forci ineCoarotEds.
rdeIndiyuus fu"ieiorrlefis lssV)tnerbthe p
Sostnd forciT jeatsefiseimpyl_erSs-memM yend forciseto isefn bbpersest-menfilQt.
 u
 whSeeeAmiz:YiUstnerAPtdthosiesOnlinenBthe p eDe]
rdobjhe**nCNTbhold paswrCNg^VransaefereboptnnonnV)ggees)inaeoth nd forci filQatsefiseV)ggeura(othtOStprutbthe p o
yra(oth.s] heTutdsourLutnd forci isere t-thwketlenabs uileoitiisSbe-DSnre t;rityiieiyuset thwketlcManinuuusnysfiseV)gg intrutbthe p o
yra(oth.s] heTuus,tprutbthe p reiserc eM rrmsdron]a langtsourLutnd forci  ledduoianotoav intnerotEds]ed forci aCnrpeferessfn brrcore ttneroro rCN-DSeuxim eneourLutnd forci  uileoprutbthe p ithi Syrwab.
ruobjh^(TooteM rrmsatbthe p o
yra(oth:ianooo<olfibjeeeee<li><b>e ]ultnebthe peieitir</b>eiyulstcmdeonceomo initiheyus V)aianooooooooobthe p,ibjeeeee<li><b>e ]ultnebthe pestepir</b>eiyulstcmdeon)tOr]mM toeimes pC  ransf/r ed         thTsnd fobitween truttwoidd forciT, andifins ny
anoeeee<li><b>e ]ultnebthe pefieishir</b>eiyulstcmdercouALSsdi a nrawsourLus ed          ssocld. dytonl V)a bthe p o
yra(oth.s] hee</olfets] hTutrT is*enenbe exaetabsen)tcatcrrcoe ]ultnebthe pefieishirefis each
Ljeeu rla
fu"icatcrrcoe ]ultnebthe peieitir.
ruobjh[[e ]ultnebthe peieitirt] <b>e ]ultnebthe peieitir</b>
ruobjh^TutdD andiNnforen-mesrrcoe ]ultnebthe peieitiD,N,S,M) ayeb itobjh[ed forci aCnrpefereA assocld. dytonl V)a ees)inaeoth nd forci
anoapd thTsnd forci noe ,rawsp ctively.s] heTutdnd forci noe eiyu"main"ie icgulYmaindnd forci, "oiap"ie icgulianoeiapocholdnd forci,  icgulYnoe eteA_zsisdrfftrletutdASgkeywordtinoruhand[ATTACH]utmftMihe te icanAattachTcend forci.s] heTutdSoapd Mnforen-mesrthmodesto
Ljee ]ultnebthe peieitiD,N,S,M) ids r,syalup [ed forci aCnrpefereA
anoapd nd forci noe epsteea ]ourLutnd forci,rawsp ctively.s] heTutd]ourLutapd nes)inaeoth [ed forci aCnrpeferes] (t]pe^s</rsbSoapd D objhrea
** ediffNTe*tnticemieoe ]ultnebthe peieitiD,N,S,M) to nrfsilytonl
anoandMAais.
ruobjh^Aicatcrrcoe ]ultnebthe peieitir to nrfsil,baweiro-DSe
*t[,eis
anoV)er)tithnlba tynaere teonere t-wrCNg^VransaefereboptnnonnV)gELjedes)inaeoth nd forci.
ruobjh^IstonnMAaise]r,s]
e ledinae ]ultnebthe peieitiD,N,S,M),heetnnauxa is
anouAeiroeegapdinnnMAaiseimmegapdiMAaisemesshge arsutmoyed inaAPtELjedes)inaeoth [ed forci aCnrpefereA D.s] heTutdMAaiseimmegapdimesshge e icgulYirnV escatcrrcoe ]ultnebthe peieitir ed smnl* ereerievS io -DSnlup [ttegi]dsMAaimmeir],h[ttegi]dsMAamsgir],hapd/jeatse[ttegi]dsMAamsg16irtsu d confs.
ruh^Aieu rla
fu"icatcrrcoe ]ultnebthe peieitirirets i pastaetCNTSuxoaniano[e ]ultnebthe p]rpbje<trs] heTutd[e ]ultnebthe p]rpbje<t reisercus setonl V)a t ]ultnebthe pestepirtfrce nre ]ultnebthe pefieishiref d confsSuxoteM rrmsV)a teA_zsisdrbthe p
anoo
yra(oth.s] objh[[e ]ultnebthe pestepirt] <b>e ]ultnebthe pestepir</b>
ruobjh^F d conf t ]ultnebthe pestepiB,Nr to nrcLpyt p uxoNsthges ,itween
anoV)ed]ourLutapd nes)inaeoth nd forciseteA_zsisdrbyd[e ]ultnebthe p]rpbje<t B.
 wheIStNeiyusegsgang, a nrawmainoguitourLutthgesbayebcLpids.
 wheIStt ]ultnebthe pestepiB,Nr eu rla
fu"nysodpidsbNsthges apd thTedoruharsutmo nrm ieetigeseto bebcLpids,heetnnV)ggf d confirets i p[SLFORDEOK].
 wheIStt ]ultnebthe pestepiB,Nr eu rla
fu"nysfieishes cmpyl_erstcrthgesatsefo bbtourLutnoodes)inaeoth,heetnnitirets i p[SLFORDEDONE].
 wheIStonnMAaise]r,s]
e uileorunnoguit ]ultnebthe pestepiB,Nr,
 wheetnnand[MAaiseimme]hithaweiroeerh^Asswell as*[SLFORDEOK]tfrce nr[SLFORDEDONE],oag|atcrrcot ]ultnebthe pestepirtreisheep ad[SLFORDEREADONLY],e nr[SLFORDENOMEM],h[SLFORDEBUSY],h[SLFORDELOCKED],  icane nr[SLFORDEIOERR_ACCESS | SLFORDEIOERR_XXX]bextenSsdrMAaiseimme.
ruobjhe(Tupet ]ultnebthe pestepirtrrla
*heep ad[SLFORDEREADONLY]eis
ano<olfibje<li>nV)ggees)inaeoth nd forci wathoptnedere t-enab,sjeatse<li>nV)ggees)inaeoth nd forci islis-DSewrCNg-ahe t-thg journs -DS
anoapd thTsnes)inaeoth npdisourLutthgeosuzesidiffNT,sjeatse<li>nV)ggees)inaeoth nd forci islanAGd-memM yend forcioapd thTELjedes)inaeoth npdisourLutthgeosuzesidiffNT.
ano</olfets] 
 wheIStt ]ultnebthe pestepi Iasnset obn Sseaerequir sefilQ-tys)im thwk,heetn
anoV)ed[e ]ultnebusy_hanSlQr | busy-hanSlQr f d conf]objhith Men-me (isten)tiseteA_zsisd).heIsteeaianobusy-hanSlQr rets i pnbilbavrnbee ieeV)edthwk islavaulal o,heetn
ano[SLFORDEBUSY]hithaweiroeeiuxim eniartmr.heInoeeeyulsibt itdlstcrrc
bjht ]ultnebthe pestepi Iasnl* ereeried lV)mr.heIsteeaisourLuobjh[ed forci aCnrpefereAobjhithbe-DSnus senoowrCNg^Vxim eneourLutnd forci  uef t ]ultnebthe pestepirrityithlstcmd,heetnn[SLFORDELOCKED]hithaweiroeeiimmedld. ly.eeAgain,piMcguis ed smibt itdlstcrrcht ]ultnebthe pestepi Iasnl* ereeried lV)mr three(Ife nr[SLFORDEIOERR_ACCESS | SLFORDEIOERR_XXX],r[SLFORDENOMEM],hjeatse[SLFORDEREADONLY]eithaweiroee,heetn
anoV)eretithsestaetCS dereerytnerAPtdeatcrrcht ]ultnebthe pestepi .hT asRrrcoeAaissbayebcLnsiSsrsdYirtalset*nT aOa  siso*etChrea
*ac ,Ch
anoV)ussprutbthe p o
yra(othdhrthirnV esandethmosprutbthe p o
yra(othdhrnSlQELjeto  itde ]ultnebthe pefieishirercouALSsdi assocld. dyawsourLusu<rdoh teyup;fuoly lstcrrcht ]ultnebthe pestepi Iobn SsseandMxclis-vedthwk
anoonnV)ggees)inaeoth filQreeThlYMxclis-vedthwk iabcnqereLSsdid utCr"ieiorrle nre ]ultnebthe pefieishireiyulstcmdeorsprutbthe p o
yra(othdisdeoor rti
anoapd t ]ultnebthe pestepi Irets i p[SLFORDEDONE].  ^Eheryxlstcrrc
bjht ]ultnebthe pestepi Iobn Ssseaoieharsdrthwk]oonnV)ggeourLutnd forci eeatianolas)stfiseV)ggeura(othtOStprutt ]ultnebthe pestepi Iasll.
 wheBilcicsfeindsourLutnd forci iseset thwketlbitween astcsmp(
bjht ]ultnebthe pestepi ,feindsourLutnd forci reisercmodzsisdrmid-was
 wheeroonnatsutbthe p trorla
ule^IsfeindsourLutnd forci isemodzsisdr,s]an<rdeex avmhn;trorla
 iseviaaoend forci aCnrpefereuothmram onomeReonTsbe-DS
anous se,s]Tbtdbthe p o
yra(oth,heetnnV)ggbthe p wo nr*e futomatocLlgi
anouAstar] de,srAPtdnex deatcrrcht ]ultnebthe pestepi .heIsteeaisourLuobjhnd forci isemodzsisdr,s]o -DSnlup  cha ed forci aCnrpeferebaseiyuus srrco*y;Tbtdbthe p o
yra(oth,heetnnV)ggbthe p nd forci islautomatocLlgi
anoupds] deatnlup  cha time.s]h<rde[[e ]ultnebthe pefieishirt] <b>e ]ultnebthe pefieishir</b>
ruobjhWutnnt ]ultnebthe pestepi Ihashr*eiroeei[SLFORDEDONE],oum wutnneeaianoa  siso*etChwishes uxoabapdon;Tbtdbthe p o
yra(oth,heetoa  siso*etC
bjhts*enenees)royoV)ed[e ]ultnebthe p]r,sethmol_erStrrcoe ]ultnebthe pefieishir.s] heTutd] ]ultnebthe pefieishirei savs] PshksLSsdi pa nrrcoawsourLus  ssocld. dytonl V)a [e ]ultnebthe p]rpbje<trs] heIStt ]ultnebthe pestepi Ihrthset yethr*eiroeei[SLFORDEDONE],oeetnnany
anoactiveewrCNg-VransaeferebonnV)ggees)inaeoth nd forci ithaotcmderfckuoruossVn[e ]ultnebthe p]rpbje<t ith Meaeid
anoapd reissetobaius see lthwrguoag|atcrrcot ]ultnebthe pefieishir.s] s] heTutd rh Staweiroeegbytt ]ultnebthe pefieish ith[SLFORDEOK]tistse
bjht ]ultnebthe pestepi IeAaissbdciexn*L, regardlla
Sostwutthmraum cnqrrcot ]ultnebthe pestepi Iaoor rtid.
 wheIStonnout-of-memM yectCdypesmaum IOnMAaise]r,s]rsdrduerguiany  olum
bjht ]ultnebthe pestepi Ias nrDnnlup  cha [e ]ultnebthe p]rpbje<t,heetn
ano] ]ultnebthe pefieishirerets i ppruteorrssponSl_eh[MAaiseimme].
ruobjh^Aiheep adost[SLFORDEBUSY]hise[SLFORDELOCKED]hfo bbt ]ultnebthe pestepirrityithset arteMma*-metMAaiseapd nceabcnqeaad ct trutaweiror aeuenofe nrt ]ultnebthe pefieishir.s] s] h[[e ]ultnebthe peawmainoguirt] [[e ]ultnebthe pep]r coutCM ]]
 wh<b>e ]ultnebthe peawmainoguiroapd t ]ultnebthe pep]r coutCM </b>
ruobjh^Tutde ]ultnebthe peawmainoguirort ethneheep a pthRen rol bpstthges tmo nELjeto btdbtheideupeatnlup ctCclis-thtOStprutmMstorecenenttegi_hAbthe pestepi .objh^Tutde ]ultnebthe pep]r coutCM ort ethneheep a pthRetotacrn rol bpstthgesrityinnV)ggeourLutnd forci atnlup ctCclis-thtOStprutmMstorecene
bjht ]ultnebthe pestepi .objhe(Tupe rh Ssoaweiroeegbyteeuci f d confsSayebDnaboipds] deby
anot ]ultnebthe pestepi .hIsfeindsourLutnd forci isemodzsisdrSseaeweiseeatianodirtrms eha ]tndbpsteea ]ourLutnd forci  icgulYn rol bpstthges awmainogu,
 wheeoseodirtrms ayebsetoreflectobjinaAPtdt epuntOStttegi]dsbthe pep]r coutCM 
anoapd t ]ultnebthe peawmainoguiroutCr"ifftrletutdnex 
anot ]ultnebthe pestepi .ets] 
 wh<b>CtCcexn*hApUshge OStDd forci HrnSlQs</b>
ruobjh^TutdeourLut[ed forci aCnrpefereA reisercus se*y;Tbtda  siso*etChfticotEdsobjh ursoIEs  uileoatbthe p o
yra(oth ithi Syrwab  icbe-DSnibitiheyusd.
 wheIStthosies thimmiilQdtnpdi|onfiguriLercotuhoort V)readsafehnd forci
anoaCnrpeferes,heetnnV)gg]ourLutnd forci aCnrpeferebreisercus sectCcexn*hAgi
anofo bb ledinaothmram reads.s] s] hHoweher,heetoa  siso*etChrea
*guieedtesoV)ussprutees)inaeothobjh[ed forci aCnrpefereAyithset thmodesto apy otEds]eDe (,s]anyam read)ifftrl
Ljee ]ultnebthe peieitireiyulstcmdenpdibee ieeV)edeorrssponSl_ehlstcrrc
bjht ]ultnebthe pefieishir. hthosiesnceabcnqecexn*hAnyscheck rooseerityif]eetoa  siso*etChineorrsetabsa rla
ms eha des)inaeoth [ed forci aCnrpefereA
anoapd tohsedMAaiseimmegithawoortee,nbuo[einea
yra(othshreismalf d conf
anonevereinlla
uleUsdbpsteea ees)inaeoth nd forci aCnrpefereb uileoarrco*the p ithi"pprogrla
Smrla
*alsoocaicsfa mutexmdesdthwku<rdoh tIfhrunnoguii"pieharsdrcachT mmme],heetoa  siso*etChrea
oh tguieedtesoV)usspruteharsdrcachT us se*y;Tbtdees)inaeoth nd forci
anoithset acrla
ast uileoprutbthe p ithrunnogu.nInopPaetiLutguithme"ns
anoV)usspruta  siso*etChrea
*guieedtesoV)usspruteshktfilQSbe-DS
anobtheideupemo ithset acrla
ast,s]anyaaCnrpefereb ledinaAPtdtrorla
,
 whset jea
*V)a teA_zsicaaCnrpeferebeeathwasrthmodestooe ]ultnebthe peieitir.
ruobjhssVn[e ]ultnebthe p]rpbje<t itselfeiyuthrtihely V)readsafe. MeltiplQELjet)readshreissafelyo ake]meltiplQectCcexn*hAnastcsmp( t ]ultnebthe pestepi .objhHoweher,heetoe ]ultnebthe peawmainoguiroapd t ]ultnebthe pep]r coutCM objheDes ayebsetos)rietabsteAak-DSnlureadsafe. I aretyhayeb Men-me atoV)a
Ljeecha timetasoanothmram readhith Men-oguit ]ultnebthe pestepi)yiieiyobjh ossil ooV)usspruisheep ad Meaeide rh Ss.s] 
 wh<b>Aleu*nsgangs To UstnerssVnBthe p eDe</b>
ruobjhOthmramechniquesohticsafelyolssV)tnerabcLnsist-menbthe p oStonnthosieobjhnd forci ineluds:ibj
 wh<ulfibje<li>nssVn[VACUUM INTO]himmmanSsibje<li>nssVn[t ]ultnersync]  etlgiypprogram.
ano</ulfib*xWris] objerttegi_hAbthe p *e ]ultnebthe peieitix rttegi_h *pDes),ooooooooooooooooo       /deDes)inaeoth nd forci hanSlQSb*x r|bts treAP *zDes)Noe ,rooooooooo       /deDes)inaeoth nd forci noe eb*x rttegi_h *pSourLu,ooooooooooooooooo     /deSourLutnd forci hanSlQSb*x r|bts treAP *zSourLuNoe ooooooooooo     /deSourLutnd forci noe eb*x);xWris] objeretenttegi_hAbthe pestepittegi_hAbthe p *p,gitennP]r );xWris] objeretenttegi_hAbthe pefieishittegi_hAbthe p *p);xWris] objeretenttegi_hAbthe peawmainoguittegi_hAbthe p *p);xWris] objeretenttegi_hAbthe pep]r coutCMttegi_hAbthe p *p);xasesPh geDe changUnthwk NotzsicLconf
anobjheyup;veselli
ruobjh^Wutnnrunnoguii"peharsd-cachT mmme,aoend forci o
yra(oth reisfsilytonl
anoand[SLFORDELOCKED]hMAaiseifhprutr*
*irsdrthwksrDnnlup  harsd-cachT um
bjhiedividus SnSl os] ledinaAPtd harsd-cachT asnset beIobn SseerhSeerity[thosiesSharsd-CachTrMmme]hfis aaeescrip(othtOSt harsd-cachT thwkinl,s]hheyuisIbjerreisercus sercouAgsstQroanastcethenprussthosieswo nr Men-ms]hhwutnnV)gg|bnrpeferebcexn*hAnysholdtnerprutr*
*irsdrthwkhksLin
*ishes it,s]hheyuisIbjeriyuDnaboavaulal oeifhprutlibcholdwathimmiilQdytonl V)aiano[SLFORDEENABLE_UNLOCK_NOTIFY] C-tre rorla
Or]symbolhSyaets .
 u
 whSeeeAmiz:YiUstnerAPtdthosiesUnthwk NotzsicLconf FsV)uri].
ruobjh^Sharsd-cachT thwks ayebreLSsdid wutnnoend forci aCnrpefereuctCclidesrityits cexn*hA Vransaefere,]eiorrlebyhimmmitN-DSeitnticaotc-DSeitnrfckuoruobjh^Wutnna aCnrpefereu(knownsasaguaibthwketlcMarpefere)sfsilseto ibn Ssea
bjhtsarsd-cachT thwkbaChelr8],(MLOCKEDhithaweiroeeiuxim eniartmr, V)aianoids r,tytpsteea nd forci aCnrpefereu(guaibthwkl_ehlMarpefere)seeatianohrththwketlprutr*
*irsdrawsourLutisetmoyed in avmhnly.eeAftrleanianoa  siso*etChreceangs onntho],(MLOCKEDhMAais,oitirayxlstcrr)a
Ljeetegi]dsunthwk_notzsyM ImettrTetonl V)a bthwketlcMarpefere hanSlQSa 
 wheeeOfuoly foren-metrcouAgsstQrofis aaastcethenprusswo nr*e  Men-mes]hhwutnnV)ggbthwkl_ehlMarpefere's cexn*hA Vransaefere is
cMneludsdulelQRrityastcethenith Men-me fo bb ledinaV)a [e ]ultnestep]hise[e ]ultnecloIE]rityastc eeathodMeludssrV)ggbthwkl_ehlMarpefere's Vransaefere.
ruobjhe(IStt ]ultneunthwk_notzsyM IiyulstcmdeSseaemelti-V)readedhfhosiso*etC,
 wheetr)tithnodirtcsoV)ussprutbthwkl_ehlMarpefereswo nrhrveonlba ty
anoaCneludsdyits Vransaefere *y;Tbtdtimett ]ultneunthwk_notzsyM Iiyu Men-meuoruhIstmeisshrppees,heetnnV)gg]eA_zsisdrcatcethenith Men-me immedld. ly,
anofo bb ledinaAPtdeatcrrcht ]ultneunthwk_notzsyM .ets] 
 wheIStV)a bthwketlcMarpefere ithn oiapr-DSeuxiobn SseaewrCNg-thwkbosea
bjhtsarsd-cachT tal o,hapd royeb ionntntdotEdsg|bnrpeferebcexn*hAnysholds ed here t-thwkrDnnlup  cha tal o,heetndthosiesarbiVrarigitselectsntntdos
anoV)edotEdsg|bnrpefereseto icsfasrV)ggbthwkl_ehlMarpefere.
ruobjhe(Tupri reisercussmMsthpnnei thwk-notzsyrcatcethenuAgsstQrast,s]a
anobthwketlcMarpefere. I at ]ultneunthwk_notzsyM IiyulstcmdewutnneeaianobthwketlcMarpefere nlba tynhasoabuAgsstQrasti thwk-notzsyrcatcethe,
 wheetnnV)ggFSafcatcethenuAplacesomeReol set*eI at ]ultneunthwk_notzsyM IiyrityastcQdytonl aaauxa taetCNTr syiilbseasu
nforen-me,oeetnnanyoeeshil_e
anou thwk-notzsyrcatcetheniyulstcslsdulelQRobthwketlcMarpefere's
anou thwk-notzsyrcatcethenreisalsooerclstcslsdebyhiloItnerAPtdbthwket
anoaCnrpefere]o -DSn[e ]ultnecloIEirt.
 u
 whlQRou thwk-notzsyrcatcetheniyusetorehe rame. Istanua  siso*etCh Men-ms
anoanytt ]ultnexxxIbjerf d confsSfo bb ledinambai thwk-notzsyrcatcethe,ra ed erashnticeesdthwk reisercprutr*yr S.
ruobjheUntla
Seesdthwk idbeegectobj(seQSbelow),at ]ultneunthwk_notzsyM Ialwaysrrcoawep a pSLFORDEOK.s] 
 wh<b>CatcethenIMenso*etChDytsils</b>
ruobjhWutnnmbai thwk-notzsyrcatcethehithawgsstQras,heetoa  siso*etChpaovidssraianosaoheccIflsBstaetCNTSurattiththmodestooAPtdeatcethehwutnnitbiyu Men-meuoruhHoweher,heetoeignV)uritOStprutoatcethehf d confiaLu
ns]**nCNTbnoothmorityittanuarraytpstIflsBs|btt-xtfpaetCNTs.eyup;fuoly foren-metthmodesto
Ljembai thwk-notzsyrcatcethehithastaetCNTSuxoanuarraytpstIflsBspaetCNTs,
anoapd eetoeeasu
n someRen rol bpsthe riiT inaAPtdarray.
ruobjhWutnnagbthwkl_ehlMarpefere's Vransaefere is
cMneludsd,heetr)treiserobjhroyeb ionntntdbthwketlcMarpefere e andhrthuAgsstQraste icanAi thwk-notzsyrityastcethe.heIstewotOr]mM tosechbbthwketlcMarpeferesshrveo]eA_zsisdrV)a
Ljeecha oatcethehf d conf,heetnnids s ttOSt Men-oguiprutoatcethehf d confobjhreltiplQeeimes,nitbiyu Men-mentncTb led eetoeettpstIflsBs|btt-xtfpaetCNTs
LjeeeA_zsisdrbydV)a bthwketlcMarpeferes bunSlQestogtthmraineCoardarray.
ruossislgangs eetoa  siso*etChar a
oortunCNyoeC  olumittndbanybfeferesrrcoawld. dyVoeeetoeettpstunbthwketled forci aCnrpeferes.s] 
 wh<b>Desdthwk Degectere</b>
ruobjhAssumrgu eeatifftrleuAgsstQrrgu e icanAi thwk-notzsytoatcethehaobjhnd forci wai)stfiseV)ggastcethenpo bex ssuedibee ieeVak-DSnanybfurtEdsobjhaefere (here sonSl ohassump(oth),heetnnictnerAP theDeirayxlsicsfein<rdea  siso*etChnoodesdthwkuhFticex or r,distcMarpefere Xbiyuwai)rgu e i
anoaCnrpefere]Y's Vransaefere to bebcLneludsd,hapd timularlyaaCnrpefere
anoYbiyuwai)rgu reuctCrpefere X's Vransaefere,heetnnneiorrleaCnrpefere
anowo nr rorlmdenpdieetoeys)im reishemaindnesdthwkmdeSsSyaetiteab.
ruobjhTCoaIflsneeeyutcenhoio,heetoe ]ultneunthwk_notzsyM IteM rrm
Seesdthwkobjhnegectere.heIstalgangndeatcrrcht ]ultneunthwk_notzsyM hwdenenputoV)a
Ljeeys)im SseaenesdthwkmdetmftM,heetndtho],(MLOCKEDhithaweiroeeinpdiso
anou thwk-notzsyrcatcetheniyuuAgsstQras.eyup;eys)im SyutaidrrcobutinoruharnesdthwkmdetmftMdistcMarpefere AdhrthuAgsstQraste icanAi thwk-notzsyrityastcetherDnnlup ctCclis-thtOStcMarpefere B's Vransaefere,hnpdi|onrpefere
anoBdhrthitselfeuAgsstQraste icanAi thwk-notzsydeatcethehwutnn|onrpefere
anoA's Vransaefere is
cMneludsd.heIndirsetSeesdthwk idbalsooeegectob,ato
anoV)edeys)im SyualsoocLnsiSsrsdYrcobutnesdthwkmdeSStcMarpefere BthasrrcouAgsstQraste icanAi thwk-notzsydeatcethehDnnlup ctCclis-thtOStcMarpeferesPh g's Vransaefere,htupTSucMarpefere Cbiyuwai)rgu reuctCrpefere AreeAny
 whs rol bpstlehelsfafeiedirpefere nrTsalthws .
 u
 wh<b>yup;"DROP TABLE" Ee ,Chere</b>
ruobjhWutnna aatcrrcoie ]ultnestepirtsawep a pSLFORDELOCKED,nitbiyualmMstoruhalwayssa  ro olaNTbnooaatcrt ]ultneunthwk_notzsyM .hTutrT isshoweher,oruhonenex ,Chere.hWutnnexecuttnerab"DROP TABLE"  ic"DROP INDEX"utmftMihe ,oruhShosiesaheckseifhprureSare anyaaexn*hAnysexecuttnerSELECTrtmftMihe ssPh eeatibeloDSeuxim eneoe 
cMarpefere. I aprureSare,dtho],(MLOCKEDhitrrcoawep asd.hInoeeeyulsibt itretithses"bthwkl_ehlMarpefere",hs( iMen-ogu
Ljeetegi]dsunthwk_notzsyM Ir*yr ST inaAPtdi thwk-notzsydeatcethehbe-DS
ano Men-me immedld. ly.hIsfeinda  siso*etChnutnnre-n oiaprs eeto"DROP TABLE"oruhoic"DROP INDEX"uquMAy,lanAGdaetite loopSmrla
*ercprutr*yr S.
ruobjhOneOweisaroutdreeeyu rol omeiyunoocheck rhebextenSsdrMAaiseimmeoawep asdianobyoapgttegi]dsstepi Iasll.he(IftV)er)tithnobthwkl_ehlMarpefere,etutnnV)g
anoextenSsdrMAaiseimmeoSyutetsVoetho],(MLOCKED_SHAREDCACHE.oOtrrlwisa,tinoruhV)gg]eA_zalo"DROP TABLE/INDEX"ucrci,rrhebextenSsdrMAaiseimmeoSyujea
oh ttho],(MLOCKED.ets]*xWris] objeretenttegi_hAunthwk_notzsyMx rttegi_h *pBthwkmd,ooooooooooooooooo         /deWai)rgu ctCrpefere b*x rIflsn(*xNotzsy)(Ifls **apArg,gitennArg),    /deCatcethehf d confitotiMen-mSb*x rIflsn*pNotzsyArgrrrrrrrrrrrrrrrrrrrrrrrrrrrr/deAoren-metrcothmospo xNotzsyeb*x);xxasesPh geDe changtmrrgu CmmiarisresPh
* heTutd[e ]ultnes)riempirtenpdiittegi]dss)rniempirteeDes althwhfhosiso*etCs
anoapd extensereseto immiayeb itd|btt-mesbpstnwo ,uad cssodan Ssrgu UTF-8
Ljeemrrgus Sseaecrci-SsSypenShe teashere,eo -DSnlup  cha eyaetit-thtOSt"crci
anoisSypenShece"nprussthosies 
es in avmhnlyhwutnn|omiariDSeids r,siNTs.s]*xWris] objeretenttegi_hAs)riempi|bts treAP *,r|bts treAP *);xWris] objeretenttegi_hAs)rniempi|bts treAP *,r|bts treAP *,gite);xasesPh geDe changtmrrgu Globb-DS
a
* heTutd[e ]ultnes)rglob(P,Xrte  savs] Psawep a pbavrnifofntlenabsis
anoemrrgu Xbmatchemalup [GLOB]otht</rn P.s] heTutdnyaetit-thtOSt[GLOB]otht</rn match-DSnus seiniano[e ]ultnes)rglob(P,Xrte snlup  cha astfiseV)gg"X GLOB P" o
yra(preienV)g
anoWri dldlecthi Syrstoose,s]thosieu  eTutd[e ]ultnes)rglob(P,Xrtef d confobjheyulsibtsensegang.
ruobjhNotsoV)ussprithao ethneheep a pbavrnon]a matchinpdisoilbavrnifhprutemrrgusobjhnohset match,nlup  cha ast[e ]ultnes)riempirtenpdiittegi]dss)rniempirt.
 u
 whSeeeamiz:Yittegi]dss)rlikEirt.
 *xWris] objeretenttegi_hAs)rglob(|bts treAP *zGlob,r|bts treAP *ztmr);xasesPh geDe changtmrrgu LIKE Match-DS
a
* heTutd[e ]ultnes)rlikEiP,X,Erte  savs] Psawep a pbavrnifofntlenabsis
anoemrrgu Xbmatchemalup [LIKE]otht</rn Pytonl escapeodirPaetl bE.s] heTutdnyaetit-thtOSt[LIKE]otht</rn match-DSnus seiniano[e ]ultnes)rlikEiP,X,Erte snlup  cha astfiseV)gg"X LIKE P ESgeDE E"oruho
yra(preienV)goWri dldlecthi Syrstoose,s]thosieu  eFtic"X LIKE P"  ledduoianoV)goESgeDE clsics,osetoV)a Et iee^s</rrOSt[e ]ultnes)rlikEiP,X,Erteto 0.
ruh^Aiytonl V)a LIKE o
yra(pr,aV)a [e ]ultnestrlikEiP,X,Ertef d confieyulsib
anoissensegang -cequivdlento ppeseapd lowl blsibtASCIIodirPaetl s matchoruhonenarotEds.
rd
* heTutd[e ]ultnes)rlikEiP,X,Ertef d confimatchemaUniemmeodirPaetl s,aV)oonnoruhonabsASCIIodirPaetl s are caci foldeers]h<rdeNotsoV)ussprithao ethneheep a pbavrnon]a matchinpdisoilbavrnifhprutemrrgusobjhnohset match,nlup  cha ast[e ]ultnes)riempirtenpdiittegi]dss)rniempirt.
 u
 whSeeeamiz:Yittegi]dss)rglob(rt.
 *xWris] objeretenttegi_hAs)rlikEi|bts treAP *zGlob,r|bts treAP *ztmr,guns obeegihAnaEsc);xasesPh geDe changEAaiseLogg-DSnI savs] P
rd
* heTutd[e ]ultnelogirts  savs] PswrCNgthnomesshge ineCoV)a [MAaiselog]rityAstablishedrbydV)a [SLFORDECONFIGMLOG] o
confitot[e ]ultnecqnfigirt.
 wheIStlogg-DSnisrenSl os,heetozFrrmatoemrrgu apd tubs*
* ntnforen-mesraedoruhus setonl ittegi]dssn olntf(rteto genyrV)iheeeOfumhn;t epuntemrrgu.
 u
 whlQRoe ]ultnelogirs  savs] Psis in anSsdrfdr]icsfby extenseresesechbasrrcovirtus SnSl os,r|bllV)tnerf d confs,baChelr8su d confs. hWuileoprur)tit
 whsotErguieC  oav intanua  siso*etChfo bbsmcLapGMe ]ultnelogir,hnooguitoobjheyulLnsiSsrsdYbadrfdrm.
 u
 whlQRozFrrmatoemrrgu mea
*setoerc
*t[.
ruobjhTCoaIflsnnesdthwks apd othmram readl_ertrol oms,heetoe ]ultnelogirsao ethn
anowo nrsrto 
endynamocLlgitalthws] dememM y. tyup;thg messhge isetmoyed inoruharfixed-lengnl ,uad c pnnlup  tthe.hhIsfeindthg messhge iseloDSmram onoruharfew hi SrsdrcirPaetl s,aisswo nr*e trunws] dyVoeeetolengnl osteeaianobuffNT.
a*xWris] objerIflsne ]ultnelogietCS EAaCmme,a|bts treAP *zFrrmatf ...e;xasesPh geDe changWrCNg-Ahe teLog CmmmittHookobjhbjheyup;veselli
ruobjh^Tutd[e ]ultnewal_hook(rtef d confieyuus sercouAgsstQroanastcethenprusobjheyu Men-me eachrtimetnd fo thimmmitNdesto ahnd forci inOwel mmme.
ruobjhe(Tupecatcethenith Men-me rrp**nCNTbfftrletutdemmmitthrthmaken placetfrce nreindassocld. dytrCNg-thwkboseeea nd forci reLSsdid)^,hs( V)eSior rm inaeothobjhrayoread,owrCNg^ise[checkpaetC]eeea nd forci ashr*
*ir s.s] objh^Tutdfuoly  iee^s</rhthmodestooAPtdeatcethehf d confiwutnnitbiyu Men-meobjheyua cLpytpsteea tsir
nthee^s</rrthmodestooe ]ultnewal_hook(riwutnrrcouAgsstQroguiprutoatcetheulelQRoeeasu
n soa cLpytpsteea nd forci hanSlQ.s] heTutdtsir
nthee^s</rr someRenoe epsteea nd forci eeatdwathwrCNtefitot-rityAiorrle"main"i icgulYnoe eoStonn[ATTACH]-etled forciulelQRofourtEnthee^s</robjheyumeRen rol bpstthges cexn*hAnyeienV)gowrCNg-ahe tdthg filQ,
 whineludoguiproci eeatdwur)tjea
*immmitNde.s] objh^Tutdeatcethehf d confits*enensrrmalgitheep ad[SLFORDEOK]. heIStonnMAais
anoaCmegithaweiroee,heeaetMAaisewo nr rothgV)ihethehupemeroonnatsuoruhShosiesaCmegorci eo lcicsfeindsmftMihe tV)ussproen-me prutoatcethee nreohawoorttonnMAais,aV)oonnetutdemmmittwo nrhrveotmo nr]r,s]rsd.hIsfeinrityastcetherrets i p[SLFORDEROW]hise[SLFORDEDONE],oum inoitirets i pas aeuRrityV)ussnceabcnqecorrssponSsto apy eaeideShosiesMAaiseimme,cprutr*yr Ss
anoarnei Syaets .
 u
 wh^Aosaoheccnd forci hanSlQSrayohrveonssmMsthaosaoheccwrCNg-ahe tdthgrityastcetherregsstQrastathpnnetime. ^CmcLapGM[e ]ultnewal_hook(rtrrcouAplacesomeRecAPar Sobehrvlum um toavluusnysregsstQrastwrCNg-ahe trrcothg oatcetheus] objh^Tutdaweiror aeueneyua cLpytpsteea tsir
nthee^s</rrfn bb itobjhtoavluus oatc,nifofnb,sje 0.
ruobjh^Tutd[e ]ultnewal_autocheckpaetCirts  savs] Psapd thTELje[wal_autocheckpaetCopPagma] botE iMen-mS[e ]ultnewal_hook(rtefrce nrto nrDverwrCNg^any  olumS[e ]ultnewal_hook(rteset)tnesu<rdoh teIstalwrCNg-ahe tdthg catcethenithseto ctnerAP thf d confitetn
ano[e ]ultnewal_checkpaetC_v2(rteumS[PRAGMAYwal_checkpaetCtrrcois*enenbe  Men-me pesiodocLlgitto keepnV)gowrCNg-ahe tdthg filQrrcofn bbgrhwrguo ledduo[boutdu<rdoh tePhmol_eraaauxa taetCNTrfiseV)ggastcethendisSl os]automatocrityaheckpaetCl_er intruly.hTohaw-enSl oomeRecAPar Sobehrvlum,nastc
Ljeetegi]dswal_autocheckpaetCidb,1000) dr]icsf[PRAGMAYwal_checkpaetCt.
a*xWris] objerIflsn*e ]ultnewal_hook(x rttegi_h*,
ooetCi*)(Ifls *,ttegi_h*,|bts treAP*,ite),x rIfls*
e;xasesPh geDe changConfiguritanuauto-checkpaetCobjhbjheyup;veselli
ruobjh^Tutd[e ]ultnewal_autocheckpaetCiD,Nrte snalwrappesearoutd
ano[e ]ultnewal_hook(rteeeathoa 
es any nd forci oh [ed forci aCnrpefereA De nreohautomatocLlgit[checkpaetCtrrcofftrleimmmitN-DSea Vransaefere ifhprureSare N um
bjhmM tofee^sT inaAPtd[wrCNg-ahe tdthg] filQretePhmol_erbavrnosobjhausegsgange aeuRo saAPtdNnthee^s</rrdisSl os]automatocrityaheckpaetCsr intruly.s] objh^TutdeatcethehuAgsstQrast,s]AP thf d confiuAplacesoanyoeeshil_etoatcethee nruAgsstQrastisapGM[e ]ultnewal_hook(rtreteLikEwisa,tuAgsstQroguiatoatcethee nrisapGM[e ]ultnewal_hook(rtrdisSl os]eindautomatocyaheckpaetC medirtism
anoaCnfiguriLe,s]AP thf d conf.
ruobjh^Tutd[wal_autocheckpaetCopPagma] omnl* eus senooiMen-mStsisl  savs] P
rdofn bbWri.
ruobjh^CheckpaetCsribitihtiLe,s]AP thmedirtismraedoruh[e ]ultnewal_checkpaetC_v2|PASSIVE].
ruobjh^EheryxFSaf[ed forci aCnrpefereA cAPar Sseto hrvlguiprutauto-checkpaetCobjhenSl osytonl aam reshold oft1000hise[SLFORDEDEFAULT_WAL_AUTOCHECKPOINTtrrco iges.
ruobjh^Tutdusdbpsteeisl  savs] PriyuDnaborpeesshrytifomeRecAPar Soset)tneobjheyufoutdrecobutsubo
comalofis aathrticulAP a  siso*etC.
 *xWris] objeretenttegi_hAwal_autocheckpaetCittegi_h *db,retenNe;xasesPh geDe changCheckpaetCoa nd forci
anobjheyup;veselli
ruobjh^(Tupet ]ultnewal_checkpaetCiD,X Iiyuequivdlentorc
bjh[e ]ultnewal_checkpaetC_v2]iD,X,[SLFORDECHECKPOINT_PASSIVE],0,0 .ets] 
 whInobrief,et ]ultnewal_checkpaetCiD,X Ioa 
es  itd|btt-meeienV)g
ano[wrCNg-ahe tdthg] fos]ed forci X oh [ed forci aCnrpefereA Drecobue nreransf/ryed in oteea nd forci filQSandifiseV)ggwrCNg-ahe tdthg rc
bjh* ereset. hteoomeRe[aheckpaetCl_eA cocum inaeoth fis addypesm
 whinurrmato m.
 u
 whlQisl  savs] Prus senooercprutenabs ay eo lcicsfayaheckpaetC rc
bjh]r,s]. hButoV)annV)ggFSaeseapd m ieetowl fu"i[e ]ultnewal_checkpaetC_v2(rt
 whinsavs] Pswasoaddsd.hhlQisl  savs] Prithawe] tobjfis ethewardt
anoaCmiaeobilgiypapdinyua cLnven--mce e icfhosiso*etCseeeathne senoomanuLlgi
anostar]oanastcethen,usswhichhnohset ne senQRofu nr owl b(npdi|orrssponSl_e
anoaCmisiso*etC)rOSt[e ]ultnewal_checkpaetC_v2(rt.
 *xWris] objeretenttegi_hAwal_checkpaetCittegi_h *db,r|bts treAP *zDbe;xasesPh geDe changCheckpaetCoa nd forci
anobjheyup;veselli
ruobjh^(Tupet ]ultnewal_checkpaetC_v2(D,X,M,L,Crs  savs] PsrunsfayaheckpaetC
*noo
yra(oth th nd forci XrOSt[ed forci aCnrpefereA Drienmmme M. htnaeus
 whinurrmato mbiyuwrCNtefietheninnooiMtegl s taetCNsenooey LpapdiC.ets] h^(TupeMnthee^s</rrrea
** ea eaeide[aheckpaetC mmme]:ets] 
 wh<dlfibje<dt>SLFORDECHECKPOINT_PASSIVE<ddfibjeee^CheckpaetCoas manybfee^sT as*tossil oo ledduo[wai)rgu e i any nd forciibjeeereadersroro rCNsrmalosfieish,etutnnsyncteea nd forci filQSifofrtbfee^sTibjeeeinaAPtdthg wur)taheckpaetCsdulelQRo[busy-hanSlQr astcethe]ibjeeeisoneverm Men-mbjinaAPtdSLFORDECHECKPOINT_PASSIVE mmme.
rueee^OnaAPtdtorrlehanS,ethmolvT mmmeSmrla
*lerveothTsaheckpaetC unfieishedibjeeeifhprureSare ctCcexn*hAnreadersroro rCNsrm.
 u
 wh<dt>SLFORDECHECKPOINT_Fuxa<ddfibjeee^lQislmmmeSbthwks (itbiMen-msomeRibjeee[e ]ultnebusy_hanSlQr|busy-hanSlQr astcethe]routCr"i itretithseibjeeend forci wrCNsrpapdin nrawadersrayebreadl_erfn bb itdmMstorecenennd forciibjeeesnapshot.heItoV)annaheckpaetCsrfrtbfee^sTeinaAPtdthg filQSandisyncsomeRibjeeend forci filQ.e^lQislmmmeSbthwks FSafnd forci wrCNsrss uileoitiisSpenSogu,
 wh n,ussFSafnd forci awadersrayebalthws eto imaninunei imbscAd.
 u
 wh<dt>SLFORDECHECKPOINT_RESTART<ddfibjeee^lQislmmmeSworksnlup  cha weisasdSLFORDECHECKPOINT_Fuxaytonl V)a addypesm
 wh  eeatifftrleaheckpaetCl_erAPtdthg filQSitnrthwks (astcsmputibjeee[busy-hanSlQr astcethe]ribjeeeutCr"if nrawadersrayebreadl_erfn bb itdnd forci filQSpnab.e^lQislensuris
 wh  eeatiV)ggFSxt wrCNsrpto nruAstar]rAPtdthg filQSfn bb itdbAgsnnogu.ibjeee^LikEdSLFORDECHECKPOINT_Fuxa,]AP thmmmeSbthwks FSaibjeeend forci wrCNsrpa oiaprs  uileoitiisSpenSogu,n,ussnceabcnqeimbscArawaders.
 u
 wh<dt>SLFORDECHECKPOINT_TRUNCATE<ddfibjeee^lQislmmmeSworksnlup  cha weisasdSLFORDECHECKPOINT_RESTARTytonl V)aiano  addypesm eeatii
*alsootrunws] srAPtdthg filQSto bavrnbscTdbjea
* olum
bjh sto aheu rla
fu"iaweiro.
 u
 wh<dt>SLFORDECHECKPOINT_NOOP<ddfibjeee^lQislmmmeSalwayssaheckpaetCsrbavrnfee^sT.eyup;onlybaw sonenooiMen-miano  a NOOPsaheckpaetC iyunooacrla
rAPtd rh Ssoaweiroeegbyibjeees ]ultnewal_checkpaetC_v2(reviaat epuntt]pe^s</rsb*pnLog andi*pnCkpt.
ano</dlfibjoh teIstpnLog iyusetoNuxa,]APann*pnLog iyutetsVoeeea totacrn rol bpstfee^sTein
 nreindthg filQSoTSuxo-1tifomeReaheckpaetC c*enensrtsrunserccics
*nooStonnMAaise]rserccicsb itdnd forci iyusetoi"piWAL mmme].teIstpnCkpt iyuset
*noNuxa,APann*pnCkpt iyutetsVoeeea totacrn rol bpstaheckpaetCsdbfee^sTeinaAPtrrcothg filQS(ineludoguianyam atdwur)tnlba tynaheckpaetCsdbbee ieeV)edf d confobjhwathistcQd)SoTSuxo-1tifomeReaheckpaetC c*enensrtsrunsdueSuxoanuMAaise]r
bjh* ccicsb itdnd forci iyusetoi"pWAL mmme.teNotsoV)ussupnfitu rla
fu"
anoaCmisweo mtpstonntho],(MCHECKPOINT_TRUNCATE,reindthg filQSwo nrhrveobeen
anoVrunws] dyVoebavrnbscTdbapd tohbotE *pnLog andi*pnCkptswo nr*e tetsVoebavr.
 u
 wh^Allnastcsmobn SseandMxclis-ved"aheckpaetC" thwkboseeea nd forci filQ.e^Ife nrapy otEds]trorla
 ithrunnogufayaheckpaetC o
yra(oth atnlup  cha time,aAPtrrcothck asnset beIobn SseebaChelr8],(MBUSYhithaweiroeerh^EngndiftV)er)tithn
bjh*usy-hanSlQr aCnfiguriL,aisswo nrset beI Men-mbjinaAPeyulsib.
ruobjh^TutdSLFORDECHECKPOINT_Fuxa,]RESTARTyaCheTRUNCATE mmmeyualsooobn Sset)g
anoexclis-ved"wrCNsr" thwkboseeea nd forci filQ.e^IfeV)ggwrCNgrothck asnset be
*noobn Sseebimmedld. ly,papdinh*usy-hanSlQr eyulLnfiguriL,aissith Men-me frce nreindwrCNgrothck reeried utCr"ieiorrlb itdbusy-hanSlQr rets i p0i icgulYthwkobjhis eu rla
fu"nysobn SseerhelQRobusy-hanSlQr eyualsoo Men-me  uileowai)rgu e i
anond forci awadersrasaeescribme fbovQ.e^IfeV)ggbusy-hanSlQr rets i p0ibee iee nreindwrCNgrothck isoobn Sseebum wuileowai)rgu e iond forci awaders,aAPtrrcoaheckpaetC o
yra(oth  rorlmdsSfn bb iatstaetCS delup  cha weisas
**dSLFORDECHECKPOINT_PASSIVE -eaheckpaetCl_eras manybfee^sT as*tossil oe nrtoedduo[bthwkl_ehanybfurtEds.he**n],(MBUSYhithaweiroeejinaAPeyulsib.
ruobjh^Istphee^s</rrzDbhithauxa um taetCsrto ahbavrnlengnl emrrgu,etutnnV)g
anoeeA_zsisdro
yra(oth itha oiapredron]a nrWAL nd forcise[attachTc]orc
bjh[ed forci aCnrpefereA cb.hhInoeeeyulsibt it
bjh rh SsowrCNtefitott epuntt]pe^s</rsb*pnLog andi*pnCkptoarnei Syaets .e^Ife nrapelr8],(MBUSYhMAaiseislencoutCQrastwutnntrorla
rgu re)tOr]mM toosteeaianoattachTceWAL nd forcis,reindo
yra(oth ithtmo nra oiapredron]anishemain-DS
anoattachTcend forcisbaChelr8],(MBUSYhithaweiroee atnlup enS.heIstapy otEds
anoeAaise]r,s]
e uileotrorla
rgu anAattachTcend forci,otrorla
rgu ithabapdoned
anoapd lup eAaiseimmegithaweiroeeiuxim eniartmriimmedld. ly.eeIfhsedMAais
ano(lr8],(MBUSYhticotEdswisa)eislencoutCQrastwuileotrorla
rgu V)a attachTc
anond forcis,pSLFORDEOKhithaweiroeer
ruobjh^Isted forci zDbhithgulYnoe eoStonnattachTcend forci urattithsetoi"pWAL
bjhmMde,pSLFORDEOKhithaweiroeeenpdibotE *pnLog andi*pnCkptstetsVoe-1.e^Ife nrzDbhithsetoNuxa (is aabavrnlengnl emrrguroapd ithsetogulYnoe eoStony
anoattachTcend forci,pSLFORDEERRORgithaweiroeeiuxim eniartmr.
ruobjheUntla
Sitirets i pSLFORDEMISUSE,
 wheetes ]ultnewal_checkpaetC_v2(re  savs] P
rdotets lup eAaiseinurrmato mburattithquMAieegbyibje[ttegi]dsMAaimmeir]enpdiittegi]dsMAamsgir].
ruobjh^Tutd[PRAGMAYwal_checkpaetCthimmmanS omnl* eus senooiMen-mStsisl  savs] P
rdofn bbWri.
r*xWris] objeretenttegi_hAwal_checkpaetC_v2(x rttegi_h *db,rrrrrrrrrrrrrrrrrrrr/deDd forci hanSlQSb*x r|bts treAP *zDb,rrrrrrrrrrrrrrrr/deNoe eoStottachTcend forci (is Nuxa)Sb*x reteneMMde,prrrrrrrrrrrrrrrrrrrrr/deSLFORDECHECKPOINT_jh rh SSb*x reten*pnLog,prrrrrrrrrrrrrrrrrrrr/deOUT: StndbpstWAL thg inbfee^sT b*x reten*pnCkptsrrrrrrrrrrrrrrrrrrrr/deOUT: Totacrn rol bpstfee^sTeaheckpaetCsdbb*x);xxsesPh geDe changCheckpaetCoMMde Vrh SssPh KEYWORDS: {aheckpaetC mmme}
 u
 whlQeci aCnstatCsrSyaets]a nreaeide rh SstfiseV)gg"aheckpaetC mmme"rthmode
anoasteea tsir
nthee^s</rreCoV)a [e ]ultnewal_checkpaetC_v2(rte  savs] P.
anoteoomeRe[e ]ultnewal_checkpaetC_v2(rtecocum inaeoth fis dytsilsnonnV)gELjeme"nrgu rf eachrosteeasReaheckpaetC mmmey.
r*x#Syaets]SLFORDECHECKPOINT_NOOPrrrr-1tr/deDohsedwork atna nrr*x#Syaets]SLFORDECHECKPOINT_PASSIVE p0ir/deDohas mechbas*tossil oo /o[bthwkl_ehr*x#Syaets]SLFORDECHECKPOINT_Fuxayyyyy1  /deWai) fis wrCNsrs,oV)annaheckpaetChr*x#Syaets]SLFORDECHECKPOINT_RESTARTy 2  /deLikEdFuxaybuo[wai) fis awadersrr*x#Syaets]SLFORDECHECKPOINT_TRUNCATE 3  /deLikEdRESTARTybuo[alsootrunws] tWAL r*xxsesPh geDe changVirtus STSl ooI savs] PgConfiguraeothobj
 whlQislf d confimayoerclsllsdebyheiorrlb itd[xCCnrpefteumS[xCssV)i]ImettrT
*nooSto [virtus SnSl o]Sior rm inaeotheto imafiguri
bjh rrluus s] PesbpstnPtd irtus SnSl oe  savs] P.
an
 whIsteeisl  savs] Priyu Men-mentutsiSs  itd|btt-xteoStonnxCCnrpefe]r
bjhxCssV)id irtus SnSl oemettrTeV)annV)ggbehrvlum isei Syaets .
 u
 whInaAPtdeatcre ]ultnevnSlecqnfigiD,C,...eaAPtdDnthee^s</rr someR
bjh[ed forci aCnrpefereA inswhichhnPtd irtus SnSl oe thbe-DSnlssV)iLefrce nrthichhiththmodesinsasaguaifuoly foren-metrco itd[xCCnrpefteumS[xCssV)i]ELjemettrTeV)assith Men-apGMe ]ultnevnSlecqnfigi). tyup;Cnthee^s</rr soons
*nooSt itd[ irtus SnSl oeconfiguraeoth o
confs]. tyup;presencegapdimean-DS
anooftt]pe^s</rsbfftrleC SypenS onswhichh[ irtus SnSl oeconfiguraeoth o
confAobjhithus s.
r*xWris] objeretenttegi_hAvnSlecqnfigittegi_h*, etC o
f ...e;xasesPh geDe changVirtus STSl ooConfiguraeoth Op*etCs
anoKEYWORDS: { irtus SnSl oeconfiguraeoth o
confs}
anoKEYWORDS: { irtus SnSl oeconfiguraeoth o
conf}
 u
 whlQeci macrosrSyaets]APtd rrluus o
confstrco itibje[ttegi]dsvnSlecqnfigi)ts  savs] PsV)ass[virtus SnSl o]Sior rm inaeothyrityasndusdbto iustomtndband o
comyus V)airgbehrvlum.
 u
 wh<dlfibje[[SLFORDEVTABECONSTRAINT_SUPPORT]]
 wh<dt>SLFORDEVTABECONSTRAINT_SUPPORT</dt>
 wh<dd>CatcsbpstnPtdurrmibje[ttegi]dsvnSlecqnfig]idb,SLFORDEVTABECONSTRAINT_SUPPORT,X Iarsutuhoorted,e nrther)tXbiyuanAGdtegl .hhIsfXbiyubavr,heetnnV)gg[virtus SnSl o]Swrociibje[xCssV)i]IumS[xCCnrpeftemettrTe Men-men[ttegi]dsvnSlecqnfigi)tsnceabcnq
rdotuhoort aCnstraetCs.hhInoeeeyulonfiguraeoth (thichhithmeRecAPar S)sis
anoa aatcrrco itd[xUpds] temettrTerets i p[SLFORDECONSTRAINT],heetnnV)gg intru
anostatMihe tithaotcmderfckr syif [ON CONFLICT | ORgABORT] hadobeen
anoteA_zsisdrfyuthrtbpstnPtdusdr' pSLFutmftMihe , regardlla
SostV)a actus 
anoON CONFLICT mmmeSteA_zsisd.
an
 whIstX ithseilbavr,heetnnV)gg irtus SnSl oe or rm inaeotheguieedtesssPh eeatiif [xUpds] terets i p[SLFORDECONSTRAINT],hisswo nrdo tohbee iee nrapy modzsiso*etCseeo in avmhn um t/rsist-mennd fostruc)urisrhrveobeen mame.
rueIfeV)gg[ON CONFLICT] mmmeS theBORT, FAIL, IGNORE um ROLLBACK,nthosieobjhithablQSto aotcerfckr ostatMihe t iond forci Vransaefere,hnpdiabapdon
anoor imaninunetrorla
rgu V)a cexn*hAnSLFutmftMihe inyua  ro olaNT.
rueIfeV)ggON CONFLICT mmmeSithREPLACEoapd lup [xUpds] temettrTerets i ibje[SLFORDECONSTRAINT],hShosieshanSlQsoeeeyuaseifhprugON CONFLICT mmmeibjehadobeenheBORT.
an
 whVirtus SnSl oe or rm inaeothseeeathayebre
*irsdrto hrnSlQSORgREPLACEELjemea
*do toh ledinaV)a [xUpds] temettrT. Ista aatcrrco itibje[ttegi]dsvnSleonecqnflict(rtef d confiendocL] srAPatnlup cexn*hAnONsPh gONFLICT policySithREPLACE,nV)gg irtus SnSl oe or rm inaeotheis*ene
anotil*hAnyeuAplacetV)a a  ro olaNTbr
ns] ledinaV)a xUpds] toatcetheharce nraweirorSLFORDEOK. Or,eifhpris ithsetotossil o,oitirayxaweiro
**dSLFORDECONSTRAINT, inswhichhlsibtShosiesfatcsbethenpo ORgABORT
anoaCnstraetC hrnSlogu.ibje</ddfibjoh t[[SLFORDEVTABEDIRECTONLY]]<dt>SLFORDEVTABEDIRECTONLY</dt>
 wh<dd>CatcsbpstnPtdurrmibje[ttegi]dsvnSlecqnfig]idb,SLFORDEVTABEDIRECTONLY)ofo bb ledinaAPt
 wheete[xCCnrpefteumS[xCssV)i]ImettrTsooSto [virtus SnSl o]Sior rm inaeoth
 wh rohibits VPatn irtus SnSl oefo bbbe-DSnus sefo bb ledinaAriggl s arce nrviews.ibje</ddfibjoh t[[SLFORDEVTABEINNOCUOUS]]<dt>SLFORDEVTABEINNOCUOUS</dt>
 wh<dd>CatcsbpstnPtdurrmibje[ttegi]dsvnSlecqnfig]idb,SLFORDEVTABEINNOCUOUS)ofo bb ledinaAPt
 wh[xCCnrpefteumS[xCssV)i]ImettrTsooSto [virtus SnSl o]Sior rm inaeoth
 whids r,sy VPatn irtus SnSl oeathbe-DSnsafehto icsffo bb ledinaAriggl s
anoapd views. oCon ,ChuLlgi,nV)ggSLFORDEVTABEINNOCUOUSSnSghme"nsrAPatnlupe nrvirtus SnSl oecanAnohse serluus harm engndiftissithimanaotcmders]a
anomalicluus hackl .hhDehelo
yrsois*enenaIflsnset)tnenV)ggSLFORDEVTABEINNOCUOUS
rdoflSghuntla
Sabsolu. lyorpeesshry.ibje</ddfibjoh t[[SLFORDEVTABEUSES_ALL_SCHEMAS]]<dt>SLFORDEVTABEUSES_ALL_SCHEMAS</dt>
 wh<dd>CatcsbpstnPtdurrmibje[ttegi]dsvnSlecqnfig]idb,SLFORDEVTABEUSES_ALL_SCHEMA)ofo bb ledinaAPt
 wheete[xCCnrpefteumS[xCssV)i]ImettrTsooSto [virtus SnSl o]Sior rm inaeoth
 whids ruc)heetequMAy planrprenooergih atnLSsdt here t Vransaeferebon
anoatcrechemath("main", "oiap",hnpdiapy ATTACH-etled forcisriwutnevermlupe nrvirtus SnSl oeithus s.
rje</ddfibjo</dlfib*x#Syaets]SLFORDEVTABECONSTRAINT_SUPPORT 1x#Syaets]SLFORDEVTABEINNOCUOUSSSSSSSSSSS2x#Syaets]SLFORDEVTABEDIRECTONLYSSSSSSSSS3x#Syaets]SLFORDEVTABEUSES_ALL_SCHEMASSSS4xasesPh geDe changDegermets]yup;Virtus STSl ooConflict Policyobj
 whlQislf d confimayoonlyberclsllsdefo bb ledinam aatcrrco itd[xUpds] temettrT
*nooSto [virtus SnSl o]Sior rm inaeothee icanAINSERT  icUPDATE o
yra(othulelQRrity rh Staweiroeegisntntdosp[SLFORDEROLLBACK],r[SLFORDEIGNORE],r[SLFORDEFAIL],ibje[SLFORDEABORT],hise[SLFORDEREPLACE],haccordiDSeuxim en[ON CONFLICT] mmme
*nooSt itdSLFutmftMihe iAPatnlriggl me prutoatcrrco itd[xUpds] temettrTeosteeaiano[virtus SnSl o].
r*xWris] objeretenttegi_hAvnSleonecqnflict(ttegi_h *e;xasesPh geDe changDegermets]IstVirtus STSl ooColumnhecrla
rIshFticUPDATE
an
 whIsteeenttegi_hAvnSlenodirtrm(X ort ethneiyulstcmdewledinaV)a [xColumn]ELjemettrTeoSto [virtus SnSl o],heetnnitSmrla
*aweiror ruoeifhpru
anoaClumnh thbe-DSnfetchTcefyuthrtbpstanAUPDATE o
yra(othrduerguiwhichhnPt
anoaClumnh rh Stwo nrset dirtrm. tyup; irtus SnSl oe or rm inaeotheasndusd
 wheeisshetCoas teMmissotheto tubstituNg^adaweiror aeuenV)assithtla

anoexpees-vedto immiuNg^andrAPatnlup corrssponSl_e
ano[xUpds] temettrTei Syrstandsinyua "no-chrtrm"r aeue.
an
 whIsteeen[xColumn]emettrTeastcsmttegi_hAvnSlenodirtrm(roapd aetdsrAPat
 wheeteaClumnh thset dirtrmdrbydV)a UPDATE tmftMihe , eetnnV)ggxColumnELjemettrTecah o
confalgitheep adtoedduo[set)tnenatr*yr S,dtoedduo[smcLapGe nrapy oSt itd[t ]ultner*yr S_etC|t ]ultner*yr S_xxxxxirei savs] Pst.
 whImburattcrci,r[ttegi]dsvaeueenodirtrm(X ]pto nruAeiror ruoefiseV)g
anotoe 
cMlumnh naV)a [xUpds] temettrT.
 u
 whlQemttegi_hAvnSlenodirtrm(rort ethneiyuah o
comiza(othulhVirtus SnSl o
 whior rm inaeothseis*enenimaninuneto g-veda eorrsetuahswl bengndiftV)e
anottegi_hAvnSlenodirtrm(roinsavs] Pswer)tto alwayssuAeirorfatciulhInaAPt
anoaexn*hAnior rm inaeoth,teeenttegi_hAvnSlenodirtrm(roinsavs] Psnceabalwaysrrcoawep a pfatcitfiseV)ggenirtcsd [UPDATE FROM] tmftMihe .
r*xWris] objeretenttegi_hAvnSlenodirtrm(e ]ultnecqnt-xt*e;xasesPh geDe changDegermets]yup;CbllV)tnf Fis aaVirtus STSl ooConstraetCsPh bjheyup;veselli_isSyx_inurobj
 whlQislf d confimayoonlyberclsllsdefo bb ledinam aatcrrco itd[xBestIsSyx]ELjemettrTeoSto [virtus SnSl o].hhlQislf d confiuAts i pastaetCNTSuxoa emrrgusPh eeatiisomeRenoe epsteea a  ro olaNTbcbllV)tnf s*
* ncehto icsffiseVex 
anocmmiarisreshDnnlup ctCstraetC ids r,siNdrbydiesraeren-mes.
 u
 whlQemfuoly foren-metrea
** elup taetCNTSuxo itd[t ]ultneisSyx_inur]rpbje<tsPh eeatiisomeRefuoly  iee^s</rhuxo itdxBestIsSyxM ImettrT.eyup;eeasu
nforen-meELjemea
*beuanAGdSyx in oteea aConstraetC[]uarraytbeloDSiDSeuxim e
anottegi_hAisSyx_inurostruc)urirthmodestooxBestIsSyx.
an
 whImoortant:
 whlQemfuoly thee^s</rrrea
** elup  cha taetCNTSurattiththmodesin oteea
bjhxBestMettrTM ImettrT.ehlQemfuoly thee^s</rrreissetobaiastaetCNTSuxoa
bjhdiffNT-met[t ]ultneisSyx_inur]rpbje<t,bengndandMxaef cLpy.
 u
 whlQemaweiror aeueneyuimmiuNgd astfiLu
ns:ibj
 wh<olfibje<li><p>hIsteeenctCstraetC immesSfn bba WHERE clsicsoexprla
o mburattodan Sss
 wh        o [COLLATE o
yra(or],heetnnV)ggnoe epsteea cbllV)tnf seA_zsisdrby
 wh        urattCOLLATE o
yra(orhithaweiroeer
rue<li><p>hIsteeeretithsesCOLLATE o
yra(or,nbuo[einecMlumnheeatiisomeRetubje<tsPh         osteeenctCstraetC seA_zsisyuah aleu*nsgangr|bllV)tners*
* ncehvia
 wh        o [COLLATE clsics]hDnnlup ctlumnhnyaetit-thtwledinaV)a CREATE TABLE
 wh        tmftMihe iAPatnwasrthmodesin ot[t ]ultnedeclsreAvnSl()],heetnnV)g
 wh        noe epsteeatna eu*nsgangr|bllV)tners*
* ncehithaweiroeer
rue<li><p>hOtrrlwisa,t"BINARY"hithaweiroeer
rue</olfib*xWris] objer|bts treAP *ttegi]dsvnSlecqllV)tnf(t ]ultneisSyx_inur*,ite);xasesPh geDe changDegermets]ifof; irtus SnSl oequMAy ithDISTINCTsPh bjheyup;veselli_isSyx_inurobj
 whlQisleDeirayxonlybercus sefo bb ledinaonn[xBestIsSyx|xBestIsSyxImettrT]
*nooSto [virtus SnSl o]Sior rm inaeoth.hlQemawyr SbpstamcLapGMeeis
 whidsavs] Psfo bbtutsiSs pstxBestIsSyxM Iisei Syaets oapd trolSl y harmful.
ruobjh^Tutdttegi]dsvnSledshil_ct(roinsavs] PsuAts i panAGdtegl bertweenh0 arce nr3.ehlQemGdtegl baweiroeegbytttegi]dsvnSledshil_ct(re nrgangs eeto irtus SnSl oeaddypesmaleinurrmato mbabduo[howheetequMAy
 wh lanrprewatCsreetet epuntnooercordQras.eAseloDSsasaguaivirtus SnSl o
 whcah meetoV)a ordQrapGMre
*irsm-mesbpstnetequMAy planrpr,oitirayxset
 wheete"ordQrByConsen-d"oflSg.ibj
 wh<olf<lir aeue="0"><p>objh^Isteeenttegi_hAvnSledshil_ct(roinsavs] PsuAts i p0,heeaetme"ns
anoV)ussprutquMAy planrprenlmdsSeeto irtus SnSl oeeohaweirorf nra
ns]inaAPt
 whsort ordQrhSyaets rbydV)a "nOrdQrBy"oapd "aOrdQrBy"osisldseosteeaiano[t ]ultneisSyx_inur]rpbje<t.hhlQisl someRecAPar Soexpecnaeoth.hhIsfeinrity irtus SnSl oet epunsrf nra
ns]inasorted ordQr,heetnnitSiabalwaysnsafehe i
ano itdxBestIsSyxemettrTeVoosetoV)a "ordQrByConsen-d"oflSg, regardlla
Sos
ano itdaweiror aeuenfo bbttegi_hAvnSledshil_ct(rr
rue<lir aeue="1"><p>objh^(Isteeenttegi_hAvnSledshil_ct(roinsavs] PsuAts i p1,heeaetme"ns
anoV)ussprutquMAy planrprenceabcnqene senQRoa
ns]nooercaweiroeejinasorted ordQre nraseloDSsasaf nra
ns] led eetoeoe e rh Sstiorf nrctlumns ids r,siNdrbydeinrity"aOrdQrBy"osisldrayebadjaceneset* lQislmmmeSeyuus sewutnnV)ggquMAy planrpr
bjhithnooguia GROUP BYr
rue<lir aeue="2"><p>objh^(Isteeenttegi_hAvnSledshil_ct(roinsavs] PsuAts i p2,heeaetme"ns
anoV)ussprutquMAy planrprenceabcnqene senQRoa
ns]aweiroeejinaany  hrticulAP
*noordQr,haseloDSsasaa
ns] led eetoeoe e rh Sstiorf nrctlumns ids r,siNd
*nobyd"aOrdQrBy"oayebadjaceneset* ^(FurtEdsmM t,ewutnnVwotOr]mM toa
ns
anoaCnn Sset)goeoe e rh Sste ica nrctlumns ids r,siNdrbyd"ctlUs s",hntceruoianotntdsechba
nirayxo
confalgitercomitNdesfn bb itdr*yr S.ets] hyup; irtus SnSl oe yusetore
*irsdrto omitoa
ns]neathayebduisiso*sssPh overmlupd"ctlUs s"rctlumns,nbuo[istnPtd irtus SnSl oecanAnohprusswoedduoianoVoo mechbex ra efe it,oitic*enenpot-meihely helpsprutquMAy eohauorfastQr.
ruossislmmmeSeyuus sefis aaDISTINCTtquMAyr
rue<lir aeue="3"><p>objh^(Isteeenttegi_hAvnSledshil_ct(roinsavs] PsuAts i p3,heeaetme"nsfeinrity irtus SnSl oerea
*aweirora
ns]inaAPt ordQrhSyaets rbyd"aOrdQrBy"oas
 whisteeenttegi_hAvnSledshil_ct(roinsavs] Pshadoaweiroeej0.hhHowehersis
anoVwotOr]mM toa
ns]inaAPt awyr SbhrveothTseoe e rh Sste ica nrctlumns
 whids r,siNdrbyd"ctlUs s",heetnnntceruootntdsechba
nirayxo
confalgitersPh omitNde.et* LikEdwutnnV)ggaweiror aeueneyu2,nV)gg irtus SnSl o
bjhithsetore
*irsdrto omitoa
ns]neathayebduisiso*ss overmlupd"ctlUs s"
anoaClumns,nbuo[istnPtd irtus SnSl oecanAnohprusswoedduoianoVoo mechbex ra efe it,oitic*enenpot-meihely helpsprutquMAy eohauorfastQr.
ruossislmmmeSeyuus sefis quMAies
anoV)usshrveobotE DISTINCTtapd ORDER BY clsicssr
rue</olfibj
 wh<p>yup;fiLu
napGMeSl oesenmarizes  itd|btdypesmsei SyriwhichhnPt
ano irtus SnSl oe yualthws eto setoV)a "ordQrByConsen-d"oflSggorcidbon
anonPtd rh Staweiroeegbytttegi]dsvnSledshil_ct(r.hhlQislnSl oe yuarrcoawstatMihe t stnPtdtoavluus four theegraphs:ibj
 wh<nSl oebordQr=1 cellspacapG=0 cellpaddypG=10swodth="90%"fibje<trfibje<tde rhign="top">ttegi_hAvnSledshil_ct(roaweiror aeueibje<tde rhign="top">R
ns]ayebreeiroeejinaaOrdQrBy ordQre nr<tde rhign="top">R
ns] led eetoeoe e rh Stiorf nraOrdQrBy ctlumns ayebadjacenee nr<tde rhign="top">Duisiso*ss overma nrctlUs s ctlumns mayoercomitNdeibje<trf<td>0<td>yes<td>yes<td>seibje<trf<td>1<td>se<td>yes<td>seibje<trf<td>2<td>se<td>yes<td>yes
ano<trf<td>3<td>yes<td>yes<td>yes
ano</nSl ofibjoh teFiseV)ggpurpocisbOStcMmiariDSe irtus SnSl oet epune rh Sstto seoeifhpru
ano rh Sstayeb itdeoe e rh Stfis sortl_erturpocis,oVwotNuxa  rh SstayeblLnsiSsrsdianoVo** elup  chaulhInaotEds]words,reindcmmiarisre o
yra(orhith"IS"
ano(is "IS NOT DISTINCTtFROM")inpdisot "==".
an
 whIstf; irtus SnSl oe or rm inaeotheisei Sl oeeohmeetoV)a re
*irsm-mes
 whseA_zsisdrfbovQ,heetnnitSmea
*setosetoV)a "ordQrByConsen-d"oflSgginaAPt
 wh[t ]ultneisSyx_inur]rpbje<t  icanAl_corrsetuahswl brayxawyr S.
ruobjheA; irtus SnSl oe or rm inaeotheisealwaysnfreoeeohaweirora
ns]inaapy ordQre nrisswatCs,haseloDSsasaV)a "ordQrByConsen-d"oflSggis*setosetreteWetnnV)g
 wh"ordQrByConsen-d"oflSggis*unset,sprutquMAy planrpreto nraddbex ra
 wh[bscTimmeteto ensurioV)ussprutfumhn;r*yr ST aweiroeegbyt itdSLFuquMAy aedoruhordQras eorrsetly. tyup;usdbpsteea "ordQrByConsen-d"oflSggapd thTELjettegi_hAvnSledshil_ct(roinsavs] Ps thmerulyuah o
comiza(othulh^Caedfu"
anousdbpsteea ttegi_hAvnSledshil_ct(roinsavs] Psapd lup "ordQrByConsen-d"
anoflSggmrla
*helpsquMAies ag Sssttf; irtus SnSl oeeohauorfastQr.  Be-DS
anooverlyuaggrla
ovQSandiset)tnenV)gg"ordQrByConsen-d"oflSggwutnnitbiyucnq
rdoeaeidenoodo to,hDnnlup torrlehanS,emrla
*ccicsb**nCNTbnooaweirorl_corrsetrrcoawsr ST.
r*xWris] objeretenttegi_hAvnSledshil_ct(t ]ultneisSyx_inur*);xasesPh geDe changIds r,sy andihrnSlQSIN aCnstraetCs]inaxBestIsSyxobj
 whlQislinsavs] Psrayxonlybercus sefo bb ledinaon
 wh[xBestIsSyx|xBestIsSyxM ImettrT]ooSto [virtus SnSl o]Sior rm inaeoth.
 whlQemawyr Sbpst Men-oguiprislinsavs] Psfn bbapy otEds]|btt-xteis
anou Syaets oapd trolSl y harmful.
ruobjh^(AnctCstraetC on]a  irtus SnSl oetstnPtdurrmibje"[IN o
yra(or|ctlumnhIN (...e]"eis
anoimmmuniws] dyVoeeetoxBestIsSyxemettrTeayuarrco[SLFORDEINDEXECONSTRAINT_EQ]nctCstraetC.et* IstxBestIsSyxewatCsreodusd
 wheeissctCstraetC,nitSmea
*setoV)a corrssponSl_e
anoaConstraetCUshge[].argvIsSyxeuxoa pocegang Gdtegl .hh^(Tupe,eondQre nrtup;usuel mmmeetsthrnSlogu IN o
yra(ors,hShosiesgenyrV)ish[bscTimmetsPh eeatiiMen-msomeRh[xFi eu*|xFi eu*M ImettrT]oomce e iceachr aeueibjeDnnlup rrla
-hanS siSs pstlup IN o
yra(orset* lQusaguaivirtus SnSl o
 whonlybseoshaosaohecc aeuenfo bblup rrla
-hanS siSs pstlup IN o
yra(or
anoattf;time.
 u
 whInasome cacis,hhoweher,rissw*enenbe advatChgeuus foraguaivirtus sPh eSl oeeohses]a nreae SstDnnlup rrla
-hanS pstlup IN o
yra(orrf nraoianotncm. tyup;ttegi_hAvnSleinirei savs] Ps s] ilgiL] srAPis]inaAwotways:ibj
 wh<olfibje<li><p>
 wh  eA;eatcrrcht ]ultnevnSleiniP,N,-1)pto nruAeiror ruoe(seilbavrribjeeeifofntlenabsis  itd[t ]ultneisSyx_inur|P->aConstraetC][N]nctCstraetCibjeeei panA[IN o
yra(orteeeathoanl* etrorla
edrf nraootncm. t^InaotEds]words,ibjeeettegi_hAvnSleinire led -1tinnlup tsir
nforen-metithnomedirtism
ano gbytwhichhnPtd irtus SnSl oeoanlaskhShosiesifofrt-at-omce trorla
rgu
ano gpstlup IN o
yra(orrislengndtossil o.ibj
 wh<li><p>
 wh  eA;eatcrrcht ]ultnevnSleiniP,N,Fre led F==1 orrF==0iendocL] s
 wh  VoethoitioV)ussprut irtus SnSl oenceaborenceabcnqewatCieC  oorla

 wh  Vup IN o
yra(orrf n-at-omce, reseA_gangly. t^lQusawutnnV)ggtsir

 wh  thee^s</rr(F) ithseilsegsgang,iprislinsavs] Ps someRemedirtismrby
 wh  whichhnPtd irtus SnSl oetellshShosieshowrisswatCsieC  oorla
nV)g
 wh  IN o
yra(ors
rue</olfibj
 wh^Tutdttegi]dsvnSleiniP,N,Freinsavs] Psoanl* e Men-menreltiplQeeimes
 whwledinaV)a eoe exBestIsSyxemettrTeasll.hteFiseapy gangndP,N thir,
 wheeteaweiror aeuenfo bbttegi_hAvnSleiniP,N,Fre l nralwaysn* elup  cha
 whwledinaV)a eoe exBestIsSyxeasll.hteIsteeeninsavs] PsuAts i p ruo
ano(seilbavrr,heeaetme"nsfeiatnlup coCstraetC iscanAIN o
yra(or
anoeeathoanl* etrorla
edrf n-at-omce.hteIsteeencoCstraetC isccnqeanAINianot
yra(orror isnset beItrorla
edrf n-at-omce,heetnnV)gginsavs] PsuAts i 
anofatciu
ruobjh^(Art-at-omce trorla
rgugpstlup IN o
yra(orrislselectobsifobotE osteeaianofiLu
napGM|btdypesmseayebmet:ibj
 wh<olfibje<li><p>hTutdP->aConstraetCUshge[N].argvIsSyxe aeueneyutetsVoea pocegang
 whidsagl .hhlQisl sohowheete irtus SnSl oetellshShosieseeatii
*watCsieC
anousdbeeteN-tE ctCstraetC.ibj
 wh<li><p>tyup;tsdt eatcrrcht ]ultnevnSleiniP,N,FreforiwhichhFnwas
 whseilsegsgangshadoF>=1s
rue</olfets] 
 wheIsteiorrlb]rseotE osteeaM|btdypesmseabovQeayebfatci,heetndthoiies 
es
 wheetetradypesmaleone-n -a-timettrorla
rgugstrasagy foraguaiIN aCnstraetC.
 wheISteotE |btdypesmseayeb ruo,heetnnV)ggargvIsSyx-tEnthee^s</reuxim e
anoxFi eu*emettrTewo nr*e anA[ttegi]dsvaeueteeeathappears]nooercNuxa,
*nobusswhichhoanl* ethmodestoo[t ]ultnevnSlein_fuoly(rtefrce nr[t ]ultnevnSlein_FSxt(rteto aetd]a nreae SstDnnlup rrla
-hanS siSsianotfaguaiIN aCnstraetC.
 *xWris] objeretenttegi_hAvnSleif(t ]ultneisSyx_inur*,reteniCnfs,betenbHrnSlQ);xasesPh geDe changFetd]a nrelsm-mesbpnnlup rrla
-hanS siSs pstanAIN ctCstraetC.ibj
 whTQeci i savs] Ps ayebenabs 
efu"ifo bb ledinaAPt
 wh[xFi eu*|xFi eu*M ImettrT]ooSto [virtus SnSl o]Sior rm inaeoth.
 whlQemawyr Sbpst Men-oguipreci i savs] Ps fn bbapy otEds]|btt-xt
bjhithu Syaets oapd trolSl y harmful.
ruobjhlQemXnthee^s</rr nam aatcrrcot ]ultnevnSlein_fuoly(X,P)e]r
bjht ]ultnevnSlein_FSxt(X,P)eis*enenbe tntdospV)ggp]pe^s</rsbuxim e
anoxFi eu*emettrTewhichhiMen-msomeRci at ethns,baCheseA_zsicLlgi
anoanthee^s</reuPatnwasrtoavluusnysselectobsforrf n-at-omceAIN ctCstraetC
anotrorla
rgugo -DSnlup [t ]ultnevnSleini)ts  savs] PsinaAPt
 wh[xBestIsSyx|xBestIsSyxImettrT].hh^(IsteeenXnthee^s</rr socnq
rdoonnxFi eu*eforen-metrPatnwasrselectobsforrf n-at-omceAIN ctCstraetC
anotrorla
rgu,heetnnV)gci at ethnstheep ad[SLFORDEERROR].ets] 
 wh^(Usdbeetci at ethnstnooacrla
ra nreae SstDnnlup rrla
-hanS siSsianotfaguaiIN aCnstraetCgo -DSnimmeglikEtnPtdurLu
napG:ibj
 wh<bthwkquote><profibj &nbsp; sfor(rc=t ]ultnevnSlein_fuoly(pLisC,n&pVal);xbj &nbsp; sssssrc==SLFORDEOKh&& pVal;xbj &nbsp; sssssrc=t ]ultnevnSlein_FSxt(pLisC,n&pVal)xbj &nbsp; s){xbj &nbsp; sss//odo tomettrguo led pValxbj &nbsp; s}xbj &nbsp; sif(src!=SLFORDEDONEs){xbj &nbsp; sss//oanuMAaisehrth]r,s]rsdxbj &nbsp; s}xbj </prof</bthwkquote>ets] 
 wh^Ofitu rla
,teeenttegi_hAvnSlein_fuoly(X,P)eanS s ]ultnevnSlein_FSxt(X,P)rrcoat ethnstheep adSLFORDEOKhandiset *PieC  aetC rcsprutfuoly orgFSxt  aeueibjeDnnlup RHSotfaguaiIN aCnstraetC.hteIsteeereSare no]mM toeae SstDnnluprrcoarla
*hanS siSs pstlup IN ctCstraetC,neetnn*PieyutetsVoeNuxa apd lupsd
 what ethnstheep ad[SLFORDEDONE]u  eTutdaweiror aeuenmrla
*bt
 whsomp torrle aeue,esechbasdSLFORDENOMEM,tinnlup av intoSto malf d conf.
ruobjhTutd*ppOune rh Sstaweiroeegbyt itci at ethnstayebenabseaeideutCr"i it
 whsSxt aatcrrcoeiorrlb]ft itci at ethnstdr]itCr"i it enS pstlup xFi eu*
 whmettrTefo bb hichhnPtci at ethnstwur)tasllsd.hhIsfeind irtus SnSl o
bjhior rm inaeothenlmdsSeohawe] tfeind*ppOune rh SstfiseloDSmr,nitSmea
*makt
anoaCpisT.ehTutd*ppOune rh Sstayeb[trotectobsttegi]dsvaeue|trotectob].
r*xWris] objeretenttegi_hAvnSlein_fuoly(ttegi]dsvaeued*pVal, ttegi]dsvaeued**ppOun);xWris] objeretenttegi_hAvnSlein_FSxt(ttegi]dsvaeued*pVal, ttegi]dsvaeued**ppOun);xasesPh geDe changConstraetCg rh SstiorxBestIsSyxM sPh bjheyup;veselli_isSyx_inurobj
 whlQisleDeirayxonlybercus sefo bb ledinameRh[xBestIsSyx|xBestIsSyxImettrT]
*nooSto [virtus SnSl o]Sior rm inaeoth.hlQemawyr SbpstamcLapGMeeisl  savs] P
rdofn bbtutsiSs pstanoxBestIsSyxemettrTearnei Syaets oapd trolSl y harmful.
ruobjh^WetnnV)gnttegi_hAvnSlerhssvaeueiP,J,Vrs  savs] Psis inen-menfo bb ledin
 wheete[xBestIsSyx]emettrTeoSto [virtus SnSl o]nior rm inaeoth,t led Phbe-DS
anoancLpytpsteea [t ]ultneisSyx_inur]rpbje<t taetCNTSthmodesin otxBestIsSyxefrce nrJhbe-DSna 0-orcidbGdSyx in otP->aConstraetC[],heetnnV)issao ethn
anoa oiaprs to seto*V rcsprutvaeuedpsteea rrla
-hanS p
yranS ps
anoeeathooCstraetC isteea rrla
-hanS p
yranS issknown.hteIsteeerrcoarla
-hanS p
yranS issset known,neetnn*VneyutetsVoea auxa taetCNT.s] heTutdttegi_hAvnSlerhssvaeueiP,J,Vrs  savs] Psrets i pSLFORDEOKhife nraptlenabsis *VneyutetsVoea  aeue. heTutdttegi_hAvnSlerhssvaeueiP,J,Vr
 whidsas] Psrets i pSLFORDENOTFOUND isteea rrla
-hanS siSs pstlup J-tE
anoaCCstraetC isccnqeavailSl o. heTutdttegi_hAvnSlerhssvaeueire  savs] P
rdooanlaweirorfmawyr Sbimmegothmram aadSLFORDEOKhiseSLFORDENOTFOUND is
 whsompttrguogoSsowrogu.
 u
 whlQRoe ]ultnevnSlerhssvaeueire  savs] PSeyuusuLlgihonlybsu rla
fu"iis
ano itdarla
-hanS p
yranS psua cLnstraetC isca ]ultrale rh Stiorlup tarlumhn
anoSLFutmftMihe .hhIsfeindarla
-hanS p
yranS issandMxprla
o mbis aarefNT-m P
rdotohsomp torrlectlumnhis aa[holy thee^s</r],heetnne ]ultnevnSlerhssvaeueir
 whwl nr rolSl y heep ad[SLFORDENOTFOUND].
ruobjh^(Some cCnstraetCs,esechbasd[SLFORDEINDEXECONSTRAINT_ISauxatefrce nr[SLFORDEINDEXECONSTRAINT_ISaOTauxat,shrveono]arla
-hanS p
yranS.hhFisesech
anoaCCstraetCs,oe ]ultnevnSlerhssvaeueirealwayssuAeiro pSLFORDENOTFOUND.ets] 
 wh^Tup [t ]ultnevaeuetepbje<t reeiroeejina*Vneyua trotectobsttegi]dsvaeuee nraptlhemainsseaeideforaguaiduraeoth ofeeetoxBestIsSyxemettrTeasll.objh^WetnnxBestIsSyxeuAeiro ,teeenttegi_hAvaeuedpbje<t reeiroeejby
 whe ]ultnevnSlerhssvaeueire shautomatocLlgitdealthws] d.
 u
 whlQRo"erhss"tiorlup noe epsteeissao ethn issandabboavlaeothee i
 wh"Rrla
-HaCheliSs".
r*xWris] objeretenttegi_hAvnSlerhssvaeueit ]ultneisSyx_inur*,rete, ttegi]dsvaeued**ppVal);xasesPh geDe changConflict rlaolu.onfimmmeysPh KEYWORDS: {aonflict rlaolu.onfimmme}
 u
 whlQeci aCnstatCsrayebreeiroeejbyt[ttegi]dsvnSleonecqnflict(rteeC
anoinurrmto [virtus SnSl o]Sior rm inaeothepsteea [ON CONFLICT] mmme
*noforaguaiSLFutmftMihe ibe-DSnevaeus] d.
 u
 whNotsoV)usseea [SLFORDEIGNORE] aCnstatC eyualsoous sea pastat-meiherrcoaweiror aeuenfo bbeea [t ]ultnetet_authorizer(rteoatcetheharc APat
 wh[SLFORDEABORT] eyualsooo [awyr Sbimme].
r*x#Syaets]SLFORDEROLLBACK 1ase #Syaets]SLFORDEIGNORE 2s//oAlsoous sebytttegi]dsauthorizer(reoatcethehr*x#Syaets]SLFORDEFAILSSSSS3xse #Syaets]SLFORDEABORT 4 s//oAlsooanuMAaiseimmegr*x#Syaets]SLFORDEREPLACEo 5xasesPh geDe changPrethe seSmftMihe iSoanltnaeus OpcmmeysPh KEYWORDS: {soansnaeus o
confs}
an
 whlQRofiLu
napGM|btstatCsromnl* eus seforaguaiTnthee^s</reuxim e
ano[t ]ultnettmt_soansnaeus(S,X,T,Vrte  savs] P.  EachraCnstatC meyignL] sra
bjhdiffNT-metmeerictfis s ]ultnettmt_soansnaeus()bnooaweiro.
 u
 whWetnnV)gn rh StaweiroeegnooVneyua emrrgu,espacoeeohhold V)ussemrrgueis
anomanarmdrbydV)a prethe setmftMihe iSharc wo nr*e automatocLlgitfreosewutn
anoSheyufumhnized.
 u
 whNotra nreae SstayebavailSl ote ica nrquMAy elsm-mes.hWetnnae aeueney
 whseqeavailSl o,reindo epune rriSl oe yutetsVoe-1[istnPtd aeueneyunumeric,
*nooTSuxoauxa iftissitha emrrguo(lr8],(MSCANSTAT_NAME).
 u
 wh<dlfibje[[SLFORDESCANSTAT_NLOOP]]h<dt>SLFORDESCANSTAT_NLOOP</dt>
 wh<dd>^Tup [t ]ultne  s64]e rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*e
 wheetsVoeeea totacrn rol bpsteimesoV)usseea X-tEnloopehrthrun.</ddfibjoh t[[SLFORDESCANSTAT_NVISIT]]h<dt>SLFORDESCANSTAT_NVISIT</dt>
 wh<dd>^Tup [t ]ultne  s64]e rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exset
 wheoeeea totacrn rol bpsta
ns]examets rbyda nrultrapesmsepsteea X-tEnloop.</ddfibjoh t[[SLFORDESCANSTAT_EST]]h<dt>SLFORDESCANSTAT_EST</dt>
 wh<dd>^Tup "doul o"e rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exseteuxim e
anoquMAy planrpr's]escomatitfiseV)ggrverarmrn rol bpsta
ns]o epunefo bbeach
anoiltrapesmepsteea X-tEnloop.hhIsfeindquMAy planrpr's]escomatitwasoar,s]ati,
 wheetnnV)iss rh Stwo nra  roxomatiteindquotihe iNVISIT/NLOOPgapd thTELje roduc)hpsteeiss rh Stfis a nr riiseloops] led eetoeoe eSELECTIDtwo n
*nobdbeeteNLOOPg rh Stfis eeaM|exn*hAnloop.</ddfibjoh t[[SLFORDESCANSTAT_NAME]]h<dt>SLFORDESCANSTAT_NAME</dt>
 wh<dd>^Tup "|bts treAP *"e rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exset
 wheoeaabavr-germets] dyUTF-8 emrrguoaCnn Ss-DSnlup noe epsteea GdSyx is eSl o
bjhus seforaguaiX-tEnloop.</ddfibjoh t[[SLFORDESCANSTAT_EXPLAIN]]h<dt>SLFORDESCANSTAT_EXPLAIN</dt>
 wh<dd>^Tup "|bts treAP *"e rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exset
 wheoeaabavr-germets] dyUTF-8 emrrguoaCnn Ss-DSnlup [EXPLAIN QUERY PLAN]
*noeescripeothee icguaiX-tEnloop.</ddfibjoh t[[SLFORDESCANSTAT_SELECTID]]h<dt>SLFORDESCANSTAT_SELECTID</dt>
 wh<dd>^Tup "itC"  rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exseteuxim e
anoiseforaguaiX-tEnquMAy plan elsm-me.hlQemide rh Shithu iqueb ledinaAPt
 whtmftMihe .hlQRoeelect-idiisomeRetoe e rh Stasl soo epuneiorlup fuoly
anoaClumnhistano[EXPLAIN QUERY PLAN]tquMAyr</ddfibjoh t[[SLFORDESCANSTAT_PARENTID]]h<dt>SLFORDESCANSTAT_PARENTID</dt>
 wh<dd>Tup "itC"  rriSl oetaetCNsenooey nPtdVnthee^s</rewo nr*exseteuxim e
anoiseospV)ggp]phe t stnPtd|exn*hAnquMAy elsm-me,eifhfhosisol o,ror
anoeoebavrnisfeindquMAy elsm-meehrthno]p]phe .hlQisl someRetoe e rh StasrrcoaweiroebjinaAPtdeeasu
naClumnhistano[EXPLAIN QUERY PLAN]tquMAyr</ddfibjoh t[[SLFORDESCANSTAT_NCYCLE]]h<dt>SLFORDESCANSTAT_NCYCLE</dt>
 wh<dd>Tup t ]ultne  s64et epune rh S iyutetsVoeeea n rol bpstaycles,ibjeaccordiDSeuxim entrorla
oragime-tmfmp coutCQr,heeaetelapsastwuileom e
anoquMAy elsm-meewathbe-DSntrorla
ed.hlQisl aeueneyuneqeavailSl oee i
 wha nrquMAy elsm-mes - iftissithunavailSl oeeindo epune rriSl oe y
 wheetsVoe-1.</ddfibjo</dlfib*x#Syaets]SLFORDESCANSTAT_NLOOPSSSS0x#Syaets]SLFORDESCANSTAT_NVISITyyy1x#Syaets]SLFORDESCANSTAT_ESTSSSSSS2x#Syaets]SLFORDESCANSTAT_NAMESSSSS3x#Syaets]SLFORDESCANSTAT_EXPLAINSS4x#Syaets]SLFORDESCANSTAT_SELECTIDt5x#Syaets]SLFORDESCANSTAT_PARENTID 6x#Syaets]SLFORDESCANSTAT_NCYCLESSS7xasesPh geDe changPrethe seSmftMihe iSoanltnaeussPh bjheyup;veselli_ttmt
bj
 whTQeci i savs] Ps aweirorl_urrmato mbabduo[V)a predic)iLefrctme"surice nrpavsrrmamce e icpStmt.hhAdvatcsd fhosiso*etCseasndusdbteis
 whidsavs] Psto immiayeb itdpredic)iLefrctteReme"suricrpavsrrmamce frce nrissueb ars-DSs arc/is awauor[ANALYZE] iftdiscrethnciSstayebfoutd.
 u
 whSincehtrislinsavs] Ps soexpecnesenooercrarulyuus s,aissithonly
 whavailSl oeiftShosiesiyuimmiilsdeo -DSnlup [SLFORDEENABLE_STMTESCANSTATUS]
anoaCmiils-timeto
conf.
 u
 whlQRo"iSoantnaeusOp"nthee^s</redegermetssb hichhsnaeus inurrmato mbuooaweiro.
 uhlQRo"iSoantnaeusOp"nrea
** etntdospV)gg[soansnaeus o
confs]i icgulYbehrvlum
anotfaguislinsavs] Ps soi Syaets .e^lQemawquMsneseme"surin-metithwrCNtefiin o
anoan rriSl oetaetCNsenooey nPtd"pOun"nthee^s</r.
 u
 whlQRo"flSgs" thee^s</rrrea
** ethmodeso maskbpstflSgs. At;presenthonly
 whtntdflSggis*Syaets o-]SLFORDESCANSTAT_COMPLEX. IstSLFORDESCANSTAT_COMPLEXe nrishseA_zsisd,heetnnenaeus inurrmato mbithavailSl ote ica nrelsm-mes
*nooSto quMAy plan eeathayebreoortedrbyd"EXPLAIN QUERY PLAN"do epun. Is
anoSLFORDESCANSTAT_COMPLEXgis*setoseA_zsisd,heetnnonlybquMAy plan elsm-mes
anoV)usscorrssponSenooquMAy loops](nPtd"SCAN..."oapd "SEARCH..."oelsm-mesbps
ano itdEXPLAIN QUERY PLANdo epun)tayebavailSl o. IMen-oguieDe
 whe ]ultnettmt_soansnaeus()b soequi ae-metrcosmcLapGe nre ]ultnettmt_soansnaeus_v2(re led aabavr seflSgsnthee^s</r.
 u
 whPhee^s</rr"idx"hids r,siNsomeReteA_zsicoquMAy elsm-meeuooawerievenenaeshilcs
*nofor. QuMAy elsm-mes are n rol  setmfrtl_erfo bbbavr. Atvaeuedpst-1irayrrcoawerievenenaeshilcstfiseV)ggenntrutquMAyrteIstidxl soo ebpstartrmrrco-htla
am aad-1 orrgssV)iram aad icequs Snoeeea totacrn rol bpstquMAy
 whelsm-mes us senooior rm inomeRetmftMihe i- aaseilbavrl aeueneyuaweiroeeenpd
ano itd rriSl oe iatstOunetaetCsrto  soi dirtrmd.
 u
 whSes]a so:o[t ]ultnettmt_soansnaeuser*yet(rt
r*xWris] objeretenttegi_hAttmt_soansnaeus(x rttegi_hAttmt *pStmt,rrrrrr/dePrethe setmftMihe iforiwhichhinuromeyirsdbb*x retenidx,prrrrrrrrrrrrrrrrr/whInSyx ifnloopeuooawoort  mbb*x reteniSoantnaeusOp,rrrrrrrr/whInurrmato mbmeyirsd.hhSLFORDESCANSTAT_*bb*x rIflsn*tOunerrrrrrrrrrrrrrr/whRwyr SbwrCNtefieereSb*x);xWris] objeretenttegi_hAttmt_soansnaeus_v2(x rttegi_hAttmt *pStmt,rrrrrr/dePrethe setmftMihe iforiwhichhinuromeyirsdbb*x retenidx,prrrrrrrrrrrrrrrrr/whInSyx ifnloopeuooawoort  mbb*x reteniSoantnaeusOp,rrrrrrrr/whInurrmato mbmeyirsd.hhSLFORDESCANSTAT_*bb*x retenflSgs,rrrrrrrrrrrrrrrr/deMaskbpstflSgshSyaets rbelowbb*x rIflsn*tOunerrrrrrrrrrrrrrr/whRwyr SbwrCNtefieereSb*x);xasesPh geDe changPrethe seSmftMihe iSoanltnaeussPh KEYWORDS: {soannenaeus flSgs}ib*x#Syaets]SLFORDESCANSTAT_COMPLEXg0x0001xasesPh geDe changZavrlSoan-tnaeus CoutCQrssPh bjheyup;veselli_ttmt
bj
 wh^Zavrla nr[t ]ultnettmt_soansnaeus()terels] dyav intcoutCQrs.
 u
 whlQisleDeiithonlyhavailSl oeift itdlibrary ithbuilto led pre-trorla
ore nreymbol [SLFORDEENABLE_STMTESCANSTATUS] Syaets .
 *xWris] objerIflsns ]ultnettmt_soansnaeuser*yet(s ]ultnettmt*);xasesPh geDe changFlushhoachnstnoodisk mid-VransaeferesPh bjheyup;veselli
bj
 wh^Istf;wrCNs-Vransaefereiithoptnnonh[ed forci aCnrpefereA DawutnnV)g
ano[t ]ultnedb_oachnflush(D)ts  savs] Psis inen-me,bapy dirty
 wh agsTeinaAPth agsr-oachn eeathayebset dexn*hAabsindusdbayebwrCNtefiduoianoVoodisk. Atdirtyh ags mayoercindusdbifof;ed forci aur
oralssV)iLebydan
anoa_gangiSLFutmftMihe ieyuawadl_erfo bbit,hiseiftissith ags 1ooSto ed forci
*nofilQS( ags 1oisealwaysn"indusd"). heTutd[t ]ultnedb_oachnflush(D)t
 whidsavs] PsflushsTeaachnste ica nrechemath- "main", "oiap",hnpd
anoapy [attachTc]oed forcisr
ruobjh^IsttQislf d confinlmdsSeohobn Sseex ra ed forci thwkshbee ietdirtyh agsyrityasndbPsflushsdoVoodisk,aissnceabso.e^IfeV)oci thwkshasnset beIobn Ssee
 whimmedld. lyefrctteRr)tithnh*usy-hanSlQr aatcethehlLnfiguriL,aissith Men-me
 whidaAPthusuel manrpr.e^IfeV)ggre
*irsdrthck tmo nrasnset beIobn Ssee,heetn
ano itded forci ishskippiLefrctonnattiapr mameeto alushhapy dirtyh agsyritybeloDSiDSeuxim ehsSxt (ifofny)ded forci.heIstapy nd forcisbarsutkippiLritybeccicsbthwkshasnset beIobn Ssee,nbuo[no torrleeAaise]r,s]
,bteis
 whf d confiuAts i plr8],(MBUSYr
ruobjh^Istapy otEds]eAaise]r,s]
e uileoalushiDSedirtyh agsytnoodisk (e i
 whexamplQeanAIO]eAaise]riduo-of-memory |btdypesm),heetnntrorla
rgu it
anoabapdonedefrctonnShosies[MAaiseimme]githaweiroeeiuxim eniartmriimmedld. ly.
ruobjh^Otrrlwisa,tifhsedMAaise]r,s]
,b[t ]ultnedb_oachnflush()]iuAts i plr8],(MOK.
ruobjh^Tuislf d confinceabcnqesetoV)a dd forci hanSlQSMAaiseimmegOr]messhrmrrcoaweiroeegbyt itd[ttegi]dsMAaimmeir]enpdiittegi]dsMAamsgir]lf d confT.
r*xWris] objeretenttegi_hAdb_oachnflush(ttegi_h*);xasesPh geDe changTitdpre-upds] thook.sPh bjheyup;veselli
bj
 wh^TQeci i savs] Ps ayebenabsavailSl oeiftShosiesiyuimmiilsdeo -DSnlup
 wh[SLFORDEENABLE_PREUPDATE_HOOK]oaCmiils-timeto
conf.
 u
 wheTutd[t ]ultnepreupds] _hooki)ts  savs] Psregist- s a aatcethehf d conf
anoV)ussis inen-men riisercoeachr[INSERT],r[UPDATE],baChe[DELETE] o
yra(oth
 whtnof;ed forci eSl o.objh^AC mmsootntdpreupds] thook mayoercregist- edoattf;timehtnof;saohec
 wh[ed forci aCnrpefereA;oeachraatcrrco[t ]ultnepreupds] _hooki)tsoverrides
 wheetetoavluus set)tne.s] heTutdpreupds] thook is*SisSl odrbydiMen-ogui[t ]ultnepreupds] _hooki)ts] h led aaauxa taetCNTsasaV)a eeasu
nthee^s</r.
 uheTutdtsir
nthee^s</rreCo[t ]ultnepreupds] _hooki)ts srthmodesthroughtasrrcolup fuolynthee^s</rreCoaatcethes.
 u
 wheTutdpreupds] thook enabsfuonste icdirtrmsSeohawel ed forci eSl os; thTELje reupds] thook is*setoi"en-menf icdirtrmsSeoh[virtus SnSl os]i icgoe nreyst-mSnSl osglikEtt ]ult_s*
* ncehis s ]ult_tmft1.
ruobjh^Tutdteasu
nthee^s</reuxim entreupds] taatcethehi pastaetCNTSuxrrcolup [ed forci aCnrpefereA V)ussregist- edotutdpreupds] thook.
 uheTutdtsir
nthee^s</rreCom entreupds] taatcethehi ptntdospV)gg|btstatCs
 wh[SLFORDEINSERT],r[SLFORDEDELETE],hise[SLFORDEUPDATE]rto  ds r,sy VPTELjekinS psuupds] to
yra(othrV)ussis abduo[Voe]r,s].
 uhe(lQRofiurtEnthee^s</rreCom entreupds] taatcethehi plup noe epsteea
*noed forci  ledinameRhed forci aCnrpefererV)ussis be-DSnmodzsied.hhlQiss] h l nr*ex"main"tfiseV)ggmainhed forci is "oiap"tfiseTEMPSnSl osg i
ano itdnoe egangndfftrle itdAS keywordh naV)a [ATTACH]etmftMihe iforiattachTc
*noed forcis.ets] heTutdfiftEnthee^s</rreCom entreupds] taatcethehi plup noe epsteea
*notSl oe iatsis be-DSnmodzsied.
ruobjhFiseapAUPDATE or DELETEto
yra(othrtnof;[rowidenSl o],heet;saxtE
anothee^s</rrthmodestoom entreupds] taatcethehi plup etit-s S[rowid]epsteea
*noa
nibe-DSnmodzsiedborenele] d.hFiseapAINSERT  
yra(othrtnof;rowidenSl o,
*nooTSapy o
yra(othrtnof;WIheyUT ROWIDenSl o,tnPtd aeuenpsteea taxtE
anothee^s</rr soi Syaets .eFiseapAINSERT  icUPDATE onof;rowidenSl oaAPt
 whtav inhothee^s</rr solup fumhn;rowidevaeuedpsteea r
nibe-DSninserNdeibjedr]ipds] T.eyup; aeuenpsteea tav inhothee^s</rrthmodestoom enaatcethe
 whf d confiis*setoSyaets rforio
yra(othstDnnWIheyUT ROWIDenSl os,hisee i
 whDELETEto
yra(othstDnnrowidenSl os.
 u
 wheTutdt ]ultnepreupds] _hookiD,C,P)hf d confiuAts i pm enPeforen-metfo b
 wheetetoavluus aatcronaV)a eoe e[ed forci aCnrpefereA D,hiseauxa e i
ano itdfuolynaatcronaD.
 u
 whlQRo[t ]ultnepreupds] _old()],h[t ]ultnepreupds] _new()],
ano[t ]ultnepreupds] _coutC()],hnpdiittegi]dspreupds] _depthi)ts  savs] PsELje roviSs addypesmaleinurrmato mbabduo[antreupds] tav in.hTQeci at ethnsELjemayoonlyberclsllsdefo bb ledinam treupds] taatcetheulhInen-oguiapy oS
ano itci at ethnstfn bbtutsiSs pstantreupds] taatcethehoriwled a
 wh[ed forci aCnrpefereA taetCNTSurattithdiffNT-metfo bbeea tntdsehosisdianoVo*m entreupds] taatcethehr*yr ST indu Syaets oapd trolSl y u SysirSl o
bjhbehrvlum.
 u
 wheTutd[t ]ultnepreupds] _coutC(D)ts  savs] Psrets i pm enn rol bpstatlumns
 whinteea r
ni iatsis be-DSninserNde,]ipds] T,borenele] d.
 u
 wheTutd[t ]ultnepreupds] _old(D,N,P)ts  savs] PswrCNss in otPpastaetCNTSuxrrcoab[trotectobsttegi]dsvaeueteeeathodan SsstnPtd aeuenpsteea NtE |blumnhis
ano itdnSl oar
nibee ietissithupds] T.ehlQRoN thee^s</rrrea
** eertweenh0
anoapd tntdtla
am aadm enn rol bpstatlumnsi icgulYbehrvlumewo nr*e
 whi Syaets .essislmustxonlybercus se ledinaSLFORDEUPDATEoapd SLFORDEDELETEELje reupds] taatcethes; iftissithusiLebydan SLFORDEINSERTtaatcethehtutnnV)g
anobehrvlume soi Syaets .ehlQRo[t ]ultnevaeueteeeathPetaetCsrtos] h l nr*exSystroy sewutnnV)ggtreupds] taatcethehr*ts i .
 u
 wheTutd[t ]ultnepreupds] _new(D,N,P)ts  savs] PswrCNss in otPpastaetCNTSuxrrcoab[trotectobsttegi]dsvaeueteeeathodan SsstnPtd aeuenpsteea NtE |blumnhis
ano itdnSl oar
nifftrleissithupds] T.ehlQRoN thee^s</rrrea
** eertweenh0
anoapd tntdtla
am aadm enn rol bpstatlumnsi icgulYbehrvlumewo nr*e
 whi Syaets .essislmustxonlybercus se ledinaSLFORDEINSERTtapd SLFORDEUPDATE
ane reupds] taatcethes; iftissithusiLebydan SLFORDEDELETEtaatcethehtutnnV)g
anobehrvlume soi Syaets .ehlQRo[t ]ultnevaeueteeeathPetaetCsrtos] h l nr*exSystroy sewutnnV)ggtreupds] taatcethehr*ts i .
 u
 wheTutd[t ]ultnepreupds] _depthiD)ts  savs] Psrets i p0eift itdpreupds] rityastcethehwathi"en-mena pasawyr Sbpstaedire<t inserN,]ipds] ,borenele] ibjed
yra(oth;bore1rforiinserNs,]ipds] s,borenele] thi"en-menbyt op-lehel
ano riggl s;bore2nf icdirtrmsSawyr Sl_erfo bbAriggl s lsllsdebyt op-lehel
ano riggl s;banS sonf ith.
 u
 whWetnnV)gn[t ]ultneblob_wrCNsi)tseDeiithus senooupds] ta blobtatlumn,
 wheetepre-upds] thooksis inen-menwled SLFORDEDELETE,ybeccics
ano itdnewreae SstayebsetoyetbavailSl o. IMttQislcrci,rwutnnarityastcethehmameewled op==SLFORDEDELETEtis achuLlgitf;wrCNseo -DSnlup
 wht ]ultneblob_wrCNsi)seDe,nV)gn[t ]ultnepreupds] _blobwrCNsi)tsuAts i 
anotea GdSyx isteea cblumnhbe-DSnwrCNtef.hInaotEds]cacis,hweRr)tthTELje re-upds] thooksis be-DSninen-menf icsomp torrlereasth,tincludl_erarrcoawgulAP DELETE,yt ]ultnepreupds] _blobwrCNsi)srets i p-1.
 u
 whSes]a so:on[t ]ultneupds] _hooki)ts]/
#iftdyaets (SLFORDEENABLE_PREUPDATE_HOOK)xWris] objerIflsn*t ]ultnepreupds] _hookix rttegi_h *db,x rIfls(*xPreUpds] )ix r rIflsn*tCtx,prrrrrrrrrrrrrrrrrr/whCLpytpsteeir
nforieC  oeupds] _hooki)bb*x r rttegi_h *db,rrrrrrrrrrrrrrrrrr/whDd forci hanSlQSb*x r retC op,prrrrrrrrrrrrrrrrrrrrrr/whSLFORDEUPDATE,hDELETEtorAINSERT b*x r rreAP |bts t*zDb,rrrrrrrrrrrrrr/whDd forci noe eb*x r rreAP |bts t*zNoe ,rrrrrrrrrrrr/whTSl oonoe eb*x r rt ]ultne  s64eiKey1,rrrrrrrrrr/whRowidepsta
n abduo[Voe*exSyle] d/upds] Teb*x r rt ]ultne  s64eiKey2rrrrrrrrrrr/whNewrrowidevaeued(fis aarowideUPDATE)bb*x r),x rIfls*x);xWris] objeretenttegi_hApreupds] _old(ttegi_h *,rete, ttegi]dsvaeued**);xWris] objeretenttegi_hApreupds] _coutC(ttegi_h *);xWris] objeretenttegi_hApreupds] _depthittegi_h *);xWris] objeretenttegi_hApreupds] _new(ttegi_h *,rete, ttegi]dsvaeued**);xWris] objeretenttegi_hApreupds] _blobwrCNsittegi_h *);x#endifxasesPh geDe changLow-lehelreyst-mSMAaiseimmesPh bjheyup;veselli
bj
 wh^Attiapr nooaweirorAPthundQrlyrgugp
yra(ogugsyst-mSMAaiseimmed iceAais
 whn rol beeathoaus sen)ggmoa
*awcene I/O]eAaise]rifailur)tto optnnaofilQ.
 whlQemaweiror aeueneyuOS-dependhe .hhFiseexamplQ,hDnnunixgsyst-ms,bafeu*
 wh[t ]ultneoptn_v2(r]iuAts i p[SLFORDECANTOPEN],iprislinsavs] Psc*enenberityastc senoogetbethehtuthundQrlyrgug"eAano"beeathoaus sen)ggtrollem,esech
anoa pENOSPC, EAUTH, EISDIR,banS sonf ith.
 *xWris] objeretenttegi_hAtyst-m_eAano(ttegi_h*);xasesPh geDe changDd forci Snapshnq
rdoKEYWORDS: {snapshnq} {stegi_hAtnapshnq}
bj
 whAfiinstatcenpsteea tnapshnqdpbje<t recordsomeRetmftMeoSto [WAL mmme]
*noed forci f icsomp teA_zsico aetC inaristory.
ruobjhIna[WAL mmme],nreltiplQe[ed forci aCnrpeferesteeeatharehoptnnonhlup
 whtoe eed forci fi oeoanleachrercreadl_erahdiffNT-metristorocLl vl soth
 whtfameRhed forci filQ. hWetnnae[ed forci aCnrpefereA begin pasawadianoVransaefere,eeeathodarpefererseoshanoi dirtrrguoaCpytpsteea ed forci
*noathiSoexistobsforrn)ggtaetC inatimehwutnnV)ggtransaefereifuolyntmfrteer
rueSubs*
* ntcdirtrmsSeohmeRhed forci fn bbttEds]|btrpeferestayebsetoseoh
 whbyt itdawader]itCr"iadnewrawad Vransaefereiithtmfrteer
ru
 whlQemstegi_hAtnapshnqdpbje<t recordsotmftMeinurrmato mbabduo[antristorocLl
 whvl sothhtfameRhed forci filQ soneeatii
* srtossil oSeohlV)iraoptnnaonewrawadianoVransaefereneeatiseoshV)usshistorocLl vl sothhtfameRhed forci ra(hmram aa
anotea moa
*awcene vl soth.
 *xtypedyaostruc)mstegi_hAtnapshnqd{x runyignas eeAP hiddhe[48];
}mstegi_hAtnapshnq;xasesPh geDe changRecord AgDd forci Snapshnq
rdoCONSTRUCTOR:mstegi_hAtnapshnq
 u
 wheTutd[t ]ultnetnapshnq_get(D,S,P)ts  savs] Psa oiaprs to maktrarrconewr[t ]ultnetnapshnqtepbje<t V)ussrecordsomeRe|exn*hAntmftMeoS
 whtchemaoShenhed forci aCnrpefererD. heOfitu rla
,teee
 wh[t ]ultnetnapshnq_get(D,S,P)ts  savs] PswrCNss a taetCNTSuxo itdnewly
 whlssV)iLe[t ]ultnetnapshnqtepbje<t in ot*Praptlhets i plr8],(MOK.
ruhIsteeeretithsetra awadypasawad-VransaefereioptnnonhtchemaoShwetn
ano iislf d confiis lsllsd, tntdithoptnmenautomatocLlgi.
an
 whIstf;awad-Vransaefereiithoptnmenbyt iislf d conf,heetnnitSiabguarantesdianoV)usseea aweiroeegtnapshnqdpbje<t reissetobaiineaeidV)iLebyda ed forci
*nowrCNsrror ihecktaetCNTSitCr"iaftrle itdawad-Vransaefereiithclo
ed.hlQis
 whithsetrguarantesdbifof;awad-Vransaefereiitha awadypoptnnwetnnV)is
 whf d confiis*asllsd.hImburattorci,rapy subs*
* ntcwrCNseor ihecktaetCibjed
yra(othronaV)a ed forci reisineaeidV)iseea aweiroeegtnapshnqdhanSlQ,
 whengndwuileom e;awad-Vransaefereihemainssoptn.
 u
 whlQemfiLu
napGMrea
** elr Stfis eeislf d confitohsu rlsd.hIfiapy oS
ano itmfiLu
napGMtmftMihe seayebfatcinwetnnt ]ultnetnapshnq_get()eis
anoisllsd, SLFORDEERRORgithaweiroee.hlQemfunale rh Sttfa*Pieyui Syaets 
 whinteeislcrci.
 u
 wh<ul>
 wh  <li>hlQemdd forci hanSlQSmea
*setoercind[autoimmmitSmmme].
r*
 wh  <li>hSchemaoShtfa[ed forci aCnrpefereA Damea
*beuaa[WAL mmme]ded forci.
r*
 wh  <li>hTeeretmea
*setoercf;wrCNseVransaefereioptnnonhtchemaoShtfaed forci
*nooooooooaCnrpefererD.
r*
 wh  <li>hOnetOr]mM toVransaefereslmustxhrveobeenhwrCNtefitoom enaexn*hAnwLl
 whhhhhhhhfilQ sincehieewathlssV)iLenfinisk (bydanyoaCnrpefere).essislme"ns
anooooooooeeathagtnapshnqdasnset beItakthrtnof;wel mmmeeed forci  ledhsedwLl
 whhhhhhhhfilQ immedld. lyefftrleissithfuoly optnme. At;leasootntdVransaeferesPh        mea
*beuwrCNtefitooissfuolys
rue</ulfibj
 whTuislf d confireisalsooheep adSLFORDENOMEM.hhIsfissithastc se led eet
*noed forci hanSlQSinamutoimmmitSmmmenbuo[failsnf icsomp torrlereasth,
*nowhetrrlb]rssetrarawad VransaefereiithoptnmenonhtchemaoSh soi Syaets .
 u
 whlQRo[t ]ultnetnapshnqtepbje<t aweiroeegfn bba su rla
fu"iaatcrrc
 wh[t ]ultnetnapshnq_get()tsmea
*beufreoseo -DSn[t ]ultnetnapshnq_freoi)ts] heoeaIflsnnomemory leak.
 u
 whlQRo[t ]ultnetnapshnq_get()ts  savs] Psis enabsavailSl oewutnnV)g
ano[SLFORDEENABLE_SNAPSHOT]oaCmiils-timeto
confiithus s.
 *xWris] objeretenttegi_hAtnapshnq_get(x rttegi_h *db,x r|bts treAP *zSchema,x rttegi_hAtnapshnqd**ppSnapshnq
);xasesPh geDe changSmfrtrarawad Vransaefereion[antristorocLl tnapshnq
 u bjheyup;veselli_tnapshnq
 u
 wheTutd[t ]ultnetnapshnq_optn(D,S,P)ts  savs] PseiorrlbtmfrtsnaonewrawadianoVransaeferendr]ipgradessandMxshil_ghtntdf icschemaoShtf
 wh[ed forci aCnrpefereA DesechbV)usseea awad VransaefereirefNTsrtos] hristorocLl [tnapshnqteP, ra(hmram aaotea moa
*awcene dirtrmeuxim e
anoed forci.heTutd[t ]ultnetnapshnq_optn()ts  savs] Psrets i plr8],(MOKibjedfitu rla
  icanAa  roprld. s[MAaiseimme]gisfissfailsr
ruobjh^In ordQrhtohsu rlsd,ameRhed forci aCnrpeferermea
*setoercin
 wh[autoimmmitSmmme]ewutnn[t ]ultnetnapshnq_optn(D,S,P)ts s*asllsd.hIsteeere
 whitha awadypasawadeVransaefereioptnnonhtchemaoS,heetnnV)gged forci hanSlQ
 whmustxhrveonooa_gangitmftMihe se(SELECTitmftMihe seV)usshrveobeenhthmodes] heoes ]ultnettep()ebuo[noenttegi_hAr*yet(rhis s ]ult3_fumhnize()rr
rueSLFORDEERRORgithaweiroeegisfeiorrlb]ft itci |btdypesmseisl iols] T,bor
 whifcschemaoShnceabcnqeMxshi,hiseifteea tnapshnqdpbje<t is ineaeid.
ruobjheA;aatcrrcot ]ultnetnapshnq_optn()h l nrfailtto optnnifteea teA_zsisd
 whtnapshnqdhasobeenhoverwrCNtefibyda [ihecktaetC]. IMttQislcrci
rueSLFORDEERROR_SNAPSHOTgithaweiroee.
an
 whIsteeeretitha awadypasawadeVransaefereioptnnwetnnV)ishf d confiis
 whinen-me,beetnnV)ggtoe eawad Vransaefereiremainssoptn (onaV)a eoe 
*noed forci tnapshnq)eiftShoORDEERROR,plr8],(MBUSYhiseSLFORDEERROR_SNAPSHOT
 whithaweiroee.hIfiapotEds]eAaiseimmed- e icexamplQeSLFORDEPROTOCOL  ican
rueSLFORDEIOERR]eAaiseimmed- ithaweiroee,beetnnV)ggfunaletmftMeoSteea
*noawad Vransaefereiithi Syaets .eIstSLFORDEOKhithaweiroee,beetnnV)g
*noawad Vransaefereiithnowioptnnonhed forci tnapshnq P.
ruobjh^(Ancatcrrco[t ]ultnetnapshnq_optn(D,S,P)ts l nrfailtisteea
*noed forci aCnrpefererDhnceabcnqeknowbV)usseea ed forci filQ e i
anotchemaoSh soina[WAL mmme].hhAhed forci aCnrpeferermrla
*cnqeknowianoV)usseea ed forci filQ  soina[WAL mmme]tisteearedhasobeenhno]prlum
anoI/O]reneeatied forci aCnrpefere,hiseifteea ed forci ent- edo[WAL mmme]
*noaftrle itdmoa
*awcene I/O]onaV)a ed forci aCnrpefere.ets] h(HetC: Run "[PRAGMA fhosiso*etC_id]" ag Sssttf;newlyhoptnme
*noed forci aCnrpefererin ordQrhtohmaktritoawadypeodusd tnapshnqs.)
 u
 whlQRo[t ]ultnetnapshnq_optn()ts  savs] Psis enabsavailSl oewutnnV)g
ano[SLFORDEENABLE_SNAPSHOT]oaCmiils-timeto
confiithus s.
 *xWris] objeretenttegi_hAtnapshnq_optn(x rttegi_h *db,x r|bts treAP *zSchema,x rttegi_hAtnapshnqd*pSnapshnq
);xasesPh geDe changDystroyhagtnapshnqsPh DESTRUCTOR:mstegi_hAtnapshnq
 u
 wheTutd[t ]ultnetnapshnq_freoiP)ts  savs] PsSystroyso[t ]ultnetnapshnqteP.
 whlQemfhosiso*etChmustxav inuLlgitfreoxav ryo[t ]ultnetnapshnqtepbje<t
 who -DSnluissao ethn eoeaIflsnnomemory leak.
 u
 whlQRo[t ]ultnetnapshnq_freoi)ts  savs] Psis enabsavailSl oewutnnV)g
ano[SLFORDEENABLE_SNAPSHOT]oaCmiils-timeto
confiithus s.
 *xWris] objerIflsns ]ultnetnapshnq_freois ]ultnetnapshnq*);xasesPh geDe changCmmiayeb itdagsytoStewogtnapshnqdhanSlQs.sPh bjheyup;veselliAtnapshnq
 u
 whlQemstegi_hAtnapshnq_cmp(P1, P2re  savs] PSeyuus senoocmmiayeb itdagsy
 whtfamwoseaeidetnapshnqdhanSlQs.sPh
 whIsteeetewogtnapshnqdhanSlQstayebsetohmoociV)iLe led eetoeoe eed forci
*nofilQ,seea awyr Sbpsteea cbmiarisre  soi Syaets .
 u
 whAddypesmally,seea awyr Sbpsteea cbmiarisre  soenabseaeideifobotE osteeaianotnapshnqdhanSlQstwur)tobn SseeibydamcLapGMt ]ultnetnapshnq_get()esincehtraianotsdt timeteea wel filQ wathnele] d.hTea wel filQ ithnele] dewutnnV)g
anoed forci ishdirtrmdbethehtoohotcethehmmmed icwutnnV)ggn rol bpsted forci
*noclihe sedrops]eoebavr.eIsteiorrlbtnapshnqdhanSlQ wathobn Sseeibee ietV)g
anowel filQ wathtsdt nele] d,tnPtd aeuenaweiroeegbyt iishf d conf
 whithi Syaets .
 u
 whOtrrlwisa,ttQisleDeirets i pf;negsgangs aeuenef P1irefNTsrtouah oldQre nrtnapshnqdm aaoP2,ebavrnisfeindewoghanSlQstrefNTitoom eneoe eed forci
*notnapshnq,banS a pocegang  aeuenef P1iisnaonewrlbtnapshnqdm aaoP2.
 u
 whlQisl  savs] Psis enabsavailSl oeiftShosiesiyuimmiilsde led eet
*no[SLFORDEENABLE_SNAPSHOT]oo
conf.
 *xWris] objeretenttegi_hAtnapshnq_cmp(x rttegi_hAtnapshnqd*p1,x rttegi_hAtnapshnqd*p2
);xasesPh geDe changRecovrlbtnapshnqs fn bbaowel filQsPh bjheyup;veselliAtnapshnq
 u
 whISto [WAL filQ]iremainssofinisk aftrleatcred forci aCnrpefereshclo
es] h(eiorrlbthroughttuthusdbpsteea [SLFORDEFCNTL_PERSIST_WAL] [fi oeoontrol]
*noorybeccicsbeea tsdt  oorla
nVoshrveoV)a ed forci optnmenMxs)iLe ledduoianoamcLapGM[t ]ultneclo
ei)t)banS a newraCnrpefereris subs*
* ntlyhoptnme
*noreneeatied forci npdiiWAL filQ],nV)gn[t ]ultnetnapshnq_optn()ts  savs] P
anowitcronlybercSl oeeohoptnneea tsdt Vransaefereiadddestoom enWAL filQ
 whengndeddughttuthWAL filQhodan Sssttorrle aeid Vransaeferes.
 u
 whlQislf d confia oiaprs to scaaotea WAL filQhhmoociV)iLe led ed forci zDb
 whtfaed forci hanSlQSdbefrctmaktra nreaeidetnapshnqthavailSl otgoe nre ]ultnetnapshnq_optn().eIC iscanAeAaiseisteeeretitha awadypasawadianoVransaeferendptnnonhlupaed forci,hiseifteea ed forci ithsetra WAL mmme
anoed forci.
 u
 whSLFORDEOKhithaweiroeehifcsu rla
fu",  icanAShosiesMAaiseimmed trrlwisa.
 u
 whlQisl  savs] Psis enabsavailSl oeiftShosiesiyuimmiilsde led eet
*no[SLFORDEENABLE_SNAPSHOT]oo
conf.
 *xWris] objeretenttegi_hAtnapshnq_recovrl(ttegi_h *db,r|bts treAP *zDb);xasesPh geDe changSerihnizeda ed forci
*n
 whlQemstegi_hAterihnize(D,S,P,Freinsavs] Psrets i pf;taetCNTSuxrrcomemory V)ussis a terihnizapesmepsteea S ed forci on
 wh[ed forci aCnrpefereA D.hhIsfSsis a auxa taetCNT,nV)gnmainhed forci ithus s.
 whIStP ithsetra auxa taetCNT,nV)gnaV)a eizedtfameRhed forci ifiby] s
 whithwrCNtefiin o *P.
ruobjhFiseapAordiDary on-nisk ed forci filQ,heet;serihnizapesmeithjustxarityaCpytpsteea eisk filQ. hFiseapAin-memory ed forci is a "TEMP"aed forci,
ano itmserihnizapesmeithm eneoe es*
* ncehifiby] siwhichhw*enenbe wrCNtefs] heoeeisk ifteeatied forci wur)tetheoseopoVoodisk.
*n
 whlQemusuel crci itheeatistegi_hAterihnize()oaCpisTo itmserihnizapesmeoS
ano itmed forci iftohmemory obn Sseeifn bb[t ]ultnemalthw64ir]enpdiuAts i 
anoa taetCNTSuxo iaetmemory.ehlQRoiartmriisSawypbtsil ote icfreo-DSnlup
 whaweiroeeh aeueneoeaIflsnnomemory leak.  Howeher,risteea Feforen-merityaCan SsstnPtdSLFORDESERIALIZDENOCOPY biC,neetnnnohmemory althws]eres
anoaretmade,efrctteRestegi_hAterihnize()of d confito nruAeirora taetCNTs] heoeeea cbntiguuus memory representapesmepsteea ed forci eiaetShosie
 whithdexn*hAabso -DSnfis eeatied forci,hiseauxa ifhsedsechbcbntiguuusrrcomemory representapesmepsteea ed forci Mxshis.hhAhcbntiguuus memory
 whawpresentapesmepsteea ed forci to nrusuLlgihonlybMxshitisteearedhas
 whbeenhan riisecatcrrco[t ]ultneSyserihnize(D,S,...)ts led eetoeoe 
 wheae SstDf Dtapd S.
 whlQemeizedtfameRhed forci ithwrCNtefiin o *Phengndisteea
*noSLFORDESERIALIZDENOCOPY biC iyutetsbuo[no cbntiguuus aCpy
 whtfamea ed forci Mxshis.
 u
 whAftrle itdcatc,risteea SLFORDESERIALIZDENOCOPY biC hadobeenhtet,
 wheeteaweiroeegbuffNT]|btt-hAnwo nruAmainhacrla
il otapd i dirtrmd
 whotCr"ieiorrlbthehsSxt wrCNseo
yra(othronaV)a aCnrpeferer icwutn
 wheeteaCnrpefereris clo
ed,banS ahosiso*etCsemea
*setomodzsy VPTELjebuffNT.hIsteee biC hadobeenhclear,heeteaweiroeegbuffNT]wo nrcnq
rdoercScrla
edrbytShosiesaftrle itdcatc.
 u
 whA;aatcrrcot ]ultneterihnize(D,S,P,Fremrla
*uAeirorauxa engndisteea
*noSLFORDESERIALIZDENOCOPY biC iyuomCNteegfn bbaoren-metFbifof;memory
 whalthws]eredMAaise]r,s]
.
 u
 whlQisl  savs] Psis emCNteegiftShosiesiyuimmiilsde led eet
*no[SLFORDEOMIT_DESERIALIZD]oo
conf.
 *xWris] objerunyignas eeAP *t ]ultneterihnize(
 rttegi_h *db,rrrrrrrrrrr/*hlQemdd forci aCnrpefererb*x r|bts treAP *zSchema,rrr/*hWhichhDB to serihnize. Mx: "main", "oiap",h...rb*x rt ]ultne  s64e*piSize,r/*hWrCNseeizedtfameRhDB eare,tifhsetrauxa b*x runyignas etenmFlSgshrrr/*hZavrlOr]mM toSLFORDESERIALIZDE*tflSgshb*x);xasesPh geDe changFlSgshfis s ]ultneterihnize
 u
 whZavrlOr]mM totfameRhfiLu
napGM|btstatCsromnl* eOR-destogetrrlbe i
ano itdFeforen-metrco[t ]ultneterihnize(D,S,P,Fr].
 u
 whSLFORDESERIALIZDENOCOPY me"ns eeati[t ]ultneterihnize()ts l nruAeiro
anoa taetCNTSuxocbntiguuus in-memory ed forci eeatii
* srdexn*hAabso -DS,
*nowledduotmakl_erahaCpytpsteea ed forci.hhIsfShosiesiyuset dexn*hAabso -DS
anoa cbntiguuus in-memory ed forci,heetnnV)isso
conficcicss
 wh[t ]ultneterihnize()tsnooaweirora auxa taetCNT. fShosieswitcronlyber
 who -DSna cbntiguuus in-memory ed forcigisfisshasobeenhetit-s izedibyda
 wh riisecatcrrco[t ]ultneSyserihnize()].
r*x#Syaets]SLFORDESERIALIZDENOCOPY 0x001rrr/whDonnohmemory althws]ereshb*xasesPh geDe changDyserihnizeda ed forci
*n
 whlQemstegi_hASyserihnize(D,S,P,N,M,Freinsavs] Psccicss eet
*no[ed forci aCnrpefereA DeVoodisaCnrpefgfn bbed forci SefrctteRn
 whawdptnnSna papAin-memory ed forci orcidbonaV)a eerihnizapesmrityaCan SsebjinaP.hhIsfSsis a auxa taetCNT,nV)gnmainhed forci it
 who  d.hTea serihnizedhed forci P ithNiby] siinhsize.  Meithm eneize
 utpsteea buffNT]P,iwhichhmrla
*bt lformram aaoN.hhIsfMeithlformram aa
 utN,efrctteReSLFORDEDESERIALIZDEREADONLY biC iyucnqesetoinhF,heetn
anoShosiesiyupermetCNsenooadd]|btt-hAneoeeea in-memory ed forci as
 whloDSsasaV)a totacreizednceabcnqeMxrlsdfMeby] s.sPh
 whIsteeetSLFORDEDESERIALIZDEFREEONCLOSE biC iyutetsinhF,heetnfShosieswitc
 whinen-m s ]ult3_freoi)bonaV)a eerihnizapesmgbuffNT]wetnnV)gged forcirityaCarpefererclo
es.hhIsfeindSLFORDEDESERIALIZDERESIZDABLE biC iyutet,heetn
anoShosieswitcrtrypeodinlssVcsbeea buffNT]eizedo -DSnttegi_hAr*althw64ir
 whifcwrCNss onaV)a ed forci acicsbiAneoega
n lformram aaoMeby] s.sPh
 whAhosiso*etCsemea
*setomodzsy VPT buffNT]PhiseineaeidV)isitibee ie
ano itmed forci aCnrpefererDhithclo
ed.
*n
 whlQemstegi_hASyserihnize(reinsavs] Ps l nrfailtwled SLFORDEBUSYhisteea
*noed forci  srdexn*hAabsinpasawadeVransaefereiorsis inenlvebjinaatetheup
 utp
yra(oth.sPh
 whIC iyucnqetossil oSeohSyserihnizeiin o  itmTEMPSed forci.hhIsfeea
*noSeforen-metrcostegi_hASyserihnize(D,S,P,N,M,Freis "oiap"teetnnV)g
*nof d confiuAts i plr8],(MERROR.
*n
 whlQemSyserihnizedhed forci sh*enensetoercind[WAL mmme].hhIsteea ed forci
*no soinaWAL mmme,heetnfanyoattiapr nooicsbeea ed forci filQ  l nruAyr S
 whintano[SLFORDECANTOPEN]dMAais.ehlQRofhosiso*etChoanneetoV)a
*no[filQ e imae vl sothgn rol s] (byNss 18efrct19)epsteea Gdpuneed forci Ps] heoe0x01n riisercoiMen-oguistegi_hASyserihnize(D,S,P,N,M,Fretonf icehtraianoed forci filQ  ntoohotcethehmmmedarc workefooutdnV)isslimeta(oth.sPh
 whIfistegi_hASyserihnize(D,S,P,N,M,Frefailsnf icanyoreasthdarc isteea
*noSLFORDEDESERIALIZDEFREEONCLOSE biC iyutetsinhaoren-metF,heetn
ano[s ]ult3_freoi)]sis inen-menonhaoren-metPn riisercouAts iigu.
 u
 whlQisl  savs] Psis emCNteegiftShosiesiyuimmiilsde led eet
*no[SLFORDEOMIT_DESERIALIZD]oo
conf.
 *xWris] objeretenttegi_hAdeterihnize(
 rttegi_h *db,rrrrrrrrrrrr/*hlQemdd forci aCnrpefererb*x r|bts treAP *zSchema,rrrr/*hWhichhDB to awdptnn led eetodeterihnizafererb*x runyignas eeAP *pDd f,rrr/*hlQemserihnizedhed forci |btt-hAnb*x rt ]ultne  s64eszDb,rrrrr/whN rol bpstby] siinheetodeterihnizafererb*x rt ]ultne  s64eszBuf,rrrr/*hTotacreizedpstbuffNT]pDd f[]rb*x runyignas mFlSgshrrr hrrr/*hZavrlOr]mM toSLFORDEDESERIALIZDE*tflSgshb*x);xasesPh geDe changFlSgshfis s ]ultneSyserihnize(r
*n
 whlQemfiLu
napGMayebaLu
neeh aeuestfiseV)gg6ed aoren-met( itdFeforen-me)Suxrrcolup [stegi_hASyserihnize(D,S,P,N,M,Frte  savs] P.
*n
 whlQemSLFORDEDESERIALIZDEFREEONCLOSE me"ns eeatieea ed forci eerihnizapesmrityinheetoPeforen-metiyuhelbjinamemory obn Sseeifn bb[t ]ultnemalthw64ir]
anoarc APattShosiessh*enentakt ownl shipotfaguislmemory anenautomatocLlgi
*nofreoxieewetnnitShasoaetishsdoo -DSni .hhWledduot iishflSg,e itdcatcNTs] hisSawypbtsil ote icfreo-DSnapy nynamocLlgitalthws] dtmemory.
*n
 whlQemSLFORDEDESERIALIZDERESIZDABLE flSggme"ns eeatiShosiesiyuaLu
neehuxrrcogr
ni iemeizedtfameRhed forci o -DSncLlgsrrco[t ]ultner*althw64ir].hhlQiss] hflSggsh*enenonlybercus seiftShoORDEDESERIALIZDEFREEONCLOSE iyualsoous s.
 whWledduot iishflSg,e itdSyserihnizedhed forci asnset inlssVcsbinhsizeberyopd
ano itdn rol bpstby] siteA_zsisdhbyt itdMnthee^s</r.
 u
 whlQRoSLFORDEDESERIALIZDEREADONLY flSggme"ns eeati itdSyserihnizedhed forcie nreh*enenbe tssV)iLeayuawad-only.
r*x#Syaets]SLFORDEDESERIALIZDEFREEONCLOSE 1r/whCa nre ]ult3_freoi)bonaclo
egr*x#Syaets]SLFORDEDESERIALIZDERESIZDABLE  2s/whRwyizedo -DSnttegi_hAr*althw64irgr*x#Syaets]SLFORDEDESERIALIZDEREADONLY    4r/whDd forci iyuawad-onlyhb*xasesPh geDe changBinS arrayh aeuest o  itmCARRAYdnSl o- aeuedhf d conf
 w
 whlQemstegi_hAcarray_binS(S,I,P,N,F,Xreinsavs] PsbinSssandarrayh aeuehuxrrcotntdospV)ggfuoly foren-metpsteea [carray()bnSl o- aeuedhf d conf].hhlQa
*noSethee^s</rr soa taetCNTSuxo itd[prethe setmftMihe teeeathicss eet carray()
*nof d confs.hhIeithm enthee^s</rr dSyx Voe*exboutd.  P itha taetCNTSuxo it
anoarrayhVoe*exboutd,efrctNhi plup n rol bpsteMihe seinheetoarray.hhlQa
*noFeforen-metiyutntdosp|btstatCsr[SLFORDECARRAY_INT32],r[SLFORDECARRAY_INT64],
ano[SLFORDECARRAY_DOUBLE],r[SLFORDECARRAY_TEXT],hise[SLFORDECARRAY_BLOBteeC
anoindiso*sbeea ed ftypetpsteea arrayhbe-DSnboutd.  lQemXeforen-metiyusetra
 utNuxa taetCNT,nV)gnaShosieswitcrinen-m V)ggf d confiX onaV)a Pnthee^s</r
anoaftrleisshasoaetishsdoo -DSnP, engndisteeaiaatcrrc
 whstegi_hAcarray_binS(refails.hTea seA_zal-crci fimhnizer
*noSLFORDETRANSIENTehrthno]effNct eare.
 *xWris] objeretenttegi_hAcarray_binS(x rttegi_hAttmt *pStmt,rrrrrrrr/whSmftMihe iVoe*exboutdbb*x reteni,prrrrrrrrrrrrrrrrrrrrr/whPhee^s</rr dSyx b*x rIflsn*aDd f,rrrrrrrrrrrrrrrr/whPaetCNTSuxoarrayhed fbb*x retennDd f,rrrrrrrrrrrrrrrrrr/whN rol bpsted fbelsm-mes b*x retenmFlSgs,rrrrrrrrrrrrrrrrr/whCARRAYdflSgshb*x rIflsn(*xDel)(Ifls*)rrrrrrrrr/whDystructisee i aDd fhb*x);xasesPh geDe changDd ftypestfiseV)ggCARRAYdnSl o- aeuedhf d conf
 w
 whlQemfiftEnforen-metrcolup [stegi_hAcarray_binS(rts  savs] Psmea
sber
 whtntdospV)ggfiLu
napGM|btstatCs,trcoseA_zsybeea ed ftypetpsteea array
ano iatsis be-DSnboutdbin o  itm[carraybnSl o- aeuedhf d conf].
r*x#Syaets]SLFORDECARRAY_INT32rrrrr0rrrr/whDd fhis 32-biC yignas eteegl s r*x#Syaets]SLFORDECARRAY_INT64eeeee1rrrr/whDd fhis 64-biC yignas eteegl s r*x#Syaets]SLFORDECARRAY_DOUBLErrrr2rrrr/whDd fhis doul os r*x#Syaets]SLFORDECARRAY_TEXTrrrrrr3rrrr/whDd fhis eeAP* r*x#Syaets]SLFORDECARRAY_BLOBrrrrrr4rrrr/whDd fhis struc)miovechb*xasesPh Vl sothsepsteea above #Syaetss eeatiemCNteea Gdit-s SSLFORDE,be i
anolegacy cbmiatibiegiy.
r*x#Syaets]CARRAY_INT32rrrrr0rrrr/whDd fhis 32-biC yignas eteegl s r*x#Syaets]CARRAY_INT64eeeee1rrrr/whDd fhis 64-biC yignas eteegl s r*x#Syaets]CARRAY_DOUBLErrrr2rrrr/whDd fhis doul os r*x#Syaets]CARRAY_TEXTrrrrrr3rrrr/whDd fhis eeAP* r*x#Syaets]CARRAY_BLOBrrrrrr4rrrr/whDd fhis struc)miovechb*xasesPh Undo  itmhthehtuathodaverNsdfloa(ogugtaetC typestrcoiMeegl be i
anobuilds onatrorla
orsowledduotfloa(ogugtaetC sehoort.s]/
#ifdyaoSLFORDEOMIT_FLOATING_POINT
#hi Sya doul ox#endifxa#iftdyaets (__wasi__)
#hi Sya SLFORDEWASI
#hSyaets]SLFORDEWASIy1x#disndyaoSLFORDEOMIT_LOAD_EXTENSIONx#dhSyaets]SLFORDEOMIT_LOAD_EXTENSIONx#dendifx#disndyaoSLFORDETHREADSAFEx#dhSyaets]SLFORDETHREADSAFES0x#dendifx#endifxa#ifdyao__cplusplus
}rr/whEnseospV)gg'exsavn "C"' bloheh]/
#endifx/wh#endiftfiseSLFORD3_Hh l nr*exadddesbytmkstegi_h.tclhb*xaseeeeeeee BeginhfilQ stegi_hrtsse.h eeeeeeeeb*xsesPh 2010 Augea
*30
 w
 whlQemauthorenisclaims aCpyrrla
* o  iis sour Psc*di.hhIn placMeoS
 whaoleganrcnqice, eRr)tithnh*lla
rgu:
r*
 wh   Maybyou do goo oapd cnqeMvic.
 uh   Maybyou finS fisgangnla
nfiseyourselfoapd fisgangd trrls.
 uh   Maybyou shayebfssely,sneherntak-DSnmoietV)andyou gang.
 u
 wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwws]/
a#ifndyao_SLFORD3RTREE_H_x#Syaets]_SLFORD3RTREE_H_xxa#ifdyao__cplusplus
exsavn "C" {x#endifxatypedyaostruc)mstegi_hArtsse_geo^s<rymstegi_hArtsse_geo^s<ry;atypedyaostruc)mstegi_hArtsse_quMAy_inurostegi_hArtsse_quMAy_inur;xasehlQemdoul o-precisothged ftypetusiLebydRTreoxdepends onaV)a
*noSLFORDERTREE_INT_ONLY aCmiils-timeto
conf.
 /
#ifdyaoSLFORDERTREE_INT_ONLYx rtypedyaos ]ultne  s64estegi_hArtsse_dbl;x#elcie rtypedyaodoul oestegi_hArtsse_dbl;x#endifxasesPh Regist- hnhgeo^s<rymastcethehnoe d zGe bbeeattornbercus seasntheSbpstamrityR-Treoxgeo^s<rymquMAy asoaiLu
ns:
r*
 wh  SELECTi...rFROM <rtsse> WHERE <rtsse cbl> MATCH $zGe b(...rthee^si...)
 *xWris] objeretenttegi_hArtsse_geo^s<ry_astcethe(x rttegi_h *db,x r|bts treAP *zGe b,x reten(*xGe b)(ttegi_hArtsse_geo^s<ry*,rete, ttegi]dsrtsse_dbl*,ete*),x rIflsn*tCbtt-xq
);xaasesPh A taetCNTSuxoaostruc)u totfameRhfiLu
napGMtypetisrthmodesasolup fuoly
anoarren-metrcoaatcethessregist- edoo -DSnrtsse_geo^s<ry_astcethe().
 /
struc)mstegi_hArtsse_geo^s<rym{x rIflsn*tCbtt-xq;rrrrrrrrrrrrrrrrr/whCCpytpsttCbtt-xqrthmodestoos_r_g_ci)bb*x retennPhee^;rrrrrrrrrrrrrrrrrrrrr/whSizedtfaarraybaPhee^[]rb*x rttegi]dsrtsse_dbln*aPhee^;rrrrrr/whPhee^s</rsrthmodestooSLFugeo^gf d confib*x rIflsn*tUser;rrrrrrrrrrrrrrrrrrrr/whCa nethehior rm inafererus rhed fbb*x rIflsn(*xDelUser)(Ifls *);rrrrrrr/whCa nedrbytShosiesrcoaleanoip tUserbb*x};xasesPh Regist- hnh2nd-ggnlra(othrgeo^s<rymastcethehnoe d zScoietV)attornber
 who  deasntheSbpstamyR-Treoxgeo^s<rymquMAy asoaiLu
ns:
r*
 wh  SELECTi...rFROM <rtsse> WHERE <rtsse cbl> MATCH $zQuMAyF d (...rthee^si...)
 *xWris] objeretenttegi_hArtsse_quMAy_astcethe(x rttegi_h *db,x r|bts treAP *zQuMAyF d ,x reten(*xQuMAyF d )(ttegi_hArtsse_quMAy_inur*),x rIflsn*tCbtt-xq,x rIflsn(*xDestructis)(Ifls*)
);xaasesPh A taetCNTSuxoaostruc)u totfameRhfiLu
napGMtypetisrthmodesasolup
anoarren-metrcoscoiedrgeo^s<rymastcethehregist- edoo -DS
 whstegi_hArtsse_quMAy_astcethe().
 u
 whNote eeati itdfuoly 5dfuelds ofaguislstruc)u toayeb ds r,cacrrc
 whstegi_hArtsse_geo^s<ry.hhlQislstruc)u tois a tubclassbps
anostegi_hArtsse_geo^s<ry.
 /
struc)mstegi_hArtsse_quMAy_inuro{x rIflsn*tCbtt-xq;rrrrrrrrrrrrrrrrrrr/whtCbtt-xqrfo bb )gnaf d confiuAgist- edob*x retennPhee^;rrrrrrrrrrrrrrrrrrrrrrr/whN rol bpstf d confiphee^s</rsrb*x rttegi]dsrtsse_dbln*aPhee^;rrrrrrrr/wh rh Sttfaf d confiphee^s</rsrb*x rIflsn*tUser;rrrrrrrrrrrrrrrrrrrrrr/whaatcethehlanoicsbeeis,tifhmeyirsdbb*x rIflsn(*xDelUser)(Ifls*);rrrrrrrrrr/whf d confitohfreoxtUserbb*x rttegi]dsrtsse_dbln*aCoord;rrrrrrrr/whCoordinatSstDf nmmed icentrypeodiheck b*x runyignas eten*anQuMue;rrrrrrrrrrrr/whN rol bpstpendapGMentri siinheetoquMueob*x retennCoord;rrrrrrrrrrrrrrrrrrrrrrr/whN rol bpstcoordinatSstb*x reteniLehel;rrrrrrrrrrrrrrrrrrrrrrr/whLehelbpstcexn*hAnnmmed icentrypb*x retenmxLehel;rrrrrrrrrrrrrrrrrrrrrrsehlQemlformseniLehel  aeuenennV)ggtreerb*x rt ]ultne  s64eiRowid;rrrrrrrrrrrrrsehRowidef icdexn*hAnentrypb*x rttegi]dsrtsse_dblnrPheentScoie;rrrsehScoietpstpan*hAnnmmedb*x retenePheentWledin;rrrrrrrrrrrrrrrrsehVisobiegiytpstpan*hAnnmmedb*x reteneWledin;rrrrrrrrrrrrrrrrrrrrrrsehOUT:hVisobiegiytb*x rttegi]dsrtsse_dblnrScoie;rrrrrrrrrsehOUT:hWrCNse iemecoieteereSb*xrrsehlQemfiLu
napGMfuelds ayebenabsavailSl oein 3.8.11oapd lV)irab*x rttegi]dsvaeued**apSqlPhee^;rrrrrrrsehOrrlunaleSLFueae SstDf phee^s</rsrb*x};xasesPh ALu
neeh aeuestfisestegi_hArtsse_quMAy.eWledinoapd .ePheentWledin.
r*x#Syaets]NOT_WIheINrrrrrrr0rrrsehObje<t aCmile] gihoutsiSs pstquMAy uAginfib*x#Syaets]PARTLY_WIheINrrrr1rrrsehObje<t theSiLlgihoherlapstquMAy uAginfib*x#Syaets]FULLY_WIheINrrrrr2rrrsehObje<t fulgihaCan Ssebj ledinaquMAy uAginfib*xxa#ifdyao__cplusplus
}rr/whenseospV)gg'exsavn "C"' bloheh]/
#endifx
#endifrr/whifndyao_SLFORD3RTREE_H_hb*xaseeeeeeee Enseospstegi_hrtsse.h eeeeeeeeb*xseeeeeeee BeginhfilQ stegi_hsla
rnf.h eeeeeeeeb*xa#ift!dyaets (__SLFORDSESSION_H_) &&tdyaets (SLFORDEENABLE_SESSION)x#Syaets]__SLFORDSESSION_H_ 1xasesPh Makt su towoeoanlaatcrrQislstuffrfo bbC++.
 /
#ifdyao__cplusplus
exsavn "C" {x#endifxaasesPh geDe changSea
rnfhObje<t HanSlQ
 wsPh Afiinstatcenpsteeiyutbje<t is a [sla
rnf]beeattornbercus serc
 whrecordcdirtrmsSeoha ed forci.
 *xtypedyaostruc)mstegi_hAtea
rnfhstegi_hAtea
rnf;xasesPh geDe changCirtrmset Itlra(iseHanSlQ
 wsPh Afiinstatcenpsteeiyutbje<t acqthas a aur
oraforiityra(ogusPh ovrlbV)ggelsm-mes oSto [cirtrmset]i ic[patchset].
 *xtypedyaostruc)mstegi_hAcirtrmset_ityrmstegi_hAcirtrmset_ityr;xasesPh geDe changCssV)i A NewrSea
rnfhObje<tsPh gONSTRUCTOR:mstegi_hAtea
rnf
 wsPh CssV)i a newrtea
rnfhtbje<t attachTcSeohSd forci hanSlQSdb.hIstsu rla
fu",
anoa taetCNTSuxothehsSwutbje<t is wrCNtefitoo*ppSea
rnfhapd SLFORDEOKhit
 whreeiroee.hIfiapdMAaise]r,s]
,b*ppSea
rnfhiyutetstooNuxa frctonnShosie
 whMAaiseimmed(e.g.dSLFORDENOMEM)githaweiroee.
an
 whI
* srtossil oSeohlssV)inreltiplQetea
rnfhtbje<ts attachTcSeohf;saohec
 whSd forci hanSlQ.
 u
 whSea
rnfhtbje<ts lssV)iLeo -DSnluissf d confieh*enenbe nele] deo -DSnlup
 wh[stegi_hsla
rnf_nele] ir]lf d confibee ietV)ghSd forci hanSlQSeeati ity
 whare attachTcSeohisl tselfoclo
ed.hIsteea ed forci hanSlQSithclo
edibee ie
ano itmtea
rnfhtbje<t ithnele] d,nV)gnaV)a r*yr ST pstcmcLapGMapy sea
rnf
 whmmmulelf d conf,hincludl_er[stegi_hsla
rnf_nele] ir]lonaV)a eea
rnfhtbje<t
 whare i Syaets .
 u
 whBeccicsbeea eea
rnfhmmmulelicss eet [t ]ultnepreupds] _hooki)tseDe,niS
 whiyucnqetossil oSf icanAa  siso*etChto awgist- hnh re-upds] thooksonnaritySd forci hanSlQSeeatihrthonetOr]mM totea
rnfhtbje<ts attachTc.hNoriis
 whitrtossil oSeohlssV)inartea
rnfhtbje<t attachTcSeohaySd forci hanSlQSe i
anowhichhnh re-upds] thooksitha awadypSyaets .essa r*yr ST pstattiaprogusPh eiorrlb]ft itci edingshare i Syaets .
 u
 whTitmtea
rnfhtbje<t  l nr*exus senoocssV)incirtrmsetstfiseVSl osgin
 whed forci zDb,hweRr)tzDbsitheiorrlb"main", is "oiap",i icgulYnoe epstamrityattachTcSed forci.hIC iyucnqeanAeAaiseisted forci zDb iyucnqeattachTc
*noeohmeRhed forci wetnnV)ggtea
rnfhtbje<t ithlssV)iL.
 *xWris] objeretenttegi_hsla
rnf_lssV)i(
 rttegi_h *db,rrrrrrrrrrrrrrrrrrrrsehDd forci hanSlQSb*x r|bts treAP *zDb,rrrrrrrrrrrrrrrr/whNoe epstdbd(e.g.d"main")ab*x rttegi]dstea
rnfh**ppSea
rnfhrrrrsehOUT:hNewrtea
rnfhtbje<t b*x);xasesPh geDe changDele]  A Sea
rnfhObje<tsPh DESTRUCTOR:mstegi_hAtea
rnf
 wsPh Dele]  artea
rnfhtbje<t toavluusgitalthws] dto -DS
 wh[stegi_hsla
rnf_lssV)i(r].hOtcenartea
rnfhtbje<t hasobeenhnele] d,nV)g
 whreyr ST pstattiaprogu nooicsbpSea
rnfhwled apy oorrlbeea
rnfhmmmule
*nof d confiare i Syaets .
 u
 whSea
rnfhtbje<ts mea
*beunele] debee ietV)ghSd forci hanSlQSeoowhichh ity
 whare attachTcSithclo
ed. RefNTitoom endocum inaferere i
ano[stegi_hsla
rnf_lssV)i(r]tfisedetailsr
r*xWris] objerIflsns ]ultnsla
rnf_nele] ittegi]dstea
rnfh*pSea
rnf);xasesPh geDe changCmnfigu toa Sea
rnfhObje<tsPh bjheyup;veselliAtea
rnf
 wsPh ssislmethodSeyuus senoocmnfigu toa tea
rnfhtbje<t aftrleisshasobeoh
 whlssV)iL. At;presentom enenabseaeide aeuestfiseV)ggteasu
nthee^s</reart
*no[SLFORDESESSION_OBJgONFIG_SIZD]onpdiiSLFORDESESSION_OBJgONFIG_ROWID].
 u
 *xWris] objeretenttegi_hsla
rnf_tbje<t_cmnfigittegi]dstea
rnf*,rete op,pIflsn*tArg);xasesPh geDe changOp*etCsefisestegi_hsla
rnf_tbje<t_cmnfig
*n
 whlQemfiLu
napGM aeuestreisthmodesasolup lup 2u
nthee^s</reux
anostegi_hsla
rnf_tbje<t_cmnfigi).
 u
 wh<dt>SLFORDESESSION_OBJgONFIG_SIZDh<dd>
 wh  T)isso
confieyuus senootet,hcleari icquMAy  itdflSggeeatienSl os
 wh  eet [t ]ultnsla
rnf_lirtrmset_size()tseDe.hBeccicsbiC impo
escsomp
 wh  aCmiunafereal ovrlhwad,ttQisleDeiithnisSl odrbytSyaar S. Aoren-merity  tArg mea
*taetC tohay aeuenpsteypet(etC).hIsteea  aeueneyuGdit-s gi
*no  0,nV)gnaV)a e ]ultnsla
rnf_lirtrmset_size()leDeiithnisSl od.hIsfis
*no  ithgssV)iram aao0,nV)gnaV)a eoe eeDeiithenSl od.hOr,risteea Gdit-s 
*no   aeueneyutla
am aadbavr,[no cirtrmeislmado. IMtatcrcacisteea (etC)
*no   ariSl oeiyutetstoo1nifteea t ]ultnsla
rnf_lirtrmset_size()leDeiit
*no  enSl odhfiLu
napGMthenaexn*hAncatc,r ic0d trrlwisa.
 u
 wh eIC iscanAeAaise(SLFORDEMISUSEretonattiapr noomodzsy VPiyutetrogu afeu*
 wh i itdfuoly nSl oahasobeenhattachTcSeohV)ggtea
rnfhtbje<t.
 u
 wh<dt>SLFORDESESSION_OBJgONFIG_ROWIDe<dd>
 wh  T)isso
confieyuus senootet,hcleari icquMAy  itdflSggeeatienSl os
 wh  ciLupeferer sted fbfiseVSl osg ledhsedex sisiC PRIMARYoKEY.
 u
 wh eN imally,seSl osg ledhsedex sisiC PRIMARYoKEYhare sior y ignoied
 wh ebyt itdtea
rnfshmmmule. Howeher,risteeishflSg iyutet,hitibehrves
 wh  athifesechbVSl osghrveoa cblumnh"_rowid_ INTEGER PRIMARYoKEY" inserNdeibje sasolupirutlftmoa
*atlumns.
 u
 wh eIC iscanAeAaise(SLFORDEMISUSEretonattiapr noomodzsy VPiyutetrogu afeu*
 wh i itdfuoly nSl oahasobeenhattachTcSeohV)ggtea
rnfhtbje<t.
 *x#Syaets]SLFORDESESSION_OBJgONFIG_SIZDhy1x#Syaets]SLFORDESESSION_OBJgONFIG_ROWIDe2xasesPh geDe changEnSl ohOr DisSl o A Sea
rnfhObje<tsPh bjheyup;veselliAtea
rnf
 wsPh EnSl ohorenisSl otgsa r*cording pstcirtrmsSbyda tea
rnfhtbje<t.hWetnsPh enSl od,oa tea
rnfhtbje<t recordsocirtrmsSmameeeohmeRhed forci.hWetnsPh nisSl odr-hitinceabcnq. A;newlyhlssV)iLetea
rnfhtbje<t ithenSl od.
Ph RefNTitoom endocum inaferere i [t ]ultnsla
rnf_lirtrmset(r]tfisefurtrrlsPh netails awgarding howhenSl apGMapd nisSl -DSna tea
rnfhtbje<t affNct 
anotea av inuLlncirtrmsets.
 u
 whPaa
rguebavrn o  iis f d confinisSl oshV)ggtea
rnf.hPaa
rgueay aeue
 whgssV)iram aaobavrnenSl osni .hPaa
rgueay aeueutla
am aadbavr isca
 whno-op,pfrctmayr*exus senooquMAy  itd|exn*hAntmftMeoShV)ggtea
rnf.
*n
 whlQemaweiror aeuenendiso*ssolup funaletmftMeoSteea tea
rnfhtbje<t:p0eif
ano itmtea
rnfhithnisSl od,bore1riftissithenSl od.
P*xWris] objeretenttegi_hsla
rnf_enSl oittegi]dstea
rnfh*pSea
rnf,rete bEnSl o);xasesPh geDe changSethOr Cleari itmIndire<t CirtrmgFlSgsPh bjheyup;veselliAtea
rnf
 wsPh EachrcirtrmerecordiLebyda tea
rnfhtbje<t ithmar-mena peiorrlbdire<t or
 whindire<t. A;cirtrmeislmar-mena pindire<tgisfeiorrl:
r*
 wh<ul>
 wh  <li>hlQemtea
rnfhtbje<t "indire<t"hflSg iyutet wetnnV)ggcirtrmeis
 wh       made,eor
 wh  <li>hlQemcirtrmeislmadoebydan SLFo riggl  oraforeign key aeferesPh        instwade steire<tlyna pasawyr Sbpstaeus r plr8etmftMihe s
rue</ulfibj
 whISto saohecta
n iscaffNctdesbytmoietV)andonetO
yra(othr ledinaa tea
rnf,
 wheetnnV)ggcirtrmeisr|btsid- edoindire<tgisfatcrO
yra(othslmeetoV)ahlsityria
 whfiseapAindire<tgcirtrmeabove,borenire<t otrrlwisa.
 u
 whT)ishf d confiisuus senootet,hcleari icquMAy  itdtea
rnfhtbje<t indire<t
 whflSg.hhIsteea teasu
narren-metthmodestoo iislf d confiis bavr,[tetnnV)g
*noindire<tgflSg iyuclearod.hIsfis ithgssV)iram aaobavr,[tetoindire<tgflSg
 whiyutet.hPaa
rgueay aeueutla
am aadbavr nceabcnqemodzsy VPT |exn*hAn aeue
 whpsteea Gddire<tgflSg,pfrctmayr*exus senooquMAy  itd|exn*hAntmftMeoShV)g
*noindire<tgflSg fiseV)ggteA_zsisdhtea
rnfhtbje<t.
 u
 whlQemaweiror aeuenendiso*ssolup funaletmftMeoSteea indire<tgflSg:p0eif
anoi
* srdlear,hore1riftissithtet.
P*xWris] objeretenttegi_hsla
rnf_indire<tittegi]dstea
rnfh*pSea
rnf,rete bIndire<t);xasesPh geDe changAttach A;TSl ooTo A Sea
rnfhObje<tsPh bjheyup;veselliAtea
rnf
 wsPh IStorren-metzTSl iyucnqeNuxa,heetnnitSiabgulYnoe epsta nSl oatonattach
anoeohV)ggtea
rnfhtbje<trthmodesasolup fuolytorren-me. ALu subs*
* ntccirtrms
 whmameeeohmeRhtSl oewuileom e;tea
rnfhtbje<t ithenSl od  l nr*exrecordiL.hSessPh nocum inaferere i [t ]ultnsla
rnf_lirtrmset(r]tfisefurtrrledetailsr
ru
 whOr,ristorren-metzTSl iyuNuxa,heetnncirtrmsSare recordiLefiseatcrrSl os
 whinaV)a ed forci.hIfiaddypesmalbVSl osgare adddestoom enSd forci (bi
*noexecurogu "CREATE TABLE"itmftMihe s)saftrle iis*aslleislmado,ncirtrmsSe i
ano itdsSwuVSl osgare alsoohecordiL.
ru
 whCirtrmstornbonlybercrecordiLefisetSl oshV)usshrveoa PRIMARYoKEYhex sisiCgi
*noSyaets easntheSbpstlupiruCREATE TABLEetmftMihe seIC nceabcnqemattir isteea
*noPRIMARYoKEYhiscanA"INTEGER PRIMARYoKEY" (rowidealias)b]rsset.essa PRIMARY
*noKEYhmayr|btsisSbpstaesaohectatlumn,horemayr*exa aCmiocege key.sPh
 whIC iyucnqeanAeAaiseisteeehnoe d tSl oenceabcnqeMxshihinaV)a ed forci.hNoTs] hisSiqeanAeAaiseisteeehnoe d tSl oenceabcnqehrveoa PRIMARYoKEY. Howeher,
 whnoncirtrmsS l nr*exrecordiLhinaeiorrlb]ft itci scenSrios.
ru
 whCirtrmstayebsetorecordiLefiseindividuLlnrowshV)usshrveoNuxa  aeueststors 
 whintonetOr]mM topstlupiruPRIMARYoKEYhatlumns.
 u
 whSLFORDEOKhithaweiroeehifcteaiaatcraCmile] sowledduotMAais.eOr,ristonceAais
 wh]r,s]
,banAShosiesMAaiseimmed(e.g.dSLFORDENOMEM)githaweiroee.
an
 wh<h3>SeA_zal;vesell_tmft1eHanSlaoh</h3>
an
 whAT pstShosiesvl sothg3.22.0,nV)g "vesell_tmft1" tSl oeiscanAexcep*etChto
anosomMeoSteea ru osgabove. IMtShosie,heet;schemaoospstegi__tmft1eis:
r*  <pre>
 wh &nbsp;rrrrrCREATE TABLEettegi__tmft1(tbl,idx,tmft)
*no </pre>
 wsPh Engndeddughtstegi__tmft1enceabcnqehrveoa PRIMARYoKEY,ncirtrmsSare
 whrecordiLefiseit athifetsa PRIMARYoKEYhisc(tbl,idx).hAddypesmally,scirtrms
 whare recordiLefiserowshf icwuichh(idx ISoNuxa)githlr S. Howeher,rfisesech
anorowshadbavr-length blobe(SLFr aeuenX'')his sto edoinnV)ggcirtrmtet is
 whpatchset instwade staoNuxa  aeue.essislaLu
nsdsechbcirtrmsetstVoe*e
 whmanipulV)iLebydlegacy ior rm inafereseospstegi_hcirtrmset_iaverN(),
 wh|btso*()banS similar.
 u
 whlQRostegi_hcirtrmset_a  sy()of d confiautomatocLlgihodaverNsdeea
*nobavr-length blobeethehtooaoNuxa  aeue wetnnupds]apGMthenstegi__tmft1
ano Sl o. Howeher,risteeRofhosiso*etChoalgsrstegi_hcirtrmset_sSw(),
 whstegi_hcirtrmset_old(rhis s ]ult3cirtrmset_cmnfsistrtnof;cirtrmset
anoi
lra(iseeire<tlyn(includl_ertnof;cirtrmsetoi
lra(isethmodestooarityaCnfsist-hanSlQrhaatcethe)heetnnV)ggX''  aeueneyuaweiroee.hlQemfhosiso*etC
 whmudt VranslV)igX'' tooNuxa  tselfoistr*
*irsd.
 u
 whLegacy (oldQram aad3.22.0)svl sothseoSteea tea
rnfshmmmule asnset cap)u trityairtrmsSmameeeohmeRhstegi__tmft1e Sl o. Legacy vl sothseoSteea
 whstegi_hcirtrmset_a  sy()of d confisilehAabsignoie apy modzsiso*etCseuxo it
anostegi__tmft1e Sl ohV)ussare theSbpstagcirtrmtet ishpatchset.
P*xWris] objeretenttegi_hsla
rnf_attach(x rttegi]dstea
rnfh*pSea
rnf,rhrrrrsehSea
rnfhtbje<tSb*x r|bts treAP *zTSl rrrrrrrrrrrrrrr/whTSl oonoe eb*x);xasesPh geDe changSetha nSl oafilNsrronoa Sea
rnfhObje<t.sPh bjheyup;veselliAtea
rnf
 wsPh ssa teasu
narren-met(xFilNsr)SiabgulY"filNsrraatcethe".hFisedirtrmsSeohrows
 whinaVSl oshV)ussayebsetohttachTcSeohV)ggSea
rnfhtbje<t,olup ful</rr soasllsd
anoeohds</rmets]whetrrlbdirtrmsSeohmeRhtSl o'sorowsheh*enenbe tstheose]rsset.sPh IStxFilNsriuAts i p0,ncirtrmsSarebsetotstheos.hNote eeatiotcenartSl oeis
ityattachTc,txFilNsriwo nrcnqnbe astc seag Ssr
r*xWris] objerIflsns ]ultnsla
rnf_tSl o_ful</r(x rttegi]dstea
rnfh*pSea
rnf,rhrrrrsehSea
rnfhtbje<tSb*x rete(*xFilNsr)(x r rIflsn*tCtx,rrrrrrrrrrrrrrrrrrr/whCCpytpst iir
narrSeoh_ful</r_tSl oi)bb*x r r|bts treAP *zTSl rrrrrrrrrrrrr/whTSl oonoe eb*x  ),x rIflsn*tCtxrrrrrrrrrrrrrrrrrrrrrr/whFuoly foren-metthmodestooxFilNsrib*x);xasesPh geDe changGgnlra(o A Cirtrmset Fo bbA Sea
rnfhObje<tsPh bjheyup;veselliAtea
rnf
 wsPh Obn Sstagcirtrmtet aCan SsapGM|irtrmsSeohmeRhtSl osohttachTcSeohV)g
anosea
rnfhtbje<trthmodesasolup fuolytorren-me. Istsu rla
fu",
anotet *ppCirtrmset eohtaetC tohaybuffNT]|btt SsapGMV)ggcirtrmtet
ityatdbbpnCirtrmset eohmeRhsizedtfameRhcirtrmsetoifiby] sebee ietuAts iigu
 whSLFORDEOK.hIfiapdMAaise]r,s]
,btetsbotE *ppCirtrmset atdbbpnCirtrmset eo
*nobavrenpdiuAts ibanAShosiesMAaiseimme.
 u
 whA;airtrmtet aCasisSseoStzavrlOr]mM toINSERT, UPDATE npd/Or]DELETE airtrmt,
anoeach awpresent-DSna cirtrmeuxio saohecta
n pstamyhttachTcSeSl o. AnoINSERTrityairtrmyaCan SsstnPtdeae SstDf each fueldbpstagsSwuSd forci a
n. A;DELETErityaCnn SsstnPtdorrlunaleeae SstDf each fueldbpstagnele] deSd forci a
n. AC
 whUPDATE airtrmyaCan SsstnPtdorrlunaleeae SstDf each fueldbpstannupds]me
*noed forci a
n aloDSs led eetoupds]mee aeuestfiseeach upds]meenon-primary-kty
 whatlumn.hIC iyucnqetossil oSfiseapAUPDATE airtrmyto awpresentoa cirtrmeueat
 whmodzsiestnPtdeae SstDf primary key atlumns. Istsu hoa cirtrmeislmado,niS
 whiyuawpresentebjinaatairtrmtet a pasDELETE fiLu
niLebydanoINSERT.
ru
 whCirtrmstayebsetorecordiLefiserowshV)usshrveoNuxa  aeueststors hintonetOr
 whmo topstlupiruPRIMARYoKEYhatlumns. Istsu hoa a
n iscinserNdeborenele] d,
 whnoncorawypbtdapGM|irtrm* srtresentoinnV)ggcirtrmtetthaweiroeehbyt iis
 whf d conf.hIfiapdMxshil_gha
n  led onetOr]mM toNuxa  aeueststors hin
*noPRIMARYoKEYhatlumnsiisuupds]meesxo iaetatcrPRIMARYoKEYhatlumnsiayebsen-Nuxa,
 wh]nabsanoINSERTeiscappearsoinnV)ggcirtrmtet.dSimilarly,sifiapdMxshil_gha
n
 wh ledhsen-NuxarPRIMARYoKEYh aeuestisuupds]meesxo iaetonetOr]mM topstit 
anoPRIMARYoKEYhatlumnsiayebtetstooNuxa,seea awyr SapGM|irtrmset aCan Sssca
 whDELETE airtrm only.
rwsPh ssa |btt-hAsbpstagcirtrmtet mayr*extstvl s deo -DSnapAi
lra(iselssV)iLsPh o -DSnlup [t ]ultnlirtrmset_smfrt()tseDe.hAgcirtrmtet mayr*exfhosi serc
 whaySd forci wled a cbmiatiblt;schemaoo -DSnlup [t ]ultnlirtrmset_a  sy()]
anoeDe.
rwsPh Wledinoagcirtrmtet ggnlra(eegbyt iishf d conf,tatcrcirtrmstrelV)iLetooaritysaohecttSl oeayebgroupdestogetrrl. IMtoorrlbwords,ewetnnityra(ogu through
 whaycirtrmtet ishwetnna  sy-DSna cirtrmtetstooaySd forci,tatcrcirtrmstrelV)iL
anoeohaysaohecttSl oeayebtrorla
 debee ietmovl_ertnouxothehsSxtSeSl o. TSl os
 whayebtortedoinnV)ggeoe eordQrhinowhichh ity wur)thttachTcS(iseauto-httachTc)
anoeohV)ggttegi]dstea
rnfhtbje<t.hTh eordQrhinowhichh itrcirtrmstrelV)iLeto
 whaysaohecttSl oeayebstors hithi Syaets .
 u
 whFiLu
napGMatsu rla
fu"ecatcrrco iishf d conf,titSiabgulYawypbtsiliegiytps
ano itdiartmrircoav inuLlgitfreox itdbuffNT] iaet*ppCirtrmset taetCs nooic-DS
 wh[stegi_h_freoi)].
an
 wh<h3>Cirtrmset Ggnlra(oth</h3>
an
 whOtcenartSl oehasobeenhattachTcSeoha tea
rnfhtbje<t,heet;sea
rnfhtbje<t
 whrecordsoeet;primary key eae SstDf atcrsSwurowshinserNdebin o  itmeSl o.
 whIC alsoohecordstnPtdorrlunaleprimary key npdioorrlbcblumnheae SstDf ani
*noSyle] deiseupds]meerows.hFiseeach uniqut;primary key eae S,ted fbis enab
 whrecordiLeotcen-i itdfuoly nimetaha
n  led salsnprimary key iscinserNde,
 whupds]meeorenele] doinnV)gglifetimetoShV)ggtea
rnf.
*n
 whlQeretiyutntdexcep*etChtooeet;pravluusntheegraph:hwetnna a
n iscinserNde,
 whupds]meeorenele] d,sifionetOr]mM topstit  primary key atlumns aCan Ssra
 utNuxa eae S,tnoohecorddtfameRhcirtrmeislmado.
 wsPh ssa tea
rnfhtbje<trorrlee ietar,smulV)isdewogtypestofohecordst-i io
es] htuathodasisSbpstprimary key eae SstDnabs(lssV)iLewetnnV)ggus rhinserN 
anoa sSwurecord)oarc APoci eeatiodasisSbpsteet;primary key eae SstfrctteR
 wh]rrlunaleeae SstDf oorrlbtSl oeatlumns (lssV)iLewetnnV)ggus rthnele] y
 whtseupds]m pasawcord).
rwsPh WetnnV)issf d confiis astc s,seea awquts)iLecirtrmsetois lssV)iLeo -DSsPh botE eeRofr,smulV)idohecordstfrctteReaexn*hAncbtt-hAsbpstV)a ed forci
 whfilQ. SeA_zsicLlgi:
r*
 wh<ul>
 wh  <li>hFiseeach hecorddggnlra(eegbytapAinserN,om enSd forci istquMAideibje ssssssfiseaha
n  led aematchogugtrimary key.hIfionetissfoutd,efroINSERTrityyyyyyyycirtrmeisladddestoom encirtrmtet.dIfhsedsechba
n iscfoutd,enoncirtrmrityyyyyyyyisladddestoom encirtrmtet.
 u
 wh e<li>hFiseeach hecorddggnlra(eegbytapAupds] torenele] ,om enSd forci isrityyyyyyyyquMAidesfiseaha
n  led aematchogugtrimary key.hIfisu hoa a
n isibje ssssssfiun oapd onetOr]mM topstlupenon-primary key fuelds hrveobeoh
 wh       modzsieeifn bblupiru]rrlunaleeae Ss,eapAUPDATE airtrmyisladddesto
 wh       m encirtrmtet.dOr,ristsedsechba
n iscfoutdnennV)ggtSl o,pasDELETErityyyyyyyycirtrmeisladddestoom encirtrmtet.dIfhteRr)tithnha
n  led aematchogurityyyyyyyyprimary key inhlupaed forci,hbuo[atcrfuelds aCan Ssrlupiru]rrlunalrityyyyyyyyeae Ss,eno cirtrmeisladddestoom encirtrmtet.
 ue</ulfibj
 whssislmeans,eamoDSst oorrlbtdings, eeatiifof;a
n iscinserNdebfrctteRn lV)ir
*noSyle] dewuileoa tea
rnfhtbje<t ithaefeve,bneiorrlbthehinserNenolbthehSyle] 
 wh l nr*extresentoinnV)ggcirtrmtet.dOriifof;a
n iscSyle] defrctteRn lV)irra
 uta
n  led V)ggeoe eprimary key eae SstinserNdebwuileoa tea
rnfhtbje<t it
anoaefeve,beea awyr SapGM|irtrmset  l nraCan SsrapAUPDATE airtrmyinstwade s
anoa DELETE frctonnINSERT.
ru
 whWetnna tea
rnfhtbje<t ithnisSl odr(seox itd[t ]ultnsla
rnf_enSl oi)tseDe),
 whitinceabcnqofr,smulV)iohecordstwetnnrowsharecinserNde,hupds]meeorenele] d.
 whssislmaybappearstoohrveosomMecout)ir-in uegang effNctsiifof;saohecta
n
 whiyuwrCNtefitoomoietV)andoncendur-DSna tea
rnf.hFiseexaor r,iifof;a
n
 whiyuinserNdebwuileoa tea
rnfhtbje<t it enSl od,oteRn lV)irrSyle] dewuile
ano itdeoe es*a
rnfhtbje<t ithnisSl od,eno INSERTehecordd l nrappearsinnV)g
*no|irtrmset,hengndeddughttuthSyle] itook placMewuileom e;tea
rnfhwathnisSl od.
 whOr,sifionetfueldbpstaga
n iscupds]meewuileoa tea
rnfhit enSl od,oapd
ano itsrapoorrlbfueldbpst itdeoe ea
n iscupds]meewuileom e;tea
rnfhithnisSl od,
ano itdawyr SapGM|irtrmset  l nraCan SsrapAUPDATE airtrmyeeathipds]m pbotE
 whfields.
 *xWris] objeretenttegi_hsla
rnf_lirtrmset(x rttegi]dstea
rnfh*pSea
rnf,rhrrrrsehSea
rnfhtbje<tSb*x retebbpnCirtrmset,rrrrrrrrrrrrrrrsehOUT:hSizedpstbuffNT]aet*ppCirtrmset b*x rIflsn**ppCirtrmset rrrrrrrrrrrrrsehOUT:hBuffNT]|btt SsapGMcirtrmset b*x);xasesPh geDe changRAts ibApAUpper-limethFisessa SizedOfessa CirtrmsetsPh bjheyup;veselliAtea
rnf
 wsPh BytSyaar S,nV)issf d confialwaysiuAts i p0.hFiseiAneoeuAeiro
anoa us fu"eawyr S,hV)ggttegi]dstea
rnfhtbje<thmudt hrveobeohocmnfigu tL
anoeohenSl o tQisleDeio -DSnttegi_hsla
rnf_tbje<t_cmnfigi)e led eet
*noSLFORDESESSION_OBJgONFIG_SIZDhverb.
ru
 whWetnnenSl od,oteissf d confirets i pfpAupperslimet,oifiby] s, fiseV)ggtize
 utpsteea cirtrmtetstiaetmrla
*bt produceehifct ]ultnsla
rnf_lirtrmset(r wur)
*no|stc s.hlQemfinLlncirtrmsethsizedmrla
*bt wquacrrchis smartmrir)andV)g
anosizeiiniby] seaweiroeehbyt iishf d conf.
 *xWris] objers ]ultne  s64estegi_hsla
rnf_lirtrmset_size(ttegi]dstea
rnfh*pSea
rnf);xasesPh geDe changLoadelQemDiffNT ncehBetweohoTSl os In o A Sea
rnfsPh bjheyup;veselliAtea
rnf
 wsPh Isfis ithcnqof awadypattachTcSeohV)ggtea
rnfhtbje<trthmodesasolup fuoly
anoarren-me,nV)issf d confiattachTsbtSl oezTbloinnV)ggeoe emannNT]as eet
*no[ttegi_hsla
rnf_attach(r]lf d conf.dIfhzTblonceabcnqeMxshi,horeisfis
*nonceabcnqehrveoa primary key,nV)issf d confiithnhno-op (buo[nceabcnqeuAeiro
anoapdMAais).
rwsPh Arren-metzFo bDb mea
*beueeehnoe bpstagnd forci ("main", "oiap" etc.)
ityattachTcSeohV)ggtoe bSd forci hanSlQSashV)ggtea
rnfhtbje<treeatiodan Sss
anoa tSl oeatmiatiblt; led V)ggtSl oeattachTcSeohV)ggtea
rnfhbyt iishf d conf.
 whA;tSl oeisc|btsid- edoatmiatiblt;isfis:
r*
 wh<ul>
 wh  <li>hHashV)ggtoe bnoe ,
 wh  <li>hHashV)ggtoe btet ifeatlumns decla edoinnV)ggeoe eordQr,oapd
ano  <li>hHashV)ggtoe bPRIMARYoKEYhSyaeticonf.
 wh</ulfibj
 whIStmeRhtSl osohyebsetoatmiatiblt,oSLFORDESCHEMAneyuaweiroee.hIStmeRhtSl os
 whayebatmiatiblt;buo[ncbcnqehrveoanyoPRIMARYoKEYhatlumns,fis ithcnqofnceAais
 whbuo[no cirtrmstayebadddestoom entea
rnfhtbje<t.hAsg ledhoorrlbeea
rnf
anoeDes,seSl osg ledduotPRIMARYoKEYshare sior y ignoied.
 u
 whT)ishf d confiadds a tet ifeairtrmsSeohmeRhtea
rnfhtbje<treeatiodenenbesPh o destooupds] tV)ggtSl oeinhed forci zFo b (aatcrrQislgulY"fo b-tSl o")
itysxo iaetit  |btt-hAnishV)ggtoe basolup lSl oeattachTcSeohV)ggtea
rnf
 utpbje<tr(aatcrrQislgulY"to-tSl o"). SeA_zsicLlgi:
r*
 wh<ul>
 wh  <li>hFiseeach h
n (primary key)o iaetMxshisnennV)ggto-tSl ohbuo[nothin
*no    m enfo b-tSl o,efroINSERTehecorddisladddestoom entea
rnfhtbje<t.
 u
 wh  <li>hFiseeach h
n (primary key)o iaetMxshisnennV)ggto-tSl ohbuo[nothin
*no    m enfo b-tSl o,ef DELETE hecorddisladddestoom entea
rnfhtbje<t.
 u
 wh  <li>hFiseeach h
n (primary key)o iaetMxshisnennbotE eSl os,hbuo[fea)u tsibje sssdiffNT ntenon-PK eae Sstineeach,eapAUPDATE hecorddisladddestoom eibje ssstea
rnf.
*ne</ulfibj
 whscoalarify,risteeishf d confiis astc sefrctteRn agcirtrmtet aCastruc)iLsPh o -DSn[t ]ultnsla
rnf_lirtrmset(r],heetnfaftrlea  sy-DSneeatioirtrmset eo
*noed forci zFo b tsa |btt-hAsbpstV)ggtwobatmiatiblt;eSl osg denenbesPh  ds r,cac.
 u
 whUntla
am eecatcrrco iishf d confiithnhno-op athnescrib sefbove,biC iscan
 wheAaiseisted forci zFo b nceabcnqeMxshihorenceabcnqeaCan Ssrluptr*
*irsd
*no|tmiatiblt;eSl o.sPh
 whIsteeetO
yra(othristsu rla
fu",hSLFORDEOKhithaweiroee. Otrrlwisa,banAShosie
 wheAaisec*di.hInnV)isscrci,historren-metpzErrMsg iyucnqeNuxa,h*pzErrMsg
 whmayr*exset eohtaetC tohaybuffNT]|btt SsapGManAEoheish lVnguageceAais
 whmla
age.hIC iyugulYawypbtsiliegiytpso itdiartmrircofreox iiyubuffNT]o -DS
 whstegi_hAfreoi).
 *xWris] objeretenttegi_hsla
rnf_diff(x rttegi]dstea
rnfh*pSea
rnf,x r|bts treAP *zFo bDb,x r|bts treAP *zTbl,x r|eAP **pzErrMsg
);xaasesPh geDe changGgnlra(o A Patchset Fo bbA Sea
rnfhObje<tsPh bjheyup;veselliAtea
rnf
 wsPh lQemdiffNT ncesobetweohoahpatchset frctotairtrmtet aietV)at:
r*
 wh<ul>
 wh  <li>hDELETE hecordsiodasisSbpsteet;primary key fuelds only.hlQa
*noooooooo]rrlunaleeae SstDf oorrlbfuelds ayebemCNtee.
 wh  <li>hTPtdorrlunaleeae SstDf apy modzsieeifuelds ayebemCNteenfo b
*nooooooooUPDATE hecords.
*ne</ulfibj
 whAhpatchset blobemayr*exus se ledhupSeohSd e vl sothseoStatc
 wht ]ultnlirtrmset_xxxleDeif d confsdexcep*efisestegi_hcirtrmset_iaverN(),
 whwhichhuAts i plr8],(MCORRUPTriftissiththmodesahpatchset.dSimilarly,
ityattiaprogu nooicsbahpatchset blobe ledhonenvl sothseoSteea
 whstegi_hcirtrmset_xxxleDeyualsooproen-msbanASho],(MCORRUPTrMAais.
 wsPh Beccicsbeea non-primary key "one.*"ifuelds ayebemCNtee,eno
*noSLFORDECHANGESET_DATAyaCnfsiststornbercds</c]meeorereportedoifbahpatchset
 whiyuthmodestoo iRostegi_hcirtrmset_a  sy()oeDe.hOorrlbcbnfsistrtypestwork
 whinnV)ggeoe eway asoairtairtrmtets.
ru
 whCirtrmst ledinaa patchset fr eordQredoinnV)ggeoe eway asoairtairtrmtets
 whggnlra(eegbyt ia t ]ultnsla
rnf_lirtrmset()of d confi(i.e.hatcrcirtrmste i
anoaysaohecttSl oeayebgroupdestogetrrl,seSl osgappearsinnV)geordQrhinowhich
ano ity wur)thttachTcStoom entea
rnfhtbje<t).
 *xWris] objeretenttegi_hsla
rnf_patchset(x rttegi]dstea
rnfh*pSea
rnf,rhrrrrsehSea
rnfhtbje<tSb*x retebbpnPatchset,rrrrrrrrrrrrrrrr/whOUT:hSizedpstbuffNT]aet*ppPatchset b*x rIflsn**ppPatchset  rrrrrrrrrrrrrsehOUT:hBuffNT]|btt SsapGMpatchset b*x);xasesPh geDe changTmsenistagcirtrmtet hayuawcordiLeapy cirtrmt.
ru
 whRAts ibnon-bavr if[no cirtrmsttonattachTcSeSl os hrveobeoherecordiLeby
ano itdeea
rnfhtbje<trthmodesasolup fuolytorren-me. Otrrlwisa,bifionetOr
 whmoietcirtrmsthrveobeoherecordiL,iuAts ibbavr.
ru
 whEngndisteeissf d confirets i pbavr,[i
* srtossil oSeeattorcLapG
*no[ttegi_hsla
rnf_lirtrmset(r]tonaV)a eea
rnfhhanSlQSmayrstl nruAts iba
*no|irtrmsetreeatiodan Sss[no cirtrms.essislornbhappenhwetnna a
n io
anoapdattachTcSeSl oeislmodzsieeifrctteRn lV)irronnV)georrlunaleeae Ss
 whayebawytors . Howeher,risteeishf d confirets i pnon-bavr,heetnnitSia
 whguaratt-ec APattaecatcrrcot ]ultnsla
rnf_lirtrmset(r wl nruAts iba
*no|irtrmsetr|btt SsapGMbavr cirtrmt.
r*xWris] objeretenttegi_hsla
rnf_isiapry(ttegi]dstea
rnfh*pSea
rnf);xasesPh geDe changQuMAy fiseV)ggamout)dpstheaplmemory usiLebyda tea
rnfhtbje<t.
 u
 whT)ishbjerrets i pV)ggtotacramout)dpstheaplmemory iniby] seaexn*hAab
 whusiLebyd itdeea
rnfhtbje<trthmodesasolup ]nabsarren-me.
 *xWris] objers ]ultne  s64estegi_hsla
rnf_memory_usiLittegi]dstea
rnfh*pSea
rnf);xasesPh geDe changCssV)i An Itlra(isescoTstvl s  A CirtrmsetsPh gONSTRUCTOR:mstegi_hAcirtrmset_i)ir
*nsPh gssV)inapAi
lra(iseo destooi
lra(oSeerdughttuth|btt-hAsbpstagcirtrmtet.sPh IStsu rla
fu",h*ppeiyutetstootaetC tohthehi
lra(isehanSlQSapd SLFORDEOK
 whiyuaweiroee. Otrrlwisa,bifiapdMAaise]r,s]
,b*ppeiyutetstoobavrenpdian
 whShosiesMAaiseimmedithaweiroee.
an
 whlQemfiLu
napGMf d confsdornbercus sercladvatcennpdiquMAy a;cirtrmset
anoi
lra(iselssV)iLebyt iishf d conf:
r*
 wh<ul>
 wh  <li>h[t ]ultnlirtrmset_sSxt()]
ano  <li>h[t ]ultnlirtrmset_op()]
ano  <li>h[t ]ultnlirtrmset_sSw()]
ano  <li>h[t ]ultnlirtrmset_old(r]
 wh</ulfibj
 whIC iyugulYawypbtsiliegiytpso itdiartmrircoav inuLlgitdestroyhthehi
lra(is
 whbisthmo-DSni irco[t ]ultnlirtrmset_fimhnize(r].hTitdbuffNT]|btt SsapGMV)g
*no|irtrmsetr(pCirtrmset) mea
*remainseaeideut)ilsaftrle iehi
lra(iseia
 whdestroyee.
an
 whAssumapGMV)ggcirtrmtet blobe aselssV)iLebyttntdospV)g
*no[ttegi_hsla
rnf_lirtrmset(r],o[t ]ultnlirtrmset_|btso*()]  i
ano[stegi_hcirtrmset_iaverN()]lf d confs,tatcrcirtrmst ledinaV)ggcirtrmtet
ano iatta  syoeohaysaohecttSl oeayebgroupdestogetrrl. ssislmeanso iattwetnsPh anAa  siso*etChi
lra(osSeerdughtagcirtrmtet o -DSnapAi
lra(iselssV)iLeby
ano iishf d conf,tatcrcirtrmst iattrelV)ioeohaysaohecttSl oeayebviceged
*no|tnsecurovely.hlQar)tithno cirtce eeati itdi
lra(isewl nrvicegtagcirtrm
ano itdfhosi sSeohmSl oeX,heetnnonetfisetSl o Y,ifrctteRn lV)irronnvicegsPh anoorrlbcirtrmyfisetSl o X.
an
 whlQembehrvioreospstegi_hcirtrmset_smfrt_v2()banS it  stssVmapGM*
*ieae-meritymayr*exmodzsieeibisthmo-DSna cbmbinatrnfhts
ano[SLFORDECHANGESETSTART_INVERTe| sehoorteenflSgs]sasolup 4edhthee^s</r.
 u
 whNote eeati itdstegi_hcirtrmset_smfrt_v2()beDeiithstl nr<b>experim inal</b>sPh anctteRlee ietsubje<trer cirtrm.
r*xWris] objeretenttegi_hlirtrmset_smfrt(x rttegi]dscirtrmset_i)irn**pp,rrrrsehOUT:hNewrcirtrmsetoi
lra(isehanSlQSb*x retennCirtrmset,rrrrrrrrrrrrrrrrr/whSizedtfacirtrmtet blobeiniby] seb*x rIflsn*tCirtrmset rrrrrrrrrrrrrrr/whPaetCNTSuxoblobe|btt SsapGMcirtrmset b*x);xWris] objeretenttegi_hlirtrmset_smfrt_v2(x rttegi]dscirtrmset_i)irn**pp,rrrrsehOUT:hNewrcirtrmsetoi
lra(isehanSlQSb*x retennCirtrmset,rrrrrrrrrrrrrrrrr/whSizedtfacirtrmtet blobeiniby] seb*x rIflsn*tCirtrmset,rrrrrrrrrrrrrrrsehPaetCNTSuxoblobe|btt SsapGMcirtrmset b*x retenflSgshhhhhhhhhhhhhhhhhhhhhhh/whSESSION_CHANGESETSTART_*dflSgshb*x);xasesPh geDe changFlSgsefisestegi_hcirtrmset_smfrt_v2
an
 whlQemfiLu
napGMflSgsereisthmodesviaolup 4edhthee^s</r eo
*no[t ]ultnlirtrmset_smfrt_v2]onpdiit ]ultnlirtrmset_smfrt_v2_smrm]:
r*
 wh<dt>SLFORDECHANGESETSTART_INVERTe<dd>
 wh  IaverNMV)ggcirtrmtet wuileoityra(ogu throughni .hssislit e
*ieae-mesto
 wh  iaverN-DSna cirtrmtetso -DSnttegi_hcirtrmset_iaverN()ebee ieta  sy-DSnit.
 wh  IC iscanAeAaisercoseA_zsybeeishflSg  led aepatchset.
P*x#Syaets]SLFORDECHANGESETSTART_INVERTeeeeeeee0x0002xaasesPh geDe changAdvatcenA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)ishf d confireisonlybercus se ledhi
lra(isselssV)iLebyt ielf d conf
*no[t ]ultnlirtrmset_smfrt(r].hIsfis ithastc senfhapoi
lra(isethmodesto
anoayaCnfsist-hanSlQrhaatcetheebyt[t ]ultnlirtrmset_a  sy()],hSLFORDEMISUSE
 whiyuaweiroeetfrctteReaatcrhayusedeffNct.sPh
 whImmedia] gihaftrleanhi
lra(iseiaelssV)iLebytt ]ultnlirtrmset_smfrt(r,fis
*nonceabcnqetaetC tohapy cirtrmoinnV)ggcirtrmtet.dAssumapGMV)ggcirtrmtet
 whiyucnqeMapry,olup fuolytcatcrrco iishf d confiadvatcesi itdi
lra(iseto
anotaetC tohthehfuolytcirtrmoinnV)ggcirtrmtet.dEachrsubs*
* ntccatcradvatces
ano itdi
lra(isetootaetC tohthehsSxtScirtrmoinnV)ggcirtrmtet (ifiapy).hIs
anosedeAaise]r,s]
tfrctteRei
lra(isetaetCs nooaseaeidecirtrmoaftrleaccatc
ano ott ]ultnlirtrmset_sSxt()rhayuadvatceS it,hSLFORDEROWdithaweiroee.
an Otrrlwisa,bifiatcrcirtrmstinnV)ggcirtrmtet hrveoa awadypbeoheviceged,
*noSLFORDEDONEdithaweiroee.
an
 whIfiapdMAaise]r,s]
,banAShosiesMAaiseimmediyuaweiroee. Possil oSeAais
 whimmeshincludeASho],(MCORRUPTr(isteea cirtrmtetsbuffNT]isc|brrupt)  i
anoSLFORDENOMEM.
r*xWris] objeretenttegi_hlirtrmset_sSxt(ttegi]dscirtrmset_i)irn*pI
lr);xasesPh geDe changObn Sstssa Cexn*hAnO
yra(othrFo bbA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)e pI
lrnarren-metthmodestoo iislf d confireiseiorrlbbinapAi
lra(is
anothmodestooayaCnfsist-hanSlQrhbyt[t ]ultnlirtrmset_a  sy()],hornapAi
lra(is
anolssV)iLebyt[t ]ultnlirtrmset_smfrt(r].hInnV)gglattir crci,hV)ggmoa
*rec-meritycatcrrco[t ]ultnlirtrmset_sSxt()]hmudt hrveoaweiroeet[SLFORDEROW].hIStmeis
 whiyucnqeteReaaci,hV)ishf d confirets i p[SLFORDEMISUSE].
an
 whArren-mes pOp,rpnColtfrctpzTSl reiscnqnbe Nuxa. Upnfirets i,hV)ressPh outputsiayebtetsterdughttutcsbpaetCNTs:
r*
 wh*pOpeiyutetstootntdosp[SLFORDEINSERT],o[SLFORDEDELETE]i ic[SLFORDEUPDATE],
 whdependapGMonnV)geeypettfacirtrm eeati itdi
lra(iseaexn*hAabetaetCs no;
r*
 wh*pnColtiyutetstoothehs rol bpstcolumnsiinnV)ggtSl ocaffNctdesbyteea cirtrm;oapd
an
 wh*pzTSl iyuset eohtaetC tohaynul-</rmetV)iLeotf-8 enimmed stsapGMcbtt SsapG
ano itdnoe bpstV)ggtSl ocaffNctdesbyteea cexn*hAncirtrm.hTitdbuffNT]remains
 wheaeideut)ilseiorrlbt ]ultnlirtrmset_sSxt()rithastc senfhthehi
lra(is
 whiseot)ilstuth|btfsist-hanSlQrhf d confirets i .
an
 whIfipbIndire<t iyucnqeNuxa,heetnn*pbIndire<t iyutetstootrue (1) isteea cirtrm
 whiyuapAindire<tgcirtrm,hornfalci (0) otrrlwisa.hSesteea docum inaferere i
ano[stegi_hsla
rnf_indire<tir]tfiseahnescripferer steire<tganS indire<t
 whcirtrmt.
ru
 whIfhsedMAaise]r,s]
,bSLFORDEOKhithaweiroee. IfiapdMAaisenceab]r,s],ian
 whShosiesMAaiseimmedithaweiroee.hTitdeae SstDf lup ]utput  ariSl os reiscnq
 whbextsus] doinnV)isscrci.
r*xWris] objeretenttegi_hlirtrmset_op(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whItlra(isetbje<tSb*x r|bts treAP **pzTSl,hhhhhhhhhhhhh/whOUT:hPaetCNTSuxotSl oonoe eb*x  etebbpnCol,rrrrrrrrrrrrrrrrrrrrrsehOUT:hN rol bpstcolumnsiinnVSl oob*x  etebbpOp,rrrrrrrrrrrrrrrrrrrrrrr/whOUT:hSLFORDEINSERT,hDELETE iseUPDATE b*x  etebbpbIndire<t rrrrrrrrrrrrrrrr/whOUT:hTrue fiseapA'indire<t'acirtrm b*x);xasesPh geDe changObn Sstssa Primary Key DyaeticonfdOfeA;TSl o
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh Fiseeach modzsieeitSl o,ef cirtrmsetoincludesolup fiLu
napG:
r*
 wh<ul>
 wh  <li>hlQems rol bpstcolumnsiinnV)ggtSl o,oapd
ano  <li>hWhichhDf luoci columnsimakt upSeeRhtSl osoPRIMARYoKEY.
 ue</ulfibj
 whssislf d confiisuus senooaetdhwhichhatlumns aCmpricsbeea PRIMARYoKEYhps
ano itdVSl oomodzsieeibiseea cirtrm  iaetitlra(isetI
lrnaexn*hAabetaetCs no.sPh IStsu rla
fu",h*pabPK iyuset eohtaetC tohafiarraytpsonColtentri s,hweRr)
anosColtiyuthehs rol bpstcolumnsiinnV)ggtSl o.dElsm-mes oSt*pabPK ayebtetsto
ano0x01nifteea corawypbtdapGM|blumnhisntheSbpstluphtSl osoprimary key,n i
ano0x00riftissithset.sPh
 whIfiarren-mettsColtiyucnqeNuxa,heetnn*pnColtiyutetstoothehs rol bpstcolumns
 whinnV)ggeSl o.sPh
 whIsteeishf d confiis astc sewetnnV)ggitlra(isenceabcnqetaetC tohaheaeid
 whentry,hSLFORDEMISUSEhiyuaweiroeetfrctteRe]utput  ariSl os bavree. Otrrlwisa,
anoSLFORDEOKhithaweiroeehfrctteRe]utput  ariSl os populV)iLeathnescrib s
anoabove.
r*xWris] objeretenttegi_hlirtrmset_pk(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whItlra(isetbje<tSb*x runyignas reAP **pabPK,rrrrrrrrrr/whOUT:hArraytpsobooleafi-otrue fisePK colseb*x  etebbpnColrrrrrrrrrrrrrrrrrrrrrr/whOUT:hN rol bpstentri siinh]utput arraytb*x);xasesPh geDe changObn Sstone.* Vae SstFo bbA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)e pI
lrnarren-metthmodestoo iislf d confireiseiorrlbbinapAi
lra(is
anothmodestooayaCnfsist-hanSlQrhbyt[t ]ultnlirtrmset_a  sy()],hornapAi
lra(is
anolssV)iLebyt[t ]ultnlirtrmset_smfrt(r].hInnV)gglattir crci,hV)ggmoa
*rec-meritycatcrrco[t ]ultnlirtrmset_sSxt()]hmudt hrveoaweiroeetSLFORDEROW.sPh Furtrrlmoie,[i
*reisonlybercastc seifteea eypettfacirtrm eeati itdi
lra(isritycexn*hAabetaetCs nolit eiorrlb[SLFORDEDELETE]i ic[SLFORDEUPDATE]. Otrrlwisa,
anoV)ishf d confirets i p[SLFORDEMISUSE]banS setth*ppVae SstooNuxa.
rwsPh Arren-metiVae mea
*beugssV)iram aaoiseequacrrch0,ifrcttla
am aadthehs rol 
 whistcolumnsiinnV)ggtSl ocaffNctdesbyteea cexn*hAncirtrm.hOtrrlwisa,
ano[SLFORDERANGE]hithaweiroeehfrct*ppVae SsiyutetstooNuxa.sPh
 whIstsu rla
fu",hluissf d confieetth*ppVae SstootaetC tohahpro</c]me
 whveselliA aeuenpbje<t aCtt SsapGMV)ggiVae'th  aeuenfn bblup ve<toreos
 whisrlunalea
n  aeueststors hasntheSbpstlupeUPDATE Or]DELETE airtrmoapd
anouAts i plr8],(MOK.hTitdnoe bpstV)ggf d confiaCmmsten bblup fa<treeatimeis
 whiyusimilarstootheh"one.*"iatlumnsiavailSl oetooupds] torenele] o riggl t.
ru
 whIfhsomMeoorrlbeAaise]r,s]
t(e.g.daadOOM aCtdypesm),banAShosiesMAaiseimme
 whiyuaweiroeetfrct*ppVae SsiyutetstooNuxa.sP*xWris] objeretenttegi_hlirtrmset_old(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whCirtrmset itlra(iseb*x  etebiVae,rrrrrrrrrrrrrrrrrrrrrrr/whCblumnhs rol bb*x rttegi]ds aeuen**ppVae Ssrrrrrrrr/whOUT:hOlee aeueS(iseNuxa paetCNT)tb*x);xasesPh geDe changObn Sstnew.* Vae SstFo bbA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)e pI
lrnarren-metthmodestoo iislf d confireiseiorrlbbinapAi
lra(is
anothmodestooayaCnfsist-hanSlQrhbyt[t ]ultnlirtrmset_a  sy()],hornapAi
lra(is
anolssV)iLebyt[t ]ultnlirtrmset_smfrt(r].hInnV)gglattir crci,hV)ggmoa
*rec-meritycatcrrco[t ]ultnlirtrmset_sSxt()]hmudt hrveoaweiroeetSLFORDEROW.sPh Furtrrlmoie,[i
*reisonlybercastc seifteea eypettfacirtrm eeati itdi
lra(isritycexn*hAabetaetCs nolit eiorrlb[SLFORDEUPDATE]i ic[SLFORDEINSERT]. Otrrlwisa,
anoV)ishf d confirets i p[SLFORDEMISUSE]banS setth*ppVae SstooNuxa.
rwsPh Arren-metiVae mea
*beugssV)iram aaoiseequacrrch0,ifrcttla
am aadthehs rol 
 whistcolumnsiinnV)ggtSl ocaffNctdesbyteea cexn*hAncirtrm.hOtrrlwisa,
ano[SLFORDERANGE]hithaweiroeehfrct*ppVae SsiyutetstooNuxa.sPh
 whIstsu rla
fu",hluissf d confieetth*ppVae SstootaetC tohahpro</c]me
 whveselliA aeuenpbje<t aCtt SsapGMV)ggiVae'th  aeuenfn bblup ve<toreos
 whsSwurow  aeueststors hasntheSbpstlupeUPDATE Or]INSERTeairtrmoapd
anouAts i plr8],(MOK.hIfameRhcirtrmeislapAUPDATE apd nceabcnqeinclude
anoaysSwu aeuenfiseV)ggawquts)iLectlumn,h*ppVae SsiyutetstooNuxaoapd
anoSLFORDEOKhaweiroee.hTitdnoe bpstV)ggf d confiaCmmsten bblup fa<treeat
anoV)ishiyusimilarstootheh"new.*"iatlumnsiavailSl oetooupds] torenele] 
anoVriggl t.
ru
 whIfhsomMeoorrlbeAaise]r,s]
t(e.g.daadOOM aCtdypesm),banAShosiesMAaiseimme
 whiyuaweiroeetfrct*ppVae SsiyutetstooNuxa.sP*xWris] objeretenttegi_hlirtrmset_sSw(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whCirtrmset itlra(iseb*x  etebiVae,rrrrrrrrrrrrrrrrrrrrrrr/whCblumnhs rol bb*x rttegi]ds aeuen**ppVae Ssrrrrrrrr/whOUT:hNSwu aeuen(iseNuxa paetCNT)tb*x);xasesPh geDe changObn SstCCnfsistapGMRow Vae SstFo bbA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)issf d confieh*enenonlybercus se ledhi
lra(ishtbje<ts thmodestooarityaCnfsist-hanSlQrhaatcethehbyt[t ]ultnlirtrmset_a  sy()]e ledheiorrl
ano[SLFORDECHANGESET_DATA]i ic[SLFORDECHANGESET_gONFLICT].hIStmeislf d conf
*noithastc senfhapy oorrlbi
lra(is,p[SLFORDEMISUSE]biyuaweiroeetfrct*ppVae S
 whiyusetstooNuxa.sPh
 whArren-metiVae mea
*beugssV)iram aaoiseequacrrch0,ifrcttla
am aadthehs rol 
 whistcolumnsiinnV)ggtSl ocaffNctdesbyteea cexn*hAncirtrm.hOtrrlwisa,
ano[SLFORDERANGE]hithaweiroeehfrct*ppVae SsiyutetstooNuxa.sPh
 whIstsu rla
fu",hluissf d confieetth*ppVae SstootaetC tohahpro</c]me
 whveselliA aeuenpbje<t aCtt SsapGMV)ggiVae'th  aeuenfn bblup
 wh"cCnfsistapGMrow"hassocis]meewled V)ggaexn*hAncbtfsist-hanSlQrhaatcethe
Ph anctuAts i plr8],(MOK.
ru
 whIfhsomMeoorrlbeAaise]r,s]
t(e.g.daadOOM aCtdypesm),banAShosiesMAaiseimme
 whiyuaweiroeetfrct*ppVae SsiyutetstooNuxa.sP*xWris] objeretenttegi_hlirtrmset_cbtfsist(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whCirtrmset itlra(iseb*x  etebiVae,rrrrrrrrrrrrrrrrrrrrrrr/whCblumnhs rol bb*x rttegi]ds aeuen**ppVae Ssrrrrrrrr/whOUT:hVaeuenfn bbcCnfsistapGMrowtb*x);xasesPh geDe changDs</rmets]TitdN rol bOf Fiseign Key CCastraetebViolo*etCs
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)issf d confireisonlybercastc se led apoi
lra(isethmodestoian
 whShoORDECHANGESET_FOREIGN_KEYhatnfsistrhanSlQrhaatcethe.hInnV)isscrci
 whitieetthteRe]utput  ariSl ostoothehtotacrs rol bpstknownaforeign key
 wheiolo*etCs inhlupaeehil_aferered forci anctuAts i plr8],(MOK.
ru
 whIMtatcroorrlbcacisteeishf d confirets i pSLFORDEMISUSE.sP*xWris] objeretenttegi_hlirtrmset_fk_cbtfsists(x rttegi]dscirtrmset_i)irn*pI
lr,hh/whCirtrmset itlra(iseb*x  eteb*pnOut rrrrrrrrrrrrrrrrrrrrr/whOUT:hN rol bpstFKheiolo*etCs b*x);xaasesPh geDe changFimhnizebA Cirtrmset I
lra(is
 whbjheyup;veselliAcirtrmset_i)ir
*nsPh T)issf d confiisuus senooaethnizebapoi
lra(iseaLu
cs]meewled
ano[stegi_hlirtrmset_smfrt(r].
*nsPh T)issf d confieh*enenonlybercastc senfhi
lra(isselssV)iLeo -DSnlup
ano[stegi_hlirtrmset_smfrt(r]hf d conf.hIfiapdfhosiso*etChoalgsr iis
 whf d confe led apoi
lra(isethmodestoiayaCnfsist-hanSlQrhby
ano[stegi_hlirtrmset_a  sy()],h[SLFORDEMISUSE]biyuimmedia] gihaweiroeehfrctteRritycatcrhayusedeffNct.sPh
 whIfiapdMAaise aseenimut)irmeewledinoagcatcrrcoapdstegi_hcirtrmset_xxx()
 whf d confe(fiseexaor roapd[SLFORDECORRUPT] inh[t ]ultnlirtrmset_sSxt()]hornap
ano[SLFORDENOMEM] inh[t ]ultnlirtrmset_sSw()])heetnnapdMAaiseimmedcorawypbtdapG
*noeohV)atheAaiseiseaweiroeehbyt iishf d conf. Otrrlwisa,bSLFORDEOKhit
anouAts iee.hTiishiyurcoaLu
nolup fiLu
napGepat)irfe(pseudo-imme):
r*
 wh<pre>
 wh tt ]ultnlirtrmset_smfrt(r;
 wh twuile(tSLFORDEROW==t ]ultnlirtrmset_sSxt()r){
 wh trr// DohsomMtdinge led cirtrm.
rwh t}
rwh trc =nttegi_hlirtrmset_fimhnize(r;
 wh tif(trc!=SLFORDEOKh){
 wh trr// ApdMAaisehayu]r,s]ied
 wh e}
 ue</pre>
 *xWris] objeretenttegi_hlirtrmset_fimhnize(ttegi]dscirtrmset_i)irn*pI
lr);xasesPh geDe changIaverNMA CirtrmsetsPhsPh T)issf d confiisuus senoo"iaverN"haycirtrmtet ibje<t.hA  sy-DSnan iaverNed
*no|irtrmtet tooaySd forciouAvl s thteReeffNctsipsta  sy-DSneee uniaverNed
*no|irtrmtet. SeA_zsicLlgi:
r*
 wh<ul>
 wh  <li>hEachrDELETE airtrmoisocirtrmestoianoINSERT, apd
ano  <li>hEachrINSERTeairtrmoisocirtrmestoiarDELETE, apd
ano  <li>hFiseeach UPDATE airtrm,hV)ggone.* frctnew.* eae Sstfrtdexcirtrme.
 ue</ulfibj
 whssislf d confinceabcnqeairtrm ee eordQrhinowhichhcirtrmstappearswledin
ano itd|irtrmtet. It mirmgihawvl s thteResensetDf each individuLlncirtrm.
rw
 whIstsu rla
fu",ha paetCNT tohaybuffNT]|btt SsapGMV)ggiaverNedgcirtrmtet
 whiyustors hint*ppOut,hV)ggtizedtfameRheoe ebuffNT]iscstors hint*pnOut,hapd
anoSLFORDEOKhithaweiroee. IfiapdMAaise]r,s]
,bbotE *pnOut frct*ppOut fra
*nobavreehfrctanAShosiesMAaiseimmedaweiroee.
an
 whIC iyugulYawypbtsiliegiytpso itdiartmrircoav inuLlgitcatcrstegi_hAfreoi)
 whinhlupa*ppOut paetCNT tohfreox itdbuffNT]aLu
cs]erere Lu
napGMatsu rla
fu"ritycatcrrco iishf d conf.
 writyWARNING/TODO:hssislf d conficexn*hAabeassummst iattV)ggiaput ithnheaeid
 wh|irtrmtet. Iftissithset,beea awyr Sstfrtdi Syaets .
 *xWris] objeretenttegi_hlirtrmset_iaverN(x retennIn,r|bts tIflsn*tIf,rhrrrrh/whIaput cirtrmset b*x reten*pnOut,hIflsn**ppOut rrrrrrr/whOUT:hIaversetDf iaput b*x);xasesPh geDe changCbtso*etV)i Two Cirtrmset Obje<tssPhsPh T)issf d confiisuus senoocbtso*etV)i twobairtrmset
,bAhfrctB,bin o aritysaohect|irtrmtet. Tea awyr S ithnhcirtrmset e
*ieae-mestota  sy-DS
*no|irtrmtet A fiLu
niLebyd|irtrmtet B.
*nsPh T)issf d conficbmbin thteRetwobiaput cirtrmsets o -DSnap
 whveselliAcirtrmgroup ibje<t.hCrcLapGtissproduceyusimilarsawyr Sstfs eet
*noe Lu
napGMimmedfragn-me:
r*
 wh<pre>
 wh tt ]ultnAcirtrmgroup *pGrp;
rwh trc =nttegi_hAcirtrmgroup_sSw(&pGrpr;
 wh tif(trc==SLFORDEOKh)trc =nttegi_hlirtrmgroup_add(pGrp, nA, pAr;
 wh tif(trc==SLFORDEOKh)trc =nttegi_hlirtrmgroup_add(pGrp, nB,bpBr;
 wh tif(trc==SLFORDEOKh){
 wh trrrc =nttegi_hlirtrmgroup_]utput(pGrp, pnOut,hppOutr;
 wh t}else{
 wh trr*ppOut = 0;
 wh trr*pnOut = 0;
 wh t}
 ue</pre>
 u
 whRAferstootheht ]ultnAcirtrmgroup docum inafererbeu
nofoledetailsr
r*xWris] objeretenttegi_hlirtrmset_cbtso*(x retennA,rrrrrrrrrrrrrrrrrrrrrrrrr/whN rol bpstby] seinibuffNT]pAeb*x rIflsn*tA,rrrrrrrrrrrrrrrrrrrrrrrsehPaetCNTSuxobuffNT]|btt SsapGMcirtrmset ASb*x retennB,rrrrrrrrrrrrrrrrrrrrrrrrr/whN rol bpstby] seinibuffNT]pBeb*x rIflsn*tB,rrrrrrrrrrrrrrrrrrrrrrrsehPaetCNTSuxobuffNT]|btt SsapGMcirtrmset B b*x reten*pnOut,hrrrrrrrrrrrrrrrrrrrrsehOUT:hN rol bpstby] seini]utput cirtrmset b*x rIflsn**ppOut rrrrrrrrrrrrrrrrrrrsehOUT:hBuffNT]|btt SsapGM]utput cirtrmset b*x);xasesPh geDe changCirtrmgroup HanSlQsPh
 whA cirtrmgroup islapApbje<t us senoocbmbin etwobOr]mM t
ano[cirtrmsets]i ic[patchsets]
r*xeypeSya struc)ht ]ultnAcirtrmgroup t ]ultnAcirtrmgroup;xasesPh geDe changCssV)i AhNSwuCirtrmgroup Obje<tsPh gONSTRUCTOR:mstegi_hAcirtrmgroupsPh
 whAnhveselliAcirtrmgroup ibje<tiisuus senoocbmbin etwobOr]mM ttairtrmtets
 wh(oshpatchsets)bin o aysaohect|irtrmteth(oshpatchset).hAysaohect|irtrmgroupsPhhtbje<thmayr|bmbin ecirtrmsets oshpatchsets,hbuo[nothbotE.hTh eoutput it
anoalwaysiinnV)ggeoe efolmatsasolup iaput.sPh
 whIstsu rla
fu",hluissf d confiuAts i plr8],(MOKtfrctpopulV)is (*pp)ewled
anoa paetCNT tohaysSwuveselliAcirtrmgroup ibje<tibee ietuAts iigu.hTh eiartmr
 whvh*enenav inuLlgitfreox itdaweiroeehpbje<t us-DSna catcrrc
 whvesellilirtrmgroup_nele] (). IfiapdMAaise]r,s]
,banAShosiesMAaiseimme
 wh(i.e.hSLFORDENOMEM)githaweiroee frct*ppsiyutetstooNuxa.sPh
 whTh eusuLlnu
ageepat)irfefiseapAveselliAcirtrmgroup ibje<tiisuasoaiLu
ns:
r*
 wh<ul>
 wh  <li>hItois lssV)iLeo -DStaecatcrrcot ]ultncirtrmgroup_sSw().
rwsPh   <li>hZavrlOr]mM tocirtrmsets (oshpatchsets)bayebadddestoom entbje<t
 whhhhhhhhbytorcLapGnttegi_hlirtrmgroup_add().
rwsPh   <li>hTea awyr S istcombin-DStallbiaput cirtrmsets togetrrlois obn Ssdeibje ssssssbyteea fhosiso*etChviaoaecatcrrcot ]ultncirtrmgroup_]utput().
rwsPh   <li>hTea tbje<t ithnyle] deo -DStaecatcrrcot ]ultncirtrmgroup_nele] ().
 ue</ulfibj
 whAnyhs rol bpstcalgsr cladd()banS ]utput()ymayr*exmameebetweoho itdiartsrrc
 whsSw() apd nele] (),ganS inhapy ordQr.
an
 whAs wetcrayugulYawgularsttegi_hlirtrmgroup_add()hapd
anot ]ultncirtrmgroup_]utput()lf d confs,tatsoiavailSl oeaietV)e stssVmapG
 whel sothsettegi_hlirtrmgroup_add_smrm()banS s ]ultncirtrmgroup_]utput_smrm()r
r*xWris] objeretenttegi_hlirtrmgroup_sSw(t ]ultnAcirtrmgroup **pp);xasesPh geDe changAdesahSchemaotohayCirtrmgroupsPhhbjheyup;veselliAcirtrmgroup_schema
*nsPh T)issmMtdodemayr*exus setootpfereLlgitenfiscox itdaulm eeati itdairtrmtets
 whadddestoom encirtrmgroup hanSlQSmea
*matchtV)e schemaoosted forci zDb
 wh("main", "oiap",horntitdnoe bpstapdattachTcSed forci).hIs
anottegi_hlirtrmgroup_add()hithastc se claddna cirtrmtetstiaetiabcnqeaCmiatiblt
anowled V)ggamnfigu tL schema,oSLFORDESCHEMAneyuaweiroeetfrctteReairtrmgroupsPhhtbje<theyuleft inhapdi Syaets  tmfte.
 u
 whA;airtrmtet schemaoisc|btsid- edoatmiatiblt;wled V)gged forci schemaoin
ano itdeoe eway asoairtstegi_hlirtrmset_a  sy(). SeA_zsicLlgi,tfiseeach
ano Sl oeinh itdairtrmtet,beeartdexshisnaySd forcio Sl oewled:
r*
 wh<ul>
 wh  <li>hlQemsoe e ds r,sieeibiseea cirtrmtet,bapd
ano  <li>haetleastsasomapy ctlumnsiayuawcordiLeinh itdairtrmtet,bapd
ano  <li>h itdprimary key atlumns innV)ggeoe eposiconfdayuawcordiLeinibje ssssss itd|irtrmtet.
 ue</ulfibj
 whss eoutput psteea cirtrmgroup ibje<tialwaysihashV)ggtoe btchemaofs eet
*noSd forcionometV)iLeo -DSnluishf d conf. InbcacistweRr) cirtrmsets thmode
*noeohttegi_hlirtrmgroup_add()hhrveofewrlbcblumn
am aadthehcorawypbtdapGMtSl o
 whinhlupaed forci schema,otutcsbaietfitc seinoo -DSnlup Syaar Sbcblumn
 wheaeuestfn bblup ed forci schema. ssislma-msbiqetossil oSnoocbmbin d
 wh|irtrmtetshV)usshrveodiffNT nten rol shistcolumnsifiseahsaohecttSl o
anowledinoagcirtrmgroup,oproeidec APatttity fr eotrrlwisaoatmiatibltr
r*xWris] objeretenttegi_hlirtrmgroup_schema(t ]ultnAcirtrmgroup*,nttegi_h*,r|bts tceAP *zDb);xasesPh geDe changAdesA Cirtrmset TosA CirtrmgroupsPhhbjheyup;veselliAcirtrmgroup
 u
 whAddnatcrcirtrmst ledinaV)ggcirtrmteth(oshpatchset)einibuffNT]pDd fb(tize
 utnDd fbby] s)stoom encirtrmgroup.sPh
 whIsteeetbuffNT]|btt Sss aepatchset,heetnfallepriortcalgsr clmeislf d conf
*noonnV)ggeoe ecirtrmgroup ibje<timea
*atsoihrveoseA_zsiec patchsets.dOr,ris
ano itdbuffNT]|btt Sss aeairtrmtet,bsoimudt hrveoteReearliertcalgsr clmeis
**hf d conf. Otrrlwisa,bSLFORDEERRORneyuaweiroeetfrctno cirtrmstayebaddde
**stoom encirtrmgroup.sPh
 whRowsh ledinaV)ggcirtrmtethfrctcirtrmgroup arecids r,sieeibiseea eae Sstin
ano itiruPRIMARYoKEYhatlumns. A;airtrmtinnV)ggcirtrmtet isc|btsid- edoto
anoa  syoeohV)ggeoe ea
n as aeairtrmoa awadyptresentoinnV)ggcirtrmgroup is
ano itdVwobrowshhrveoteReeoe eprimary key.
ru
 whCirtrmsttoerowshV)ussncbcnqef awadypappearsinnV)gecirtrmgroup areritysaor y copieebin o it.dOr,ristbotE eeRonewrcirtrmsetofrctteReairtrmgroupsPhhaCan Ssrcirtrmst iatta  syoeohaysaohectrow,olup funLlncbtt-hAsbpstV)g
 wh|irtrmgroup dependsMonnV)geeypettfaeach airtrm,hasoaiLu
ns:
r*
 wh<tSl ohbordQr=1 tmyle="margin-left:8ex;margin-rrla
:8ex">
 wh  <tr><ed smyle="whell-space:tre">Exshil_ghCirtrm  </th>ibje sssss<ed smyle="whell-space:tre">NSwuCirtrme sssss</th>ibje sssss<ed>Output Cirtrm
 wh  <tr><ed>INSERTe<ed>INSERTe<ed>ibje sssssTeRonewrcirtrmbiyuignoied.essislorseinceabcnqe]r,s]eifteea newibje ssssscirtrmsetowayuawcordiLeimmedia] gihaftrle itdairtrmtetsef awadyibje sssssadddestoom encirtrmgroup.
 wh  <tr><ed>INSERTe<ed>UPDATE <ed>ibje sssssTeRoINSERTeairtrmoremainssinnV)gecirtrmgroup.hTitdeae SstinnV)g
*noooooooINSERTeairtrmoaroomodzsieeiaseifteea a
n  ayuinserNdebbiseea
*noooooooMxshil_ghairtrmoarctteRn upds]meeaccordogu nooeeRonewrcirtrm.
 wh  <tr><ed>INSERTe<ed>DELETE <ed>ibje sssssTeRoMxshil_ghINSERTeiscremoveeifn bblupecirtrmgroup.hTitdDELETE isibje ssssscnqefddde.
 wh  <tr><ed>UPDATE <ed>INSERTe<ed>ibje sssssTeRonewrcirtrmbiyuignoied.essislorseinceabcnqe]r,s]eifteea newibje ssssscirtrmsetowayuawcordiLeimmedia] gihaftrle itdairtrmtetsef awadyibje sssssadddestoom encirtrmgroup.
 wh  <tr><ed>UPDATE <ed>UPDATE <ed>ibje sssssTeRoMxshil_ghUPDATE hemainss ledinaV)ggcirtrmgroup.hIC iscamenddeibje ssssssxo iaeteea fcatmiany-DSneae Sstfrtdaseifteea a
n  ayuupds]meeonca
*nooooooobiseea Mxshil_ghairtrmoarctteRn againobiseea newrcirtrm.
 wh  <tr><ed>UPDATE <ed>DELETE <ed>ibje sssssTeRoMxshil_ghUPDATE iscreplacMdobiseea newrDELETE  ledinaV)gibje ssssscirtrmgroup.
 wh  <tr><ed>DELETE <ed>INSERTe<ed>ibje sssssIfionetOr]mM topstthehcolumnheae SstSsrluptr
n ioserNdebbiseea
*nooooooonewrcirtrmbdiffNTifn bbluoci Ssrluptr
n nyle] debiseea Mxshil_gibje ssssscirtrm,seea Mxshil_ghDELETE iscreplacMdobisapAUPDATE  ledinaV)gibje ssssscirtrmgroup. Otrrlwisa,bifilup iaserNdeba
n iscexacAabeteReeoe ibje sssssasnlup Syle] derow,olup Mxshil_ghDELETE iscsaor y discardde.
 wh  <tr><ed>DELETE <ed>UPDATE <ed>ibje sssssTeRonewrcirtrmbiyuignoied.essislorseinceabcnqe]r,s]eifteea newibje ssssscirtrmsetowayuawcordiLeimmedia] gihaftrle itdairtrmtetsef awadyibje sssssadddestoom encirtrmgroup.
 wh  <tr><ed>DELETE <ed>DELETE <ed>ibje sssssTeRonewrcirtrmbiyuignoied.essislorseinceabcnqe]r,s]eifteea newibje ssssscirtrmsetowayuawcordiLeimmedia] gihaftrle itdairtrmtetsef awadyibje sssssadddestoom encirtrmgroup.
 wh</tSl ofibj
 whIStmeRhnewrcirtrmseto|btt Sss cirtrmst ooa tSl oetiaetiaba awadyptresent
 whinhlupacirtrmgroup,otetnnV)ggs rol bpstcolumnsifrctteReposiconfdpstV)g
 whprimary key atlumns fiseV)ggVSl oomea
*beuodasisS-me. IStmeisliyucnqeteR
 wh|aci,hV)ishf d confifails;wled SLFORDESCHEMA. Excep*, isteea cirtrmgroupsPhhtbje<thhashbeohocmnfigu tL  led aeed forci schemaoo -DSnlup
anottegi_hlirtrmgroup_schema()beDe,heetnnitSiaetossil oSnoocbmbin dairtrmtets
 wh led diffNT nten rol shistcolumnsifiseahsaohecttSl o,oproeidec APat
ano ity fr eotrrlwisaoatmiatibltr
rj
 whIStmeRhiaput cirtrmsetpappearst oobec|brruptofrctteReabrruptonfiis
*noSs</c]me,ASho],(MCORRUPTrithaweiroee. Or,ristani]ut-of-memory aCtdypesmsPhhtr,s]
tdur-DSnprorla
-DS,hluissf d confiuAts i plr8],(MNOMEM.
ru
 whIMtatcrcacis,bifiapdMAaise]r,s]
tV)e sts] tofolup funLlncbtt-hAsbpstV)g
 wh|irtrmgroup isuu Syaets .hIfhsedMAaise]r,s]
,bSLFORDEOKhithaweiroee.
r*xWris] objeretenttegi_hlirtrmgroup_add(t ]ultnAcirtrmgroup*,netennDd f,hIflsn*pDd f);xasesPh geDe changAdesA SaohectCirtrmeTosA CirtrmgroupsPhhbjheyup;veselliAcirtrmgroup
 u
 whT)ishf d confiadds V)e saohect|irtrmicexn*hAabeindicV)iLebyt ieli
lra(is
anothmodesashV)ggteaCtdnarren-mettoom encirtrmgroup ibje<t.hTitdaulmste i
anoaddapGMV)ggcirtrm fr ejustsasonescrib sefise[ttegi_hlirtrmgroup_add()]r
rj
 whIStmeRhcirtrmbiyusu rla
fu"gihadddestoom encirtrmgroup,bSLFORDEOKhit
anouAts iee.hOtrrlwisa,banAShosiesMAaiseimmedithaweiroee.
an
 whlQemi
lra(isemea
*taetC tohaheaeidhentryewetnnV)ishf d confiis astc s.sPh IStitinceabcnq,bSLFORDEERRORneyuaweiroeetfrctno cirtrmdisladddestoom eibjecirtrmgroup. AdeifereLlgi,t ieli
lra(isemea
*cnqehrveobeohoopenmeewled
ano ielShoORDECHANGESETAPPLY_INVERTeflSg.hInnV)isscrcibSLFORDEERRORneyuatso
anouAts iee.
r*xWris] objeretenttegi_hlirtrmgroup_addAcirtrm(x rttegi]dscirtrmgroup*,x rttegi]dscirtrmset_i)ir*x);xaaasesPh geDe changObn SstA Ctmiosica CirtrmsettFo bbA CirtrmgroupsPhhbjheyup;veselliAcirtrmgroup
 u
 whObn SstaybuffNT]|btt SsapGMagcirtrmteth(oshpatchset)erepresentapGMV)g
*no|exn*hAncbtt-hAsbpstV)ggcirtrmgroup.hIStmeRhiaputsstoom encirtrmgroup
 wh eietV)emselvesdairtrmtets,hV)ggoutput ittagcirtrmtet. Or,ristV)g
*noiaputss eietpatchsets,hV)ggoutput ittatsoiaepatchset.
Pn
 whAs wled V)ggoutput psteea t ]ultnsla
rnf_lirtrmset(r apd
anot ]ultnsla
rnf_patchset()lf d confs,tatcrcirtrmstrelV)idoeohaysaohec
ano Sl oeayebgroupdestogetrrlsinnV)geoutput psteeishf d conf. TSl osgappear
 whinhlupaeoe eordQr asoairteea eMAy fuolytcirtrmsetpadddestoom encirtrmgroup.
 whIStmeRhteaCtdnirtsubs*
* ntccirtrmtetsefdddestoom encirtrmgroup |btt Ss
 wh|irtrmtyfisetSl oshV)ussncbcnqefppearsinnV)gefuolytcirtrmset,o ity fr 
anoa  enddeiontoom enendbpst itd]utput cirtrmset, againoinnV)geordQrhin
 wh hichh ity fr efuolytenimut)irme.
an
 whIfiapdMAaise]r,s]
,banAShosiesMAaiseimmediyuaweiroeehfrctteRe]utput
 wheariSl os (*pnDd f)banS (*ppDd f)bayebtetstop0.hOtrrlwisa,bSLFORDEOK
 whithaweiroeehfrctteRe]utput  ariSl os ayebtetstopV)e saz bpstapd aritypaetCNT tohteRe]utput buffNT,Yawype<tovely.hInnV)isscrcibiC iyugul
anouAypbtsiliegiytpso itdiartmrircoav inuLlgitfreox itdbuffNT]o -DSta
 wh|atcrrcot ]ultnAfreoi).
 *xWris] objeretenttegi_hcirtrmgroup_]utput(x rttegi]dscirtrmgroup*,x reten*pnDd f,hhhhhhhhhhhhhhhhhhhh/whOUT:hSizedpst]utput buffNTeiniby] seb*x rIflsn**ppDd fhhhhhhhhhhhhhhhhhhh/whOUT:hPaetCNTSuxo]utput buffNTeb*x);xasesPh geDe changDsle] oAuCirtrmgroup Obje<tsPh DESTRUCTOR:mstegi_hAcirtrmgroupsP*xWris] objerIflsnt ]ultncirtrmgroup_nele] (ttegi]dscirtrmgroup*);xasesPh geDe changA  syoA Cirtrmset TosA Dd forci
Pn
 whA  syoaycirtrmtet ishpatchset tooaySd forci.hTitsggf d confsyattiaproto
anoupds] tV)gg"main"red forci attachTcStoohanSlQSdbowled V)ggairtrmtyfiund in
ano itd|irtrmtetsthmodesviaolup teaCtdnarctteirdnarren-met.
ru
 whAtcrcirtrmstmameebyt iesggf d confsyartdenclos seinoaysrvetaetC transa conf.
 whIfhapy oorrlbMAaise(asid-ifn bba aCastraetebfailu thwetnnattiaprogu no
 wh ritostoothehtarretsed forci)e]r,s]
,btetnnV)ggsrvetaetC transa confhit
anouotc seethe,bawytorapGMV)ggtarretsed forci nolits osrlunalests] ,enpdian
 whShosiesMAaiseimmeduAts iee.hAdeifereLlgi,tsmfrtinge led el soth 3.51.0,
ityapdMAaiseimmednpdiMAaisemla
agehV)ussmayr*exa rla
iLeo -DSnlup
ano[stegi_h_MAaimme()]hnpdiit ]ultn_MAamsg()]heDeyua thleft inhtup ed forci
anohanSlQ.
an
 whlQemfiurtrnarren-met(xFilCNT)tthmodestoo iRsggf d confsyislgulY"filCNT
 wh|atcethe". ssislmayr*exthmodesNuxa,hinowhichhcrci atcrcirtrmstinnV)g
 wh|irtrmtet fr efhosi estoom enSd forci.hFirtstegi_hlirtrmset_a  sy() apd
anot ]ultn_lirtrmset_a  sy_v2(),riftissithseteNuxa,heetnnissithinen-meeonca
*nofiseeachgtSl ocaffNctdesbytaetleastsonRhcirtrmbinnV)ggcirtrmtet.dInnV)is
 wh|acieV)ggVSl oosoe e sothmodesashV)ggteaCtdnarren-me,enpdia copyhps
ano itdcbtt-xt paetCNT thmodesashV)ggtixtrnarren-mettota  sy()horna  sy_v2()
ityasolup fuoly.hIStmeRh"filCNTh|atcethe"irets i pbavr,[eetnnnoyattiaprois
 whmameetota  syhapy cirtrmsstoothehtal o.dOtrrlwisa,bifilup uAts ibvae Ssiy
 whnon-bavr,hatcrcirtrmstrelV)idoeohV)ggVSl ooar)thttiaprme.
an
 whFirtstegi_h_lirtrmset_a  sy_v3(),rV)ggxFilCNThaatcethehithinen-meeonca
*noprlbcirtrm.hTitdteaCtdnarren-metinnV)isscrcibiseapAveselliAcirtrmset_i)ir
*nhV)ussmayr*exquMAiiLeo -DSnlupeusuLlneDeyuairteea detailstpso itdiexn*hA
 wh|irtrm.hIStmeRh"filCNTh|atcethe"irets i pbavrtinnV)isscrci,[eetnnnoyattiapr
 whithmameetota  syh itdiexn*hAh|irtrm.hIStitirets i pnon-bavr,heeth|irtrm
 whithfhosi e.
an
 whFirteachgtSl octiaetiabcnqeexcludeLebyt ielfilCNTh|atcethe,hluissf d conf
*nhVestst iattV)ggtarretsed forci |btt Sss aeatmiatiblt;eSl o.sA eSl oeis
PhhaCasid- edoatmiatiblt;ifiatcrofolup f Lu
napGMarextsue:
r*
 wh<ul>
 wh  <li>hlQemeSl oehashV)ggtoe bsoe eashV)ggsoe eawcordiLeinh itibje sssssdairtrmtet,bapd
ano  <li>hlQemeSl oehashaetleastsasomapy ctlumnsiayuawcordiLeinh itibje sssssdairtrmtet,bapd
ano  <li>hlQemeSl oehashprimary key atlumns innV)ggeoe eposiconfdayibje sssssdawcordiLeinh itdairtrmtet.
 ue</ulfibj
 whIStmeRr)tithno ctmiatiblt;eSl o,tissithseteapdMAais,hbuo[nontdospV)g
*nocirtrmstassocis]meewled V)ggVSl ooar)thhosi e.sA wa iiguemla
agehisliysudeibjeviaolup teselliAlog()ymecirtismewled V)ggMAaiseimmedSLFORDESCHEMA. Atgmoa
sPhhtnetsuchgwa iigueisliysudeofiseeachgtSl ocinh itdairtrmtet.
 u
 whFirteachgcirtrmbfise hichh itr)tithaeatmiatiblt;eSl o,tapdattiaproishmame
*nhVoomodzsy V)ggVSl oocbtt-hAsbaccordogu nooeach UPDATE,hINSERTeOr]DELETE
*nocirtrmctiaetiabcnqeexcludeLebytalfilCNTh|atcethe. Ifiat|irtrmicancnqnbe
anoa  si escleafgi,t ielatnfsistrhanSlQrhf d confithmodesasolup fuftrnarren-me
*nhVoostegi_hlirtrmset_a  sy() mayr*exinen-me.sA nescripferer stexacAabewetnsPh  ielatnfsistrhanSlQrhithinen-meefiseeachgtypettfacirtrm isrbeu
n.
 u
 whUnlikerV)ggxFilCNTharren-me,exCCnfsist reiscnqnbe thmodesNuxa. Tea awyr Syibjetfathmo-DSnanytdingeoorrlbm aadaheaeidhf d confitaetCNT asolup xCCnfsist
anoarren-metfrtdi Syaets .
 u
 whEachgtimet ielatnfsistrhanSlQrhf d confiithinen-me,[i
*rea
*rets ibtneibjetfa[SLFORDECHANGESET_OMIT],o[SLFORDECHANGESET_ABORT]  i
ano[SLFORDECHANGESET_REPLACE]. SLFORDECHANGESET_REPLACEireisonlybercuAts iee
 whiStmeRhteaCtdnarren-metthmodestoo ielatnfsistrhanSlQrhitheiorrl
anoSLFORDECHANGESET_DATAyiseSLFORDECHANGESET_gONFLICT.hIfameRhcCnfsist-hanSlQr
anouAts iyuapAitc galeeae S,hapy cirtrmssa awadypmameeayebaotc seethebapd
ano itdiarthVoostegi_hlirtrmset_a  sy() rets i pSLFORDEMISUSE. DiffNT nt
anoa confsyartdtakenebytt ]ultnlirtrmset_a  sy() dependapGMonnV)gevae S
 whaweiroeehbyteach inv
cs]ererofameRhcCnfsist-hanSlQrhf d conf. RAfersto
ano itddocum inaferere i V)ggV)ressPh [SLFORDECHANGESET_OMIT|availSl oeuAts ibvae Ss]ofoledetailsr
r*
 wh<dl>
 wh<dt>DELETE Cirtrms<dd>
 wh  FirteachgDELETE airtrm,olup f d conficheckseifteea tarretsed forci
 wh  |btt Sss aea
n  led V)ggeoe eprimary keyu aeuen(isevae Ss)ofs eet
*no hisrlunalea
n  aeueststors hinnV)ggcirtrmtet.dIStitincea,ifrctteReeae Ss
 wh tstors hinnarthnon-primary key atlumns atsoimatchtV)e  aeueststors hin
 wh t itd|irtrmtetstuptr
n ithnyle] defn bblupetarretsed forci.
rwsPh   Ifiata
n  led match-DSnprimary keyu aeuesyislfiund,hbuo[onetOr]mM tops
 wh t itdnon-primary key fields |btt Sss ae aeuendiffNT ntefn bblupeisrlunal
 wh ta
n  aeuetstors hinnV)ggcirtrmtet,ameRhcCnfsist-hanSlQrhf d conf isibje sinen-mee led [SLFORDECHANGESET_DATA]iashV)ggteaCtdnarren-me.hIfameRibje sSd forcio Sl oehashmM tocblumn
am aadayebawcordiLeinh itdairtrmtet,
*no hinliseea eae SstDf luoci non-primary key fields araoatmiars hagainst
 wh t itd|exn*hAhed forci |btt-hAsb-hapy traeLapGnSd forcio Sl oecolumns
 wh  arecignoied.
rwsPh   Ifinota
n  led match-DSnprimary keyu aeuesyislfiund inhtup ed forci,
 wh t itd|Cnfsist-hanSlQrhf d conf issinen-mee led [SLFORDECHANGESET_NOTFOUND]
ano  thmodesashV)ggteaCtdnarren-me.
rwsPh   IfiV)ggDELETE i
yra(othristhttiaprme,hbuo[Shosiesrets i pSLFORDEgONSTRAINTsPh   (whichhcrnhinlisha  en;ifiaaforeign key aCastraetebisteiolo*ed),rV)g
 wh  |btfsist-hanSlQrhf d conf issinen-mee led [SLFORDECHANGESET_gONSTRAINT]
ano  thmodesashV)ggteaCtdnarren-me.hTiishincludesolup crcibweRr) V)ggDELETE
*no hi
yra(othristhttiaprmebercauci aneearliertcalgstoo ielatnfsistrhanSlQr
*no hf d confiuAts iedo[SLFORDECHANGESET_REPLACE].
r*
 wh<dt>INSERTeCirtrms<dd>
 wh  FirteachgINSERTeairtrm,tapdattiaproishmame noliaserNt itdnSwurow in o
 wh t itdSd forci.hIStmeRhcirtrmtetsrow |btt Sss fewrlbfields m aadtheibje sSd forcio Sl o,ameRhtraeLapGnfields araopopulV)iLe led V)gir Syaar Sibje s aeues.
rwsPh   IfiV)ggattiaprotoliaserNt itdrow fails;ercauci  itdSd forcief awadyibje s|btt Sss aea
n  led V)ggeoe eprimary keyu aeues,t ielatnfsistrhanSlQr
*no hf d confiissinen-mee led meRhteaCtdnarren-metsetsto
ano c[SLFORDECHANGESET_gONFLICT].
rwsPh   IfiV)ggattiaprotoliaserNt itdrow fails;ercauci ofhsomMeoorrlbaCastraeteibje s iolo*etCt(e.g.dNOTeNuxa iseUNIQUE),t ielatnfsistrhanSlQrhf d confiisibje sinen-mee led meRhteaCtdnarren-metsetsto [SLFORDECHANGESET_gONSTRAINT].
 wh  Tiishincludesolup crcibweRr) V)ggINSERTeO
yra(othristre-httiaprmebercauci
 wh  aneearliertcalgstoo ielatnfsistrhanSlQrhf d confiuAts ied
ano c[SLFORDECHANGESET_REPLACE].
r*
 wh<dt>UPDATE Cirtrms<dd>
 wh  FirteachgUPDATE airtrm,hV)ggf d conficheckseifteea tarretsed forci
 wh  |btt Sss aea
n  led V)ggeoe eprimary keyu aeuen(isevae Ss)ofs eet
*no hisrlunalea
n  aeueststors hinnV)ggcirtrmtet.dIStitincea,ifrctteReeae Ss
 wh tstors hinnarthmodzsieeinon-primary key atlumns atsoimatchtV)e  aeues
 wh tstors hinn itd|irtrmtetstuptr
n ithupds]mee ledinaV)ggtarretsed forci.
rwsPh   Ifiata
n  led match-DSnprimary keyu aeuesyislfiund,hbuo[onetOr]mM tops
 wh t itdmodzsieeinon-primary key fields |btt Sss ae aeuendiffNT ntefn bban
*no hisrlunalea
n  aeuetstors hinnV)ggcirtrmtet,ameRhcCnfsist-hanSlQrhf d confibje sissinen-mee led [SLFORDECHANGESET_DATA]iashV)ggteaCtdnarren-me.hSinca
*noooUPDATE airtrmshinlisaCan SsreaeuestfOr]non-primary key fields  iattara
*nooo oobecmodzsiee,hinliseeoci fields nedestoomatchtV)e isrlunaleeaeuestto
ano caIflsnV)e SLFORDECHANGESET_DATAycbtfsist-hanSlQrhaatcethe.
rwsPh   Ifinota
n  led match-DSnprimary keyu aeuesyislfiund inhtup ed forci,
 wh t itd|Cnfsist-hanSlQrhf d conf issinen-mee led [SLFORDECHANGESET_NOTFOUND]
ano  thmodesashV)ggteaCtdnarren-me.
rwsPh   IfiV)ggUPDATE O
yra(othristhttiaprme,hbuo[Shosiesrets i sPh   SLFORDEgONSTRAINT,ameRhcCnfsist-hanSlQrhf d conf issinen-mee led
ano c[SLFORDECHANGESET_gONSTRAINT] thmodesashV)ggteaCtdnarren-me.
rwh  Tiishincludesolup crcibweRr) V)ggUPDATE O
yra(othristhttiaprmehaftrl
 wh  aneearliertcalgstoo ielatnfsistrhanSlQrhf d confiuAts ied
ano c[SLFORDECHANGESET_REPLACE].
r* </dlfibj
 whIt iyutafe nolexecute SLFests] n-met,hinclud-DSnluosmctiaet ritostoothe
ano Sl octiaet itdiartethebrelV)idoeo,efn bb ledinaV)ggxCCnfsist aatcethe.
rwessislornr*exus setoofurtrrld|estomizedV)ggahosiso*etC'slatnfsist
 whawstluconfietrategy.
ru
 whIst itd]utput thee^s</rs (ppReorci)eanS (pnReorci)eari non-Nuxaoapd
ano itdiaput ithnhcirtrmteth(seteahpatchset),[eetnnt ]ultnlirtrmset_a  sy_v2()
ityreisteth(*ppReorci)etootaetC tohah"reorci" V)ussmayr*exus se ledhtup
anottegi_h_reorcirneDeyubuffNTebee ietuAts iigu.hInnV)isscrcib(*pnReorci)
 whithtetstopV)e saz bpstV)e buffNTeiniby] s.hIC iyugulYawypbtsiliegiytpso it
 wh|atcmrircoav inuLlgitfreoxapy suchgbuffNT]o -DStt ]ultnAfreoi).hTitdbuffNT
 whithinlisaLu
cs]meefrctpopulV)iseiftonetOr]mM tocbtfsistss eietenimut)irme
 whwuileta  sy-DSneee patchset.hSestatmm-mes sexniund-DSneee ttegi_h_reorcir
 wheDeyuairtfurtrrlddetailsr
r*
 whTitdbehavioreosnt ]ultnlirtrmset_a  sy_v2()ganS ies stssVmapG e
*ieae-me
ityreisboomodzsieeibisthmo-DSnaocbmbins]ererofsPh [SLFORDECHANGESETAPPLY_NOSAVEPOINT | sepporNdebflSgs]iashV)gg9edhthee^s</rr
r*
 whNotoctiaet itdt ]ultnlirtrmset_a  sy_v2()gbjeres stilgs<b>ex
yrim inal</b>
 whfrctteRree ietsubje<thto cirtrmr
r*xWris] objeretenttegi_hlirtrmset_a  sy(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x retennCirtrmtet,ahhhhhhhhhhhhhhhh/whSizedpstcirtrmtethiniby] seb*x rIflsn*pCirtrmtet,ahhhhhhhhhhhhhh/whCirtrmset blobSb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r r|bts treAP *zTSl hhhhhhhhhhhhh/whTSl oonoe eb*x  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtxhhhhhhhhhhhhhhhhhhhhhh/whFuolytarren-metthmodestooxCCnfsist b*x);xWris] objeretenttegi_hlirtrmset_a  sy_v2(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x retennCirtrmtet,ahhhhhhhhhhhhhhhh/whSizedpstcirtrmtethiniby] seb*x rIflsn*pCirtrmtet,ahhhhhhhhhhhhhh/whCirtrmset blobSb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r r|bts treAP *zTSl hhhhhhhhhhhhh/whTSl oonoe eb*x  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtx,hrrrrrrrrrrrrrrrrrrrrsehFuolytarren-metthmodestooxCCnfsist b*x rIflsn**ppReorci,reten*pnReorci,r/whOUT:hReorci ed fSb*x retenflSgshrrrrrrrrrrrrrrrrrrrrhh/whSESSIONECHANGESETAPPLY_*nflSgshb*x);xWris] objeretenttegi_hlirtrmset_a  sy_v3(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x retennCirtrmtet,ahhhhhhhhhhhhhhhh/whSizedpstcirtrmtethiniby] seb*x rIflsn*pCirtrmtet,ahhhhhhhhhhhhhh/whCirtrmset blobSb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmob*x  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtx,hrrrrrrrrrrrrrrrrrrrrsehFuolytarren-metthmodestooxCCnfsist b*x rIflsn**ppReorci,reten*pnReorci,r/whOUT:hReorci ed fSb*x retenflSgshrrrrrrrrrrrrrrrrrrrrhh/whSESSIONECHANGESETAPPLY_*nflSgshb*x);xasesPh geDe changFlSgshairtstegi_hlirtrmset_a  sy_v2
an
 whlQemfiLu
napGMflSgshreisthmodesviaolup 9edhthee^s</rtto
ano[stegi_hlirtrmset_a  sy_v2]hnpdiit ]ultnlirtrmset_a  sy_v2_smrm]:
r*
 wh<dl>
 wh<dt>SLFORDECHANGESETAPPLY_NOSAVEPOINT <dd>
 wh  UsuLlgi,t ielsla
rnfshmMdulm enclos siatcro
yra(othsoprlfolmeeibi
 wh  a saohect|atcrrcoa  sy_v2()gorna  sy_v2_smrm()binoay[SAVEPOINT].hTitsPh   SAVEPOINT isc|bmmit)iseift itd|irtrmtetsishpatchset iyusu rla
fu"gi
 wh  a  si e,hornaotc seethebifiapdMAaise]r,s]
. SeA_zsy-DSnluishflSg
 wh  |aucist ielsla
rnfshmMdulm uxo]mitnluishsrvetaetC.hInnV)isscrci,ristV)g
*no h|atcmrihashahoopen transa confhirtsrvetaetC wetnna  sy_v2()gis astc s,
 wh ti
*reisawvl tneee partiLlgita  si escirtrmset bynaotcapGtissethe.
rwsPh <dt>SLFORDECHANGESETAPPLY_INVERTe<dd>
 wh  IaverNM itd|irtrmtetsbee ieta  sy-DSnit.hTiishiyue
*ieae-mestotiaverNl_gibje snhcirtrmtetho -DStt ]ultncirtrmset_iaverN()sbee ieta  sy-DSnit.hItiisibje sapdMAaiseVooseA_zsynluishflSg  led aepatchset.
Pn
 wh<dt>SLFORDECHANGESETAPPLY_IGNORENOOPe<dd>
 wh  Dobcnqeinen-mo ielatnfsistrhanSlQrhiartethebfiseapy cirtrmsstPat
ano  w*enenseteacnuLlgitmodzsy V)ggSd forcieav iristV)gys eietfhosi e.
an   SeA_zsicLlgi,tt)issmManst iattV)ggatnfsistrhanSlQrhithcnqeinen-md
ano cfis:
ano ch<ul>
 wh   <li>aenele] ocirtrm ifteea a
n beapGnSyle] decancnqnbelfiund,
 wh   <li>an upds]mocirtrm ifteea modzsieeifields araoa awadypsetsto
ano ccccccV)gir sSwu aeuessinnV)gecCnfsistapGMrow,  i
ano   <li>an iaserNtcirtrm iftatcrfields ofameRhcCnfsistapGMrowtmatch
ano ccccccV)g a
n beapGniaserNde.
ano   </ulfibj
 wh<dt>SLFORDECHANGESETAPPLY_FKNOACTIONe<dd>
 wh  IfnluishflSg itieet,heetnfalleforeign key aCastraetesiinnV)ggtSrretibje sSd forciobehavtdaseifteeays eietdecla tL  led "ONeUPDATE NO ACTIONeON
 wh  DELETE NO ACTION",eav iristV)gysaraoacnuLlgitCASCADE, RESTRICT, SETeNuxa
*no his SETeDEFAULTr
r*x#SyaetslShoORDECHANGESETAPPLY_NOSAVEPOINT   0x0001x#SyaetslShoORDECHANGESETAPPLY_INVERTeeeeeeee0x0002x#SyaetslShoORDECHANGESETAPPLY_IGNORENOOPeeee0x0004x#SyaetslShoORDECHANGESETAPPLY_FKNOACTIONeeee0x0008xasesPh geDe changCbtstatesiPhmodesTohlQemCCnfsist HanSlQr
*nsPh Vae SstV)ussmayr*exthmodesashV)ggteaCtdnarren-mettooayaCnfsist-hanSlQrr
r*
 wh<dl>
 wh<dt>SLFORDECHANGESET_DATA<dd>
 wh  TielatnfsistrhanSlQrhithinen-mee led CHANGESET_DATAyashV)ggteaCtdnarren-me
ano  wetnfprorla
-DSiarDELETE iseUPDATE airtrm;ifiaaa
n  led V)ggawquiied
 wh ePRIMARYoKEYhfields  sotresentoinnV)gged forci,hbuo[onetOr]mM topthrl
 wh  (nnfitrimary-key)hfields modzsieeibisV)ggupds]moncbcnqeaCan SsrV)g
*no hex
yctdes"bee ie"s aeues.
rwsPh   T)gecCnfsistapGMrow, innV)isscrci,[iyugulYSd forciou
n  led V)ggmatch-DS
ano  trimary key.
ru
 wh<dt>SLFORDECHANGESET_NOTFOUND<dd>
 wh  TielatnfsistrhanSlQrhithinen-mee led CHANGESET_NOTFOUNDyashV)ggteaCtdibje sarren-metwetnfprorla
-DSiarDELETE iseUPDATE airtrm;ifiaaa
n  led V)gibje sawquiiedePRIMARYoKEYhfields  socnqetresentoinnV)gged forci.
rwsPh   T)gr)tithno ctnfsistapGMrowtinnV)isscrci. Tea awyr SytDf iaen--DSnlup
ano tt ]ultnlirtrmset_cbtfsist()gbjerfrtdi Syaets .
 u
 wh<dt>SLFORDECHANGESET_gONFLICT<dd>
 wh  CHANGESET_gONFLICTe sothmodesashV)ggteaCtdnarren-mestoo ielatnfsist
 wh  hanSlQrhwuiletprorla
-DSianrINSERTeairtrmoist itd]
yra(othrw*enenawyr Sibje sin duosiso* eprimary keyu aeues.
rwsPh   T)gecCnfsistapGMrowtinnV)isscrcibisegulYSd forciou
n  led V)ggmatch-DS
ano  trimary key.
ru
 wh<dt>SLFORDECHANGESET_FOREIGN_KEY<dd>
 wh  Ifnforeign key hanSligueislenSl od,enpdia  sy-DSnahcirtrmtethleaves eet
*no hSd forcioinoaysts] t|btt SsapGMforeign key eiolo*etCs,o ielatnfsist
 wh  hanSlQrhithinen-mee led CHANGESET_FOREIGN_KEYhashV)ggteaCtdnarren-me
ano  exacAabeoncasbee iet itd|irtrmtetsisc|bmmit)is.hIfameRhcCnfsistrhanSlQr
*no hrets i pCHANGESET_OMIT,heeth|irtrmt,hinclud-DSnluosmctiaet|aucid eet
*no hforeign key aCastraetebeiolo*etC, araoatmmit)is.hOr,ristitirets i 
 wh  CHANGESET_ABORT,t itd|irtrmtetsiscaotc seethe.
rwsPh   Nod|exn*hAhiseimnfsistapGMrowtinfolmatothristproeidec.hTh eonlisf d confibje sitSiaetossil oSnoocatcronnV)ggeu  si esttegi]dscirtrmset_i)irnhanSlQsPh  sissttegi_hlirtrmset_fk_cbtfsists().
 u
 wh<dt>SLFORDECHANGESET_gONSTRAINT<dd>
 wh  Ifnapy oorrlbaCastraetebeiolo*etCe]r,s]
twuileta  sy-DSnat|irtrmi(i.e.ibje snhUNIQUE, CHECKhiseNOTeNuxa aCastraete),t ielatnfsistrhanSlQrhisibje sinen-mee led CHANGESET_gONSTRAINTsashV)ggteaCtdnarren-me.
rwsPh   T)gr)tithno ctnfsistapGMrowtinnV)isscrci. Tea awyr SytDf iaen--DSnlup
ano tt ]ultnlirtrmset_cbtfsist()gbjerfrtdi Syaets .
 u
 wh</dlfib*x#SyaetslShoORDECHANGESET_DATAyyyyyyyy1x#SyaetslShoORDECHANGESET_NOTFOUNDyyyy2x#SyaetslShoORDECHANGESET_gONFLICTeeee3x#SyaetslShoORDECHANGESET_gONSTRAINTs 4x#SyaetslShoORDECHANGESET_FOREIGN_KEYh5xasesPh geDe changCbtstatesiRAts iedoByhlQemCCnfsist HanSlQr
*nsPh AlatnfsistrhanSlQrhiartethebrea
*rets ibtnerofolup f Lu
napGMV)resu aeues.
rwsPh <dl>
 wh<dt>SLFORDECHANGESET_OMIT<dd>
 wh  IfnalatnfsistrhanSlQrhrets i pV)iss aeuetnooseA_zal a confhitdtaken.hTitsPh   cirtrmctiaet|aucid eetlatnfsistrithseteahosi e.sTielsla
rnfhmMdulm
 wh  |bttinumsstoothehsSxthcirtrmbinnV)ggcirtrmtet.
 u
 wh<dt>SLFORDECHANGESET_REPLACE<dd>
 wh  Tiiss aeuetreisonlybercuAts ieehiStmeRhteaCtdnarren-mettoo ielatnfsist
 wh  hanSlQrhwasoSLFORDECHANGESET_DATAyiseSLFORDECHANGESET_gONFLICT.hIfameisibje siyucnqeteRscrci,[apy cirtrmssa  si esto fareayebaotc seethebapdtV)g
*no h|atchVoostegi_hlirtrmset_a  sy() rets i pSLFORDEMISUSE.
rwsPh   IfiCHANGESET_REPLACEiiseaweiroeehbytanAShoORDECHANGESET_DATAycbtfsist
 wh  hanSlQr,btetnnV)ggctnfsistapGMrowtitheiorrluupds]meeornSyle] d, dependapG
*no hinnV)geeypettfacirtrmr
rwsPh   IfiCHANGESET_REPLACEiiseaweiroeehbytanAShoORDECHANGESET_gONFLICTecbtfsist
 wh  hanSlQr,btetnnV)ggctnfsistapGMrowtithremoveeifn bblupeed forci ancta
ano tteaCtdnattiaprotola  syh itdiirtrm isrmame. IStmeislteaCtdnattiaprofails,
 wh t itdisrlunalea
n ithrestors htoom enSd forcisbee iet|bttinuigu.
 u
 wh<dt>SLFORDECHANGESET_ABORT<dd>
 wh  Ifnluishvae Ssiyeaweiroee,[apy cirtrmssa  si esto fareayebaotc seetheibje sapdt itdiarthVoostegi_hlirtrmset_a  sy() rets i pSLFORDEABORT.
 wh</dlfib*x#SyaetslShoORDECHANGESET_OMITeeeeeee0x#SyaetslShoORDECHANGESET_REPLACEiyyy1x#SyaetslShoORDECHANGESET_ABORTeeeeee2xasesPh geDe changReorcapGMcirtrmsetsibjeEXPERIMENTAL
 u
 whSeppoci  itr)tithaesica uost-DSnatSd forcioinosts] tS0. Anc APat
anomodzsicaconfsyartdmame n)ussmove n)ussed forci nolsts] tS1 ancta
anocirtrmtetsrwcordiLe( itd"u
csl"ocirtrmtet).hTitC, ad|irtrmtetsbaode
*noinnS0siyeawceiveeifn bbanoorrlbsica ( itd"remote"ocirtrmtet)oapd
anofhosi estoom enSd forci.hT enSd forcisisegulnoinosts] 
ano(S1+"remote"),tweRr) V)ggexacAlsts] tdependsMonnapy ctnfsist
 whawstluconfidA_z
rnfsh(OMITeornREPLACE)dmame wuileta  sy-DSn"remote".
 whReorcapGMad|irtrmtetsisctooupds]moiettoo a-mo iose ctnfsist
 whawstluconfidA_z
rnfshin o acimut),ssxo iaeteea eoe ecbtfsists
 whncbcnqehrveotobercuAstlveeielseweRr) innV)ggnetwore.
rwsPh Fiseexaor r,ristbotE eeRou
csl anctremoteccirtrmtetseaCan Ssran
*noINSERTeOfameRheoe ekey nfi"CREATE TABLE t1(aePRIMARYoKEY, b)":
rwsPh   u
csl:ooINSERTeINTO t1 VALUES(1, 'v1'r;
 wh tremote:oINSERTeINTO t1 VALUES(1, 'v2'r;
 w
 whfrctteRlatnfsistrawstluconfiiscREPLACE,btetnnV)ggINSERTeairtrmois
 whawmoveeifn bblupeu
csl cirtrmteth(itowayuoverridden). Or,ristV)g
*noatnfsistrawstluconfiwayu"OMIT",btetnnV)ggu
csl cirtrmtethis modzsiee
*notoliasteadeaCan Ss:
rwsPh           UPDATE t1 SETeb = 'v2' WHERE a=1;
 w
 whCirtrmsb ledinaV)ggu
csl cirtrmtethayebawbaodehasoaiLu
ns:
r*
 wh<dl>
 wh<dt>L
csl INSERT<dd>
 wh  Tiissreisonlybatnfsistr led aeremotecINSERT.hIfameRhcCnfsist
 wh trestluconfiwayuOMIT,heetnladdnaneUPDATE airtrm;toom enawbaodesPh   cirtrmtet. Or,ristV)goatnfsistrawstluconfiwayuREPLACE,baddsPh   noorogu nooeeRoawbaodehcirtrmtet.
 u
 wh<dt>L
csl DELETE<dd>
 wh  Tiissreisatnfsistr led aeremotecUPDATE Or]DELETE.hInnbotE cacistV)g
*no honlybtossil oSawstluconfiiscOMIT.hIfameRhremotec]
yra(othrwasha
 wh  DELETE,heetnladdnno cirtrmdnooeeRoawbaodehcirtrmtet.hIfameRhremote
*no ho
yra(othrwashan UPDATE,htetnnV)ggone.* fields ofaairtrmoarggupds]mdsPh   toerefle<tht)ggnew.* eae SstinaV)ggUPDATE.
 u
 wh<dt>L
csl UPDATE<dd>
 wh  Tiissreisatnfsistr led aeremotecUPDATE Or]DELETE.hIstiticbtfsists
 wh r led aeDELETE,hfrctteRlatnfsistrawstluconfiwayuOMIT,heetnlV)ggupds]mibje siyuairtrmebin o anrINSERT.hAnyhi Syaets  eae SstinaV)ggnew.* rwcord
*no hfn bblupeupds]mocirtrm aietfitc seinoo -DSnlup one.* eaeuestfn b
 wh t itdctnfsistapGMDELETE.hOr,ristV)goatnfsistrawstluconfiwayuREPLACE,
 wh t itdUPDATE airtrm;iscsaor y omit)isefn bblupeawbaodehcirtrmtet.
 u
 wh  Ifnatnfsistrith led aeremotecUPDATE frctteRlawstluconfiiscOMIT,heetn
 wh t itdine.* eaeuestayebawbaodeho -DSnlup new.* eae SstinaV)ggremote
*no h|irtrm.hOr,ristV)goawstluconfiiscREPLACE,btetnnV)ggairtrm;isccopieeibje sinnooeeRoawbaodehcirtrmteth led upds]msSnoocblumns atsoiupds]meebi
 wh  V)ggctnfsistapGMremotecUPDATE awmovee. IStmeislmManstnoocblumns w*ene
 wh  bggupds]md,nV)ggairtrm;iscomit)is.
r* </dlfibj
 whAgu
csl cirtrmsmayr*exawbaodehagainst multipletremoteccirtrmt
 whsaoultaneously.hIf a saohectkey is modzsieeibismultipletremote
anocirtrmtets,o ity fr  cbmbin dhasoaiLu
nssbee iet itdu
csl cirtrmtet
anoiyeawbaode:
r*
 wh<ul>
 wh   <li>hIStmeRr)thashbeohoonetOr]mM toREPLACEiawstluconfsMonnasPh         key,tissithawbaodehaccordogu nooaoREPLACE.
 u
 wh   <li>hIStmeRr)thaveobeohonooREPLACEiawstluconfsMonna key,teetn
 wh tttttttV)ggu
csl cirtrmtethis awbaodehaccordogu nooV)ggmoa
*rec-me
ano        OfameRhOMITeawstluconfs.
 ue</ulfibj
 whNotoctiaetatnfsistrawstluconfstfn bbmultipletremoteccirtrmtetsefrg
*noatmbin dhonna 
yr-fieldsbaois,ocnqetyr-a
n. ssislmManst iattinnV)g
 wh|aci ofhmultipletremotecUPDATE O
yra(oths,hsomMefields ofaaysaohec
anou
csl cirtrmsmayr*exawbaodehfornREPLACE wuiletoorrlstayebawbaodehe i
anoOMIT.
ru
 whIMtordQrhtoereorci agu
csl cirtrmtet,ameRhremoteccirtrmtethrea
*fuoly
 whb efhosi estoom enu
csl Sd forciso -DStt ]ultncirtrmset_a  sy_v2()ganS
*not)e buffNTeofareorci infolmatothrcaptuied.esses:
rwsPh <ol>
 wh  <li>hAnhveselliAreorcirntbje<theyulssV)iLebytorcLapG
ano       vesellireorcir_lssV)i().
 ue  <li>hlQemsewntbje<theyulmnfigu tL  led eeRoawbaod buffNTeobn Ssdetfn b
 wh t     vesellicirtrmset_a  sy_v2()gbytorcLapGnttegi_hreorcir_lmnfigu t().
 ue       IfameRhu
csl cirtrmtethis tobercuAbaodehagainst multipletremote
 ue       cirtrmtets,o itnnttegi_hreorcir_lmnfigu t()hvh*enenbtdiartmeibje ssssssmultiplettimes,hinhlupaeoe eordQr  iaeteea multiple
 wh t     vesellicirtrmset_a  sy_v2()gcalgsr eietmame.
 ue  <li>hEachgu
csl cirtrmtethis awbaodehbytorcLapGnttegi_hreorcir_reorci().
 ue  <li>hlQemveselliAreorcirntbje<theyunyle] debisorcLapG
ano       vesellireorcir_nele] ().
 ue</olfib*xeypeSya stsuctmveselliAreorcirnveselliAreorcir;xasesPh geDe changCssV)iMad|irtrmtetsreorcirntbje<t.ibjeEXPERIMENTAL
 u
 whALu
cs]mhaysSwu|irtrmtetsreorcirntbje<t.hIstsu rla
fu",hteth(*ppNew)sto
anotaetC tohtQemsewntbje<thanctrets ibSLFORDEOK.dOtrrlwisa,bifiapdMAais
*noir,s]
,brets ibanAShosiesMAaiseimmed(e.g.dSLFORDENOMEM)ganS seth(*ppNew)
*notolNuxa.sP*xWris] objeretenttegi_hreorcir_lssV)i(veselliAreorcirn**ppNew);xasesPh geDe changCmnfigu tMad|irtrmtetsreorcirntbje<t.ibjeEXPERIMENTAL
 u
 whCmnfigu tM itd|irtrmtetsreorcirntbje<thtoereorci cirtrmtetsefccordogu
*notolV)goatnfsistrawstluconfsonescrib sebisbuffNT]pReorci (tize nReorci
 whby] s),e hichhmudt hrveobeohoobn Ssdetfn bna 
reviousdiarthVo
 whsesellicirtrmset_a  sy_v2().sP*xWris] objeretenttegi_hreorcir_lmnfigu t(x rttegi]dAreorcir*,x retennReorci,r|bts tIflsn*pReorci
);xasesPh geDe changReorci agcirtrmtet
anoEXPERIMENTAL
 u
 whArren-mettIMtmea
*taetC tohahbuffNT]|btt SsapGMagcirtrmtethnIniby] s
anoin saz .hT)ishf d confiaLu
cs]msefrctpopulV)ishahbuffNT] led aecopy
*noiStmeRhcirtrmtetsrwbaodehaccordogu nooV)gglmnfigu s]ererofameR
 whaworcirntbje<ththmodesasolup fuolytarren-me.hIstsu rla
fu",h(*ppOut)
 whithtetstoptaetC tohtQemsewnbuffNT]|btt SsapGMeeRoawbaodehcirtrmtethanS
*no(*pnOut) nolits tize iniby] sefrctSLFORDEOKhuAts iee.hIC iyugul
 whawspbtsiliegiytpso itdiartmrircoav inuLlgitfreox itdsewnbuffNT]o -DS
 whseselliAfreoi).hOtrrlwisa,bifiapdMAaisoir,s]
,b(*ppOut)banS (*pnOut)
 whayebtetstopbavrtnpdianhShosiesMAaiseimmeduAts iee.sP*xWris] objeretenttegi_hreorcir_reorci(x rttegi]dAreorcir*,x retennIn,r|bts tIflsn*pIn,
 reten*pnOut,rIflsn**ppOutx);xasesPh geDe changDsle] oad|irtrmtetsreorcirntbje<t.ibjeEXPERIMENTAL
 u
 whDsle] o itd|irtrmtetsreorcirntbje<thnpdiarthassocis]meeawsturc s.hT)gr)
 whsh*enenbtdonRhcalgstoo iishf d confifiseeachgsu rla
fu" inv
cs]ere
*noiStvesellireorcir_lssV)i().
 *xWris] objerIflsnt ]ultnreorcir_nele] (veselliAreorcirn*p);xasesPh geDe changStssVmapG Vl soths ofabjerf d confsr
r*
 whTitdsix stssVmapG bjerxxx_smrm()bf d confsycirveosimilaT]purpos sitoom eibjecorawypbtdapGMnon-stssVmapG bjerf d confs:
r*
 wh<tSl ohbordQr=1 tmyle="margin-left:8ex;margin-rrla
:8ex">
 wh  <tr><ed>StssVmapG f d conf<ed>Non-stssVmapG e
*ieae-me</th>ibje s<tr><ed>sesellicirtrmset_a  sy_smrm<ed>it ]ultnlirtrmset_a  sy]ibje s<tr><ed>sesellicirtrmset_a  sy_smrm_v2<ed>it ]ultnlirtrmset_a  sy_v2]ibje s<tr><ed>sesellicirtrmset_|btcs]_smrm<ed>it ]ultnlirtrmset_|btcs]]ibje s<tr><ed>sesellicirtrmset_iaverN_smrm<ed>it ]ultnlirtrmset_iaverN]ibje s<tr><ed>sesellicirtrmset_smfrt_smrm<ed>it ]ultnlirtrmset_smfrt]ibje s<tr><ed>sesellisla
rnf_lirtrmset_smrm<ed>it ]ultnsla
rnf_lirtrmset]ibje s<tr><ed>sesellisla
rnf_patchset_smrm<ed>it ]ultnsla
rnf_patchset]
 ue</tSl ofibj
 whNon-stssVmapG f d confsy iattaccep* cirtrmtetse(oshpatchsets)ofs iaput
 whawquiie  iaeteea entartd|irtrmtetsbetstors hinna saohectbuffNTeinimemory.ibjeSimilaTgi,tt)osmctiaetrets ibad|irtrmtetsishpatchset dossxobynaAts iigu
 whaypaetCNT toha saohectlSrretbuffNTeaLu
cs]meeo -DStt ]ultnAmaLu
c().
 ueNolmallynluisheyulmnv ii-me.hHowwvl ,bifiapdahosiso*etC runiigueinnasPh low-memory environn-metissawquiiedetoohanSlQSeMAy lSrretcirtrmtets,o itsPh lSrretcbttiguousdmemory aLu
cs]onfsyawquiiedeornr*ecomMeonavrus.
ru
 whIMtordQrhtoeaIflsnV)istprol om,liasteadeofaaysaohectlSrretbuffNT, iaput
 wh sothmodestoha stssVmapG bjerf d confsobynwayeofaayiartethebf d confiAPat
ano itlsla
rnfshmMdulm inen-msotolialssm inallyyawquestdiaput ed fSfs itois
 whawquiied.hIMtatcrcacis,baepair ofabjerf d conf thee^s</rs suchgayibjibje <
re>ibje &nbsp;     etennCirtrmtet,ibje &nbsp;     Iflsn*pCirtrmtet,ibje </
re>ibj
 whIscreplacMdobi:ibjibje <
re>ibje &nbsp;     eten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),ibje &nbsp;     Iflsn*pIn,
bje </
re>ibj
 whEachgtimet ielxIaputhaatcethehithinen-meebisV)ggsla
rnfshmMdulm,olup fuoly
 whayren-metthmodesithaeatpytpso itdeu  si estIMtcbtt-xt paetCNT.hTitdteaCtd
 whayren-me, pDd f,rpaetCs tohahbuffNT](*pnDd f)bby] sein saz .hAssumapGMno
 whMAaise]r,s]
tV)e xIaputh^s<hodhsh*enenatpytup toh(*pnDd f)bby] sepsoed f
anointohtQembuffNTeanS seth(*pnDd f)btohtQemacnuLlgs rol bpstby] secopieeibjebee ietuAts iigubSLFORDEOK.dIStmeRhiaput isc|bmple] lyyexhaea
md,n(*pnDd f)
 whsh*enenbtdtetstopbavrttoliadicV)inV)is. Or,ristaniMAaise]r,s]
,banAShosie
 whMAaiseimmedsh*enenbtduAts iee.hIMtatcrcacis,bifiapdxIaputhaatcethehrets i 
 whapdMAais,hatcrprorla
-DSiithabanSooeehfrctteRestssVmapG bjerf d conf
 whawts iyuaeatpytpso itdMAaiseimmednooV)gglartmr.
ru
 whIMtteRscrcieosnt ]ultnlirtrmset_smfrt_smrm(),rV)ggxIaputhaatcethehmayr*e
anoinen-meebisV)ggsla
rnfshmMdulmhaetapy taetC dur-DSnmeRhuifetimetofameR
 whi
lra(is.hIstsu hiapdxIaputhaatcethehrets i hapdMAais,hmeRhi
lra(iseetCNT 
 whapdMAaisests] ,eweRr)by aLutsubs*
* ntccalgsrnolitlra(isef d confs
 whimmedia] gihfail  led V)ggeoe eMAaiseimmednseaweiroeehbytxIaput.
ru
 whSimilaTgi,tstssVmapG bjerf d confsotiaetrets ibcirtrmtetse(oshpatchsets)
 whawts i V)gmein chunksobynwayeofaayiartethebf d confiiasteadeofaviaoaritypaetCNT tohaysaohectlSrretbuffNT.hInnV)isscrci,raepair ofathee^s</rs such
 whas:ibjibje <
re>ibje &nbsp;     eten*pnCirtrmtet,ibje &nbsp;     Iflsn**ppCirtrmtet,ibje </
re>ibj
 whIscreplacMdobi:ibjibje <
re>ibje &nbsp;     eten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),ibje &nbsp;     Iflsn*pOut
 wh </
re>ibj
 whTitdxOutputhaatcethehithinen-meebavrtOr]mM totimeshtoerets i ed fSto
ano itdahosiso*etC.hTitdfuolytthee^s</rtthmodestoheachgcaLutithaeatpytpso itritypOut paetCNT eu  si esbisV)ggahosiso*etC.hTitdteaCtdnthee^s</r, pDd f,ritypaetCs tohahbuffNT]nDd fbby] sein saz ]|btt SsapGMeeRochunkdpst]utputrityed fSbeapGnuAts iee.hIso itdxOutputhaatcethehsu rla
fu"gihprorla
istV)g
*noeu  si esdd f,retdsh*enenrets ibSLFORDEOKttoliadicV)insu rla
.hOtrrlwisa,
 whi
dsh*enenrets ibsomMeoorrlbShosiesMAaiseimme.hInnV)isscrcibprorla
-DS
 wh soimmedia] gihabanSooeehfrctteRestssVmapG bjerf d confhawts iyuaeatpy
*noiStmeRhxOutputhMAaiseimmednooV)ggahosiso*etC.
r*
 whTitdsla
rnfshmMdulmhnwvl  inen-msoapdxOutputhaatcethehwled V)ggVeirdrityphee^s</rtset tooayvae Sslla
 m aadiseequLlgtopbavr.hOtrrl m aadthis,
 whno guheetCNesyartdmame asstoothehsaz bpstV)e chunksopsoed fduAts iee.sP*xWris] objeretenttegi_hcirtrmset_a  sy_smrm(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),h/whIaputhf d confhb*x rIflsn*pIn,hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhsehFuolytarrifisexIaputhb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r r|bts treAP *zTSl hhhhhhhhhhhhh/whTSl oonoe eb*x  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtxhhhhhhhhhhhhhhhhhhhhhhsehFuolytarren-metthmodestooxCCnfsist b*x);xWris] objeretenttegi_hlirtrmset_a  sy_v2_smrm(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),h/whIaputhf d confhb*x rIflsn*pIn,hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhsehFuolytarrifisexIaputhb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r r|bts treAP *zTSl hhhhhhhhhhhhh/whTSl oonoe eb*x  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtx,hrrrrrrrrrrrrrrrrrrrrsehFuolytarren-metthmodestooxCCnfsist b*x rIflsn**ppReorci,reten*pnReorci,
 retenflSgsx);xWris] objeretenttegi_hlirtrmset_a  sy_v3_smrm(x rttegi]d *db,hhhhhhhhhhhhhhhhhhhh/whA  syocirtrmctog"main"reb psteeishhanSlQSb*x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),h/whIaputhf d confhb*x rIflsn*pIn,hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhsehFuolytarrifisexIaputhb*x rete(*xFilCNT)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r rttegi]dscirtrmset_i)irn*px  ),x rete(*xCCnfsist)(x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbpyhpsgtixtrnarrctog_a  sy() b*x r reteneCCnfsist,hhhhhhhhhhhhhhhh/whDATA, MISSING, gONFLICT, gONSTRAINT b*x r rttegi]dscirtrmset_i)irn*phhhhh/whHanSlQSdescribl_ghairtrmoarctatnfsistrb*x  ),x rIflsn*pCtx,hrrrrrrrrrrrrrrrrrrrrsehFuolytarren-metthmodestooxCCnfsist b*x rIflsn**ppReorci,reten*pnReorci,
 retenflSgsx);xWris] objeretenttegi_hlirtrmset_|btcs]_smrm(x reten(*xIaputA)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pInA,x reten(*xIaputB)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pInB,x reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i  Iflsn*pOut
);xWris] objeretenttegi_hlirtrmset_iaverN_smrm(x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pIn,x reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i  Iflsn*pOut
);xWris] objeretenttegi_hlirtrmset_smfrt_smrm(
 rttegi]dscirtrmset_i)irn**pp,x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pIn
);xWris] objeretenttegi_hlirtrmset_smfrt_v2_smrm(x rttegi]dscirtrmset_i)irn**pp,x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pIn,
 retenflSgsx);xWris] objeretenttegi_hsla
rnf_lirtrmset_smrm(x rttegi]dssla
rnfh*pSla
rnf,x reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i  Iflsn*pOut
);xWris] objeretenttegi_hsla
rnf_patchset_smrm(x rttegi]dssla
rnfh*pSla
rnf,x reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i  Iflsn*pOut
);xWris] objeretenttegi_hlirtrmgroup_add_smrm(ttegi]dscirtrmgroup*,x r reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i r rIflsn*pIn
);xWris] objeretenttegi_hlirtrmgroup_]utput_smrm(ttegi]dscirtrmgroup*,x r reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i    Iflsn*pOut
);xWris] objeretenttegi_hreorcir_reorci_smrm(x rttegi]dsreorcirn*pReorcir,x reten(*xIaput)(Iflsn*pIn,hIflsn*pDd f,reten*pnDd f),i rIflsn*pIn,
 reten(*xOutput)(Iflsn*pOut,r|bts tIflsn*pDd f,retennDd f),i  Iflsn*pOut
);xasesPh geDe changCmnfigu tMglobLlgthee^s</rs
r*
 whTitdstegi_hsla
rnf_lmnfig()bin</rfacm;iscus setooma-moglobLlglmnfigu s]ereibjecirtrmsbtoothehsla
rnfshmMdulm intordQrhtoetunmoiettoo hehseA_zsic nedes
*noiStmeRhahosiso*etC.
r*
 whTitdstegi_hsla
rnf_lmnfig()bin</rfacm;isccnqeteawadtafe.hIstitiithinen-me
 whwuiletapy oorrlbteawadiithinsid-tapy oorrlbsla
rnfshms<hodhtetnnV)g
 whawsr Sytfrtdi Syaets . FurtrrlmM t,riftissithinen-meeaftrlxapy sla
rnfs
 whawlV)isetbje<ts hrveobeoholssV)iL,ameRhresr Sytfrtdatsoiu Syaets .
 u
 whTitdfuolytarren-mettoo ielstegi_hsla
rnf_lmnfig()bf d confhmea
*btdonR
*noiStmeRhSLFORDESESSIONECONFIG_XXXr|bts atesiSyaets  beu
n.hTitsPh in</rprets]ererofameRh(Ifls*)yvae SsthmodesashV)ggteaCtdnphee^s</rtanS
*not)e effNct ofaarcLapGn iishf d confidependsMonnt)e vae Ssofolup fuoly
 whthee^s</rr
r*
 wh<dl>
 wh<dt>SLFORDESESSIONECONFIG_STRMSIZE<dd>
 wh  oByhSyaar S,t ielsla
rnfshmMdulm stssVmapG in</rfacmsgattiaprotoliaputrity  sapdt]utput ed fdipdahoroxima] gih1 KiB chunks.hT)ishO
yrapdtmayr*exus srity  snolsethanSxquMAynt)e vae Ssofolueyulmnfigu s]erersettigu.hTitdpaetCNTrity  sthmodesashV)ggteaCtdnarren-mesmea
*taetC tohahvae Ssofolypet(ete).
 ue   Ifnluishvae SsiyegssV)il m aad0,tissithuodesashV)ggsewnstssVmapG ed f
ano  ochunkdsaz bfisebotE iaput apdt]utput. Bee ietuAts iigu,t iel(ete)evae S
 wh  staetCNsetoobistArghithtetstopV)e funaleeaeuetpso itdetssVmapG in</rfacm
ano  ochunkdsaz .
r* </dlfibj
 whT)ishf d confirets i pSLFORDEOKriftsu rla
fu",hiseapbShosiesMAaiseimme
*noitrrlwisa.sP*xWris] objeretenttegi_hsla
rnf_lmnfig(etenop,hIflsn*pArg);xasesPh geDe changVaeuestfOr]stegi_hsla
rnf_lmnfig()r
r*x#SyaetslShoORDESESSIONECONFIG_STRMSIZE 1xasesPh Ma-mosu tMwmicanhcalgsteislttufftfn bnC++r
r*x#ifSya __cplusplus
}
#endaf

#endafrrseh!Syaets (__ShoORDSESSIONEH_) &&iSyaets (ShoORDEENABLEESESSION) b*xaseeeeeeee Endeosnt ]ultnsla
rnf.h eeeeeeeeb*xseeeeeeee Begipdfiletfts5.h eeeeeeeeb*xsesPh 2014 May 31
 u
 whTitdau<hor disclaimsecopyrrla
stoo iishsturc eimme.hhInnplacMrofsPh a c galecnqict,ritr)tithaeblla
-DS:
rwsPh    May you dosgooehfrctcnqeevil.sPh    May you aetehe igivenla
 fOr]yourselfhfrcte igivetoorrls.sPh    May you shaietfreegi,tnwvl  ta--DSnmM tot aadyou giver
r*
 wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
ru
 whIM</rfacmsgnolextend FTS5. U -DSnlup in</rfacmsgSyaets  innV)issfile,
 whFTS5tmayr*exextendtL  led:
rwsPh     *d|estomgnokenaz ]
,bandsPh     *d|estomgauxiliary f d confsr
r*xax#ifnSya _FTS5_Hx#Syaetsl_FTS5_Hx
x#ifSya __cplusplus
exterfi"C" {
#endaf

/wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
ru CUSTOM AUXILIARYoFUNCTIONS
rwsPh VirnuLlgtSl ohaor em inaferessreisovl loactSLFrf d confsobynaor em inogu
*notQemveselliAmMdulm.xFeteF d conf() ms<hodr
r*xaeypeSya stsuctmFts5Exten
rnfApimFts5Exten
rnfApi;aeypeSya stsuctmFts5Cbtt-xt Fts5Cbtt-xt;aeypeSya stsuctmFts5PhrrciI)il Fts5PhrrciI)il;xaeypeSya Iflsn(*fts5_exten
rnf_f d conf)(x r|bts tFts5Exten
rnfApim*pApi,rrrsehbjeroffNT debisoexn*hAhFTSSeMAsonfhb*x rFts5Cbtt-xt *pFts,orrrrrrrrrrrrrsehFuolytarrstoptassgnolpApirf d confsob*x rttegi]dscbtt-xt *pCtx,hrrrrrrrrr/whCbtt-xt fOr]uAts iigubresr S/MAaiseb*x retennVae,hhhhhhhhhhhhhhhhhhhhhhh/whN rol bpsteae SstinaapVae[]tarreisb*x rttegi]dseaeuet**apVaehhhhhhhhhhh/whArreispso raeLapGnarren-meshb*x);xastsuctmFts5PhrrciI)il {x r|bts tun
rgndehcirseba;x r|bts tun
rgndehcirsebb;
};xasesPh EXTENSIONhbjerFUNCTIONS
rwsPh xUcirDd f(pFts):
ano cRets ibad|tpytpso itdpUcirDd f paetCNT thmodestoomeRhxCssV)iF d conf()
ano cbjerwetnnV)ggexten
rnfhf d confiwnseawgis)irmer
r*
 whxCblumnTotalSize(pFts,oiCbl, pnToken):
ano cIfathee^s</roiCbltithlla
 m aadbavr,hteth]utput variSl oh*pnToken
ano ctoomeRhtotalgs rol bpstnokenstinaV)ggFTS5ttSl o.hOr,ristiCbltit
ano cnon-n gativetbuo[lla
 m aadV)ggs rol bpstcblumns innV)ggtSl o,auAts i
ano cteRhtotalgs rol bpstnokenstinacblumnoiCbl, |btsid-r-DSnalgsr
nssin
 wh t itdFTS5ttSl o.
rwsPh   Ifathee^s</roiCbltithgssV)il m aadiseequLlgtopV)ggs rol bpstcblumnssPh   innV)ggtSl o,aShoORDERANGEsiyeaweiroee. Or,ristaniMAaise]r,s]
d(e.g.sPh   aniOOM aCtdiconfhirtIOiMAais),iapdahoropriate SLFsiesMAaiseimmedit
ano cuAts iee.sP*
 whxCblumnCmut)(pFts):
ano cRets ibV)ggs rol bpstcblumns innV)ggtSl o.sP*
 whxCblumnSize(pFts,oiCbl, pnToken):
ano cIfathee^s</roiCbltithlla
 m aadbavr,hteth]utput variSl oh*pnToken
ano ctoomeRhtotalgs rol bpstnokenstinaV)ggoexn*hAha
n. Or,ristiCbltit
ano cnon-n gativetbuo[lla
 m aadV)ggs rol bpstcblumns innV)ggtSl o,asetibje s*pnTokengtopV)ggs rol bpstnokenstinacblumnoiCblbpstV)e cexn*hAha
n.
rwsPh   Ifathee^s</roiCbltithgssV)il m aadiseequLlgtopV)ggs rol bpstcblumnssPh   innV)ggtSl o,aShoORDERANGEsiyeaweiroee. Or,ristaniMAaise]r,s]
d(e.g.sPh   aniOOM aCtdiconfhirtIOiMAais),iapdahoropriate SLFsiesMAaiseimmedit
ano cuAts iee.sP*
 wh hT)ishf d confimayr*exqusiesetsffici-metifxus se ledhapdFTS5ttSl o
 wh hlssV)iLewled V)gg"cblumnsize=0"nop*etC.
r*
 whxCblumnText:
ano cIfathee^s</roiCbltithlla
 m aadbavr,hisegssV)il m aadiseequLlgtopV)g
ano cn rol bpstcblumns innV)ggtSl o,aShoORDERANGEsiyeaweiroee.sP*
 wh hOtrrlwisa,b iishf d confiattiaprshtoeretrievet ielt-xt pstcblumnoiCblbps
 wh t itdcexn*hAhdocen-me.hIstsu rla
fu",h(*pz)hithtetstoptaetC tohadbuffNT
 wh  |btt Ss-DSnlup t-xt inootf-8tenimdigu,t(*pn)hithtetstopV)e tize iniby] s
 wh  (setecirsac</rs)bpstV)e buffNTefrctSLFORDEOKhiyeaweiroee. Otrrlwisa,
 wh ristaniMAaise]r,s]
,banAShosiesMAaiseimmediteaweiroeehfrctteRefunaleeaeues
 wh  pst(*pz)hanS (*pn)rfrtdi Syaets .
 u
 whxPhrrciCmut):
ano cRets ispV)ggs rol bpstphrrcistinaV)ggoexn*hAhquMAynextressetC.
r*
 whxPhrrciSize:
ano cIfathee^s</roiCbltithlla
 m aadbavr,hisegssV)il m aadiseequLlgtopV)g
ano cn rol bpstphrrcistinaV)ggoexn*hAhquMAy,dnseaweiroeehbytxPhrrciCmut),
 wh r0hiyeaweiroee. Otrrlwisa,b iishf d confirets ispV)ggs rol bpstnokenstin
 wh rphrrci iPhrrcibpstV)e quMAy. Phrrcistari n rol  estmfrtapG fn bnbavr.
r*
 whxIts Cmut):
ano cSeen*pnIts ctoomeRhtotalgs rol bpst]r,s]n*hc sepsoatcrphrrcist ledin
 wh t itdquMAyn ledinaV)ggoexn*hAha
n. Rets ibSLFORDEOKtiftsu rla
fu",hissPh   aniMAaiseimmed(i.e.dSLFORDENOMEM)gifiapdMAaise]r,s]
.sP*
 wh hT)ishbjerornr*exqusiessl
n ifxus se ledhapdFTS5ttSl ohlssV)iLewled V)g
 wh h"detail=none"dise"detail=cblumn"nop*etC.hIso itdFTS5ttSl oheyulssV)iL
 wh hwled eiorrlu"detail=none"dise"detail=cblumn"nanS "cbtt-nt="nop*etC
 wh  (i.e.diftissitha cbtt-ntlla
 mSl o),btetnnV)ishbjeralwaysirets isp0.
r*
 whxIts :
ano cQuMAynfOr] itddetailsbpstphrrciomatchtiIdxn ledinaV)ggoexn*hAha
n.
ano cPhrrciomatchistari n rol  estmfrtapG fn bnbavr,ssxo ietiIdxnarren-me
ano  sh*enenbtdgssV)il m aadiseequLlgtopbavrtnpdismartmrir aadV)ggvae S
 wh  ]utput bytxIas Cmut)i).hIstiIdxnithlla
 m aadbavrhisegssV)il m aa
 wh  ]seequLlgtopV)ggeaeuetaweiroeehbytxIas Cmut)i),aShoORDERANGEsiyeaweiroee.sP*
 wh hOtrrlwisa,b]utput thee^s</rn*piPhrrcibithtetstopV)e phrrcion rol ,n*piCbl
ano ctoomeRhcblumnoine hichhiss]r,s]
dnpdi*piOffomeRhtokengoffteth]stV)g
*no hfuolyttokengofpV)e phrrci.tSLFORDEOKhiyeaweiroeeriftsu rla
fu",hiseap
*no hMAaiseimmed(i.e.dSLFORDENOMEM)gifiapdMAaise]r,s]
.sP*
 wh hT)ishbjerornr*exqusiessl
n ifxus se ledhapdFTS5ttSl ohlssV)iLewled V)g
 wh h"detail=none"dise"detail=cblumn"nop*etC.
r*
 whxRowid:
ano cRets ispV)ggrowidbpstV)e cexn*hAha
n.
rwsPh xTokenaz :
ano cTokenaz  t-xt o -DSnlup nokenaz ] beu
ngogu nooV)ggFTS5ttSl o.
rwsPh xQuMAyPhrrci(pFts5, iPhrrci,dpUcirDd f,hxCatcethe):
ano cT)ishbjerf d conf issus setooquMAynt)e FTSStSl ohfOr]phrrci iPhrrci
 wh  pstV)ggoexn*hAhquMAy. SeA_zsicLlgi,tahquMAyne
*ieae-mesto:
rwsPh       ... FROM ftstSl ohWHERE ftstSl ohMATCH $p ORDER BYgrowid
rwsPh   wled $p set tooayphrrci e
*ieae-mestotV)e phrrcioiPhrrcibpstV)e
 wh  |exn*hAhquMAynithexecuted.hAnyhcblumnofilCNT  iatta  si ssto
ano cphrrci iPhrrcibpstV)e |exn*hAhquMAynithincluds  inn$p. Fiseeach
ano ca
n visicad,nV)ggaartethebf d confithmodesasolup fourtrnarren-me
ano  ithinen-me. T)gecCnt-xt npdibjerobje<ts thmodestoomeRhaartethe
*no hf d confimayr*exus setooa rla
tV)e prO
yrti sepsoeachgmatchidha
n.
ano cIaen--DSnApi.xUcirDd f()hawts iyuaeatpygofpV)e paetCNT thmodesas
ano cteRhteirdtarren-mettoopUcirDd f.
rwsPh   Ifathee^s</roiPhrrcibithlla
 m aadbavr,hisegssV)il m aadiseequLlgto
ano cteRhn rol bpstphrrcistinaV)ggquMAy,dnseaweiroeehbytxPhrrciCmut)(),
 wh t iishf d confirets i pSLFORDERANGE.
rwsPh   IfaV)ggaartethebf d confirets i hapyeeaeuetptrrl m aadSLFORDEOK,tV)e
 wh  quMAynithabanSooeehfrctteRexQuMAyPhrrcibf d confirets i himmedia] gi.sPh   IfaV)ggaweiroeehvae SsiyeSLFORDEDONE,exQuMAyPhrrcibrets i pSLFORDEOK.
 wh hOtrrlwisa,b iesMAaiseimmediteprO
ags]meeopwards.
rwsPh   IfaV)ggquMAynrunsSnoocbmple]onfiwledout incid-me, SLFORDEOKhiyeaweiroee.
 wh hOr,ristsomMeMAaise]r,s]
dbee iet itdquMAyn|bmple] sdiseithaborNdebbi
 wh  V)ggcartethe,banAShosiesMAaiseimmediteaweiroee.
rwsPhsPh xSeeAuxdd f(pFts5, pAux,exDsle] )
rwsPh   Savet ielpaetCNT thmodesashV)ggteaCtdnarren-mesashV)ggexten
rnfhf d conf's
ano c"auxiliary dd f".hTitdpaetCNTimayrtetnnbtduAtrieveesbisV)gg|exn*hAhiseapy
*no hf tuie inv
cs]ereeOfameRheoe efts5gexten
rnfhf d confimame asspartbps
 wh t itdeoe eMATCH quMAyno -DSnlup xGeeAuxdd f()gbje.
rwsPh   Eachgexten
rnfhf d confiiseaLu
cs]meeaysaohectauxiliary dd fssl
the i
ano oeachgFTSSquMAyn(MATCH extressetC).hIso itdexten
rnfhf d confiiseinen-md
ano cmM tot aadoncasfiseaysaohectFTSSquMAy,heetnfalleinv
cs]eres shaieta
ano ttaohectauxiliary dd fscCnt-xt.
rwsPh   IfaV)gr)titha awadypapdauxiliary dd fspaetCNTiwetnnV)ishf d confiissPh   inen-md,heetnfissithawplacMdobihV)ggsewnpaetCNT.hIfiapdxDsle] oaartethe
*no hwnseseA_zsimeeau
ngewled V)ggisrlunalepaetCNT,tissithinen-meeatnluis
ano cpaetC.sP*
 wh hT)edxDsle] oaartethe,ristonRhiseseA_zsime,titha sohinen-meeosrV)g
*no hauxiliary dd fspaetCNTiaftrlxV)ggFTS5tquMAynhashfinishee.sP*
 wh hIfiapdMAaise(e.g.daniOOM aCtdiconf)e]r,s]
twledinaV)ishf d conf,
 wh t itdauxiliary dd fsithtetstopNuxa npdianhMAaiseimmeduAts iee. IfaV)g
 wh txDsle] othee^s</rownseseteNuxa,tissithinen-meeonnt)e auxiliary dd f
ano cpaetC ] bee ietuAts iigu.
rwsPhsPh xGeeAuxdd f(pFts5, bClear)
rwsPh   Rets ispV)gg|exn*hAhauxiliary dd fspaetCNTifOr] itdfts5gexten
rnf
*no hf d conf. Seox itdxSeeAuxdd f() ms<hodifOr]details.
rwsPh   IfaV)ggbClearnarren-mesisccnn-bavr,htetnnV)ggauxiliary dd fsithclearmd
ano c(tetstopNuxa)dbee iet iishf d confirets i .hInnV)isscrcibt)edxDsle] ,
 wh ristany,hithcnqeinen-md.
rwsPhsPh xRowCmut)(pFts5, pnRow)
P*
 wh hT)ishf d confiissus setooretrievet ieltotalgs rol bpstr
nssinnV)ggtSl o.sP*o cIatptrrl words,t itdeoe evae Ss iattw*enenbtduAts ieeobi:ibjibje       SELECTecbut)(*) FROM ftstSl o;
 w
 whxPhrrciFuoly()
ano cT)ishf d confiissus s,eau
ngewled VypetFts5PhrrciI)il frctteRexPhrrciNext
ano cms<hod,rnolitlra(Ss iroughfalleins atc sepsoattaohectquMAynphrrci  ledin
 wh t itdoexn*hAha
n. Tiishiyu itdeoe einfolmatothrashiyua rla
il oSviaolup
 wh txIas Cmut)/xIas gbje .hWuiletteRexIas Cmut)/xIas gbje yartdm iet|btv ii-me
ano ctoousa,b iishbjermayr*exfas)irdi SyrtsomMecircums atc s.sTohitlra(S
 wh t iroughfins atc sepsophrrci iPhrrci,ousaolup foLu
napGMimme:ibjibje      Fts5PhrrciI)il i)il;xbje      etC iCbl, iOff;xbje      fol(pApi->xPhrrciFuoly(pFts,oiPhrrci,o&iCNT,t&iCbl, &iOff);xbje          eCbl>=0;xbje          pApi->xPhrrciNext(pFts,o&iCNT,t&iCbl, &iOff)xbje      ){xbje        //hAnhins atc epsophrrci iPhrrcieatnofftethiOffopstcblumnoiCblxbje      }sP*
 wh hT)edFts5PhrrciI)il stsuctur)tithSyaets  abov .hAhosiso*etCs sh*enencnq
ano cmMdzsynluishstsuctur)tdirecAabe-hi
dsh*enenonlybercuodesashsh*wn abov sPh   wled teRexPhrrciFuoly() frctxPhrrciNext()gbjerms<hods (frctbi
 wh  xPhrrciFuolyCblumn() frctxPhrrciNextCblumn() fshillustrats  beu
n).sP*
 wh hT)ishbjerornr*exqusiessl
n ifxus se ledhapdFTS5ttSl ohlssV)iLewled V)g
 wh h"detail=none"dise"detail=cblumn"nop*etC.hIso itdFTS5ttSl oheyulssV)iL
 wh hwled eiorrlu"detail=none"dise"detail=cblumn"nanS "cbtt-nt="nop*etC
 wh  (i.e.diftissitha cbtt-ntlla
 mSl o),btetnnV)ishbjeralwaysiitlra(Ss
 wh t iroughfanhMmptypsets(atcrcalgsrnolxPhrrciFuoly() tethiCbltnol-1).sP*
 wh hIMtatcrcacis,bmatchistari visicadsinn(cblumnoASC,nofftethASC)tordQr.sP*o ci.e.dalgsteocioinocblumno0,ssxrNdebbinofftet, foLu
nMdobihV)ocioin
 wh  |blumno1, etc.
r*
 whxPhrrciNext()sPh   SeRexPhrrciFuoly abov .
 w
 whxPhrrciFuolyCblumn()
ano cT)ishf d confifrctxPhrrciNextCblumn() freosimilaT]toomeRhxPhrrciFuoly()
ano cfrctxPhrrciNext()gbjesonescrib seabov .hT)eddzsfNT ncisiseguattinstead
 wh  pstitlra(apGMV)roughfalleins atc sepsoatphrrci inaV)ggoexn*hAha
n,btetci
 wh  bje yartdus setooitlra(Ss iroughfV)ggtet pstcblumnstinaV)ggoexn*hAha
n
 wh t iaqeaCan SsronetOr]mM toins atc sepsoatteA_zsimeephrrci.tFiseexaor r:ibjibje      Fts5PhrrciI)il i)il;xbje      etC iCbl;xbje      fol(pApi->xPhrrciFuolyCblumn(pFts,oiPhrrci,o&iCNT,t&iCbl);xbje          eCbl>=0;xbje          pApi->xPhrrciNextCblumn(pFts,o&iCNT,t&iCbl)xbje      ){xbje        //hCblumnoiCblbaCan Sssgathleaso[onetins atc epsophrrci iPhrrcixbje      }sP*
 wh hT)ishbjerornr*exqusiessl
n ifxus se ledhapdFTS5ttSl ohlssV)iLewled V)g
 wh h"detail=none"dip*etC.hIso itdFTS5ttSl oheyulssV)iLhwled eiorrl
 wh h"detail=none"d"cbtt-nt="nop*etC (i.e.diftissitha cbtt-ntlla
 mSl o),
 wh t itnnV)ishbjeralwaysiitlra(Sst iroughfanhMmptypsets(atcrcalgsrno
 wh  xPhrrciFuolyCblumn() tethiCbltnol-1).sP*
 wh hTh einfolmatothra rla
deho -DSnluishbjerarctitsc|bmpanetC
 wh  xPhrrciFuolyCblumn() mayra sohbtdobn Ssdeto -DSnxPhrrciFuoly/xPhrrciNext
ano c(isexIas)/xIas Cmut)). T)gechiesoadvaan gSsofolueyubjereseguattitiissPh   
rgnzsicLnAabemM tosffici-metr aadV)ocioalCNTnativesiwetnnus se led
 wh h"detail=cblumn"nmSl os.
r*
 whxPhrrciNextCblumn()
ano cSeRexPhrrciFuolyCblumnoabov .
 w
 whxQuMAyToken(pFts5, iPhrrci,diToken, ppToken, pnToken)
 wh hT)ishissus setooa rla
tVokengiTokenepsophrrci iPhrrciepstV)e |exn*hA
 wh  quMAy. Bee ietuAts iigu,t]utput thee^s</rn*ppTokenhithtetstoptaetC
ano ctooahbuffNT]|btt SsapGMV)ggawquest setoken, npdi*pnTokengtopV)gsPh   
rzSsofolueyubuffNTeiniby] s.
rwsPh   IfaiPhrrcieprgiTokeneartdlla
 m aadbavr,hiseifoiPhrrcibithgssV)il m aa
 wh  ]seequLlgtopV)ggn rol bpstphrrcistinaV)ggquMAydnseawporNdebbi
 wh  xPhrrciCmut)(),hiseifoiTokenhithequLlgtopisegssV)il m aadV)ggn rol bps
ano ctokenstinaV)ggphrrci,dShoORDERANGEsiyeaweiroee npdi*ppTokenhnpdi*pnToken
     artdbotE bavree.sP*
 wh hT)et]utput t-xt ithseteaeatpygofpV)e quMAynt-xt guattteA_zsimeeV)gsPh   token.hIC iyugult]utput ofomeRhtokenaz ] mMdulm.tFisetokendd f=1sPh   tSl os,b iishincluds hapyeeroldds  0x00 frcttraeLapGndd f.
rwsPh xIas Token(pFts5, iIdx,diToken, ppToken, pnToken)
 wh hT)ishissus setooa rla
tVokengiTokenepsophrrci hitiiIdxn ledinaV)g
 wh  |exn*hAha
n. IstiIdxnithlla
 m aadbavrhisegssV)il m aadiseequLlgtopV)g
ano ceaeuetaweiroeehbytxIas Cmut)i),aShoORDERANGEsiyeaweiroee.  Otrrlwisa,
 wh r]utput variSl oh(*ppToken)hithtetstoptaetC tohadbuffNT]|btt SsapGMV)g
ano cmatch-DShdocen-meetoken, npdi(*pnToken)btohtQem
rzSsofoluattbuffNTein
ano cby] s.
rwsPh   T)et]utput t-xt ithseteaeatpygofpV)e docen-meet-xt guattwashtokenaz e.
 wh hIC iyugult]utput ofomeRhtokenaz ] mMdulm.tFisetokendd f=1 tSl os,b iissPh   includs hapyeeroldds  0x00 frcttraeLapGndd f.
rwsPh  hT)ishbjermayr*exsl
n iibsomMecacistifomeRhtokengid-mezsieeibisthee^s</rs
r*   iIdxnarctiTokenematchidha 
refixhtokenginaV)ggquMAy.hInnmoa
*cacis,bV)g
*no hfuolytcalgstoo iishbjerfiseeachg
refixhtokenginaV)ggquMAy iyufiscmdsPh   toescaadV)ggporNereeOfameRhfu"g-t-xt index guattmatchistV)e prefixsPh   tokenSnoocblle<tht)gg-xtraoed fduAquiiedebyo iishbje.hIso itdprefixsPh   tokenSmatchistatlSrrets rol bpstnokenoins atc seinaV)ggdocen-meetet,ibje o iishmayr*exa 
yrfolmatc eprol om.
rwsPh   IfaV)ggucirnkn
nssinnadvaacSs iattahquMAynmayrusaoluishbjerfisef
ano cprefixhtoken,hFTS5tmayr*exlmnfigu tL noocblle<thalgsrAquiiedeed fSfs part
 wh  pst ietinitzal quMAyapGnOfameRhfu"g-t-xt index,eaIflsapGMV)ggteaCtdnscaa
 wh  entartly.hT)isha soh|auciscprefixhquMAi sst)ussecbcnqeusaoluishbjerno
 wh  runemM tosl
ngihandeusaomM tomemory.hFTS5tmayr*exlmnfigu tL inaV)ishway
 wh  eiorrluonna 
yr-tSl ohbaoisno -DSnlup [FTS5tins nokeno| 'ins noken']ibje sop*etC,hiseonna 
yr-quMAynbaoisno -DSnlupibje s[fts5_ins nokeno| fts5_ins noken()]gucirnf d conf.sP*
 wh hT)ishbjerornr*exqusiessl
n ifxus se ledhapdFTS5ttSl ohlssV)iLewled V)g
 wh h"detail=none"dise"detail=cblumn"nop*etC.
rwsPh xCblumnL
csle(pFts5, iIdx,dpzL
csle, pnL
csle)sPh   Ifathee^s</roiCbltithlla
 m aadbavr,hisegssV)il m aadiseequLlgtopV)g
ano cn rol bpstcblumns innV)ggtSl o,aShoORDERANGEsiyeaweiroee.sP*
 wh hOtrrlwisa,b iishf d confiattiaprshtoeretrievet ielu
cslehassocis]me
 wh hwled cblumnoiCblbpstV)e cexn*hAha
n. UsuLlgi,tV)gr)tithnohassocis]me
 wh hl
csle, apdt]utput thee^s</rs (*pzL
csle) npdi(*pnL
csle) nyebtetsPh   toeNuxa npdi0,hawspe<tively.hHowwvl ,bifi itdfts5_l
csle()bf d conf
*no hwnseus setooassocis]m agu
csle wled teReeaeuetwetnfisswfs iacirteeibje sinnooeeRofts5gtSl o,a itnn(*pzL
csle) ithtetstoptaetC tohadnug-t-rmins]me
 wh hbuffNT]|btt SsapGMV)ggnoe eoft ielu
cslehinootf-8tenimdigu.i(*pnL
csle)ibje sithtetstopV)e tize iniby] sbpstV)e buffNT,hcnqeinclud-DSnlupibje snug-t-rmins]or.
rwsPh   Ifasu rla
fu",hSLFORDEOKhiyeaweiroee. Or,ristaniMAaise]r,s]
,ban
ano cShosiesMAaiseimmediteaweiroee.hTitdfunaleeaeuetpso itd]utput thee^s</rsibje sithi Syaets  innV)isscrci.
rwsPh xTokenaz _v2:
ano cTokenaz  t-xt o -DSnlup nokenaz ] beu
ngogu nooV)ggFTS5ttSl o.hT)is
 wh  bjehiyu itdeoe eashV)ggxTokenaz ()gbje,g-xcep* guattitiaLu
nssa nokenaz ]
 wh hl
csle tobercteA_zsimer
r*xstsuctmFts5Exten
rnfApim{x retC iVl soth;                   /whCexn*hAgihalwaysitetstop4 b*xa  Iflsn*(*xUcirDd f)(Fts5Cbtt-xt*);xa reten(*xCblumnCmut))(Fts5Cbtt-xt*);x reten(*xRowCmut))(Fts5Cbtt-xt*,rttegi]dsete64n*pnRow);x reten(*xCblumnTotalSize)(Fts5Cbtt-xt*,retC iCbl, ttegi]dsete64n*pnToken);xa reten(*xTokenaz )(Fts5Cbtt-xt*,
    |bts treAP *pText,retennText,r/whT-xt go nokenaz  b*x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhh/whCbtt-xt phmodestooxToken() b*x r reten(*xToken)(Ifls*,retC, |bts treAP*,retC, etC, etC)hhhhhhh/whCartethebb*x  );xa reten(*xPhrrciCmut))(Fts5Cbtt-xt*);x reten(*xPhrrciSize)(Fts5Cbtt-xt*,retC iPhrrci);xa reten(*xIas Cmut))(Fts5Cbtt-xt*,retC *pnIts );x reten(*xIts )(Fts5Cbtt-xt*,retC iIdx,ditC *piPhrrci,ditC *piCbl, itC *piOff);x
  ttegi]dsete64n(*xRowid)(Fts5Cbtt-xt*);x reten(*xCblumnText)(Fts5Cbtt-xt*,retC iCbl, |bts treAP **pz,retC *pn);x reten(*xCblumnSize)(Fts5Cbtt-xt*,retC iCbl, etC *pnToken);xa reten(*xQuMAyPhrrci)(Fts5Cbtt-xt*,retC iPhrrci,hIflsn*pUcirDd f,x r rete(*)(|bts tFts5Exten
rnfApi*,Fts5Cbtt-xt*,Ifls*)x  );x reten(*xSeeAuxdd f)(Fts5Cbtt-xt*,rIflsn*pAux,eIfls(*xDsle] )(Ifls*));x rIflsn*(*xGeeAuxdd f)(Fts5Cbtt-xt*,retenbClear);xa reten(*xPhrrciFuoly)(Fts5Cbtt-xt*,retC iPhrrci,hFts5PhrrciI)il*,retC*,retC*);x rIflsn(*xPhrrciNext)(Fts5Cbtt-xt*,rFts5PhrrciI)il*,retC *piCbl, itC *piOff);x
  eten(*xPhrrciFuolyCblumn)(Fts5Cbtt-xt*,retC iPhrrci,hFts5PhrrciI)il*,retC*);x rIflsn(*xPhrrciNextCblumn)(Fts5Cbtt-xt*,rFts5PhrrciI)il*,retC *piCbl);x
  /e Bel
n V)istpaetC nyebiVl soth>=3nonlybb*x reten(*xQuMAyToken)(Fts5Cbtt-xt*,
     retC iPhrrci,hetC iToken,
     r|bts treAP **ppToken, etC *pnTokenx  );x reten(*xIas Token)(Fts5Cbtt-xt*,retC iIdx,ditC iToken, |bts treAP**,retC*);x
  /e Bel
n V)istpaetC nyebiVl soth>=4nonlybb*x reten(*xCblumnL
csle)(Fts5Cbtt-xt*,retC iCbl, |bts treAP **pz,retC *pn);x reten(*xTokenaz _v2)(Fts5Cbtt-xt*,
    |bts treAP *pText,retennText,rhhhhh/whT-xt go nokenaz  b*x r r|bts treAP *pL
csle, etennL
csle, h/whL
csle tobtassgnolnokenaz ] b*x r rIflsn*pCtx,hhhhhhhhhhhhhhhhhhhhhhhh/whCbtt-xt phmodestooxToken() b*x r reten(*xToken)(Ifls*,retC, |bts treAP*,retC, etC, etC)hhhhhhh/whCartethebb*x  );x};xasesPh CUSTOM AUXILIARYoFUNCTIONS
rwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww/

/wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
ru CUSTOM TOKENIZERS
rwsPh Ahosiso*etCs mayra sohawgis)ird|estomgnokenaz ] Vypes. A nokenaz ]
 whiseawgis)irmeibistrovlsapGMfts5g led aepopulV)idtins atc epsolupibjefoLu
napGMstsuctur).hALuhstsuctur)tms<hods mea
*btdSyaets ,rsettiguibjeapyemerol bpstnitdfts5_nokenaz ] stsuctmtoeNuxa lwadtctoou Syaets ibjebehaviouT.hTitdttsuctur)tms<hods nyebexpe<tdestoof d confiasoaiLu
ns:ibjibjexCssV)i:
ano cT)ishf d confiissus setooaLu
cs]mharctinitzalaz  a nokenaz ]tins atc .
 wh hA nokenaz ]tins atc tissawquiiedetooacnuLllynlokenaz  t-xt.
rwsPh   T)etfuolytarren-metthmodestooV)ishf d confiiseaeatpygofpV)e (Ifls*)sPh   paetCNT trovls esbisV)ggahosiso*etCrwetnnV)ggfts5_nokenaz ]_v2robje<t
*no hwnseawgis)irmei led FTS5t(teRhteirdtarren-mettooxCssV)iTokenaz r()).
 ue  T)ggteaCtdnarctteirdtarren-meytfrtdantarreisofpnug-t-rmins]medttsigus
 wh  |btt Ss-DSnlup tokenaz ]tarren-mey,ristany,hteA_zsimeefoLu
napGMV)gsPh   tokenaz ]tnoe eashpartbpsnlup CREATE VIRTUAL TABLEests] n-metus srity  noocssV)iMV)ggFTS5ttSl o.
rwsPh   T)etfunalearren-mesiscaadiutput variSl o.hIstsu rla
fu",h(*ppOut)
 wh hsh*enenbtdtetstoptaetC tohtQemsewntokenaz ]thanSlQSfrctSLFORDEOK
 wh huAts iee. IfaaniMAaise]r,s]
,bsomMeeaeuetptrrl m aadSLFORDEOKhsh*ene
 wh hbtduAts iee.hIMtV)isscrci,rfts5gassum sst)usstitdfunaleeaeuetpso*ppOutxbje sithi Syaets .
rwsPh xDsle] :
ano cT)ishf d confiissinen-meetohdsle] oadtokenaz ]thanSlQS
reviously
 wh  aLu
cs]meeo -DStxCssV)ii).hFts5 guheetCNesyt)usstiishf d confiwill
 wh hbtdinen-meeexacAabeoncasfiseeachgsu rla
fu" calgstooxCssV)ii).
rwsPh xTokenaz :
ano cT)ishf d confiissexpe<tdestoolokenaz  tQemsT-xt by] dttsigu iadicV)ie
 wh hbytarren-mettT-xt.ttT-xtsreisoTimayrcnqebepnug-t-rmins]me.hTitdfuoly
 wh  arren-metthmodestooV)ishf d confiiseaepaetCNT tohanhFts5Tokenaz rrobje<t
*no haweiroeehbytaniMarliird|algstooxCssV)ii).
rwsPh   T)etteirdtarren-metiadicV)ispV)ggreasnfiAPatgFTS5tissawquestiguibje  tokenazs]ereeOfameRheu  si est-xt.hT)ishissalwaysionetOstnitdfoLu
napGibje  foureeaeues:ibjibje  <ul><li>h<b>FTS5_TOKENIZE_DOCUMENT</b> -hA docen-meeeyubeigu iacirteesinno
bje           Or]uAmoveesfn bnt)e FTSStSl o.hTitdnokenaz ]tiyubeigu iaen-meeto
bje           det-rminefV)ggtet psttokensttohadestoo(Or]dele] ofn b)MV)gsPh            FTSSindex.
rwsPh       <li>h<b>FTS5_TOKENIZE_QUERY</b> -hA MATCH quMAyniyubeigu executedsPh            ag Ssstnt)e FTSSindex.hTitdnokenaz ]tiyubeigu lartmestoolokenaz sPh            a bfrtword Or]quo]medttsigueseA_zsimeeashpartbpsnlup quMAy.
rwsPh       <li>h<b>(FTS5_TOKENIZE_QUERY | FTS5_TOKENIZE_PREFIX)</b> -hSoe eassPh            FTS5_TOKENIZE_QUERY,g-xcep* guattV)e bfrtword Or]quo]medttsigueissPh            foLu
nMdobiha "*"ecirsac</r,tiadicV)apGMV)attV)e lalyttokensPh            aweiroeehbytlup tokenaz ]twillebeptssV)iLeassa nokencprefix.
rwsPh       <li>h<b>FTS5_TOKENIZE_AUX</b> -hTitdnokenaz ]tiyubeigu iaen-meeto
bje           sV)asfytanifts5_api.xTokenaz ()gawquestdmame bypapdauxiliarysPh            f d conf. Ortanifts5_api.xCblumnSize()gawquestdmame byp itdeoe 
bje           Oibad|tlumnsize=0eed fbrci.
rw   </ulfibj
 wh hTitdsixedhapS sev inhtarren-meytphmodestooxTokenize()g- pL
cslebandsPh   nL
csleg- frtdaypaetCNT tohaybuffNT]|btt SsapGMV)ggl
csle tobusaoe i
ano otokenazs]eree(e.g.d"en_US")rarctitsctize iniby] s,hawspe<tively.hT)gsPh   pL
cslebbuffNTeithsetenug-t-rmins]me.hpL
cslebmayr*exphmodesNuxa (in
ano c hichhcrcibnL
cslegissalwaysi0) noliadicV)inV)attV)e nokenaz ] sh*ene
 wh husaoiesiSyaar Sgl
csle.
rwsPh   FiseeachhtokenginaV)ggiaput ttsigu,ameRheu  si esaartethebxToken() mea

 wh hbtdinen-me. T)etfuolytarren-mettooithsh*enenbtdaeatpygofpV)e paetCNTsPh   phmodesashV)ggteaCtdnarren-mestooxTokenize(). T)etteirdtarcte urtr
 wh  arren-mes frtdaypaetCNT tohaybuffNT]|btt SsapGMV)ggtokenSnext,rfrctteR
Ph   
rzSsofoluehtokenginaby] s. T)et4edhapS 5nhtarren-meytaiet itdby] dofftets
 wh  pstt)etfuolytby] doftarcteuolytby] dimmedia] gihfoLu
napGMV)g t-xt fn b
ano c hichhluehtokengisiSyrivmei ledinaV)ggiaput.
rwsPh   T)etteaCtdnarren-mesthmodestoomeRhxToken() aartetheb("tflSgs")rsh*ene
 wh hnolmallynbtdtetstop0. T)et-xcep*onfiissifomeRhtokenaz ] eu  orts
 wh  synonym .hInnV)isscrcibseox itddiscua
rnfhbeu
nifOr]details.
rwsPh   FTS5tassum sst)RhxToken() aartethebissinen-meefiseeachhtokenginaV)g
 wh  prdQrht)attV)eye]r,s]i ledinaV)ggiaput t-xt.
rwsPh   IfiapdxToken() aartethebrets i hapyeeaeuetptrrl m aadSLFORDEOK,tV)ei
ano cteRhtokenazs]ereesh*enenbtdabanSooeehfrctteRexTokenize()g^s<hodhsh*enexbje simmedia] gihrets ibad|tpygofpV)e xToken() rets ibeaeue. Or,ristV)g
 wh  iaput buffNTeithexhaea
md,nxTokenize()gsh*enenrets ibSLFORDEOK.hFunally,
 wh ristaniMAaise]r,s]
 wled teRexTokenize()gaor em inafereoieself,tis
ano cmaihabanSoocteRhtokenazs]ereefrctrets ibapyeeAaiseimmedptrrl m aa
ano cShoORDEOKhoreSLFORDEDONE.
rwsPh   IfaV)ggnokenaz ]tiyuawgis)irmeio -DStanifts5_nokenaz ]_v2robje<t,
 wh t itnnV)RexTokenize()g^s<hodhhashtwohadeiconfalearren-mesg- pL
csle
 wh  arctcL
csle. T)esrcteA_zsyMV)ggl
csle t)attV)e nokenaz ] sh*enehusaibje  fortV)e cexn*hAhawquest. IfapL
cslebandbnL
cslegartdbotE 0,htetnnV)gsPh   tokenaz ]tsh*enehusaoiesiSyaar Sgl
csle.hOtrrlwisa,bpL
cslebpaetCs to
 wh  arbnL
cslegby] dbuffNT]|btt SsapGMV)ggnoe eoft ielu
cslehtobusaonseutf-8sPh   t-xt.ttL
cslegisssetenug-t-rmins]me.
rwsPh FTS5_TOKENIZER
 u
 whTitr)titha sotanifts5_nokenaz ]robje<t.hT)ishissaeeOld/r,tdeprecV)ie,
 wheMAsonfhoftfts5_nokenaz ]_v2.hIC iyusimilaT]-xcep* guat:ibjibje <ulfibj    <li>hT)gr)tithnoh"iVl soth"teueld,bandsPh    <li>hT)gexTokenize()g^s<hodhdoesccnqeta-moagu
csle arren-me.
rw  </ulfibj
 whLegacyifts5_nokenaz ]rnokenaz ]s mea
*btdawgis)irmeio -DStV)gsPh legacyixCssV)iTokenaz r()hf d conf,tinsteadhoftxCssV)iTokenaz r_v2i).
rwsPh Tokenaz rraor em inaferessawgis)irmeio -DSteiorrlubjermayr*exuAtrieveesPh o -DStbotE xFeteTokenaz r()hfrctxFeteTokenaz r_v2i).
rwsPh SYNONYM SUPPORT
rwsPh   Cestomgnokenaz ]
 mayra soheu  ort synonym .hCbtsid-raayiaci ina hichha
 wh husa]i lshmsgnolquMAynfOr]atphrrci su hias "fuolyttlacM". U -DSnlup
 wh hbuilt-inaVokenaz ]
,MV)ggFTS5tquMAyn'fuolyt+ttlacM'twillematchtins atc s
 wh  pst"fuolyttlacM"i ledinaV)ggdocen-meetet,tbuo[setealCNTnativenfOrms
 wh  su hias "1lyttlacM". IibsomMeahosiso*etCs,tissw*enenbtdbetCNT tohmatch
 wh  aLuoins atc sepso"fuolyttlacM"iise"1lyttlacM"sawgardlla
 pso hichhfOrm
ano cteRhusa]iseA_zsimeeinaV)ggMATCH quMAynt-xt.
rwsPh   T)ere nyebteeMAalewaysitohahoroachhtiishingFTS5:ibjibje  <ol><li>hBynmapp-DSnalgssynonym  tohaytaohecttoken.hIMtV)isscrci,rusapGibje           V)ggabov eexaor r,b iishmeans t)attV)e nokenaz ] rets ispV)g
bje           sVmehtokengfOr]iaputs "fuoly"nanS "1ly". SayrteathtokengisiinsPh            fac< "fuoly",ssxo iattwitnnV)Reusa]iiacirtsaV)ggdocen-mee"Isw*nsPh            1lyttlacM"s-meAi ssfrtdadds  toomeRhindex fisetokens "i",s"w*n",sPh            "fuoly"nanS "tlacM". IfaV)ggucirntetnnquMAi ssfise'1lyt+ttlacM',sPh            meRhtokenaz ] eubstitu)isp"fuoly"nfise"1ly"hfrctteRequMAyn orkssPh            assexpe<tde.
rwsPh       <li>hBynquMAyapGnmeRhindex fisealgssynonym  psoeachgquMAynt-rm
ano c         sethee] gi.hIMtV)isscrci,rwitnnVokenazapGnquMAynt-xt,pV)g
bje           tokenaz ] maistrovlsebmr Siplm synonym  fiseaysaohectt-rm
ano c          ledinaV)ggdocen-me.hFTS5ttetnnquMAi ssmeRhindex fiseeach
ano c         synonymliadivlsuLlly.tFiseexaor r, faciLewled V)ggquMAy:ibjibje  <immebu
ckfibj     ... MATCH 'fuolyttlacM'</immebu
ckfibjsPh            meRhtokenaz ] offNTstbotE "1ly"hfrct"fuoly"nas synonym  fiseV)g
bje           fuolyttokenginaV)ggMATCH quMAynand FTS5 effNctivelynrunsSahquMAy
ano c         similaT]to:ibjibje  <immebu
ckfibj     ... MATCH '(fuolytOR 1ly)ttlacM'</immebu
ckfibjsPh            -xcep* guat, fortV)e purpos sepsoauxiliary f d confs, V)ggquMAy
ano c         stilleappearsSnoocban Ssrjea
*twohphrrcist- "(fuolytOR 1ly)"
ano c         beigu tssV)iLeassa saohectphrrci.
rwsPh       <li>hBynadeiDSnmr Siplm synonym  fiseaysaohectt-rm nooV)ggFTSSindex.
rwo c         U -DSnluishms<hod,rwitnnVokenazapGndocen-meet-xt, meRhtokenaz ]
rwo c         trovlsesnmr Siplm synonym  fiseeachhtoken. Sxo iattwitnna
rwo c         docen-meetu hias "Isw*n fuolyttlacM"iishtokenaz e,s-meAi ssfrtsPh            adds  toomeRhFTSSindexnfise"i",s"w*n", "fuoly",s"1ly"hfrcsPh            "tlacM".ibjsPh            T)ishway,s-vengifaV)ggnokenaz ]tdoesccnqetrovlsebsynonym 
ano c          itnnVokenazapGnquMAynt-xt (ithsh*enencnqe-etohdossxow*enenbt
ano c         etsffici-me),tissdoesn'ttmat</roifaV)ggucirnquMAi ssfis
ano c         'fuolyt+ttlacM'tise'1lyt+ttlacM',sashV)gre nyeb-meAi ssinaV)g
 wh           FTSSindexncorawspCtdigu noobotE fOrms pstt)etfuolyttoken.
rw   </olfibj
 wh hWheorrluissiththesapGndocen-meeornquMAynt-xt,papye|algstooxTokene iat
 wh  seA_zsimssa <i>tflSgs</i>harren-meswled V)ggFTS5_TOKEN_COLOCATED bitxbje sith|btsid-rs  tooeu  siha synonymlfortV)e previoushtoken. Fiseexaor r,
ano c hencphesapGnV)ggdocen-mee"Isw*n fuolyttlacM",oadtokenaz ]tguatttu  orts
 wh  synonym ow*enen|algsxToken() 5ttim s,hasoaiLu
ns:ibjibje  <immebu
ckfibj      sxToken(pCtx,h0,h"i",ssssssssssssssssssssss1,ss0,h 1);xbje      xToken(pCtx,h0,h"w*n",                    3,  2,  5);xbje      xToken(pCtx,h0,h"fuoly",ssssssssssssssssss5,ss6, 11);xbje      xToken(pCtx,hFTS5_TOKEN_COLOCATED,s"1ly", 3,  6, 11);xbje      xToken(pCtx,h0,h"tlacM",osssssssssssssssss5,s12, 17);xbj</immebu
ckfibjsPh   IesiscaadeAaisetooeeA_zsyMV)ggFTS5_TOKEN_COLOCATED flSgtt)etfuolyttie 
bje  xToken() isscrrtme. Mr Siplm synonym  mayr*exseA_zsimeeforhaytaohecttoken
 wh hbytma--DSnmr Siplm calgsrnolxToken(FTS5_TOKEN_COLOCATED) iibswquetc .
 wh hT)gr)tithnohlimiC tohtQems rol bpstsynonym  tuattmayr*exprovls esfisef
ano ctaohecttoken.ibjsPh   InSmapye|acis,bms<hodh(1)gabov eiyu itdbestdahoroach.hIC doesccnqeaddsPh   -xtraoed fdtoomeRhFTSSindexnOr]uAquiiehFTS5ttolquMAynfOr]mr Siplm t-rms,
ano csouissithsffici-metin t-rmsbpstdiskxseacMranSxquMAynseAme. Howwvl ,bitxbje sdoesccnqeeu  ort prefixhquMAi ssvMAyn ell. If,hasosuggest seabov ,pV)g
bje  tokeng"fuoly"niyusubstitu)idnfise"1ly"hbytlup tokenaz ],htetnnV)ggquMAy:ibjibje  <immebu
ckfibj     ... MATCH '1s*'</immebu
ckfibjsPh   willecnqematchtdocen-me  tuattcban Ssrluehtokeng"1ly"h(ashV)ggtokenaz ]
rwo cwilleprolablyecnqemapg"1l" tohany prefixhpso"fuoly").
rwsPh   Fisefu"g prefixheu  ort,bms<hodh(3)tmayr*exprefNTree.hIMtV)isscrci,
 wh hbe|aucismeRhindex aCan Sssg-meAi ssfisebotE "fuoly"nanS "1ly",dprefixsPh   quMAi sstu hias 'fu*'tise'1l*'twillematchtcorawcAab. Howwvl ,bbe|aucisPh   -xtrao-meAi ssfrtdadds  toomeRhFTSSindex,nluishms<hod uciscmM tospacm
ano   ledinaV)ggdd fbrci.
rw
ano  Ms<hodh(2) offNTsta midtaetC betweoho(1)gandh(3). U -DSnluishms<hod,
 wh  axquMAynsu hias '1l*'twillematchtdocen-me  tuattcban Ssrluehlitlral
bje  tokeng"1ly",dbuo[sete"fuoly"n(assum-DSnlup tokenaz ]tithseteabectto
bje  trovlsebsynonym hfOr]prefixes). Howwvl ,baccnn-prefixhquMAyhlikee'1ly'
rwo cwillematchtag Ssstn"1ly"hfrct"fuoly".hT)ish^s<hodhdoesccnqeuAquiiesPh   -xtraoeiskxseacM,hasono -xtrao-meAi ssfrtdadds  toomeRhFTSSindex.
 wh hOsrluehptrrl hanS,tissmayruAquiiehmM toCPU cyclmsgnolruneMATCH quMAi s,
 wh  as sethee]  quMAi ssofomeRhFTSSindexnaresawquiiedefiseeachgsynonym.
rw
ano  Wetnnus-DSnms<hods (2) orh(3),tissithim ortan* guattV)e tokenaz ] only
 wh  trovlsebsynonym hwitnnVokenazapGndocen-meet-xt (ms<hodh(3))eornquMAysPh   t-xt (ms<hodh(2)),hcnqebotE. Doigueso willecnqe|aucisapyeeAaiss,dbuo[issPh   insffici-mer
r*xeypeSya stsuctmFts5Tokenaz rrFts5Tokenaz r;aeypeSya stsuctmfts5_nokenaz ]_v2rfts5_nokenaz ]_v2;
stsuctmfts5_nokenaz ]_v2r{x retC iVl soth;             /whCexn*hAgihalwaysi2 b*xa  eten(*xCssV)i)(Ifls*,r|bts treAP **azArg, etennArg, Fts5Tokenaz rr**ppOut);x rIflsn(*xDsle] )(Fts5Tokenaz r*);x reten(*xTokenaz )(Fts5Tokenaz r*,
     rIflsn*pCtx,
     retenflSgs,            /whMaskxofoFTS5_TOKENIZE_*nflSgs b*x r r  |bts treAP *pText,retennText,x r r  |bts treAP *pL
csle, etennL
csle,
     reten(*xToken)(
        Iflsn*pCtx,hhhhhhhhh/whCbpygofp2tdnarren-mestooxTokenize() b*x r r   retentflSgs,         /whMaskxofoFTS5_TOKEN_*nflSgs b*x r r    |bts treAP *pToken, /whPaetCNT tohbuffNT]|btt SsapGMVokengb*x r r   retennToken,         /whSrzSsofolokenginaby] sgb*x r r   reteniSmfrt,         /whBy] dofftetsofolokeng ledinaiaput t-xtgb*x r r   reteniEnde           /whBy] dofftetsofoendeosnlokeng ledinaiaput t-xtgb*x r r  )x  );x};xasesPh Neweimmedsh*enehusaot)ggfts5_nokenaz ]_v2rVypettohdsaetslnokenaz ]
 whior em inaferes. T)etfoLu
napGMVypetishincludsdefiselegacyiahosiso*etCs
 whguattttilleusaoier
r*xeypeSya stsuctmfts5_nokenaz ]rfts5_nokenaz ];
stsuctmfts5_nokenaz ]r{x retC (*xCssV)i)(Ifls*,r|bts treAP **azArg, etennArg, Fts5Tokenaz rr**ppOut);x rIflsn(*xDsle] )(Fts5Tokenaz r*);x reten(*xTokenaz )(Fts5Tokenaz r*,
     rIflsn*pCtx,
     retenflSgs,            /whMaskxofoFTS5_TOKENIZE_*nflSgs b*x r r  |bts treAP *pText,retennText,
     reten(*xToken)(
        Iflsn*pCtx,hhhhhhhhh/whCbpygofp2tdnarren-mestooxTokenize() b*x r r   retentflSgs,         /whMaskxofoFTS5_TOKEN_*nflSgs b*x r r    |bts treAP *pToken, /whPaetCNT tohbuffNT]|btt SsapGMVokengb*x r r   retennToken,         /whSrzSsofolokenginaby] sgb*x r r   reteniSmfrt,         /whBy] dofftetsofolokeng ledinaiaput t-xtgb*x r r   reteniEnde           /whBy] dofftetsofoendeosnlokeng ledinaiaput t-xtgb*x r r  )x  );x};xa
sehFlSgs tuattmayr*exphmodesashV)ggteirdtarren-mettooxTokenize() b*x#SyaetslFTS5_TOKENIZE_QUERY     0x0001x#SyaetslFTS5_TOKENIZE_PREFIX    0x0002x#SyaetslFTS5_TOKENIZE_DOCUMENT  0x0004x#SyaetslFTS5_TOKENIZE_AUX       0x0008a
sehFlSgs tuattmayr*exphmodesbytlup tokenaz ]taor em inafereoethebtooFTS5
 whashV)ggteirdtarren-mettoomeRheu  si esxTokeneaartethe. b*x#SyaetslFTS5_TOKEN_COLOCATED    0x0001      /whSVmehposiconfiasoprev.MVokengb*xasesPh END OF CUSTOM TOKENIZERS
rwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww/

/wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
ru FTS5tEXTENSIONhREGISTRATIONhbje
r*xeypeSya stsuctmfts5_apirfts5_api;
stsuctmfts5_apim{x retC iVl soth;                   /whCexn*hAgihalwaysitetstop3 b*xa  /whCssV)iMamsewntokenaz ]tb*x reten(*xCssV)iTokenaz r)(
    fts5_apim*pApi,
    |bts treAP *zNVme,
    Iflsn*pUcirDd f,x r rfts5_nokenaz ]r*pTokenaz ],
    Iflsn(*xDsstsoy)(Ifls*)
  );xa rsehFupdianhMxistapGMVokenaz ]tb*x reten(*xFeteTokenaz r)(
    fts5_apim*pApi,
    |bts treAP *zNVme,
    Iflsn**ppUcirDd f,x r rfts5_nokenaz ]r*pTokenaz ]
  );xa rsehCssV)iMamsewnauxiliary f d conftb*x reten(*xCssV)iF d conf)(
    fts5_apim*pApi,
    |bts treAP *zNVme,
    Iflsn*pUcirDd f,x r rfts5_exten
rnf_f d conf xF d conf,
    Iflsn(*xDsstsoy)(Ifls*)
  );xa rsehbje ybel
n V)istpaetC nyebonlybavailSl ohefbiVl soth>=3nb*xa  /whCssV)iMamsewntokenaz ]tb*x reten(*xCssV)iTokenaz r_v2)(
    fts5_apim*pApi,
    |bts treAP *zNVme,
    Iflsn*pUcirDd f,x r rfts5_nokenaz ]_v2r*pTokenaz ],
    Iflsn(*xDsstsoy)(Ifls*)
  );xa rsehFupdianhMxistapGMVokenaz ]tb*x reten(*xFeteTokenaz r_v2)(
    fts5_apim*pApi,
    |bts treAP *zNVme,
    Iflsn**ppUcirDd f,x r rfts5_nokenaz ]_v2r**ppTokenaz ]
  );x};xasesPh END OF REGISTRATIONhbje
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr*xa#ifSya __cplusplus
} rsehendeosnleRh'extern "C"' bu
ck b*x#endif
x#endifrseh_FTS5_H w/

/wwwwwwww Endeosnfts5.h rrrrrrrrr*x#endifrsehSLFORD3_H w/
           