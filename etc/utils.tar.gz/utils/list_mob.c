
#include <stdio.h>

#include "structs.h"

#define FILE_NAME "tinyworld.mob"
#define FALSE 0
#define TRUE 1

struct char_data *read_mobile(int nr, int type);

int main()
{
	struct char_data mob; 
	mob = *read_mobile(int nr, int type);
}

/* read a mobile from MOB_FILE */
struct char_data *read_mobile(int nr, int type)
{
	int i;
	struct char_data *mob;
	long tmp, tmp2, tmp3;
	char letter;
	int level, level2, level3, abil, class;
	char buf[256];
	extern struct spell_info_type spell_info[];
	int r_num;

	i = nr;
	if (type == VIRTUAL) {
        r_num = real_mobile(nr);
        if (r_num < 0) {
            snprintf(buf, sizeof(buf), "read_mobile: Invalid virtual number %d. Mobile not loaded.", nr);
            mudlog(buf);
            return(0);
        }
    } else {
        r_num = nr;
    }

	fseek(mob_f, mob_index[r_num].pos, 0); // nr 대신 r_num 사용
	CREATE(mob, struct char_data, 1);
	clear_char(mob);

	/***** String data *** */
	mob->player.name = fread_string(mob_f);
	mob->player.short_descr = fread_string(mob_f);
	mob->player.long_descr = fread_string(mob_f);
	mob->player.description = fread_string(mob_f);
	mob->player.title = 0;

	/* *** Numeric data *** */
	fscanf(mob_f, "%ld ", &tmp);
	mob->specials.act = tmp;
	SET_BIT(mob->specials.act, ACT_ISNPC);

	fscanf(mob_f, " %ld ", &tmp);
	mob->specials.affected_by = tmp;

	fscanf(mob_f, " %ld \n", &tmp);
	mob->specials.alignment = tmp;

	/* set mob's class */
	fscanf(mob_f, " %c ", &letter);
	switch (letter) {
	case 'M':
		GET_CLASS(mob) = CLASS_MAGIC_USER;
		break;
	case 'C':
		GET_CLASS(mob) = CLASS_CLERIC;
		break;
	case 'T':
		GET_CLASS(mob) = CLASS_THIEF;
		break;
	case 'W':
		GET_CLASS(mob) = CLASS_WARRIOR;
		break;
	default:
		/* random selection */
		GET_CLASS(mob) = number(1, 4);
	}
	class = GET_CLASS(mob);

	/* set mob's level */
	fscanf(mob_f, " %ld ", &tmp);
	level = MIN(43, tmp);
	level2 = level * level;
	level3 = level2 * level;

	GET_LEVEL(mob) = level;

	/* level dependent data */
	abil = level / 4 + 5;
	switch (class) {
	case CLASS_MAGIC_USER:
		mob->abilities.str = number(abil >> 1, abil);
		mob->abilities.str_add = 0;
		mob->abilities.intel = number(abil, 18);
		mob->abilities.wis = number(abil, 17);
		mob->abilities.dex = number(abil >> 1, abil);
		mob->abilities.con = number(abil >> 1, abil);
		break;
	case CLASS_CLERIC:
		mob->abilities.str = number(abil >> 1, abil);
		mob->abilities.str_add = 0;
		mob->abilities.intel = number(abil, 17);
		mob->abilities.wis = number(abil, 18);
		mob->abilities.dex = number(abil >> 1, abil);
		mob->abilities.con = number(abil >> 1, abil);
		break;
	case CLASS_THIEF:
		mob->abilities.str = number(abil, 18);
		mob->abilities.str_add = 0;
		mob->abilities.intel = number(abil >> 1, abil);
		mob->abilities.wis = number(abil >> 1, abil);
		mob->abilities.dex = number(abil, 18);
		mob->abilities.con = number(abil, 17);
		break;
	case CLASS_WARRIOR:
		mob->abilities.str = 18;
		mob->abilities.str_add = number(1, MAX(abil << 3, 100));
		mob->abilities.intel = number(abil >> 1, abil);
		mob->abilities.wis = number(abil >> 1, abil);
		mob->abilities.dex = number(abil, 17);
		mob->abilities.con = number(abil, 18);
		break;
	}

	mob->points.mana = mob->points.max_mana =
	    number(level2, level * mob->abilities.wis * mob->abilities.intel);
	mob->points.move = mob->points.max_move =
	    number(level2, level * mob->abilities.dex * mob->abilities.dex);

	/* set hit */
	fscanf(mob_f, " %ld ", &tmp);
	if (tmp < 2) {		/* tmp == 1 */
		mob->points.hit = mob->points.max_hit =
		    number(level3, mob_bal_hit[level - 1][0]);
	} else if (tmp > 20) {
		mob->points.hit = mob->points.max_hit =
		    number(mob_bal_hit[level - 1][19], level3 * tmp);
	} else {		/* 1 < tmp <= 20 */
		mob->points.hit = mob->points.max_hit =
		    number(mob_bal_hit[level - 1][tmp - 2], mob_bal_hit[level - 1][tmp - 1]);
	}

	/* set armor */
	fscanf(mob_f, " %ld ", &tmp);
	if (tmp < 2) {		/* tmp == 1 */
		tmp2 = 100 - mob_bal_ac[level - 1][0];
		mob->points.armor = 100 - number(level, tmp2);
	} else if (tmp > 20) {	/* tmp > 20 */
		tmp2 = 100 - mob_bal_ac[level - 1][19];
		mob->points.armor = 100 - number(tmp2, level * tmp);
	} else {		/* 1 < tmp <= 20 */
		tmp2 = 100 - mob_bal_ac[level - 1][tmp - 2];
		tmp3 = 100 - mob_bal_ac[level - 1][tmp - 1];
		mob->points.armor = 100 - number(tmp2, tmp3);
	}

	/* set hitroll */
	fscanf(mob_f, " %ld ", &tmp);
	if (tmp < 2) {		/* tmp == 1 */
		mob->points.hitroll = number(level, mob_bal_hr[level - 1][0]);
	} else if (tmp > 20) {
		mob->points.hitroll =
		    number(mob_bal_hr[level - 1][19], level * tmp);
	} else {		/* 1 < tmp <= 20 */
		mob->points.hitroll =
		    number(mob_bal_hr[level - 1][tmp - 2], mob_bal_hr[level -
			   1][tmp - 1]);
	}

	/* set damdice */
	mob->specials.damnodice = number(level / 3, level / 2) + 1;
	mob->specials.damsizedice = number(level / 4, level / 3) + 1;

	/* set damroll */
	fscanf(mob_f, " %ld \n", &tmp);
	if (tmp < 2) {		/* tmp == 1 */
		mob->points.damroll = number(level, mob_bal_dr[level - 1][0]);
	} else if (tmp > 20) {
		mob->points.damroll =
		    number(mob_bal_dr[level - 1][19], level * tmp);
	} else {		/* 1 < tmp <= 20 */
		mob->points.damroll =
		    number(mob_bal_dr[level - 1][tmp - 2], mob_bal_dr[level - 1][tmp - 1]);
	}

	/* set gold */
	fscanf(mob_f, " %ld ", &tmp);
	mob->points.gold = tmp;

	/* set XP */
	fscanf(mob_f, " %ld ", &tmp);
	if (tmp < 2) {		/* tmp == 1 */
		mob->points.exp = number(level3, mob_bal_exp[level - 1][0]);
	} else if (tmp > 20) {
		mob->points.exp =
		    number(mob_bal_exp[level - 1][19], level3 * level * tmp / 10);
	} else {		/* 1 < tmp <= 20 */
		mob->points.exp =
		    number(mob_bal_exp[level - 1][tmp - 2], mob_bal_exp[level - 1][tmp - 1]);
	}

	/* set position */
	fscanf(mob_f, " %ld ", &tmp);
	mob->specials.default_pos = mob->specials.position = tmp;

	/* set sex */
	fscanf(mob_f, " %c \n", &letter);
	switch (letter) {
	case 'N':
		mob->player.sex = 0;
		break;
	case 'M':
		mob->player.sex = 1;
		break;
	case 'F':
		mob->player.sex = 2;
		break;
	default:
		mob->player.sex = number(0, 2);
	}

	mob->player.guild = 0;
	mob->player.pk_num = 0;
	mob->player.pked_num = 0;

	mob->player.weight = number(100, 200);
	mob->player.height = number(100, 200);

	for (i = 0; i < 3; i++)
		GET_COND(mob, i) = -1;

	mob->specials.apply_saving_throw[SAVING_PARA] =
	    100 - number(GET_LEVEL(mob) >> 1, GET_LEVEL(mob));
	mob->specials.apply_saving_throw[SAVING_PETRI] =
	    100 - number(GET_LEVEL(mob) >> 1, GET_LEVEL(mob));
	mob->specials.apply_saving_throw[SAVING_BREATH] =
	    100 - number(GET_LEVEL(mob) >> 1, GET_LEVEL(mob));

	switch (class) {
	case CLASS_MAGIC_USER:
	case CLASS_CLERIC:
		mob->specials.apply_saving_throw[SAVING_HIT_SKILL] =
		    100 - number(GET_LEVEL(mob) >> 1, GET_LEVEL(mob));
		mob->specials.apply_saving_throw[SAVING_SPELL] =
		    100 - number(GET_LEVEL(mob), GET_LEVEL(mob) << 1);
		break;
	case CLASS_THIEF:
	case CLASS_WARRIOR:
		mob->specials.apply_saving_throw[SAVING_HIT_SKILL] =
		    100 - number(GET_LEVEL(mob), GET_LEVEL(mob) << 1);
		mob->specials.apply_saving_throw[SAVING_SPELL] =
		    100 - number(GET_LEVEL(mob) >> 1, GET_LEVEL(mob));
		break;
	}

	mob->tmpabilities = mob->abilities;

	mob->player.time.birth = time(0);
	mob->player.time.played = 0;
	mob->player.time.logon = time(0);

	for (i = 0; i < MAX_WEAR; i++)	/* Initialisering Ok */
		mob->equipment[i] = 0;

	mob->nr = r_num; // nr에서 r_num으로 수정
	mob->desc = 0;

	for (i = 0; i < MAX_SKILLS; i++) {
		if (spell_info[i].min_level[class - 1] <= level) {
			mob->skills[i].learned
			    = (level > 40) ? 99 : number(level,
							 spell_info[i].max_skill[class
										 - 1]);
		} else {
			mob->skills[i].learned = 0;
		}
		// FiXME : level 60 balancing
		mob->skills[i].skilled = (level > 40) ? level : 0;
		mob->skills[i].recognise = 0;
	}

	if (level > 40)
		mob->regeneration = level << 4;
	else if (level > 35)
		mob->regeneration = level << 2;
	else
		mob->regeneration = level << 1;

	/* quest */
	mob->quest.type = 0;
	mob->quest.data = 0;
	mob->quest.solved = 0;

	/* insert in list */
	mob->next = character_list;
	character_list = mob;

	mob_index[r_num].number++; // nr에서 r_num으로 수정

    if (mob_index[r_num].virtual == SON_OGONG) // nr에서 r_num으로 수정
        son_ogong = mob;
    else if (mob_index[r_num].virtual == FOURTH_JANGRO) // nr에서 r_num으로 수정
		fourth_jangro = mob;

	mob->regened = 0;
	mob->specials.fighting = 0;

	return (mob);
}
